# ⚡ TurboFex v0.1.7
WhatsApp group management bot by **Nelson Fx** (Trinity Flow).

Type `!menu` to see all commands grouped by category.
`!menu group` shows one category with descriptions, `!menu kick` shows help for one command,
and `!list` shows every command with its description.

## Commands
- **General:** `!alive` `!list` `!menu` `!owner` `!ping` `!support`
- **Group:** `!add` `!admins` `!amute` `!antifake` `!antigm` `!antigstatus` `!antilink` `!antispam` `!antiword` `!aunmute` `!badword` `!close` `!demote` `!disappear` `!goodbye` `!gpp` `!groupinfo` `!hidetag` `!inactive` `!invite` `!kick` `!leave` `!lock` `!msgs` `!open` `!pdm` `!promote` `!requests` `!resetwarn` `!revoke` `!setdesc` `!setgoodbye` `!setname` `!setwelcome` `!tagall` `!unlock` `!warn` `!warnings` `!warnlimit` `!welcome`
- **Autoreply:** `!delgreet` `!filter` `!filters` `!getgreet` `!gfilter` `!gstop` `!pfilter` `!pstop` `!setgreet` `!stop`
- **Status:** `!autolikestatus` `!autosavestatus` `!autoviewstatus` `!gjids` `!gsend` `!gstatus` `!statusdelay` `!statusemoji` `!statusinfo` `!statusjid`
- **Watch:** `!antidelete` `!antiedit` `!autoviewonce` `!deletejid` `!editjid` `!viewoncejid`
- **Tools:** `!afk` `!age` `!base64` `!calc` `!convert` `!countdown` `!delete` `!fancy` `!hash` `!jid` `!password` `!poll` `!pp` `!qr` `!random` `!react` `!remind` `!reminders` `!reverse` `!schedule` `!schedules` `!time` `!unremind` `!unschedule` `!whois`
- **Fun:** `!8ball` `!choose` `!coin` `!compliment` `!dare` `!dice` `!joke` `!rate` `!ship` `!truth` `!wyr`
- **Games:** `!endgame` `!guess` `!hangman` `!mathquiz` `!rps` `!scramble` `!slots` `!tictactoe` `!trivia`
- **Budget:** `!budget` `!delbudget` `!expense` `!income` `!summary`
- **Media:** `!circle` `!mp3` `!photo` `!play` `!rotate` `!sticker`
- **Audio:** `!bass` `!chipmunk` `!deep` `!echo` `!fast` `!nightcore` `!rewind` `!slow` `!tremble`
- **Video:** `!compress` `!gif` `!mute` `!trim` `!vreverse`
- **Editor:** `!blur` `!brighten` `!contrast` `!flip` `!grey` `!invert` `!mirror` `!pixelate` `!sepia` `!sharpen`
- **Owner:** `!addsudo` `!autoupdate` `!backup` `!ban` `!block` `!delsudo` `!join` `!mode` `!repair` `!restart` `!setbio` `!setpp` `!setprefix` `!status` `!sudolist` `!unban` `!unblock` `!update`

Notes:
- Anti-link, anti-word, anti-spam, anti-fake, welcome and goodbye are OFF by default. Turn them on per group.
- Welcome/goodbye text can use `@user`, `{group}` and `{count}`.
- The bot must be a group admin to delete messages, remove people, and change group settings.
- Private mode (`!mode private`): only the owner can use commands.
- Auto-replies, AFK notices and tic-tac-toe moves work on normal messages (no prefix needed).
- Games use a lobby: the host starts one (e.g. `!trivia 8`), players type `join`, and after the countdown only the joined players can play. The host can type `start` to begin early, `quit` leaves. Add `solo` to play alone. Type `!endgame` to stop a game.
- `!mode private` only limits who can use commands; auto-replies, AFK notices and running games still work for everyone.
- Budget data is personal: use `!income`, `!expense` and `!summary` in a private chat with the bot.
- Change the prefix any time with `!setprefix .`
- Time zone for auto open/close: set `timezone` in `config.js` (default Africa/Johannesburg).

## Status and watchers (owner)
- `!autoviewstatus on`, `!autolikestatus on`, `!statusemoji ❤️ 🔥`, `!statusdelay 3 10` handle everybody's WhatsApp statuses.
- `!gjids` lists your groups with numbers; `!gstatus 3 Hello` posts a group status and `!gsend 3 Hello` a message, from any chat, no admin needed.
- `!antigstatus` and `!antigm` (group admins) stop group status posts and group mentions in a status.
- `!autoviewonce`, `!antidelete`, `!antiedit` keep copies of view-once, deleted and edited messages; `!viewoncejid`, `!deletejid`, `!editjid` choose where the copies go. Use these only for messages that were sent to you.

## Community and support
- 💬 Support group (Telegram): https://t.me/+7PwU2Vo9czE1NTRk
- 📣 Telegram channel: https://t.me/+e89lCBU2wLpjNWNk
- 🟢 WhatsApp channel: https://whatsapp.com/channel/0029VbDpuKM8qIzkoQscOE2w
- 💻 GitHub: https://github.com/nels0nfx/TurboFex

The bot sends a welcome message with these links to the owner when it connects for the first time. Type `!support` any time to see them again.

## Troubleshooting
- Console full of `Bad MAC` lines, or the bot stops answering: send `!repair` (clears old chat sessions, you stay logged in). Make sure the number is linked to only ONE running bot.
- `!status` shows the version, loaded commands and any problems.
- Stickers, `!mp3`, `!qr`, audio effects, video tools and picture effects use optional tools (sharp, ffmpeg, qrcode). If your server cannot install them, only those commands are affected.

## Updates
- `!update` checks for a new version, `!update now` installs it and restarts the bot.
- When the bot starts it also checks for updates by itself (turn off with `!autoupdate off`).
- If an update crashes the bot on start, the previous version is put back automatically.
- Your `config.js`, login (`session/`) and settings (`data/`) are never touched by updates.

### Publishing an update (bot author)
Upload the new `turbofex-latest.zip` to the main page of the GitHub repo
(Add file > Upload files > Commit). Every bot picks it up on its next check or restart.

## Setup on a Pterodactyl panel
1. Upload the zip in the panel's **Files** tab, then tap **Unarchive**.
2. Open `config.js` and fill in your numbers (country code, digits only, no +):
   - `ownerNumber` = your personal number
   - `pairingNumber` = the number the bot will run on
3. Make sure the server uses **Node.js 20 or newer** and runs `npm install` on start.
4. Press **Start**. The console shows a pairing code like `ABCD-1234`.
5. On the bot number's WhatsApp: **Settings > Linked devices > Link a device > Link with phone number instead**, then enter the code.
6. Add the bot to a group, make it admin, and send `!ping`.

## Notes
- Your login is saved in `session/`. Group settings and warnings are saved in `data/`. Don't delete them.
- Use a spare number for the bot, not your main one. Unofficial bots can get banned.
