# ⚡ TurboFex v0.1.2
WhatsApp group management bot by **Nelson Fx** (Trinity Flow).

Type `!menu` to see all commands grouped by category.
`!menu group` shows one category with descriptions, `!menu kick` shows help for one command,
and `!list` shows every command with its description.

## Commands
- **General:** `!alive` `!list` `!menu` `!owner` `!ping`
- **Group:** `!add` `!admins` `!amute` `!antifake` `!antilink` `!antispam` `!antiword` `!aunmute` `!badword` `!close` `!demote` `!disappear` `!goodbye` `!groupinfo` `!hidetag` `!inactive` `!invite` `!kick` `!leave` `!lock` `!msgs` `!open` `!pdm` `!promote` `!requests` `!resetwarn` `!revoke` `!setdesc` `!setgoodbye` `!setname` `!setwelcome` `!tagall` `!unlock` `!warn` `!warnings` `!warnlimit` `!welcome`
- **Autoreply:** `!filter` `!filters` `!gfilter` `!gstop` `!pfilter` `!pstop` `!stop`
- **Tools:** `!afk` `!calc` `!delete` `!fancy` `!jid` `!poll` `!pp` `!react` `!schedule` `!schedules` `!unschedule`
- **Fun:** `!8ball` `!choose` `!coin` `!compliment` `!dare` `!dice` `!joke` `!rate` `!ship` `!truth` `!wyr`
- **Games:** `!endgame` `!guess` `!hangman` `!mathquiz` `!rps` `!scramble` `!slots` `!tictactoe` `!trivia`
- **Budget:** `!budget` `!delbudget` `!expense` `!income` `!summary`
- **Owner:** `!addsudo` `!autoupdate` `!backup` `!ban` `!block` `!delsudo` `!join` `!mode` `!restart` `!setbio` `!setprefix` `!status` `!sudolist` `!unban` `!unblock` `!update`

Notes:
- Anti-link, anti-word, anti-spam, anti-fake, welcome and goodbye are OFF by default. Turn them on per group.
- Welcome/goodbye text can use `@user`, `{group}` and `{count}`.
- The bot must be a group admin to delete messages, remove people, and change group settings.
- Private mode (`!mode private`): only the owner can use commands.
- Auto-replies, AFK notices and tic-tac-toe moves work on normal messages (no prefix needed).
- Games are open to everybody, in groups and private chats, one game at a time per chat. Quiz games play several rounds by themselves (`!trivia 8`). Type `!endgame` to stop one.
- `!mode private` only limits who can use commands; auto-replies, AFK notices and running games still work for everyone.
- Budget data is personal: use `!income`, `!expense` and `!summary` in a private chat with the bot.
- Change the prefix any time with `!setprefix .`
- Time zone for auto open/close: set `timezone` in `config.js` (default Africa/Johannesburg).

## Updates
- `!update` checks for a new version, `!update now` installs it and restarts the bot.
- When the bot starts it also checks for updates by itself (turn off with `!autoupdate off`).
- If an update crashes the bot on start, the previous version is put back automatically.
- Your `config.js`, login (`session/`) and settings (`data/`) are never touched by updates.

### Publishing an update (bot author)
Upload the new `turbofex-latest.zip` to the main page of the GitHub repo
(Add file > Upload files > Commit). Every bot picks it up on its next check or restart.

## Setup on a Pterodactyl panel
1. Upload the zip in the panel's **Files** tab, then tap **Unarchive**.
2. Open `config.js` and fill in your numbers (country code, digits only, no +):
   - `ownerNumber` = your personal number
   - `pairingNumber` = the number the bot will run on
3. Make sure the server uses **Node.js 20 or newer** and runs `npm install` on start.
4. Press **Start**. The console shows a pairing code like `ABCD-1234`.
5. On the bot number's WhatsApp: **Settings > Linked devices > Link a device > Link with phone number instead**, then enter the code.
6. Add the bot to a group, make it admin, and send `!ping`.

## Notes
- Your login is saved in `session/`. Group settings and warnings are saved in `data/`. Don't delete them.
- Use a spare number for the bot, not your main one. Unofficial bots can get banned.
