# ⚡ TurboFex v0.0.10
WhatsApp group management bot by **Nelson Fx** (Trinity Flow).

Type `!menu` to see all commands grouped by category.
`!menu group` shows one category, `!menu kick` shows help for one command.

## Categories
- **General:** `!menu` `!ping`
- **Group:** `!groupinfo` `!tagall` `!kick` `!promote` `!demote` `!warn` `!warnings` `!resetwarn` `!warnlimit 5` `!antilink off/delete/warn/kick` `!open` `!close` `!welcome` `!setwelcome` `!goodbye` `!setgoodbye`
- **Owner:** `!mode public/private` `!update` `!update now` `!autoupdate on/off` `!restart`

Notes:
- Anti-link, welcome and goodbye are OFF by default. Turn them on per group.
- Welcome/goodbye text can use `@user`, `{group}` and `{count}`.
- The bot must be a group admin to delete links, remove people, and open/close the group.
- Private mode: only the owner can use commands.

## Updates
- `!update` checks for a new version, `!update now` installs it and restarts the bot.
- When the bot starts it also checks for updates by itself (turn off with `!autoupdate off`).
- Your `config.js`, login (`session/`) and settings (`data/`) are never touched by updates.

### Publishing an update (bot author)
Upload the new `turbofex-latest.zip` to the main page of the GitHub repo
(Add file > Upload files > Commit). Every bot picks it up on its next check or restart.

## Setup on a Pterodactyl panel
1. Upload the zip in the panel's **Files** tab, then tap **Unarchive**.
2. Open `config.js` and fill in your numbers (country code, digits only, no +):
   - `ownerNumber` = your personal number
   - `pairingNumber` = the number the bot will run on
3. Make sure the server uses **Node.js 20 or newer** and runs `npm install` on start.
4. Press **Start**. The console shows a pairing code like `ABCD-1234`.
5. On the bot number's WhatsApp: **Settings > Linked devices > Link a device > Link with phone number instead**, then enter the code.
6. Add the bot to a group, make it admin, and send `!ping`.

## Notes
- Your login is saved in `session/`. Group settings and warnings are saved in `data/`. Don't delete them.
- Use a spare number for the bot, not your main one. Unofficial bots can get banned.
