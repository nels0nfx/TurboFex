# ⚡ TurboFex v0.3.1

[![CI](https://github.com/nels0nfx/TurboFex/actions/workflows/ci.yml/badge.svg)](https://github.com/nels0nfx/TurboFex/actions/workflows/ci.yml)

WhatsApp group management and assistant bot by **Nelson Fx** (Trinity Flow). It runs on Node.js with the
[Baileys](https://github.com/WhiskeySockets/Baileys) library and is built to run for months without attention:
it reconnects by itself, backs up its login, updates itself safely and protects the server it runs on.

> Unofficial bots can get a number banned. Use a spare number for the bot, never your main one.

## Features
- **210+ commands** in 16 categories (group management incl. ranks and birthdays, security, lookup, status tools, games, media, audio/video/picture editing, budget, tools...). Send `.menu`.
- **Link previews:** every message with a link shows the preview card (picture, title, description).
- **Private by default.** Only the owner can use commands; everybody else gets no reply at all. `.mode public` opens it up.
- **Formatted replies.** Every command reply uses WhatsApp formatting (bold titles and labels, `▸` bullets, commands in monospace).
- **Safe in production:** server protection for heavy commands, safe self-update with automatic rollback, daily login backup, write-behind key store for fast replies.
- **Watchers:** auto view-once, anti-delete and anti-edit (also for the new sealed edits), auto view / like / save for statuses.
- **Reactions** (⏳ then ✅), **watermark** under results, **sticker credit**, **AFK** that tells each person once.

## Requirements
- Node.js **20 or newer**
- A WhatsApp number for the bot
- Optional tools (only the commands that need them are affected if missing): `sharp` (pictures), `ffmpeg` (audio/video), `qrcode`

## Quick start
1. Upload the files (or the release zip) to your host and unarchive them. On a Pterodactyl panel use the **Files** tab and **Unarchive**.
2. Open `config.js` and set `ownerNumber` (your personal number) and, optionally, `pairingNumber` (the bot's number). Country code, digits only, no `+`. Every setting can also be an environment variable.
3. Make sure the host runs `npm install`, then start it with `npm start`.
4. Link the bot (see below), add it to a group, make it admin, and send `.ping`.

### Linking the bot
Since **28 July 2026** WhatsApp links new devices differently and the WhatsApp library does not handle it. TurboFex handles it itself:
1. Start the bot with an **empty** `session/` folder. A **QR code** is drawn in the console (a pairing code is shown too when `pairingNumber` is set, but WhatsApp is refusing codes right now and the bot tells you when it does).
2. WhatsApp > **Linked devices** > **Link a device** and scan the QR (you need a second screen to show the console).
3. WhatsApp may ask for a refresh: the bot draws a **new QR**, scan that one as well.
4. The bot restarts once and prints `online as ...`.

If it fails, wait a few minutes (too many attempts are rate limited) and try again. A bot that is already linked is not affected.

## Configuration
| Setting (`config.js`) | Environment variable | Meaning |
|---|---|---|
| `ownerNumber` | `OWNER_NUMBER` | The boss of the bot |
| `pairingNumber` | `PAIRING_NUMBER` | The bot's own number (adds a pairing code to the QR) |
| `prefix` | `PREFIX` | Command prefix (default `.`; `.setprefix` changes it while running) |
| `timezone` | `TIMEZONE` | For the menu clock and auto open/close |
| | `BOT_BROWSER` | Device identity used when linking (`android` can receive view-once files) |
| | `FAST_KEYS=off` | Turns off the write-behind key store |
| | `RESTORE_LOGIN=1` | Start once to restore the login from the last backup |
| | `YTDLP_PATH`, `YTDLP_COOKIES` | Your own yt-dlp binary, a cookies.txt for YouTube |
| | `PLAY_MAX_MB`, `PLAY_MAX_SECONDS` | Limits for `.play` (default 60 MB / 60 min) |
| | `DL_MAX_MB`, `DL_MAX_SECONDS` | Limits for `.dl` videos (default 60 MB / 30 min) |
| | `TURBOFEX_DATA` | Folder for saved data (default `data/`) |

## Using the bot
- `.menu` shows the categories (alphabetical). `.menu group` shows one category, `.menu kick` shows help for one command, `.list` shows everything with descriptions.
- Anti-link, anti-word, anti-spam, anti-fake, welcome and goodbye are OFF by default and are turned on per group. The bot must be a group admin to delete messages, remove people and change group settings.
- Auto-replies, AFK notices, protections and running games still work in private mode; they are not commands.
- **AFK:** `.afk on lunch` stays on until `.afk off`. Everybody who writes to you or mentions you is told once per AFK session.
- **Reactions:** `.cmdreact on|smart|clean|off` (`smart` = only slow commands).
- **Watermark:** `.watermark on|off|text ...`, added under the result of media, audio, video and editor commands.
- **Sticker credit:** `.stickerpack My Pack | My Name` (default: bot name by Nelson Fx).
- **Status tools:** `.autoviewstatus on`, `.autolikestatus on`, `.statusemoji`, `.statusdelay`, `.statuslimit 200`, `.statusinfo`. WhatsApp only delivers the statuses of people saved as contacts on the bot's phone.
- **Watchers:** `.autoviewonce`, `.antidelete`, `.antiedit` plus `.viewoncejid`, `.deletejid`, `.editjid` for where copies go. `.vv` opens a view-once you reply to. Anti-edit and anti-delete only know messages the bot saw before they changed. Use these only for messages that were sent to you.
- **Security:** `.ratelimit 20` (commands per person per minute), `.anticall reject|block`, `.privacy` (bot account privacy), `.antipromote on` / `.antidemote on` (undo promotions and demotions made by anyone except the group creator and the bot owner, the bot must be admin), `.antimedia sticker on` (block stickers, images, videos, audio or documents), `.slowmode 10` (seconds between messages of a member).
- **Community:** `.rules` / `.setrules`, `.report <why>` (reply to a message: tags the admins), `.rank on` then `.rank` and `.top` (XP and levels for chatting), `.giveaway 2 prize`, `.setbirthday 25 Dec` and `.birthday on` (wishes at 08:00), `.feedback <message>` (to the owner, 3 a day per person).
- **Lookup:** `.weather <city>`, `.define <word>`, `.wiki <topic>`, `.currency 100 usd ngn`, `.translate fr <text>`. They use free public services (Open-Meteo, dictionaryapi.dev, Wikipedia, exchangerate-api.com, MyMemory) which can be slow or limit use.
- **Media and tools:** `.dl <link or name>` (video, up to 720p), `.take My Pack | Me` (new credit on a sticker), `.attp <text>` (text sticker), `.setgpp` (group picture), `.note` and `.todo` (private, in a private chat).
- **Owner:** `.stats` (usage and last errors), `.broadcast <text>` then `.broadcast confirm` (all groups, slowly, 100 at most), `.linkpreview on|off|test <link>`.
- **play:** `.play <name or link>` always sends audio (YouTube, TikTok, SoundCloud, Instagram and most other sites, through yt-dlp, downloaded automatically on first use). If YouTube blocks the server, send a `cookies.txt` with `.ytcookies`. Only download content you have the right to.
- **Server protection:** heavy commands are blocked with a clear message when a tool is missing, memory is low, the server is overloaded or too many run at once. `.server` shows the state, `.server guard off` disables it.

## Operating the bot
### Updates
- `.update` checks, `.update now` installs and restarts, and the bot checks at start (`.autoupdate off` to stop). After an update you get an "update complete" message; after a restart an "I am back" message with a short menu (`.restartmsg off` to silence restarts).
- A downloaded update is **validated before any file is replaced** (every file must compile, required files must exist, `package.json` must be valid). A broken zip is rejected and nothing changes.
- If a valid update still crashes the bot at start, the previous version is put back automatically.
- `config.js`, `session/` and `data/` are never touched by updates.

### Backups and cleanup
- A copy of the login is made a few minutes after connecting and then daily (last 3 kept) in `data/session-backup/`. It is never sent over WhatsApp. `.loginbackup` lists the copies, `.loginbackup now` makes one.
- If `session/` has files but `creds.json` is damaged, the last backup is restored at start. An empty `session/` means "link a fresh device". To restore on purpose start once with `RESTORE_LOGIN=1`. After WhatsApp logs the bot out the copies are deleted.
- Once a month encryption files of chats silent for 90+ days are removed (`.sessionclean` runs it now). The login itself is never touched.
- `.backup` saves the bot's settings.

### Troubleshooting
- Lots of `Bad MAC` lines, "Waiting for this message", or the bot stops answering: send `.repair` (clears chat sessions, you stay logged in). Make sure the number is linked to only ONE running bot.
- `.status` shows version, library version, loaded commands, watcher counters and problems. `.statusinfo` shows status counters and the like route.
- View-once files arrive empty on linked devices. Reply to them with `.vv`.

## Security
- **`session/` and `data/` hold the bot's login and private data. Never commit or share them.** The included `.gitignore` excludes them.
- Owner commands (`.block`, `.update`, `.restart`, `.loginbackup`...) are limited to the owner number; destructive ones to the main owner only.
- Update notes and links come from `update.json` (the repo to update from). Point it to your own repository if you fork this project.
- The bot only fetches PUBLIC web addresses (link previews, downloads, lookups): private, local and cloud-metadata addresses are refused, also after redirects.
- The bot name is part of the code: it cannot be changed from a panel setting, and editing `core/brand.js` stops the bot from starting.

## Development
```
npm test        # unit tests (no network, no WhatsApp, no install needed)
```
- `index.js` supervises `core/boot.js`; `whatsapp/` holds the connection, handler and features; `commands/` has one file per command (or a list of related ones); `core/` holds shared services (updater, backup, capacity guard...); `tests/` has the tests, which also run on every push (GitHub Actions).
- A command is `{ name, aliases?, category, description, run(ctx) }`. Optional: `ownerOnly`, `realOwnerOnly`, `adminOnly`, `groupOnly`, `botAdminRequired`, `slow`, `weight: 'light'|'medium'|'heavy'`, `needs: [...]`, `format: false`, `noReact`, `watermark`. The tests check names, aliases (no duplicates), categories and descriptions.
- Replies are formatted automatically (see `whatsapp/format.js`); write plain text and it comes out formatted, or write your own WhatsApp formatting and it is left alone.
- **Publishing an update:** bump `version` in `package.json`, add notes at the top of `changelog.txt`, run `npm test`, then upload the new `turbofex-latest.zip` to the main page of the GitHub repo. Every bot picks it up on its next check or restart.

## Community and support
- 💬 Support group (Telegram): https://t.me/+7PwU2Vo9czE1NTRk
- 📣 Telegram channel: https://t.me/+e89lCBU2wLpjNWNk
- 🟢 WhatsApp channel: https://whatsapp.com/channel/0029VbDpuKM8qIzkoQscOE2w
- 💻 GitHub: https://github.com/nels0nfx/TurboFex
