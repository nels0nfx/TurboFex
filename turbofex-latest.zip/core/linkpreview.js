// Link previews (the card with a picture, title and description under a link). The WhatsApp library only makes them when
// an optional package is installed, which is why no message ever showed one. This makes them itself: it reads the page's
// title, description and picture (Open Graph tags) from the public web, and shrinks the picture to a small thumbnail.
const safefetch = require('./safefetch');

const URL_RE = /(https?:\/\/[^\s<>"']+|www\.[^\s<>"']+\.[a-z]{2,}[^\s<>"']*)/i;
const BUDGET_MS = 3500; // a message is never held back longer than this for its preview
const cache = new Map(); // url -> { at, value }

function firstUrl(text) {
  const m = URL_RE.exec(String(text || ''));
  if (!m) return null;
  const matched = m[0].replace(/[)\].,;:!?]+$/, '');
  return { matched, url: /^https?:/i.test(matched) ? matched : `https://${matched}` };
}

const ENTITIES = { amp: '&', lt: '<', gt: '>', quot: '"', apos: "'", nbsp: ' ' };
const decode = (s) =>
  String(s || '')
    .replace(/&#x([0-9a-f]+);/gi, (_, h) => String.fromCodePoint(parseInt(h, 16)))
    .replace(/&#(\d+);/g, (_, d) => String.fromCodePoint(parseInt(d, 10)))
    .replace(/&([a-z]+);/gi, (m, n) => ENTITIES[n.toLowerCase()] ?? m)
    .replace(/\s+/g, ' ')
    .trim();

// the title, description and picture of a web page
function parseMeta(html) {
  const head = String(html).slice(0, 300000);
  const meta = {};
  for (const m of head.matchAll(/<meta\s+([^>]*?)\/?>/gi)) {
    const attrs = {};
    for (const a of m[1].matchAll(/([a-zA-Z:_-]+)\s*=\s*(?:"([^"]*)"|'([^']*)')/g)) attrs[a[1].toLowerCase()] = a[2] ?? a[3] ?? '';
    const key = (attrs.property || attrs.name || '').toLowerCase();
    if (key && attrs.content !== undefined && !(key in meta)) meta[key] = attrs.content;
  }
  const t = /<title[^>]*>([\s\S]*?)<\/title>/i.exec(head);
  return {
    title: decode(meta['og:title'] || meta['twitter:title'] || (t && t[1]) || ''),
    description: decode(meta['og:description'] || meta['twitter:description'] || meta.description || '').slice(0, 300),
    image: meta['og:image'] || meta['og:image:url'] || meta['twitter:image'] || meta['twitter:image:src'] || '',
    canonical: meta['og:url'] || '',
  };
}

let sharpLib;
function loadSharp() {
  if (sharpLib === undefined) {
    try {
      sharpLib = require('sharp');
    } catch (err) {
      sharpLib = null;
    }
  }
  return sharpLib;
}

// a small JPEG thumbnail (WhatsApp wants about 100-300 px and a few KB)
async function thumbnail(buf) {
  const sharp = loadSharp();
  if (sharp) {
    try {
      return await sharp(buf, { failOn: 'none' }).resize({ width: 300, height: 300, fit: 'cover' }).jpeg({ quality: 55 }).toBuffer();
    } catch (err) {
      return null;
    }
  }
  return buf.length > 2 && buf[0] === 0xff && buf[1] === 0xd8 && buf.length <= 40000 ? buf : null; // without sharp only a small JPEG can be used as it is
}

async function build(found, fetchOpts) {
  const page = await safefetch.get(found.url, { ...fetchOpts, timeout: 3000, maxBytes: 400 * 1024, headers: { Accept: 'text/html,application/xhtml+xml,image/*;q=0.8' } });
  if (page.status >= 400) return null;
  const type = String(page.headers['content-type'] || '').toLowerCase();
  if (type.startsWith('image/')) {
    const jpeg = await thumbnail(page.body);
    return jpeg ? { 'canonical-url': page.url, 'matched-text': found.matched, title: new URL(page.url).hostname, description: '', jpegThumbnail: jpeg } : null;
  }
  if (!/html|xml/.test(type)) return null;
  const meta = parseMeta(page.body.toString('utf8'));
  if (!meta.title && !meta.description) return null;
  let jpeg = null;
  if (meta.image) {
    try {
      const img = await safefetch.get(new URL(meta.image, page.url).href, { ...fetchOpts, timeout: 3000, maxBytes: 2.5 * 1024 * 1024, headers: { Accept: 'image/*' } });
      if (img.status < 400 && /^image\//i.test(String(img.headers['content-type'] || 'image/'))) jpeg = await thumbnail(img.body);
    } catch (err) {
      jpeg = null; // a preview without a picture is still a preview
    }
  }
  return { 'canonical-url': meta.canonical || page.url, 'matched-text': found.matched, title: meta.title || new URL(page.url).hostname, description: meta.description, ...(jpeg ? { jpegThumbnail: jpeg } : {}) };
}

// text -> the preview information WhatsApp needs, or undefined (no link / no preview possible). Never throws.
async function getUrlInfo(text, fetchOpts = {}) {
  const found = firstUrl(text);
  if (!found) return undefined;
  const hit = cache.get(found.url);
  if (hit && Date.now() - hit.at < (hit.value ? 3600000 : 300000)) return hit.value ? { ...hit.value, 'matched-text': found.matched } : undefined;
  let value = null;
  try {
    value = await Promise.race([build(found, fetchOpts), new Promise((r) => setTimeout(() => r(null), BUDGET_MS))]);
  } catch (err) {
    value = null;
  }
  if (cache.size > 300) cache.clear();
  cache.set(found.url, { at: Date.now(), value });
  return value || undefined;
}

module.exports = { getUrlInfo, firstUrl, parseMeta, decode, cache };
