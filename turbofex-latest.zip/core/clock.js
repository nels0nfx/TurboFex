// Time helpers. The time zone comes from (in order): TIMEZONE variable, config.js "timezone", or Johannesburg.
const config = require('../config');

function zone() {
  const z = process.env.TIMEZONE || config.timezone || 'Africa/Johannesburg';
  try {
    new Intl.DateTimeFormat('en-GB', { timeZone: z });
    return z;
  } catch (err) {
    return 'UTC';
  }
}

function parts(date = new Date()) {
  const timeZone = zone();
  const fmt = (locale, opts) => new Intl.DateTimeFormat(locale, { timeZone, ...opts }).format(date);
  return {
    zone: timeZone,
    time: fmt('en-US', { hour: 'numeric', minute: '2-digit', hour12: true }),
    day: fmt('en-GB', { weekday: 'long' }),
    date: fmt('en-GB', { day: 'numeric', month: 'short', year: 'numeric' }),
    hhmm: fmt('en-GB', { hour: '2-digit', minute: '2-digit', hourCycle: 'h23' }),
  };
}

// "6:30" -> "06:30", anything invalid -> null
function parseHHMM(text) {
  const m = /^([01]?\d|2[0-3]):([0-5]\d)$/.exec(String(text || '').trim());
  return m ? `${m[1].padStart(2, '0')}:${m[2]}` : null;
}

// 3725 seconds -> "1h 2m"
function uptime(seconds = process.uptime()) {
  const s = Math.floor(seconds);
  const d = Math.floor(s / 86400);
  const h = Math.floor((s % 86400) / 3600);
  const m = Math.floor((s % 3600) / 60);
  if (d) return `${d}d ${h}h ${m}m`;
  if (h) return `${h}h ${m}m`;
  return `${m}m ${s % 60}s`;
}

module.exports = { zone, parts, parseHHMM, uptime };
