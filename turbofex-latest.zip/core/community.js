// The community fund: everybody puts coins in a shared pot. When the goal is reached, every donor gets back 125% of what he put in,
// and the whole group earns +15% for one hour (a "community boom"). One pot at a time per group, the goal grows after each success.
const jsonstore = require('./jsonstore');
const economy = require('./economy');
const quests = require('./quests');

const js = jsonstore.open('community', { groups: {} });
const HOUR = 3600000;
const RULES = { startGoal: 5000, growth: 1.5, maxGoal: 200000, min: 50, payback: 1.25, boost: 1.15, boostMs: HOUR, minDonors: 3 };

const stateOf = (group) => js.data.groups[group] || (js.data.groups[group] = { goal: RULES.startGoal, total: 0, donors: {}, boostUntil: 0, done: 0 });

function info(group, now = Date.now()) {
  const G = stateOf(group);
  return { goal: G.goal, total: G.total, donors: Object.values(G.donors), boostLeft: Math.max(0, G.boostUntil - now), done: G.done };
}

// puts coins in the pot. Returns { ok, reached, payouts }
function donate(group, jid, amount, now = Date.now()) {
  const G = stateOf(group);
  if (!Number.isInteger(amount) || amount < RULES.min) return { ok: false, why: 'min', min: RULES.min };
  const room = G.goal - G.total;
  const n = room > 0 ? Math.min(amount, room) : amount; // nobody puts in more than the pot still needs (when it is full but has too few donors, more people can still join)
  if (economy.inDebt(jid)) return { ok: false, why: 'debt' };
  if (!economy.take(jid, n)) return { ok: false, why: 'poor', wallet: economy.balance(jid) };
  const key = economy.keyOf(jid);
  const d = G.donors[key] || (G.donors[key] = { jid, coins: 0 });
  d.coins += n;
  G.total += n;
  const quest = quests.note(quests.track(group, jid, 'donate'));
  let reached = false;
  let payouts = [];
  if (G.total >= G.goal && Object.keys(G.donors).length >= RULES.minDonors) {
    reached = true;
    payouts = Object.values(G.donors).map((x) => ({ jid: x.jid, coins: x.coins, back: Math.round(x.coins * RULES.payback) }));
    for (const p of payouts) economy.add(p.jid, p.back);
    const reachedGoal = G.goal;
    G.boostUntil = now + RULES.boostMs;
    G.done += 1;
    G.goal = Math.min(RULES.maxGoal, Math.round(G.goal * RULES.growth));
    G.total = 0;
    G.donors = {};
    js.touch();
    return { ok: true, put: n, reached, payouts, goal: reachedGoal, quest };
  }
  js.touch();
  return { ok: true, put: n, reached, total: G.total, goal: G.goal, donors: Object.keys(G.donors).length, quest, capped: n < amount };
}

const boostLeft = (group, now = Date.now()) => Math.max(0, (js.data.groups[group]?.boostUntil || 0) - now);
economy.addBoost((group) => (boostLeft(group) > 0 ? RULES.boost : 1));

module.exports = { RULES, info, donate, boostLeft };
