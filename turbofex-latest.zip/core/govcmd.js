// What people type for the Governor (used by "governor" and "gov"): run, vote, candidates, salary, resign, sale, feecut, veto, audit
const governor = require('./governor');
const throne = require('./throne');
const economy = require('./economy');
const quests = require('./quests');
const { resolveTarget, num } = require('../whatsapp/utils');

const fmt = economy.fmt;
const tag = (jid) => `@${num(jid)}`;
const dur = (ms) => {
  const m = Math.max(1, Math.ceil(ms / 60000));
  if (m < 60) return `${m}m`;
  const h = Math.floor(m / 60);
  return h < 48 ? `${h}h ${m % 60}m` : `${Math.floor(h / 24)}d ${h % 24}h`;
};
const SUBS = ['run', 'candidate', 'campaign', 'vote', 'candidates', 'election', 'salary', 'resign', 'sale', 'feecut', 'veto', 'audit', 'governor'];
const R = governor.RULES;

async function panel(ctx) {
  const { jid, reply, prefix, myJid } = ctx;
  const i = governor.info(jid);
  const lines = ['🏛️ *Governor*'];
  if (i.gov) {
    lines.push(`*Governor:* ${tag(i.gov.jid)} • term ends in ${dur(i.gov.until - Date.now())}`, `*Salary:* ${i.salary} coins an hour${governor.isGovernor(jid, myJid) ? ` • waiting: ${fmt(i.waiting)}` : ''}`);
  } else {
    lines.push(i.ended ? `*The term of ${tag(i.ended.jid)} is over.*` : '*There is no governor.*');
  }
  if (i.el) {
    lines.push('', `🗳️ *Election is open* – ends in ${dur(i.el.end - Date.now())}`, ...i.el.cands.map((c, n) => `${n + 1}. ${tag(c.jid)} – ${c.votes} vote${c.votes === 1 ? '' : 's'}`), `_${i.el.total} voted. At least ${R.minVotes} votes are needed._`, `▸ \`${prefix}governor vote @name\` • \`${prefix}governor run\` (${R.fee} coins)`);
  } else if (!i.gov) {
    lines.push('', `▸ \`${prefix}governor run\` – stand for election (${R.fee} coins). It opens the vote for ${dur(R.voteMs)}.`);
  }
  if (i.gov) {
    const on = (k) => (i.laws[k] ? `✅ ${dur(i.laws[k])} left` : 'off');
    lines.push('', `*What the governor can do*`, `▸ \`${prefix}governor sale\` – shop 20% cheaper for ${dur(R.sale.ms)} (${R.sale.cost} coins) • ${on('sale')}`, `▸ \`${prefix}governor feecut\` – market fees halved for ${dur(R.feecut.ms)} (${R.feecut.cost}) • ${on('feecut')}`, `▸ \`${prefix}governor veto\` – stops the king's tax for ${dur(R.veto.ms)} (${R.veto.cost}) • ${on('veto')}`, `▸ \`${prefix}governor audit @user\` – see somebody's money (${R.audit.cost})`, `▸ \`${prefix}governor salary\` • \`${prefix}governor resign\``);
  }
  lines.push('', '_The king is bought with coins, the governor is voted by the group. A king cannot be the governor._');
  return reply(lines.join('\n'), { mentions: [i.gov?.jid, ...(i.el ? i.el.cands.map((c) => c.jid) : [])].filter(Boolean) });
}

async function handle(ctx, sub) {
  const { jid, args, reply, myJid, msg, prefix } = ctx;
  if (!sub || ['panel', 'info', 'governor'].includes(sub)) return panel(ctx);
  if (sub === 'candidates' || sub === 'election') return panel(ctx);
  if (sub === 'run' || sub === 'candidate' || sub === 'campaign') {
    const r = governor.run(jid, myJid);
    if (!r.ok) {
      const m = { term: `🏛️ *There is a governor already:* ${r.gov ? tag(r.gov.jid) : ''} for another ${dur((r.until || 0) - Date.now())}.`, king: '👑 *A king cannot also be the governor.*', already: '✅ *You are already a candidate.*', poor: `⚠️ *Standing for election costs ${R.fee} coins.* You have ${fmt(r.wallet || 0)}.` }[r.why];
      return reply(m || '⚠️ *That did not work.*', { mentions: r.gov ? [r.gov.jid] : [] });
    }
    return reply(`🗳️ *${tag(myJid)} is a candidate for Governor!*\n${r.started ? `The vote is open for *${dur(R.voteMs)}*.` : `The vote ends in *${dur(r.end - Date.now())}*.`} Everybody can vote with \`${prefix}governor vote @${num(myJid)}\`.\n_At least ${R.minVotes} votes are needed. The winner gets all the candidates' fees as a campaign fund._`, { mentions: [myJid] });
  }
  if (sub === 'vote') {
    const target = resolveTarget(msg, args.slice(1));
    if (!target) return reply(`🗳️ *Usage:* \`${prefix}governor vote @candidate\``);
    const r = governor.vote(jid, myJid, target);
    if (!r.ok) return reply(r.why === 'none' ? `🗳️ *There is no election now.* Start one with \`${prefix}governor run\`.` : `⚠️ *${tag(target)} is not a candidate.* See \`${prefix}governor\``, { mentions: [target] });
    const q = quests.note(quests.track(jid, myJid, 'vote'));
    return reply(`🗳️ *Your vote ${r.changed ? 'was changed to' : 'goes to'} ${tag(target)}.*${q ? `\n\n${q}` : ''}`, { mentions: [target] });
  }
  if (sub === 'salary') {
    const r = governor.collect(jid, myJid);
    if (!r.ok) return reply(r.why === 'notgov' ? '⚠️ *Only the governor can collect the salary.*' : '⏳ *Nothing to collect yet.*');
    return reply(`💼 *Salary collected:* +${fmt(r.amount)} coins\n*Wallet:* ${fmt(economy.balance(myJid))}`);
  }
  if (sub === 'resign') {
    const r = governor.resign(jid, myJid);
    if (!r.ok) return reply('⚠️ *Only the governor can resign.*');
    return reply(`🏛️ *${tag(myJid)} resigned as governor.*${r.paid ? ` The last salary (${fmt(r.paid)}) was paid.` : ''}\n_A new election can start with_ \`${prefix}governor run\``, { mentions: [myJid] });
  }
  if (sub === 'sale' || sub === 'feecut' || sub === 'veto') {
    const r = governor.law(jid, myJid, sub);
    if (!r.ok) {
      const m = { notgov: '⚠️ *Only the governor can do this.*', notax: '👑 *The king has set no tax,* there is nothing to veto.', active: `ℹ️ *It is already in force* for another ${dur(r.left || 0)}.`, wait: `⏳ *Too soon.* Again in ${dur(r.waitMs || 0)}.`, poor: `⚠️ *It costs ${fmt(r.cost || 0)} coins.* You have ${fmt(r.wallet || 0)}.` }[r.why];
      return reply(m || '⚠️ *That did not work.*');
    }
    const text = { sale: `🛍️ *SHOP SALE!* Everything in the shop is *20% cheaper* for ${dur(r.ms)}. \`${prefix}shop\``, feecut: `📉 *FEE HOLIDAY!* Market fees are *halved* for ${dur(r.ms)}. Good time to trade: \`${prefix}picks\``, veto: `🛑 *VETO!* The governor stopped the king's tax for ${dur(r.ms)}.` }[sub];
    return reply(`${text}\n_The governor paid ${fmt(r.cost)} coins._`);
  }
  if (sub === 'audit') {
    const target = resolveTarget(msg, args.slice(1));
    if (!target) return reply(`🔎 *Usage:* \`${prefix}governor audit @user\` (${R.audit.cost} coins)`);
    const r = governor.audit(jid, myJid, target);
    if (!r.ok) return reply(r.why === 'notgov' ? '⚠️ *Only the governor can audit.*' : r.why === 'wait' ? `⏳ *The auditors are busy.* Again in ${dur(r.waitMs || 0)}.` : `⚠️ *An audit costs ${R.audit.cost} coins.*`);
    return reply(`🔎 *Audit of ${tag(target)}*\n*Wallet:* ${fmt(r.coins)}\n*Bank:* ${fmt(r.bank)}\n*Invested:* ${r.invested === null ? 'not in the market' : fmt(Math.round(r.invested))}\n*Reputation:* ${r.rep} ⭐${r.bounty ? `\n*Bounty on him:* ${fmt(r.bounty)}` : ''}${r.title ? `\n*Title:* ${r.title}` : ''}\n_Paid ${fmt(r.cost)} coins._`, { mentions: [target] });
  }
  return panel(ctx);
}

module.exports = { SUBS, handle, panel };
