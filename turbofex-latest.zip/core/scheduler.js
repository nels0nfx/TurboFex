// Runs timed jobs once a minute: automatic group open/close and scheduled messages
const clock = require('./clock');
const store = require('../whatsapp/store');

let timer = null;
let lastKey = '';

async function tick(sock) {
  const p = clock.parts();
  const key = `${p.date} ${p.hhmm}`;
  if (key === lastKey) return; // already handled this minute
  lastKey = key;

  const jobs = [];
  store.forEachGroup((jid, g) => {
    if (g.autoMute.mute === p.hhmm) jobs.push({ jid, mode: 'announcement', text: '🔒 Group closed automatically. Only admins can send messages.' });
    if (g.autoMute.unmute === p.hhmm) jobs.push({ jid, mode: 'not_announcement', text: '🔓 Group opened automatically. Everyone can send messages.' });
  });

  // Scheduled messages (!schedule)
  for (const item of [...store.schedules()]) {
    if (item.time !== p.hhmm) continue;
    try {
      await sock.sendMessage(item.jid, { text: item.text });
    } catch (err) {
      console.log(`Scheduled message ${item.id} failed: ${err.message}`);
    }
    if (item.once) store.removeSchedule(item.id);
  }

  for (const job of jobs) {
    try {
      await sock.groupSettingUpdate(job.jid, job.mode);
      await sock.sendMessage(job.jid, { text: job.text });
    } catch (err) {
      console.log(`Scheduled job failed for ${job.jid}: ${err.message}`);
    }
  }
}

function start(sock) {
  stop();
  timer = setInterval(() => tick(sock).catch((e) => console.error('Scheduler error:', e.message)), 20000);
}

function stop() {
  if (timer) clearInterval(timer);
  timer = null;
}

module.exports = { start, stop, tick };
