// The throne: one person is King of the group. Anybody can take the throne by paying its price. The old king gets most of
// it back (so being dethroned is a profit), the rest of the coins are gone. The price goes up when somebody takes the throne
// and slides down by itself every hour. A king earns coins every hour for as long as he keeps the throne.
const jsonstore = require('./jsonstore');
const economy = require('./economy');

const js = jsonstore.open('throne', { groups: {} });

const RULES = {
  base: 500, raise: 1.25, decayPerHour: 0.96, payback: 0.7, incomePerHour: 100, storeHours: 24, decreeMax: 100,
  maxTax: 5, // the king's tax on jobs and daily, in % (the bot owner can change the limit)
  feastMin: 300, feastCooldownMs: 3 * 3600000, feastBonus: 0.1, feastMinPeople: 3, feastMax: 15, activeMs: 3600000,
  jailCost: 400, jailMs: 30 * 60000, jailCooldownMs: 2 * 3600000,
  peaceCost: 600, peaceMs: 12 * 3600000, peaceCooldownMs: 24 * 3600000, // "peace law": nobody can rob
  holidayCost: 1000, holidayMs: 2 * 3600000, holidayCooldownMs: 12 * 3600000, holidayBoost: 1.25, // "bank holiday": everybody earns more
};
const HOUR = 3600000;

const stateOf = (group) => js.data.groups[group] || (js.data.groups[group] = { king: null, price: RULES.base, at: 0, since: 0, collected: 0, decree: '' });
// ---- the income of a king (coins an hour): the owner can set it for one group or for all groups
const incomeOf = (G) => (Number.isFinite(G.income) ? G.income : Number.isFinite(js.data.income) ? js.data.income : RULES.incomePerHour);
const maxTaxOf = () => (Number.isFinite(js.data.maxTax) ? js.data.maxTax : RULES.maxTax);
function setIncome(group, n) {
  // what the king already earned at the old rate is kept, then the new rate starts
  const list = group ? [stateOf(group)] : Object.values(js.data.groups);
  const now = Date.now();
  for (const G of list) {
    if (G.king) {
      G.stash = Math.min(incomeOf(G) * RULES.storeHours, waiting(G, now));
      G.collected = now;
    }
    if (group) G.income = n;
  }
  if (!group) {
    js.data.income = n;
    for (const G of Object.values(js.data.groups)) delete G.income;
  }
  js.touch();
}
function resetIncome(group) {
  if (group) delete stateOf(group).income;
  else {
    delete js.data.income;
    for (const G of Object.values(js.data.groups)) delete G.income;
  }
  js.touch();
}
function setMaxTax(n) {
  js.data.maxTax = n;
  for (const G of Object.values(js.data.groups)) if ((G.tax || 0) > n) G.tax = n;
  js.touch();
}
const incomeInfo = (group) => {
  const G = group ? stateOf(group) : null;
  return { global: Number.isFinite(js.data.income) ? js.data.income : null, group: G && Number.isFinite(G.income) ? G.income : null, now: G ? incomeOf(G) : Number.isFinite(js.data.income) ? js.data.income : RULES.incomePerHour, base: RULES.incomePerHour };
};
// what it costs now: the price slides down every hour, never under the base price
const priceNow = (G, now) => Math.max(RULES.base, Math.round(G.price * Math.pow(RULES.decayPerHour, Math.max(0, now - G.at) / HOUR)));
const waiting = (G, now) => (G.king ? (G.stash || 0) + Math.floor((Math.min(RULES.storeHours * HOUR, Math.max(0, now - G.collected)) / HOUR) * incomeOf(G)) : 0);
const wallet = (group, jid) => economy.runIn(group, () => economy.balance(jid));

function info(group, now = Date.now()) {
  const G = stateOf(group);
  return { king: G.king, since: G.since, price: priceNow(G, now), waiting: waiting(G, now), decree: G.decree, rules: RULES, income: incomeOf(G), tax: G.tax || 0, maxTax: maxTaxOf(), jailed: Object.keys(G.jail || {}).filter((k) => G.jail[k].until > now).length, peace: lawLeft(group, 'peace', now), holiday: lawLeft(group, 'holiday', now) };
}

function take(group, jid, now = Date.now()) {
  const G = stateOf(group);
  const key = economy.keyOf(jid);
  if (G.king && G.king.key === key) return { ok: false, why: 'already' };
  if (economy.runIn(group, () => economy.inDebt(jid))) return { ok: false, why: 'debt' };
  const price = priceNow(G, now);
  if (wallet(group, jid) < price) return { ok: false, why: 'poor', price, wallet: wallet(group, jid) };
  if (!economy.runIn(group, () => economy.take(jid, price))) return { ok: false, why: 'poor', price, wallet: wallet(group, jid) };
  const prev = G.king;
  let prevGot = 0;
  let prevIncome = 0;
  if (prev) {
    prevIncome = waiting(G, now); // what the old king earned is paid out to him
    prevGot = Math.floor(price * RULES.payback);
    economy.runIn(group, () => economy.add(prev.jid, prevGot + prevIncome));
  }
  G.king = { jid, key };
  G.price = Math.round(price * RULES.raise);
  G.at = now;
  G.since = now;
  G.collected = now;
  G.stash = 0;
  G.decree = '';
  G.tax = 0;
  G.jail = {};
  js.touch();
  return { ok: true, price, prev, prevGot, prevIncome, next: G.price, burned: price - prevGot, wallet: wallet(group, jid) };
}

function collect(group, jid, now = Date.now()) {
  const G = stateOf(group);
  if (!G.king || G.king.key !== economy.keyOf(jid)) return { ok: false, why: 'notking' };
  const n = waiting(G, now);
  if (n < 1) return { ok: false, why: 'nothing' };
  G.collected = now;
  G.stash = 0;
  economy.runIn(group, () => economy.add(jid, n));
  js.touch();
  return { ok: true, amount: n, wallet: wallet(group, jid) };
}

function decree(group, jid, text) {
  const G = stateOf(group);
  if (!G.king || G.king.key !== economy.keyOf(jid)) return { ok: false, why: 'notking' };
  const t = String(text || '').replace(/\s+/g, ' ').trim().slice(0, RULES.decreeMax);
  if (!t) return { ok: false, why: 'empty' };
  G.decree = t;
  js.touch();
  return { ok: true, decree: t };
}


// ---- what a king can do to the people of the group
// the tax: a share of what people earn from jobs and daily goes to the king
function setTax(group, jid, pct) {
  const G = stateOf(group);
  if (!G.king || G.king.key !== economy.keyOf(jid)) return { ok: false, why: 'notking' };
  const n = Math.round(Number(pct) * 10) / 10;
  if (!Number.isFinite(n) || n < 0 || n > maxTaxOf()) return { ok: false, why: 'range', max: maxTaxOf() };
  G.tax = n;
  js.touch();
  return { ok: true, tax: n };
}
// who chatted lately (the feast is shared among them)
function seen(group, jid, now = Date.now()) {
  if (!group || !jid) return;
  const G = stateOf(group);
  const R = G.recent || (G.recent = {});
  R[economy.keyOf(jid)] = { jid, at: now };
  const keys = Object.keys(R);
  if (keys.length > 200) for (const k of keys) if (now - R[k].at > RULES.activeMs) delete R[k];
}
// the royal feast: the king pays, the people who chatted in the last hour share it (with a small bonus from the crown)
function feast(group, jid, amount, now = Date.now()) {
  const G = stateOf(group);
  const key = economy.keyOf(jid);
  if (!G.king || G.king.key !== key) return { ok: false, why: 'notking' };
  if (!(amount >= RULES.feastMin)) return { ok: false, why: 'min', min: RULES.feastMin };
  const wait = (G.feastAt || 0) + RULES.feastCooldownMs - now;
  if (wait > 0) return { ok: false, why: 'wait', waitMs: wait };
  const guests = Object.values(G.recent || {}).filter((r) => now - r.at < RULES.activeMs && economy.keyOf(r.jid) !== key).sort((a, b) => b.at - a.at).slice(0, RULES.feastMax);
  if (guests.length < RULES.feastMinPeople) return { ok: false, why: 'quiet', have: guests.length, need: RULES.feastMinPeople };
  if (wallet(group, jid) < amount) return { ok: false, why: 'poor', wallet: wallet(group, jid) };
  economy.runIn(group, () => economy.take(jid, amount));
  const each = Math.floor((amount * (1 + RULES.feastBonus)) / guests.length);
  for (const g of guests) economy.runIn(group, () => economy.add(g.jid, each));
  G.feastAt = now;
  js.touch();
  return { ok: true, each, guests: guests.map((g) => g.jid), amount };
}
// the king sends somebody to jail for a short time: no gambling and no robbing
function jail(group, jid, target, now = Date.now()) {
  const G = stateOf(group);
  const key = economy.keyOf(jid);
  if (!G.king || G.king.key !== key) return { ok: false, why: 'notking' };
  const tk = economy.keyOf(target);
  if (tk === key) return { ok: false, why: 'self' };
  const wait = (G.jailAt || 0) + RULES.jailCooldownMs - now;
  if (wait > 0) return { ok: false, why: 'wait', waitMs: wait };
  if (wallet(group, jid) < RULES.jailCost) return { ok: false, why: 'poor', wallet: wallet(group, jid) };
  economy.runIn(group, () => economy.take(jid, RULES.jailCost));
  if (!G.jail) G.jail = {};
  G.jail[tk] = { until: now + RULES.jailMs, jid: target };
  G.jailAt = now;
  js.touch();
  return { ok: true, until: now + RULES.jailMs, cost: RULES.jailCost };
}

// ---- government: free somebody, free everybody, a peace law and a bank holiday
function unjail(group, jid, target, now = Date.now()) {
  const G = stateOf(group);
  if (!G.king || G.king.key !== economy.keyOf(jid)) return { ok: false, why: 'notking' };
  const tk = economy.keyOf(target);
  if (!G.jail || !G.jail[tk] || G.jail[tk].until <= now) return { ok: false, why: 'free' };
  delete G.jail[tk];
  js.touch();
  return { ok: true };
}
function amnesty(group, jid, now = Date.now()) {
  const G = stateOf(group);
  if (!G.king || G.king.key !== economy.keyOf(jid)) return { ok: false, why: 'notking' };
  const jailed = Object.values(G.jail || {}).filter((j) => j.until > now);
  if (!jailed.length) return { ok: false, why: 'none' };
  G.jail = {};
  js.touch();
  return { ok: true, freed: jailed.map((j) => j.jid) };
}
// a law that costs the king coins and lasts for a while: kind = 'peace' | 'holiday'
function law(group, jid, kind, now = Date.now()) {
  const G = stateOf(group);
  if (!G.king || G.king.key !== economy.keyOf(jid)) return { ok: false, why: 'notking' };
  const cost = RULES[`${kind}Cost`];
  const L = G.laws || (G.laws = {});
  const cur = L[kind] || { until: 0, at: 0 };
  if (cur.until > now) return { ok: false, why: 'active', left: cur.until - now };
  const wait = cur.at + RULES[`${kind}CooldownMs`] - now;
  if (wait > 0) return { ok: false, why: 'wait', waitMs: wait };
  if (wallet(group, jid) < cost) return { ok: false, why: 'poor', wallet: wallet(group, jid), cost };
  economy.runIn(group, () => economy.take(jid, cost));
  L[kind] = { at: now, until: now + RULES[`${kind}Ms`] };
  js.touch();
  return { ok: true, cost, until: L[kind].until };
}
const lawLeft = (group, kind, now = Date.now()) => Math.max(0, ((js.data.groups[group]?.laws || {})[kind]?.until || 0) - now);
const jailLeft = (group, key, now = Date.now()) => Math.max(0, ((stateOf(group).jail || {})[key]?.until || 0) - now);
const jailedList = (group, now = Date.now()) => Object.values(stateOf(group).jail || {}).filter((j) => j.until > now);
const isKing = (group, jid) => {
  const G = js.data.groups[group];
  return !!(G && G.king && G.king.key === economy.keyOf(jid));
};

// the coin module asks us for the tax and the jail
economy.setHooks({
  tax: (group, key, gross) => {
    const G = js.data.groups[group];
    if (!G || !G.king || !G.tax || G.king.key === key) return null;
    return { tax: Math.floor((gross * G.tax) / 100), to: G.king.jid };
  },
  jail: (group, key) => (js.data.groups[group] ? jailLeft(group, key) : 0),
  king: (group, key) => !!(js.data.groups[group]?.king && js.data.groups[group].king.key === key),
  peace: (group) => lawLeft(group, 'peace'),
  boost: (group) => (lawLeft(group, 'holiday') > 0 ? RULES.holidayBoost : 1),
});

module.exports = { RULES, info, take, collect, decree, setIncome, resetIncome, setMaxTax, incomeInfo, setTax, seen, feast, jail, jailedList, unjail, amnesty, law, lawLeft, jailLeft, isKing };

