// The throne: one person is King of the group. Anybody can take the throne by paying its price. The old king gets most of
// it back (so being dethroned is a profit), the rest of the coins are gone. The price goes up when somebody takes the throne
// and slides down by itself every hour. A king earns coins every hour for as long as he keeps the throne.
const jsonstore = require('./jsonstore');
const economy = require('./economy');

const js = jsonstore.open('throne', { groups: {} });

const RULES = { base: 500, raise: 1.25, decayPerHour: 0.96, payback: 0.7, incomePerHour: 100, storeHours: 24, decreeMax: 100 };
const HOUR = 3600000;

const stateOf = (group) => js.data.groups[group] || (js.data.groups[group] = { king: null, price: RULES.base, at: 0, since: 0, collected: 0, decree: '' });
// what it costs now: the price slides down every hour, never under the base price
const priceNow = (G, now) => Math.max(RULES.base, Math.round(G.price * Math.pow(RULES.decayPerHour, Math.max(0, now - G.at) / HOUR)));
const waiting = (G, now) => (G.king ? Math.floor((Math.min(RULES.storeHours * HOUR, Math.max(0, now - G.collected)) / HOUR) * RULES.incomePerHour) : 0);
const wallet = (group, jid) => economy.runIn(group, () => economy.balance(jid));

function info(group, now = Date.now()) {
  const G = stateOf(group);
  return { king: G.king, since: G.since, price: priceNow(G, now), waiting: waiting(G, now), decree: G.decree, rules: RULES };
}

function take(group, jid, now = Date.now()) {
  const G = stateOf(group);
  const key = economy.keyOf(jid);
  if (G.king && G.king.key === key) return { ok: false, why: 'already' };
  if (economy.runIn(group, () => economy.inDebt(jid))) return { ok: false, why: 'debt' };
  const price = priceNow(G, now);
  if (wallet(group, jid) < price) return { ok: false, why: 'poor', price, wallet: wallet(group, jid) };
  if (!economy.runIn(group, () => economy.take(jid, price))) return { ok: false, why: 'poor', price, wallet: wallet(group, jid) };
  const prev = G.king;
  let prevGot = 0;
  let prevIncome = 0;
  if (prev) {
    prevIncome = waiting(G, now); // what the old king earned is paid out to him
    prevGot = Math.floor(price * RULES.payback);
    economy.runIn(group, () => economy.add(prev.jid, prevGot + prevIncome));
  }
  G.king = { jid, key };
  G.price = Math.round(price * RULES.raise);
  G.at = now;
  G.since = now;
  G.collected = now;
  G.decree = '';
  js.touch();
  return { ok: true, price, prev, prevGot, prevIncome, next: G.price, burned: price - prevGot, wallet: wallet(group, jid) };
}

function collect(group, jid, now = Date.now()) {
  const G = stateOf(group);
  if (!G.king || G.king.key !== economy.keyOf(jid)) return { ok: false, why: 'notking' };
  const n = waiting(G, now);
  if (n < 1) return { ok: false, why: 'nothing' };
  G.collected = now;
  economy.runIn(group, () => economy.add(jid, n));
  js.touch();
  return { ok: true, amount: n, wallet: wallet(group, jid) };
}

function decree(group, jid, text) {
  const G = stateOf(group);
  if (!G.king || G.king.key !== economy.keyOf(jid)) return { ok: false, why: 'notking' };
  const t = String(text || '').replace(/\s+/g, ' ').trim().slice(0, RULES.decreeMax);
  if (!t) return { ok: false, why: 'empty' };
  G.decree = t;
  js.touch();
  return { ok: true, decree: t };
}

module.exports = { RULES, info, take, collect, decree };
