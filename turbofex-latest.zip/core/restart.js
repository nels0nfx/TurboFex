// Exit code 42 tells index.js: "start me again"
const RESTART_CODE = 42;

function restartBot(delayMs = 2000) {
  setTimeout(() => process.exit(RESTART_CODE), delayMs);
}

module.exports = { RESTART_CODE, restartBot };
