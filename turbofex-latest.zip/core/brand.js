// The bot's name. Changing it here renames it everywhere, and updates carry the change to everyone.
module.exports = {
  botName: 'TurboFex',
  creator: 'Nelson Fx',
};
