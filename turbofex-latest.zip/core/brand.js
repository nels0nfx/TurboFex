// The bot's name and links. Changing them here changes them everywhere, and updates carry the change to everyone.
module.exports = {
  botName: 'TurboFex',
  creator: 'Nelson Fx',
  links: {
    telegramSupport: 'https://t.me/+7PwU2Vo9czE1NTRk',
    telegramChannel: 'https://t.me/+e89lCBU2wLpjNWNk',
    whatsappChannel: 'https://whatsapp.com/channel/0029VbDpuKM8qIzkoQscOE2w',
    github: 'https://github.com/nels0nfx/TurboFex',
  },
};
