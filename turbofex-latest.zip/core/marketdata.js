// The fixed facts of the market: the moods, the made-up companies and coins, the properties and businesses, the news.
// Nothing here is saved. Numbers for price moves are "percent per price update" (an update is every 30 minutes).

// ---- moods. hours: how long a mood lasts. inflation: the yearly inflation rate shown (a random number in the range).
// bond: what a bond pays per day (%). pay: job pay (work, fish, hunt, mine). biz: profit of businesses. rent: rent of properties.
const MOODS = {
  boom: { name: 'Boom', icon: '🚀', hours: [4, 6], inflation: [3, 6], bond: 0.3, pay: 1.2, biz: 1.2, rent: 1.1 },
  stable: { name: 'Stable', icon: '⚖️', hours: [4, 6], inflation: [2, 4], bond: 0.5, pay: 1.0, biz: 1.0, rent: 1.0 },
  recession: { name: 'Recession', icon: '📉', hours: [4, 6], inflation: [1, 3], bond: 0.8, pay: 0.85, biz: 0.8, rent: 0.9 },
  inflation: { name: 'Inflation', icon: '🔥', hours: [4, 6], inflation: [10, 18], bond: 0.4, pay: 0.95, biz: 0.9, rent: 1.0 },
  crash: { name: 'Crash', icon: '💥', hours: [3, 4], inflation: [0, 2], bond: 1.0, pay: 0.7, biz: 0.6, rent: 0.75 },
};
const MOOD_IDS = Object.keys(MOODS);

// what the next mood can be (chance of each, "stay the same" is not an option: every shift is news)
const NEXT = {
  boom: { stable: 0.4, inflation: 0.25, recession: 0.06, crash: 0.05 },
  stable: { boom: 0.35, inflation: 0.2, recession: 0.15, crash: 0.03 },
  recession: { stable: 0.35, inflation: 0.15, boom: 0.12, crash: 0.08 },
  inflation: { stable: 0.35, recession: 0.25, boom: 0.1, crash: 0.05 },
  crash: { stable: 0.4, recession: 0.35, inflation: 0.1, boom: 0.08 },
};

// ---- the assets. fx = the average move per update in each mood (%), vol = the random swing per update (%),
// k = how strongly the price is pulled back to its normal level. drop / rise = the most it can fall / rise in 24 hours
// (this is the crash protection: no portfolio of stocks can lose more than 12% in a day, a portfolio of coins 25%).
const stock = (id, name, sector, icon, base, vol, risk, fx) => ({ id, name, sector, icon, kind: 'stock', base, vol, risk, fx, k: 0.008, drop: 0.12, rise: 0.2 });
const coin = (id, name, icon, base, vol, risk, fx) => ({ id, name, sector: 'crypto', icon, kind: 'coin', base, vol, risk, fx, k: 0.004, drop: 0.25, rise: 0.5 });
const fx = (boom, stable, recession, inflation, crash) => ({ boom, stable, recession, inflation, crash });

const STOCKS = [
  stock('NCOM', 'Naijacom Telecom', 'telecom', '📡', 120, 0.5, 'low', fx(0.1, 0.02, -0.05, -0.05, -0.2)),
  stock('UTB', 'UnityTrust Bank', 'bank', '🏦', 85, 0.7, 'medium', fx(0.25, 0.03, -0.2, 0.15, -0.5)),
  stock('FARM', 'GreenAcre Farms', 'agri', '🌾', 40, 0.6, 'low', fx(0.05, 0.03, 0, 0.2, -0.1)),
  stock('TECH', 'TurboTech', 'tech', '💻', 250, 1.2, 'high', fx(0.45, 0.02, -0.35, -0.25, -0.9)),
  stock('OIL', 'PetroLink Oil', 'oil', '🛢️', 150, 1.0, 'high', fx(0.25, 0, -0.3, 0.35, -0.55)),
  stock('MOVE', 'SwiftMove Logistics', 'transport', '🚚', 60, 0.8, 'medium', fx(0.3, 0.02, -0.25, -0.35, -0.6)),
  stock('CARE', 'CareFirst Pharma', 'pharma', '💊', 95, 0.4, 'low', fx(0.05, 0.03, 0.05, 0, -0.05)),
  stock('BUILD', 'BuildRite Cement', 'build', '🏗️', 70, 0.9, 'medium', fx(0.4, 0.02, -0.3, -0.2, -0.65)),
  stock('MART', 'MegaMart Retail', 'retail', '🛒', 55, 0.7, 'medium', fx(0.3, 0.02, -0.25, -0.2, -0.45)),
  stock('VOLT', 'SparkGrid Power', 'power', '⚡', 110, 0.5, 'low', fx(0.1, 0.03, 0, -0.05, -0.15)),
];
const COINS = [
  coin('TRB', 'TurboCoin', '🪙', 500, 3.5, 'extreme', fx(1.2, 0, -0.9, -0.3, -2.4)),
  coin('NOVA', 'NovaCoin', '🌟', 90, 4.5, 'extreme', fx(1.5, 0, -1.2, -0.5, -3)),
  coin('GCH', 'GoldChain', '🥇', 1200, 1.5, 'high', fx(0.5, 0.02, 0.1, 0.6, -0.8)),
  coin('PUP', 'MoonPup', '🐶', 8, 6, 'extreme', fx(2, 0, -1.5, -0.4, -3.5)),
];
// the value of all property follows this index (it starts at 1.00 and moves slowly)
const PROPERTY_INDEX = { id: 'PROP', name: 'Property index', sector: 'property', kind: 'index', base: 1, vol: 0.04, k: 0.002, drop: 0.04, rise: 0.06, fx: fx(0.05, 0.01, -0.04, 0.08, -0.12) };

const ASSETS = [...STOCKS, ...COINS];
const BOND = { id: 'BOND', name: 'Bonds', icon: '🏛️' };

// ---- properties: what you pay is the value now. rent and tax are a share of the value per day.
const PROPERTIES = {
  room: { name: 'Room Apartment', icon: '🏠', value: 5000 },
  flat: { name: 'Family Flat', icon: '🏢', value: 20000 },
  duplex: { name: 'Duplex', icon: '🏡', value: 75000 },
  mansion: { name: 'Mansion', icon: '🏰', value: 250000 },
};
// ---- businesses: one of each kind per person. profit per day = cost x 3%, +50% of that for every level
const BUSINESSES = {
  kiosk: { name: 'Kiosk', icon: '🏪', cost: 3000 },
  farm: { name: 'Farm', icon: '🚜', cost: 10000 },
  shop: { name: 'Shop', icon: '🛍️', cost: 25000 },
  factory: { name: 'Factory', icon: '🏭', cost: 80000 },
};

// ---- the rules (all the numbers in one place)
const RULES = {
  tickMs: 30 * 60 * 1000, // prices update every 30 minutes, for everybody at once
  maxCatchUp: 96, // after the bot was off: at most 2 days of updates are played back
  fee: { stock: 0.015, coin: 0.02, bond: 0.005 }, // trading fee, taken from every buy and sell (these coins are gone)
  capShare: 0.25, // one trade can use at most this share of the wallet...
  capFloor: 100, // ...but a wallet up to this many coins can be used fully
  cooldownMs: 30 * 1000, // wait between two trades
  minTrade: 10,
  bondCap: 25000, // the most one person can keep in bonds
  propertyStamp: 0.03, // buying and selling property costs this share
  propertyMax: 3, // of each kind
  rentPerDay: 0.007, // of the value
  taxPerDay: 0.0025, // property tax, of the value
  rentStoreDays: 3, // rent waits for you at most this long
  bizProfitPerDay: 0.03, // of the cost
  bizLevelBonus: 0.5,
  bizMaxLevel: 5,
  bizTax: 0.05, // taken when you collect
  bizResale: 0.7, // selling a business gives back this share of what you put in
  bizStoreDays: 2,
  loanMin: 1000, // the first loan is always possible up to this
  loanShare: 0.5, // you can borrow up to half of what you own...
  loanMax: 100000,
  loanFee: 0.02, // taken from the money you borrow
  loanDays: 7,
  loanBaseRate: 1.0, // % per day, plus a tenth of the inflation rate
  margin: 0.8, // when the debt is this share of everything you own, investments are sold to repay
  weekPrizes: [1500, 800, 400],
  weekMinInvested: 1000, // you must have invested at least this much during the week to rank
};

// ---- the news. Every mood shift picks a headline. tilt = sectors that get an extra push (%) until the next shift.
const NEWS = {
  boom: [
    { t: 'Factories are hiring and the markets cheer', tilt: { build: 0.15, retail: 0.1 } },
    { t: 'Tech startups raise record funding', tilt: { tech: 0.3, crypto: 0.4 } },
    { t: 'Shoppers are back: retail sales jump', tilt: { retail: 0.25 } },
    { t: 'Telecom subscribers hit a new high', tilt: { telecom: 0.2 } },
    { t: 'Investors pour money into banks and builders', tilt: { bank: 0.2, build: 0.2 } },
    { t: 'Property buyers rush back to the market', tilt: { property: 0.04, build: 0.2 } },
  ],
  stable: [
    { t: 'Calm trading as the market waits for new data', tilt: {} },
    { t: 'The harvest report is strong, farms stay steady', tilt: { agri: 0.15 } },
    { t: 'A new power plant opens and the grid is steadier', tilt: { power: 0.15 } },
    { t: 'A new drug is approved and pharma stocks rise', tilt: { pharma: 0.3 } },
    { t: 'Transport companies report smooth deliveries', tilt: { transport: 0.15 } },
    { t: 'Coin traders take a break after a busy week', tilt: { crypto: -0.1 } },
  ],
  recession: [
    { t: 'Factories cut shifts as orders fall', tilt: { build: -0.2, transport: -0.1 } },
    { t: 'Shoppers spend less and retailers worry', tilt: { retail: -0.2 } },
    { t: 'Banks tighten lending to small businesses', tilt: { bank: -0.2 } },
    { t: 'Investors run to safe bonds and medicine', tilt: { pharma: 0.15, tech: -0.15 } },
    { t: 'Layoffs spread through the tech sector', tilt: { tech: -0.3 } },
    { t: 'Coin traders lose their nerve', tilt: { crypto: -0.4 } },
  ],
  inflation: [
    { t: 'Fuel prices jump, transport stocks fall', tilt: { transport: -0.4, oil: 0.3 } },
    { t: 'Food prices climb in every market', tilt: { agri: 0.3, retail: -0.2 } },
    { t: 'The central bank raises rates to fight rising prices', tilt: { bank: 0.2, tech: -0.2, property: -0.02 } },
    { t: 'Power bills rise and companies feel it', tilt: { power: 0.1, build: -0.2 } },
    { t: 'Gold is the safe place as prices run away', tilt: { crypto: 0.2 } },
    { t: 'Everything costs more: shoppers cut back', tilt: { retail: -0.3 } },
  ],
  crash: [
    { t: 'Panic selling hits the whole market', tilt: {} },
    { t: 'A big investor collapses and confidence breaks', tilt: { bank: -0.4 } },
    { t: 'The tech bubble bursts', tilt: { tech: -0.6, crypto: -0.6 } },
    { t: 'Fear spreads: traders dump coins and shares', tilt: { crypto: -0.5 } },
    { t: 'A bad rumour about the banks shakes the market', tilt: { bank: -0.5, build: -0.2 } },
  ],
};

module.exports = { MOODS, MOOD_IDS, NEXT, STOCKS, COINS, ASSETS, PROPERTY_INDEX, BOND, PROPERTIES, BUSINESSES, RULES, NEWS };
