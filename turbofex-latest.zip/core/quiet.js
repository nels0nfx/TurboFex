// Hides the noisy "Closing session: SessionEntry {...}" dumps that the
// WhatsApp encryption library prints. Real errors are NOT hidden.
const NOISE =
  /^(Closing (open |stale open )?session|Removing old closed session|Opening session|Session already (closed|open)|Migrating session|Decrypted message with closed session)/i;

function isNoise(args) {
  if (args.some((a) => a && typeof a === 'object' && a.constructor && a.constructor.name === 'SessionEntry')) {
    return true;
  }
  return typeof args[0] === 'string' && NOISE.test(args[0]);
}

for (const method of ['log', 'info', 'warn', 'debug']) {
  const original = console[method].bind(console);
  console[method] = (...args) => {
    if (isNoise(args)) return;
    original(...args);
  };
}
