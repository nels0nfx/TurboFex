// Forex: a made-up currency market (not real money, not real currencies) inside the group market.
// 4 invented currencies: TBD Turbo Dollar (safe), NVE Nova Euro (steady), GLY Gold Yen (safe haven), SHN Sahara Naira (risky, lives on commodities).
// 6 pairs come out of them (so the pairs agree with each other). People open LONG (bet the first currency gets stronger) or SHORT
// (bet it gets weaker) with a margin and a leverage x1-x10, with optional take profit / stop loss. A trade that loses almost
// all its margin is closed by force (liquidation). Nobody can lose more than the margin of a trade.
// The positions live on the player of the market (P.fx), the rates in the group's market (G.fx), the update comes with the price tick.

const CUR = {
  TBD: { name: 'Turbo Dollar', icon: '💵', per: 1, vol: 0.0015 },
  NVE: { name: 'Nova Euro', icon: '💶', per: 1.085, vol: 0.002 },
  GLY: { name: 'Gold Yen', icon: '💴', per: 152.4, vol: 0.002 },
  SHN: { name: 'Sahara Naira', icon: '🪙', per: 1540, vol: 0.004 },
};
// how the mood pushes each currency, in % per price update
const DRIFT = {
  boom: { TBD: -0.01, NVE: 0.02, GLY: -0.03, SHN: 0.06 },
  stable: { TBD: 0, NVE: 0, GLY: 0, SHN: 0 },
  recession: { TBD: 0.02, NVE: -0.02, GLY: 0.04, SHN: -0.04 },
  inflation: { TBD: -0.03, NVE: -0.01, GLY: -0.02, SHN: 0.05 },
  crash: { TBD: 0.08, NVE: -0.03, GLY: 0.12, SHN: -0.12 },
};
const PAIRS = ['TBD/NVE', 'TBD/GLY', 'NVE/GLY', 'TBD/SHN', 'NVE/SHN', 'GLY/SHN'];
const RULES = { maxLev: 10, defaultLev: 2, minMargin: 20, maxMargin: 10000, maxOpen: 5, spread: 0.0005, liquidAt: 0.2, newsChance: 0.04, shockMin: 0.006, shockMax: 0.015, strengthCap: 0.25, revert: 0.015, histLen: 49 };
const NEWS_UP = ['{c} jumps after the central bank raises rates', '{c} gains on strong export numbers', '{c} rises as investors look for safety', '{c} climbs after a surprise trade surplus'];
const NEWS_DOWN = ['{c} slips after weak jobs numbers', '{c} falls as the central bank cuts rates', '{c} drops after a political scare', '{c} sinks on a bigger trade deficit'];

const pairParts = (pair) => pair.split('/');
const baseOf = (pair) => { const [b, q] = pairParts(pair); return CUR[q].per / CUR[b].per; };
const priceOf = (S, pair) => { const [b, q] = pairParts(pair); return baseOf(pair) * Math.exp(S[b] - S[q]); };
const round = (n, d = 6) => Math.round(n * 10 ** d) / 10 ** d;
const decimals = (price) => (price >= 100 ? 2 : 4);
const show = (price) => Number(price).toFixed(decimals(price));

function ensure(G) {
  if (!G.fx) {
    const S = { TBD: 0, NVE: 0, GLY: 0, SHN: 0 };
    const rates = {};
    const hist = {};
    for (const p of PAIRS) { rates[p] = round(priceOf(S, p)); hist[p] = [rates[p]]; }
    G.fx = { S, rates, hist, next: 1, real: {} };
  }
  return G.fx;
}

function findPair(text) {
  const t = String(text || '').toUpperCase().replace(/[\s_-]+/g, '').replace(/\\/g, '/');
  const flat = t.replace('/', '');
  return PAIRS.find((p) => p.replace('/', '') === flat) || null;
}

const pnlOf = (pos, price) => pos.exposure * (pos.side === 'long' ? price / pos.entry - 1 : 1 - price / pos.entry);
const closeFee = (pos) => Math.max(1, Math.round(pos.exposure * RULES.spread));
const equityOf = (pos, price) => Math.max(0, pos.margin + pnlOf(pos, price));

// what the trades of one player are worth now (margin + profit or loss): counts in the net worth
function equity(G, P) {
  if (!G.fx || !P.fx || !P.fx.length) return 0;
  let n = 0;
  for (const pos of P.fx) n += equityOf(pos, G.fx.rates[pos.pair]);
  return n;
}

// the closing of one trade. Returns what happened. The coins go back to the wallet (needs the pay function)
function settle(G, P, pos, why, pay) {
  const price = G.fx.rates[pos.pair];
  const pl = pnlOf(pos, price);
  const fee = closeFee(pos);
  const payout = Math.max(0, Math.floor(pos.margin + pl - fee));
  if (payout > 0) pay(P.j, payout);
  const gain = payout - pos.amount;
  const k = key(P);
  const R = G.fx.real[k] || (G.fx.real[k] = { j: P.j, pl: 0, w: 0, l: 0, n: 0 });
  R.j = P.j;
  R.pl += gain;
  R.n += 1;
  if (gain > 0) R.w += 1; else R.l += 1;
  P.fx = P.fx.filter((x) => x.id !== pos.id);
  if (P.life) P.life.fees = (P.life.fees || 0) + fee;
  return { id: pos.id, pair: pos.pair, side: pos.side, lev: pos.lev, entry: pos.entry, price, why, pl: Math.round(pl), fee, payout, gain, amount: pos.amount };
}
const key = (P) => require('./economy').keyOf(P.j);

// one price update: strengths move with the mood and some noise, trades are checked. rnd is the market's random source.
function step(G, mood, rnd, pay, notes) {
  const F = ensure(G);
  const gauss = () => (rnd() + rnd() + rnd() - 1.5) * 2;
  const drift = DRIFT[mood] || DRIFT.stable;
  for (const c of Object.keys(CUR)) {
    F.S[c] = F.S[c] * (1 - RULES.revert) + drift[c] / 100 + gauss() * CUR[c].vol;
    F.S[c] = Math.max(-RULES.strengthCap, Math.min(RULES.strengthCap, F.S[c]));
  }
  // news shock: one currency jumps or falls
  if (rnd() < RULES.newsChance) {
    const c = Object.keys(CUR)[Math.floor(rnd() * 4)];
    const up = rnd() < 0.5;
    const size = RULES.shockMin + rnd() * (RULES.shockMax - RULES.shockMin);
    F.S[c] = Math.max(-RULES.strengthCap, Math.min(RULES.strengthCap, F.S[c] + (up ? size : -size)));
    const list = up ? NEWS_UP : NEWS_DOWN;
    notes.push({ type: 'fxnews', cur: c, up, text: list[Math.floor(rnd() * list.length)].replace('{c}', `${CUR[c].icon} ${CUR[c].name}`) });
  }
  for (const p of PAIRS) {
    F.rates[p] = round(priceOf(F.S, p));
    F.hist[p].push(F.rates[p]);
    if (F.hist[p].length > RULES.histLen) F.hist[p].shift();
  }
  // trades: liquidation first, then stop loss, then take profit
  for (const P of Object.values(G.players)) {
    if (!P.fx || !P.fx.length) continue;
    for (const pos of [...P.fx]) {
      const price = F.rates[pos.pair];
      let why = null;
      if (equityOf(pos, price) <= pos.margin * RULES.liquidAt) why = 'liquidated';
      else if (pos.sl && (pos.side === 'long' ? price <= pos.sl : price >= pos.sl)) why = 'stop';
      else if (pos.tp && (pos.side === 'long' ? price >= pos.tp : price <= pos.tp)) why = 'target';
      if (why) notes.push({ type: 'fx', jid: P.j, ...settle(G, P, pos, why, pay) });
    }
  }
}

// ----- what people do (called by core/market.js which owns the money functions)
function open(ctx, G, P, o) {
  const { fail, wallet, spend, now, R } = ctx;
  const F = ensure(G);
  const pair = findPair(o.pair);
  if (!pair) return fail('nopair');
  if (!['long', 'short'].includes(o.side)) return fail('side');
  const lev = o.lev == null ? RULES.defaultLev : o.lev;
  if (!Number.isInteger(lev) || lev < 1 || lev > RULES.maxLev) return fail('lev', { max: RULES.maxLev });
  if ((P.fx || []).length >= RULES.maxOpen) return fail('fxmany', { max: RULES.maxOpen });
  const left = Math.max(0, (P.last || 0) + R.cooldownMs - now);
  if (left) return fail('wait', { waitMs: left });
  const cap = Math.min(RULES.maxMargin, Math.max(Math.floor(wallet * R.capShare), Math.min(wallet, R.capFloor)));
  const a = o.amount;
  if (!a) return fail('amount');
  const amount = a.all ? cap : a.pct ? Math.floor((wallet * a.pct) / 100) : a.n;
  if (wallet < RULES.minMargin) return fail('poor', { wallet });
  if (amount < RULES.minMargin) return fail('min', { min: RULES.minMargin });
  if (amount > wallet) return fail('poor', { wallet });
  if (amount > cap) return fail('cap', { cap });
  const price = F.rates[pair];
  const fee = Math.max(1, Math.round(amount * lev * RULES.spread));
  const margin = amount - fee;
  if (margin < 1) return fail('min', { min: RULES.minMargin });
  const long = o.side === 'long';
  // take profit and stop loss must be on the right side of the price
  if (o.tp != null && !(long ? o.tp > price : o.tp < price && o.tp > 0)) return fail('tp', { price });
  if (o.sl != null && !(long ? o.sl < price && o.sl > 0 : o.sl > price)) return fail('sl', { price });
  if (!spend(amount)) return fail('poor', { wallet });
  const pos = { id: F.next++, pair, side: o.side, lev, amount, margin, exposure: round(margin * lev, 2), entry: price, tp: o.tp || null, sl: o.sl || null, opened: now };
  (P.fx = P.fx || []).push(pos);
  P.last = now;
  const liq = liquidationPrice(pos);
  return { ok: true, pos, fee, price, liq };
}

// the price where the trade is closed by force
function liquidationPrice(pos) {
  const k = (1 - RULES.liquidAt) * pos.margin / pos.exposure; // share of the exposure that may be lost
  return pos.side === 'long' ? pos.entry * (1 - k) : pos.entry * (1 + k);
}

function view(G, P) {
  const F = ensure(G);
  return (P?.fx || []).map((pos) => {
    const price = F.rates[pos.pair];
    const pl = pnlOf(pos, price);
    return { ...pos, price, pl: Math.round(pl), plPct: (pl / pos.margin) * 100, equity: Math.round(equityOf(pos, price)), liq: liquidationPrice(pos), closeFee: closeFee(pos) };
  });
}

function quotes(G) {
  const F = ensure(G);
  return PAIRS.map((pair) => {
    const h = F.hist[pair];
    return { pair, price: F.rates[pair], change: (F.rates[pair] / h[0] - 1) * 100, hist: h, lo: Math.min(...h), hi: Math.max(...h) };
  });
}

function top(G, limit = 10) {
  const F = ensure(G);
  return Object.values(F.real).filter((r) => r.n > 0).sort((a, b) => b.pl - a.pl).slice(0, limit);
}

module.exports = { CUR, PAIRS, RULES, DRIFT, ensure, findPair, step, open, settle, view, quotes, top, equity, liquidationPrice, pnlOf, show };
