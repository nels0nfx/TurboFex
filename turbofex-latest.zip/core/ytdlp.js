// Downloads the audio of (almost) any link or song name using yt-dlp, a free tool that supports YouTube, TikTok,
// SoundCloud, Instagram, Facebook and hundreds of other sites. The tool is found on the server, or downloaded once
// into data/bin the first time it is needed (and updated by itself when a site changes).
// Optional: YTDLP_PATH = your own yt-dlp file, YTDLP_COOKIES = a cookies.txt (helps when YouTube asks "confirm you are not a bot").
const fs = require('fs');
const os = require('os');
const path = require('path');
const { execFile, spawn } = require('child_process');

const BIN_DIR = path.join(__dirname, '..', 'data', 'bin');
const MAX_MB = Number(process.env.PLAY_MAX_MB) || 60;
const MAX_SECONDS = Number(process.env.PLAY_MAX_SECONDS) || 3600;
const WIN = process.platform === 'win32';
let installing = null;
let lastUpdate = 0;

function releaseFile() {
  if (WIN) return 'yt-dlp.exe';
  if (process.platform === 'darwin') return 'yt-dlp_macos';
  return process.arch === 'arm64' ? 'yt-dlp_linux_aarch64' : 'yt-dlp_linux';
}

const localPath = () => path.join(BIN_DIR, WIN ? 'yt-dlp.exe' : 'yt-dlp');

function works(bin) {
  return new Promise((resolve) => execFile(bin, ['--version'], { timeout: 15000 }, (err) => resolve(!err)));
}

async function findBinary() {
  for (const c of [process.env.YTDLP_PATH, localPath(), 'yt-dlp'].filter(Boolean)) {
    if ((c === 'yt-dlp' || fs.existsSync(c)) && (await works(c))) return c;
  }
  return null;
}

// downloads the tool once (about 35 MB)
async function install() {
  if (installing) return installing;
  installing = (async () => {
    fs.mkdirSync(BIN_DIR, { recursive: true });
    const res = await fetch(`https://github.com/yt-dlp/yt-dlp/releases/latest/download/${releaseFile()}`, { redirect: 'follow', signal: AbortSignal.timeout(180000) });
    if (!res.ok) throw new Error(`could not download the downloader (error ${res.status})`);
    const tmp = `${localPath()}.part`;
    fs.writeFileSync(tmp, Buffer.from(await res.arrayBuffer()));
    if (!WIN) fs.chmodSync(tmp, 0o755);
    fs.renameSync(tmp, localPath());
    if (!(await works(localPath()))) throw new Error('the downloader was installed but does not run on this server');
    return localPath();
  })().finally(() => {
    installing = null;
  });
  return installing;
}

// the tool updates itself when sites change (at most once every 6 hours)
async function selfUpdate(bin) {
  if (Date.now() - lastUpdate < 6 * 3600 * 1000) return false;
  lastUpdate = Date.now();
  if (bin === 'yt-dlp') return false; // a system install is updated by the system
  return new Promise((resolve) => execFile(bin, ['-U'], { timeout: 120000 }, (err) => resolve(!err)));
}

function ffmpegLocation() {
  try {
    return require('@ffmpeg-installer/ffmpeg').path;
  } catch (err) {
    return null;
  }
}

function run(bin, args, timeoutMs) {
  return new Promise((resolve, reject) => {
    const child = spawn(bin, args, { stdio: ['ignore', 'pipe', 'pipe'] });
    let out = '';
    let err = '';
    const timer = setTimeout(() => {
      child.kill('SIGKILL');
      reject(Object.assign(new Error('The download took too long'), { code: 'TIMEOUT' }));
    }, timeoutMs);
    child.stdout.on('data', (d) => (out += d));
    child.stderr.on('data', (d) => (err = (err + d).slice(-4000)));
    child.on('error', (e) => {
      clearTimeout(timer);
      reject(e);
    });
    child.on('close', (code) => {
      clearTimeout(timer);
      if (code === 0) resolve(out);
      else reject(Object.assign(new Error(err.trim().split('\n').pop() || `downloader exited with code ${code}`), { stderr: err }));
    });
  });
}

const MIME = { '.mp3': 'audio/mpeg', '.m4a': 'audio/mp4', '.mp4': 'audio/mp4', '.aac': 'audio/aac', '.ogg': 'audio/ogg; codecs=opus', '.opus': 'audio/ogg; codecs=opus', '.wav': 'audio/wav' };

// target = a link, or a song name (it is searched). Returns { buffer, mimetype, title, artist, duration, url }
async function downloadAudio(target, { onSetup } = {}) {
  let bin = await findBinary();
  if (!bin) {
    if (onSetup) await onSetup();
    bin = await install();
  }
  const isLink = /^https?:\/\//i.test(target);
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'tfx-'));
  const ff = ffmpegLocation();
  const build = (extra) => [
    '--no-playlist', '--no-simulate', '-q', '--no-warnings',
    '--max-filesize', `${MAX_MB}M`,
    '--match-filter', `duration<=${MAX_SECONDS}`,
    '-o', path.join(dir, '%(id)s.%(ext)s'),
    '--print', 'after_move:%(title)s\t%(uploader)s\t%(duration_string)s\t%(webpage_url)s\t%(filepath)s',
    // MP3 when ffmpeg exists (plays everywhere), else the best audio the site gives (usually m4a)
    ...(ff ? ['-f', 'bestaudio/best', '-x', '--audio-format', 'mp3', '--audio-quality', '5', '--ffmpeg-location', ff] : ['-f', 'bestaudio[ext=m4a]/bestaudio[acodec^=mp4a]/bestaudio/best']),
    ...(process.env.YTDLP_COOKIES ? ['--cookies', process.env.YTDLP_COOKIES] : []),
    ...extra,
    isLink ? target : `ytsearch1:${target}`,
  ];

  try {
    let out;
    const attempts = [[], ['--js-runtimes', 'node'], ['--extractor-args', 'youtube:player_client=android,web']];
    let lastErr;
    for (let i = 0; i < attempts.length && out === undefined; i++) {
      try {
        out = await run(bin, build(attempts[i]), 180000);
      } catch (err) {
        lastErr = err;
        const text = String(err.stderr || err.message);
        if (/does not pass filter/i.test(text)) throw Object.assign(new Error(`That is longer than ${Math.round(MAX_SECONDS / 60)} minutes.`), { code: 'TOO_LONG' });
        if (/larger than max-filesize|File is larger/i.test(text)) throw Object.assign(new Error(`That file is bigger than ${MAX_MB} MB.`), { code: 'TOO_BIG' });
        if (err.code === 'TIMEOUT') throw err;
        if (i === 0 && (await selfUpdate(bin))) i = -1; // the site changed: update the tool and try again from the start
      }
    }
    if (out === undefined) throw lastErr;

    const line = out.trim().split('\n').filter(Boolean).pop() || '';
    const [title, uploader, duration, url, file] = line.split('\t');
    const filePath = file && fs.existsSync(file) ? file : fs.readdirSync(dir).map((f) => path.join(dir, f))[0];
    if (!filePath || !fs.existsSync(filePath)) throw new Error('nothing was downloaded');
    const buffer = fs.readFileSync(filePath);
    const ext = path.extname(filePath).toLowerCase();
    return { buffer, mimetype: MIME[ext] || 'audio/mp4', title: title || '', artist: uploader && uploader !== 'NA' ? uploader : '', duration: duration && duration !== 'NA' ? duration : '', url: url && url !== 'NA' ? url : isLink ? target : '' };
  } finally {
    fs.rmSync(dir, { recursive: true, force: true });
  }
}

module.exports = { downloadAudio, findBinary, install, MAX_MB, MAX_SECONDS };
