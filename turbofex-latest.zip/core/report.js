// The daily economy report: once a day, in every group where the economy is on (and the news is not muted):
// the richest people, the best and worst stock of the day with their owners tagged, the king, the governor, the fund and the bounties.
const jsonstore = require('./jsonstore');
const economy = require('./economy');
const market = require('./market');
const throne = require('./throne');
const governor = require('./governor');
const community = require('./community');
const D = require('./marketdata');

const js = jsonstore.open('report', { groups: {} });
const DAY = 24 * 3600000;
const tag = (jid) => `@${String(jid).split('@')[0].split(':')[0]}`;
const sign = (n) => `${n >= 0 ? '+' : '−'}${Math.abs(n).toFixed(1)}%`;
const TIPS = [
  'Send `earn` to see everything you can do right now.',
  'Send `picks` before you invest: it shows what looks profitable.',
  'A pet finds coins while it is fed: `pet`.',
  'The community fund pays 125% back when the goal is reached: `community`.',
  'Stand for governor with `gov run`, the group votes.',
  'Put a bounty on a rival with `bounty @user 500`.',
  'Brain time: the first right answer wins coins. Send `brain`.',
  'Spin the free daily wheel: `spin`.',
  'Married? `couple` gives you dates, a daily bonus and extra pay.',
  'Plant a seed with `plant`, harvest it in an hour with `garden harvest`.',
];

function build(group, now = Date.now()) {
  const G = market.state(group);
  const mentions = new Set();
  const lines = ['📰 *Daily Economy Report*', ''];
  const top = economy.runIn(group, () => economy.richest(3));
  if (top.length) {
    lines.push('*💰 Richest*');
    top.forEach((r, i) => {
      mentions.add(r.jid);
      lines.push(`${['🥇', '🥈', '🥉'][i]} ${tag(r.jid)} – ${economy.fmt(r.coins)} coins`);
    });
    lines.push('');
  }
  if (G && G.on) {
    const rows = D.ASSETS.map((a) => ({ id: a.id, name: a.name, pct: market.change24Of(group, a.id) })).sort((a, b) => b.pct - a.pct);
    const best = rows[0];
    const worst = rows[rows.length - 1];
    const line = (m, icon) => {
      const who = market.holders(group, m.id).slice(0, 8);
      who.forEach((j) => mentions.add(j));
      return `${icon} *${m.id}* (${m.name}) ${sign(m.pct)}${who.length ? ` 👥 ${who.map(tag).join(' ')}` : ''}`;
    };
    lines.push(`*📊 Market* – ${market.moodName(group)}`, line(best, '🚀 Best:'), line(worst, '📉 Worst:'), '');
  }
  const k = throne.info(group);
  const g = governor.info(group, now);
  if (k.king) mentions.add(k.king.jid);
  if (g.gov) mentions.add(g.gov.jid);
  lines.push(`*🏛️ Government*`, `👑 King: ${k.king ? `${tag(k.king.jid)} (tax ${k.tax}%)` : 'nobody – `throne take`'}`, `🏛️ Governor: ${g.gov ? tag(g.gov.jid) : g.el ? 'an election is open! `gov vote @name`' : 'nobody – `gov run`'}`, '');
  const c = community.info(group, now);
  const bounty = economy.runIn(group, () => economy.bountyBoard(1))[0];
  lines.push(`🤝 *Fund:* ${economy.fmt(c.total)} / ${economy.fmt(c.goal)}${c.boostLeft ? ' • 🎉 boom on' : ''}`);
  if (bounty) {
    mentions.add(bounty.jid);
    lines.push(`🎯 *Most wanted:* ${tag(bounty.jid)} – ${economy.fmt(bounty.bounty)} coins`);
  }
  lines.push('', `💡 _${TIPS[Math.floor(now / DAY) % TIPS.length]}_`);
  return { text: lines.join('\n'), mentions: [...mentions] };
}

async function tick(post, now = Date.now()) {
  for (const group of Object.keys(market.allGroups())) {
    const G = market.state(group);
    if (!G || !G.on || !G.news || economy.isOff(group)) continue;
    const at = js.data.groups[group] ?? (js.data.groups[group] = G.created || now);
    if (now - at < DAY) continue;
    js.data.groups[group] = now;
    js.touch();
    try {
      await post(group, build(group, now));
    } catch (err) {
      console.log(`Daily report could not be sent to ${group}: ${err.message}`);
      js.data.groups[group] = at; // tried again at the next pass
      js.touch();
    }
  }
}

module.exports = { build, tick };
