// Coins. One purse per person for the whole bot (not per group), kept under the person's phone number when it is known.
// Coins come from chatting in groups with ranks on, from the daily bonus, and from games. They are spent in the shop.
const jsonstore = require('./jsonstore');
const levels = require('../whatsapp/levels');

const js = jsonstore.open('economy', { users: {} });
const DAY = 24 * 60 * 60 * 1000;

const keyOf = (jid) => levels.keyOf(jid);
const idmap = require('../whatsapp/idmap');
function user(key, jid) {
  const u = js.data.users[key] || (js.data.users[key] = { coins: 0, streak: 0, lastDaily: 0, items: {}, title: null });
  if (!u.items) u.items = {};
  // remember an id to tag the person with (a phone number id is preferred over a hidden one)
  if (jid && jid.includes('@') && (!u.j || (idmap.isLid(u.j) && !idmap.isLid(jid)))) u.j = jid;
  return u;
}

const balance = (jid) => user(keyOf(jid), jid).coins;
const peek = (jid) => user(keyOf(jid), jid);

function add(jid, n) {
  const u = user(keyOf(jid), jid);
  u.coins = Math.max(0, Math.floor(u.coins + n));
  js.touch();
  return u.coins;
}

function take(jid, n) {
  const u = user(keyOf(jid), jid);
  if (!Number.isInteger(n) || n <= 0 || u.coins < n) return false;
  u.coins -= n;
  js.touch();
  return true;
}

function transfer(from, to, n) {
  if (keyOf(from) === keyOf(to) || !take(from, n)) return false;
  add(to, n);
  return true;
}

// daily bonus: 200 coins, +25 for every day in a row (up to +300). Missing a whole day starts the streak again.
function daily(jid, now = Date.now()) {
  const u = user(keyOf(jid), jid);
  const since = now - u.lastDaily;
  if (u.lastDaily && since < DAY) return { ok: false, waitMs: DAY - since };
  u.streak = u.lastDaily && since < 2 * DAY ? u.streak + 1 : 1;
  const amount = 200 + Math.min(300, (u.streak - 1) * 25);
  u.lastDaily = now;
  u.coins += amount;
  js.touch();
  return { ok: true, amount, streak: u.streak, coins: u.coins };
}

const ITEMS = {
  charm: { name: '🍀 Lucky Charm', price: 1500, about: '+5% chance to win in gamble for 24 hours' },
  vip: { name: '👑 VIP', price: 5000, about: 'a title next to your name in balance' },
  legend: { name: '🔥 Legend', price: 20000, about: 'a title next to your name in balance' },
  rich: { name: '💎 Rich', price: 50000, about: 'a title next to your name in balance' },
};

function buy(jid, id, now = Date.now()) {
  const item = ITEMS[id];
  if (!item) return { ok: false, why: 'unknown' };
  const u = user(keyOf(jid), jid);
  if (id === 'charm' && u.items.charm > now) return { ok: false, why: 'active' };
  if (id !== 'charm' && u.title === item.name) return { ok: false, why: 'owned' };
  if (u.coins < item.price) return { ok: false, why: 'poor', need: item.price - u.coins };
  u.coins -= item.price;
  if (id === 'charm') u.items.charm = now + DAY;
  else u.title = item.name;
  js.touch();
  return { ok: true, item };
}

const hasCharm = (jid, now = Date.now()) => (user(keyOf(jid), jid).items.charm || 0) > now;

// gamble: 45% to win (50% with a Lucky Charm). A win pays the bet once more, a loss loses the bet.
function gamble(jid, bet, rand = Math.random, now = Date.now()) {
  const u = user(keyOf(jid), jid);
  if (!Number.isInteger(bet) || bet < 10) return { ok: false, why: 'min' };
  if (bet > u.coins) return { ok: false, why: 'poor' };
  const chance = hasCharm(jid, now) ? 0.5 : 0.45;
  const win = rand() < chance;
  u.coins += win ? bet : -bet;
  js.touch();
  return { ok: true, win, coins: u.coins, chance };
}

// the richest people: [{ key, coins, title, jid }]
function richest(limit = 10, only = null) {
  const worth = (u) => u.coins + (u.bank || 0);
  return Object.entries(js.data.users)
    .filter(([key, u]) => worth(u) > 0 && (!only || only(key, u)))
    .sort((a, b) => worth(b[1]) - worth(a[1]))
    .slice(0, limit)
    .map(([key, u]) => ({ key, coins: worth(u), title: u.title, jid: u.j || `${key}@s.whatsapp.net` }));
}

// ---- cooldowns (work, fish, hunt, mine, rob): ok, or how long to wait
function cooldown(jid, name, ms, now = Date.now()) {
  const u = user(keyOf(jid), jid);
  if (!u.cd) u.cd = {};
  const since = now - (u.cd[name] || 0);
  if (since < ms) return { ok: false, waitMs: ms - since };
  u.cd[name] = now;
  js.touch();
  return { ok: true };
}

const resetCooldown = (jid, name) => {
  const u = user(keyOf(jid), jid);
  if (u.cd) u.cd[name] = 0;
  js.touch();
};

// ---- the bank: coins in the bank cannot be robbed
const bankOf = (jid) => user(keyOf(jid), jid).bank || 0;
function deposit(jid, n) {
  const u = user(keyOf(jid), jid);
  if (!Number.isInteger(n) || n < 1 || n > u.coins) return false;
  u.coins -= n;
  u.bank = (u.bank || 0) + n;
  js.touch();
  return true;
}
function withdraw(jid, n) {
  const u = user(keyOf(jid), jid);
  if (!Number.isInteger(n) || n < 1 || n > (u.bank || 0)) return false;
  u.bank -= n;
  u.coins += n;
  js.touch();
  return true;
}

// ---- robbing the wallet of someone (never the bank): 40% success, a failure costs a fine that goes to the victim
function rob(thief, victim, rand = Math.random) {
  const t = user(keyOf(thief), thief);
  const v = user(keyOf(victim), victim);
  if (keyOf(thief) === keyOf(victim)) return { ok: false, why: 'self' };
  if (t.coins < 100) return { ok: false, why: 'poor' };
  if (v.coins < 200) return { ok: false, why: 'empty' };
  if (rand() < 0.4) {
    const amount = Math.min(5000, Math.max(10, Math.floor(v.coins * (0.1 + rand() * 0.2))));
    v.coins -= amount;
    t.coins += amount;
    js.touch();
    return { ok: true, success: true, amount };
  }
  const fine = Math.min(t.coins, Math.max(50, Math.floor(t.coins * 0.15)));
  t.coins -= fine;
  v.coins += fine;
  js.touch();
  return { ok: true, success: false, amount: fine };
}

// ---- marriage: marry @user (a proposal for 2 minutes), the other person accepts with "marry accept"
const proposals = new Map(); // key of the one asked -> { from, fromJid, at }
const PROPOSAL_MS = 2 * 60 * 1000;
const spouseOf = (jid) => {
  const u = user(keyOf(jid), jid);
  return u.spouse ? { key: u.spouse, jid: u.spouseJid } : null;
};
function propose(from, to, now = Date.now()) {
  if (keyOf(from) === keyOf(to)) return { ok: false, why: 'self' };
  if (spouseOf(from)) return { ok: false, why: 'married' };
  if (spouseOf(to)) return { ok: false, why: 'taken' };
  proposals.set(keyOf(to), { from: keyOf(from), fromJid: from, at: now });
  if (proposals.size > 500) proposals.clear();
  return { ok: true };
}
function accept(to, now = Date.now()) {
  const p = proposals.get(keyOf(to));
  if (!p || now - p.at > PROPOSAL_MS) return { ok: false, why: 'none' };
  proposals.delete(keyOf(to));
  if (spouseOf(to) || spouseOf(p.fromJid)) return { ok: false, why: 'taken' };
  const a = user(p.from, p.fromJid);
  const b = user(keyOf(to), to);
  a.spouse = keyOf(to);
  a.spouseJid = to;
  b.spouse = p.from;
  b.spouseJid = p.fromJid;
  js.touch();
  return { ok: true, fromJid: p.fromJid };
}
function decline(to) {
  return proposals.delete(keyOf(to));
}
function divorce(jid) {
  const mine = spouseOf(jid);
  if (!mine) return false;
  const a = user(keyOf(jid), jid);
  const b = user(mine.key);
  a.spouse = a.spouseJid = b.spouse = b.spouseJid = null;
  js.touch();
  return mine;
}

const fmt = (n) => Number(n).toLocaleString('en-US');

module.exports = { balance, peek, add, take, transfer, daily, buy, gamble, richest, hasCharm, cooldown, resetCooldown, bankOf, deposit, withdraw, rob, propose, accept, decline, divorce, spouseOf, ITEMS, fmt, DAY };
