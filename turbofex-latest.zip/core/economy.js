// Coins. One purse per person for the whole bot (not per group), kept under the person's phone number when it is known.
// Coins come from chatting in groups with ranks on, from the daily bonus, and from games. They are spent in the shop.
const jsonstore = require('./jsonstore');
const levels = require('../whatsapp/levels');

const js = jsonstore.open('economy', { users: {} });
const DAY = 24 * 60 * 60 * 1000;

const keyOf = (jid) => levels.keyOf(jid);
function user(key) {
  const u = js.data.users[key] || (js.data.users[key] = { coins: 0, streak: 0, lastDaily: 0, items: {}, title: null });
  if (!u.items) u.items = {};
  return u;
}

const balance = (jid) => user(keyOf(jid)).coins;
const peek = (jid) => user(keyOf(jid));

function add(jid, n) {
  const u = user(keyOf(jid));
  u.coins = Math.max(0, Math.floor(u.coins + n));
  js.touch();
  return u.coins;
}

function take(jid, n) {
  const u = user(keyOf(jid));
  if (!Number.isInteger(n) || n <= 0 || u.coins < n) return false;
  u.coins -= n;
  js.touch();
  return true;
}

function transfer(from, to, n) {
  if (keyOf(from) === keyOf(to) || !take(from, n)) return false;
  add(to, n);
  return true;
}

// daily bonus: 200 coins, +25 for every day in a row (up to +300). Missing a whole day starts the streak again.
function daily(jid, now = Date.now()) {
  const u = user(keyOf(jid));
  const since = now - u.lastDaily;
  if (u.lastDaily && since < DAY) return { ok: false, waitMs: DAY - since };
  u.streak = u.lastDaily && since < 2 * DAY ? u.streak + 1 : 1;
  const amount = 200 + Math.min(300, (u.streak - 1) * 25);
  u.lastDaily = now;
  u.coins += amount;
  js.touch();
  return { ok: true, amount, streak: u.streak, coins: u.coins };
}

const ITEMS = {
  charm: { name: '🍀 Lucky Charm', price: 1500, about: '+5% chance to win in gamble for 24 hours' },
  vip: { name: '👑 VIP', price: 5000, about: 'a title next to your name in balance' },
  legend: { name: '🔥 Legend', price: 20000, about: 'a title next to your name in balance' },
  rich: { name: '💎 Rich', price: 50000, about: 'a title next to your name in balance' },
};

function buy(jid, id, now = Date.now()) {
  const item = ITEMS[id];
  if (!item) return { ok: false, why: 'unknown' };
  const u = user(keyOf(jid));
  if (id === 'charm' && u.items.charm > now) return { ok: false, why: 'active' };
  if (id !== 'charm' && u.title === item.name) return { ok: false, why: 'owned' };
  if (u.coins < item.price) return { ok: false, why: 'poor', need: item.price - u.coins };
  u.coins -= item.price;
  if (id === 'charm') u.items.charm = now + DAY;
  else u.title = item.name;
  js.touch();
  return { ok: true, item };
}

const hasCharm = (jid, now = Date.now()) => (user(keyOf(jid)).items.charm || 0) > now;

// gamble: 45% to win (50% with a Lucky Charm). A win pays the bet once more, a loss loses the bet.
function gamble(jid, bet, rand = Math.random, now = Date.now()) {
  const u = user(keyOf(jid));
  if (!Number.isInteger(bet) || bet < 10) return { ok: false, why: 'min' };
  if (bet > u.coins) return { ok: false, why: 'poor' };
  const chance = hasCharm(jid, now) ? 0.5 : 0.45;
  const win = rand() < chance;
  u.coins += win ? bet : -bet;
  js.touch();
  return { ok: true, win, coins: u.coins, chance };
}

// the richest people: [{ key, coins, title, jid }]
function richest(limit = 10) {
  return Object.entries(js.data.users)
    .filter(([, u]) => u.coins > 0)
    .sort((a, b) => b[1].coins - a[1].coins)
    .slice(0, limit)
    .map(([key, u]) => ({ key, coins: u.coins, title: u.title }));
}

const fmt = (n) => Number(n).toLocaleString('en-US');

module.exports = { balance, peek, add, take, transfer, daily, buy, gamble, richest, hasCharm, ITEMS, fmt, DAY };
