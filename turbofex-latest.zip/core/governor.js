// The Governor: a second office next to the king. The king is bought with coins; the governor is ELECTED by the group.
// Anybody can run (a small fee), members vote, and after 12 hours the one with most votes governs for 7 days.
// The governor earns a salary and has powers over the economy (shop sale, fee holiday, veto of the king's tax, audit).
const jsonstore = require('./jsonstore');
const economy = require('./economy');
const market = require('./market');
const throne = require('./throne');

const js = jsonstore.open('governor', { groups: {} });
const HOUR = 3600000;
const DAY = 24 * HOUR;

const RULES = {
  termMs: 7 * DAY, voteMs: 12 * HOUR, fee: 200, minVotes: 3,
  salaryPerHour: 60, storeHours: 24,
  sale: { cost: 500, ms: 2 * HOUR, cooldownMs: 12 * HOUR, mult: 0.8 }, // the shop is 20% cheaper
  feecut: { cost: 800, ms: 2 * HOUR, cooldownMs: 12 * HOUR, mult: 0.5 }, // the market fees are half
  veto: { cost: 300, ms: 6 * HOUR, cooldownMs: 24 * HOUR }, // the king's tax is stopped
  audit: { cost: 100, cooldownMs: 30 * 60000 },
};

const stateOf = (group) => js.data.groups[group] || (js.data.groups[group] = { gov: null, el: null, laws: {}, auditAt: 0 });
const salaryOf = () => (Number.isFinite(js.data.salary) ? js.data.salary : RULES.salaryPerHour);
const setSalary = (n) => {
  // what the governor already earned is kept
  const now = Date.now();
  for (const G of Object.values(js.data.groups)) {
    if (G.gov) {
      G.gov.stash = Math.min(salaryOf() * RULES.storeHours, waiting(G, now));
      G.gov.collected = now;
    }
  }
  js.data.salary = n;
  js.touch();
};
const resetSalary = () => {
  setSalary(RULES.salaryPerHour);
  delete js.data.salary;
  js.touch();
};
const active = (G, now) => !!(G.gov && G.gov.until > now);
const waiting = (G, now) => (G.gov ? (G.gov.stash || 0) + Math.floor((Math.min(RULES.storeHours * HOUR, Math.max(0, now - G.gov.collected)) / HOUR) * salaryOf()) : 0);
const wallet = (group, jid) => economy.runIn(group, () => economy.balance(jid));
const keyOf = economy.keyOf;

// the election closes: returns the announcement (or null when nothing was due)
function resolve(group, now = Date.now()) {
  const G = js.data.groups[group];
  if (!G || !G.el || now < G.el.end) return null;
  const el = G.el;
  G.el = null;
  const cands = Object.entries(el.cands).map(([key, c]) => ({ key, jid: c.jid, votes: 0 }));
  for (const cand of Object.values(el.votes)) {
    const c = cands.find((x) => x.key === cand);
    if (c) c.votes += 1;
  }
  const total = cands.reduce((s, c) => s + c.votes, 0);
  const ranked = [...cands].sort((a, b) => b.votes - a.votes);
  const winner = total >= RULES.minVotes ? ranked.find((c) => c.votes > 0 && !throne.isKing(group, c.jid)) : null;
  if (!winner) {
    for (const c of cands) economy.runIn(group, () => economy.add(c.jid, RULES.fee)); // fees are given back
    js.touch();
    return { ok: false, total, cands, text: total < RULES.minVotes ? `🗳️ *The election failed.* Only ${total} vote${total === 1 ? '' : 's'} (at least ${RULES.minVotes} are needed). The candidates got their ${RULES.fee} coins back.\n_Try again with_ \`governor run\`` : '🗳️ *The election failed.* The winner is the king, and a king cannot also govern. Fees were returned.', mentions: cands.map((c) => c.jid) };
  }
  G.gov = { key: winner.key, jid: winner.jid, since: now, until: now + RULES.termMs, collected: now, stash: 0 };
  const pool = el.pool || 0;
  if (pool) economy.runIn(group, () => economy.add(winner.jid, pool)); // the fees of all candidates are the campaign fund
  js.touch();
  const board = ranked.map((c) => `▸ @${c.jid.split('@')[0]} – ${c.votes} vote${c.votes === 1 ? '' : 's'}`).join('\n');
  return { ok: true, winner, total, cands, text: `🏛️ *We have a new Governor!*\n@${winner.jid.split('@')[0]} won with *${winner.votes}* of ${total} votes.\n\n${board}\n\n_Term: 7 days • salary ${salaryOf()} coins an hour • campaign fund +${economy.fmt(pool)} coins_\n▸ \`governor\` – powers and how to use them`, mentions: cands.map((c) => c.jid) };
}

function info(group, now = Date.now()) {
  const G = stateOf(group);
  const out = { gov: active(G, now) ? G.gov : null, ended: G.gov && !active(G, now) ? G.gov : null, salary: salaryOf(), waiting: active(G, now) ? waiting(G, now) : 0, laws: {}, el: null };
  for (const k of ['sale', 'feecut', 'veto']) out.laws[k] = lawLeft(group, k, now);
  if (G.el && now < G.el.end) {
    const cands = Object.entries(G.el.cands).map(([key, c]) => ({ key, jid: c.jid, votes: 0 }));
    for (const cand of Object.values(G.el.votes)) {
      const c = cands.find((x) => x.key === cand);
      if (c) c.votes += 1;
    }
    out.el = { end: G.el.end, cands: cands.sort((a, b) => b.votes - a.votes), total: Object.keys(G.el.votes).length, pool: G.el.pool };
  }
  return out;
}

function run(group, jid, now = Date.now()) {
  const G = stateOf(group);
  if (active(G, now)) return { ok: false, why: 'term', until: G.gov.until, gov: G.gov };
  if (throne.isKing(group, jid)) return { ok: false, why: 'king' };
  const key = keyOf(jid);
  if (G.el && now < G.el.end && G.el.cands[key]) return { ok: false, why: 'already' };
  if (wallet(group, jid) < RULES.fee) return { ok: false, why: 'poor', wallet: wallet(group, jid) };
  economy.runIn(group, () => economy.take(jid, RULES.fee));
  let started = false;
  if (!G.el || now >= G.el.end) {
    G.el = { start: now, end: now + RULES.voteMs, cands: {}, votes: {}, pool: 0 };
    started = true;
  }
  G.el.cands[key] = { jid };
  G.el.pool += RULES.fee;
  js.touch();
  return { ok: true, started, end: G.el.end };
}

function vote(group, jid, target, now = Date.now()) {
  const G = stateOf(group);
  if (!G.el || now >= G.el.end) return { ok: false, why: 'none' };
  const tk = keyOf(target);
  if (!G.el.cands[tk]) return { ok: false, why: 'notcand' };
  const key = keyOf(jid);
  const changed = !!G.el.votes[key];
  G.el.votes[key] = tk;
  js.touch();
  return { ok: true, changed };
}

function resign(group, jid) {
  const G = stateOf(group);
  if (!active(G, Date.now()) || G.gov.key !== keyOf(jid)) return { ok: false, why: 'notgov' };
  const pay = waiting(G, Date.now());
  if (pay) economy.runIn(group, () => economy.add(jid, pay));
  G.gov = null;
  js.touch();
  return { ok: true, paid: pay };
}

function collect(group, jid, now = Date.now()) {
  const G = stateOf(group);
  if (!active(G, now) || G.gov.key !== keyOf(jid)) return { ok: false, why: 'notgov' };
  const n = waiting(G, now);
  if (n < 1) return { ok: false, why: 'empty' };
  G.gov.collected = now;
  G.gov.stash = 0;
  economy.runIn(group, () => economy.add(jid, n));
  js.touch();
  return { ok: true, amount: n };
}

const isGovernor = (group, jid, now = Date.now()) => {
  const G = js.data.groups[group];
  return !!(G && active(G, now) && G.gov.key === keyOf(jid));
};
const lawLeft = (group, kind, now = Date.now()) => Math.max(0, ((js.data.groups[group]?.laws || {})[kind]?.until || 0) - now);
const vetoLeft = (group, now = Date.now()) => lawLeft(group, 'veto', now);

// a power that costs coins and lasts a while: kind = 'sale' | 'feecut' | 'veto'
function law(group, jid, kind, now = Date.now()) {
  const G = stateOf(group);
  if (!isGovernor(group, jid, now)) return { ok: false, why: 'notgov' };
  const R = RULES[kind];
  if (kind === 'veto' && !(throne.info(group).tax > 0)) return { ok: false, why: 'notax' };
  const cur = G.laws[kind] || { at: 0, until: 0 };
  if (cur.until > now) return { ok: false, why: 'active', left: cur.until - now };
  const wait = cur.at + R.cooldownMs - now;
  if (wait > 0) return { ok: false, why: 'wait', waitMs: wait };
  if (wallet(group, jid) < R.cost) return { ok: false, why: 'poor', wallet: wallet(group, jid), cost: R.cost };
  economy.runIn(group, () => economy.take(jid, R.cost));
  G.laws[kind] = { at: now, until: now + R.ms };
  js.touch();
  return { ok: true, cost: R.cost, until: G.laws[kind].until, ms: R.ms };
}

// the governor looks into somebody's money: wallet, bank and what is invested
function audit(group, jid, target, now = Date.now()) {
  const G = stateOf(group);
  if (!isGovernor(group, jid, now)) return { ok: false, why: 'notgov' };
  if (now - (G.auditAt || 0) < RULES.audit.cooldownMs) return { ok: false, why: 'wait', waitMs: RULES.audit.cooldownMs - (now - G.auditAt) };
  if (wallet(group, jid) < RULES.audit.cost) return { ok: false, why: 'poor', cost: RULES.audit.cost };
  economy.runIn(group, () => economy.take(jid, RULES.audit.cost));
  G.auditAt = now;
  js.touch();
  const u = economy.runIn(group, () => economy.peek(target));
  let invested = null;
  try {
    const pf = market.isOn(group) ? market.portfolio(group, target) : null;
    if (pf && pf.worth) invested = pf.worth.invested;
  } catch (err) {
    invested = null;
  }
  return { ok: true, coins: u.coins, bank: u.bank || 0, invested, title: u.title || null, rep: u.rep || 0, bounty: u.bounty || 0, cost: RULES.audit.cost };
}

// closes the elections that are due and tells the group (called by the scheduler)
async function tick(post, now = Date.now()) {
  for (const group of Object.keys(js.data.groups)) {
    const G = js.data.groups[group];
    if (!G.el || now < G.el.end) continue;
    const r = resolve(group, now);
    if (!r) continue;
    if (economy.isOff(group)) continue;
    try {
      await post(group, { text: r.text, mentions: r.mentions });
    } catch (err) {
      console.log(`Election result could not be sent to ${group}: ${err.message}`);
    }
  }
}

// the shop sale and the fee holiday reach the rest of the economy
economy.addShopMod((group) => (lawLeft(group, 'sale') > 0 ? RULES.sale.mult : 1));
market.addFeeMod((group) => (lawLeft(group, 'feecut') > 0 ? RULES.feecut.mult : 1));

module.exports = { RULES, info, run, vote, resign, collect, law, audit, resolve, tick, isGovernor, lawLeft, vetoLeft, salaryOf, setSalary, resetSalary };
