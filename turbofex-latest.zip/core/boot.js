require('./quiet'); // must come first, before the WhatsApp library loads
const brand = require('./brand');
const { RESTART_CODE } = require('./restart');

async function start() {
  console.log(`\n⚡ Starting ${brand.botName} by ${brand.creator}...\n`);

  process.on('unhandledRejection', (err) => console.error('Unhandled error:', err));
  process.on('uncaughtException', (err) => console.error('Crash prevented:', err));

  // Look for a new version BEFORE the bot loads
  const { autoUpdateOnStart } = require('./updater');
  const updated = await autoUpdateOnStart();
  if (updated) {
    console.log('✅ Update installed. Restarting...');
    process.exit(RESTART_CODE);
  }

  const { startWhatsApp } = require('../whatsapp/connection');
  await startWhatsApp();
}

module.exports = { start };
