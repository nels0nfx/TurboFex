const fs = require('fs');
const pino = require('pino');
const qrcode = require('qrcode-terminal');
const baileys = require('@whiskeysockets/baileys');
const config = require('../config');
const brand = require('../core/brand');
const { handleMessage } = require('./handler');
const { handleParticipants } = require('./events');

const makeWASocket = baileys.default || baileys.makeWASocket;
const { useMultiFileAuthState, DisconnectReason, Browsers } = baileys;

async function startWhatsApp() {
  const { state, saveCreds } = await useMultiFileAuthState(config.sessionDir);

  const sock = makeWASocket({
    auth: state,
    logger: pino({ level: 'silent' }),
    browser: Browsers.ubuntu('Chrome'),
    markOnlineOnConnect: false,
    syncFullHistory: false,
  });

  sock.ev.on('creds.update', saveCreds);

  let pairingAsked = false;

  sock.ev.on('connection.update', async (update) => {
    const { connection, lastDisconnect, qr } = update;

    if (qr) {
      if (config.pairingNumber) {
        if (!pairingAsked && !sock.authState.creds.registered) {
          pairingAsked = true;
          try {
            const raw = await sock.requestPairingCode(config.pairingNumber);
            const code = raw?.match(/.{1,4}/g)?.join('-') || raw;
            console.log('\n==============================================');
            console.log(`  YOUR PAIRING CODE:  ${code}`);
            console.log('  WhatsApp > Linked devices > Link a device >');
            console.log('  "Link with phone number instead" > enter code');
            console.log('==============================================\n');
          } catch (err) {
            pairingAsked = false;
            console.log('Could not get a pairing code:', err.message);
          }
        }
      } else {
        console.log('\nScan this QR code: WhatsApp > Linked devices > Link a device\n');
        qrcode.generate(qr, { small: true });
      }
    }

    if (connection === 'open') {
      console.log(`✅ ${brand.botName} is online as ${sock.user?.id}`);
    }

    if (connection === 'close') {
      const status = lastDisconnect?.error?.output?.statusCode;
      if (status === DisconnectReason.loggedOut) {
        console.log('Logged out of WhatsApp. Clearing saved login, starting fresh...');
        fs.rmSync(config.sessionDir, { recursive: true, force: true });
      } else {
        console.log(`Connection closed (code ${status}). Reconnecting...`);
      }
      setTimeout(() => startWhatsApp().catch(console.error), 3000);
    }
  });

  sock.ev.on('messages.upsert', async ({ messages, type }) => {
    if (type !== 'notify') return;
    for (const msg of messages) {
      try {
        await handleMessage(sock, msg);
      } catch (err) {
        console.error('Message error:', err);
      }
    }
  });

  sock.ev.on('group-participants.update', async (update) => {
    try {
      await handleParticipants(sock, update);
    } catch (err) {
      console.error('Welcome/goodbye error:', err);
    }
  });
}

module.exports = { startWhatsApp };
