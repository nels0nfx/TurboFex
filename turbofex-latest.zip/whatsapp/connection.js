const fs = require('fs');
const path = require('path');
const pino = require('pino');
const qrcode = require('qrcode-terminal');
const baileys = require('@whiskeysockets/baileys');
const config = require('../config');
const brand = require('../core/brand');
const scheduler = require('../core/scheduler');
const meta = require('./metadata');
const { withTimeout } = require('./timeout');
const { handleMessage, diag } = require('./handler');
const { handleParticipants } = require('./events');
const sent = require('./sent');
const replay = require('./replay');
const welcome = require('./welcome');

const makeWASocket = baileys.default || baileys.makeWASocket;
const { useMultiFileAuthState, DisconnectReason, Browsers } = baileys;

let generation = 0; // only the newest connection may do anything
let current = null;
let reconnectTimer = null;
const queues = new Map(); // one line of waiting messages per chat

// messages of ONE chat are handled in order, different chats never wait for each other
function enqueue(jid, task) {
  const previous = queues.get(jid) || Promise.resolve();
  const next = previous.then(task).catch(() => {}).finally(() => {
    if (queues.get(jid) === next) queues.delete(jid);
  });
  queues.set(jid, next);
}

async function startWhatsApp() {
  const gen = ++generation;
  clearTimeout(reconnectTimer);
  // never keep two connections open (two copies fight each other and cause "Bad MAC")
  if (current) {
    try {
      current.ev.removeAllListeners();
      current.end(undefined);
    } catch (err) {
      // already closed
    }
    current = null;
  }

  const { state, saveCreds } = await useMultiFileAuthState(config.sessionDir);
  if (gen !== generation) return;

  const sock = makeWASocket({
    auth: state,
    logger: pino({ level: 'silent' }),
    browser: Browsers.ubuntu('Chrome'),
    markOnlineOnConnect: false,
    syncFullHistory: false,
    cachedGroupMetadata: async (jid) => meta.getMeta(sock, jid),
  });
  current = sock;
  const alive = () => gen === generation;

  // remember the ids of our own replies so we never answer ourselves
  const rawSend = sock.sendMessage.bind(sock);
  sock.sendMessage = async (...args) => {
    const res = await rawSend(...args);
    if (res?.key?.id) sent.remember(res.key.id);
    return res;
  };

  sock.ev.on('creds.update', () => {
    if (alive()) saveCreds();
  });

  let pairingAsked = false;

  sock.ev.on('connection.update', async (update) => {
    if (!alive()) return;
    const { connection, lastDisconnect, qr } = update;

    if (qr) {
      if (config.pairingNumber) {
        if (!pairingAsked && !sock.authState.creds.registered) {
          pairingAsked = true;
          try {
            const raw = await sock.requestPairingCode(config.pairingNumber);
            const code = raw?.match(/.{1,4}/g)?.join('-') || raw;
            console.log('\n==============================================');
            console.log(`  YOUR PAIRING CODE:  ${code}`);
            console.log('  WhatsApp > Linked devices > Link a device >');
            console.log('  "Link with phone number instead" > enter code');
            console.log('==============================================\n');
          } catch (err) {
            pairingAsked = false;
            console.log('Could not get a pairing code:', err.message);
          }
        }
      } else {
        console.log('\nScan this QR code: WhatsApp > Linked devices > Link a device\n');
        qrcode.generate(qr, { small: true });
      }
    }

    if (connection === 'open') {
      console.log(`✅ ${brand.botName} is online as ${sock.user?.id}`);
      scheduler.start(sock);
      replay.open(); // for a few seconds, skip old messages WhatsApp re-delivers
      // the first time an account connects, send it a welcome message
      setTimeout(() => {
        if (alive()) welcome.maybeSendWelcome(sock).catch((e) => console.error('Welcome message error:', e.message));
      }, welcome.settings.delayMs);
      // The bot started fine, so a fresh update does not need to be rolled back
      try {
        fs.rmSync(path.join(__dirname, '..', 'data', 'rollback', 'pending'), { force: true });
      } catch (err) {
        // ignore
      }
    }

    if (connection === 'close') {
      scheduler.stop();
      const status = lastDisconnect?.error?.output?.statusCode;
      if (status === DisconnectReason.loggedOut) {
        console.log('Logged out of WhatsApp. Clearing saved login, starting fresh...');
        fs.rmSync(config.sessionDir, { recursive: true, force: true });
      } else if (status === DisconnectReason.connectionReplaced) {
        console.log('⚠️ This WhatsApp number was opened somewhere else (another copy of the bot?). Make sure only ONE copy is running. Reconnecting...');
      } else {
        console.log(`Connection closed (code ${status}). Reconnecting...`);
      }
      clearTimeout(reconnectTimer);
      reconnectTimer = setTimeout(() => startWhatsApp().catch(console.error), 3000);
    }
  });

  sock.ev.on('messages.upsert', ({ messages, type }) => {
    if (!alive() || type !== 'notify') return;
    for (const msg of messages) {
      if (replay.isReplay(msg)) {
        diag.stats.replaysIgnored += 1;
        continue;
      }
      enqueue(msg.key.remoteJid || 'unknown', async () => {
        try {
          await withTimeout(handleMessage(sock, msg), 60000, 'Handling a message took too long');
        } catch (err) {
          console.error('Message error:', err);
        }
      });
    }
  });

  sock.ev.on('group-participants.update', async (update) => {
    if (!alive()) return;
    try {
      await handleParticipants(sock, update);
    } catch (err) {
      console.error('Group event error:', err);
    }
  });

  sock.ev.on('groups.update', (updates) => {
    if (!alive()) return;
    for (const u of updates || []) if (u.id) meta.invalidate(u.id);
  });
}

module.exports = { startWhatsApp };
