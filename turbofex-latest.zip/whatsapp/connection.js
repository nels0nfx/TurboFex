const fs = require('fs');
const path = require('path');
const pino = require('pino');
const qrcode = require('qrcode-terminal');
const baileys = require('../core/baileys');
const config = require('../config');
const brand = require('../core/brand');
const scheduler = require('../core/scheduler');
const meta = require('./metadata');
const { withTimeout } = require('./timeout');
const { handleMessage, diag } = require('./handler');
const { handleParticipants } = require('./events');
const sent = require('./sent');
const outbox = require('./outbox');
const idmap = require('./idmap');
const watchers = require('./watchers');
const store = require('./store');
const { getText, isCommandText } = require('./utils');
const startup = require('./startup');
const ack = require('./ack');
const { makeCache } = require('../core/cache');
const replay = require('./replay');
const welcome = require('./welcome');
const status = require('./status');

let generation = 0; // only the newest connection may do anything
let current = null;
let reconnectTimer = null;
let attempts = 0; // failed connection attempts in a row (the wait between attempts grows, so we never hammer WhatsApp)
let watchdog = null;
const queues = new Map(); // one line of waiting messages per chat

const FRESH_SECONDS = 120; // a message that arrived while the bot was reconnecting is still answered if it is this young

// how the bot shows up in Linked devices (only used when linking). 'android' can receive view-once files.
function pickBrowser(Browsers) {
  const want = String(store.getBrowser() || config.browser || process.env.BOT_BROWSER || '').toLowerCase();
  if (want === 'android') {
    const a = Browsers.android;
    try {
      if (typeof a === 'function') return a('Chrome');
      if (Array.isArray(a)) return a;
    } catch (err) {
      // fall through
    }
    console.log('⚠️ This WhatsApp library has no "android" identity. Using the default one.');
  }
  if (want === 'macos' && Browsers.macOS) return Browsers.macOS('Desktop');
  if (want === 'windows' && Browsers.windows) return Browsers.windows('Chrome');
  return Browsers.ubuntu('Chrome');
}

// Checks every minute that WhatsApp still answers. A connection can die silently (the bot looks online but hears
// nothing): that is the "bot sleeps" problem. Two missed answers in a row = reconnect at once.
function startWatchdog(sock, alive) {
  stopWatchdog();
  let misses = 0;
  watchdog = setInterval(async () => {
    if (!alive()) return stopWatchdog();
    try {
      await withTimeout(
        sock.query({ tag: 'iq', attrs: { to: 's.whatsapp.net', type: 'get', xmlns: 'w:p' }, content: [{ tag: 'ping', attrs: {} }] }),
        20000,
        'ping timed out'
      );
      misses = 0;
    } catch (err) {
      misses += 1;
      console.log(`⚠️ WhatsApp did not answer a health check (${misses}/2): ${err.message}`);
      if (misses >= 2) {
        misses = 0;
        console.log('🔌 The connection stopped answering. Reconnecting...');
        try {
          sock.end(new Error('Watchdog: connection stopped answering'));
        } catch (e) {
          // already closed
        }
      }
    }
  }, 60000);
  if (watchdog.unref) watchdog.unref();
}

function stopWatchdog() {
  if (watchdog) clearInterval(watchdog);
  watchdog = null;
}

const isFresh = (msg) => {
  const ts = replay.timestampOf(msg);
  return ts > 0 && Date.now() / 1000 - ts < FRESH_SECONDS;
};

// messages of ONE chat are handled in order, different chats never wait for each other
function enqueue(jid, task) {
  const previous = queues.get(jid) || Promise.resolve();
  const next = previous.then(task).catch(() => {}).finally(() => {
    if (queues.get(jid) === next) queues.delete(jid);
  });
  queues.set(jid, next);
}

async function startWhatsApp() {
  const lib = await baileys.load(); // works with the old and the new library version
  const { makeWASocket, useMultiFileAuthState, DisconnectReason, Browsers } = lib;
  const cacheKeys = lib.makeCacheableSignalKeyStore || ((keys) => keys); // keeps encryption keys in memory (much faster on slow disks)

  const gen = ++generation;
  clearTimeout(reconnectTimer);
  stopWatchdog();
  // never keep two connections open (two copies fight each other and cause "Bad MAC")
  if (current) {
    try {
      current.ev.removeAllListeners();
      current.end(undefined);
    } catch (err) {
      // already closed
    }
    current = null;
  }

  const { state, saveCreds } = await useMultiFileAuthState(config.sessionDir);
  if (gen !== generation) return;

  const logger = pino({ level: 'silent' });
  const sock = makeWASocket({
    auth: { creds: state.creds, keys: cacheKeys(state.keys, logger) },
    logger,
    browser: pickBrowser(Browsers),
    markOnlineOnConnect: false,
    syncFullHistory: false,
    keepAliveIntervalMs: 25000, // WhatsApp is pinged more often, so a dead connection is noticed sooner
    getMessage: async (key) => outbox.get(key), // lets WhatsApp ask for a message again ("Waiting for this message" fix)
    userDevicesCache: makeCache(30 * 60 * 1000), // who has which devices: remembered for 30 min (faster group replies)
    msgRetryCounterCache: makeCache(10 * 60 * 1000),
    cachedGroupMetadata: async (jid) => meta.getMeta(sock, jid),
  });
  current = sock;
  const alive = () => gen === generation;
  ack.installStatusAck(sock); // stops WhatsApp from cutting the connection about every 50 minutes

  // remember the ids of our own replies so we never answer ourselves
  const rawSend = sock.sendMessage.bind(sock);
  sock.sendMessage = async (...args) => {
    // a private chat is addressed the way WhatsApp itself addresses that person (LID when known). Messages sent to
    // the phone number of such a person show "Waiting for this message" on many phones.
    if (typeof args[0] === 'string' && args[0].endsWith('@s.whatsapp.net') && !args[2]?.statusJidList) {
      args[0] = idmap.lidSync(args[0]) || args[0];
    }
    const res = await rawSend(...args);
    if (res?.key?.id) sent.remember(res.key.id);
    outbox.remember(res);
    return res;
  };

  sock.ev.on('creds.update', () => {
    if (alive()) Promise.resolve(saveCreds()).catch((e) => console.error('Could not save the login:', e.message));
  });

  let pairingAsked = false;

  sock.ev.on('connection.update', async (update) => {
    if (!alive()) return;
    const { connection, lastDisconnect, qr } = update;

    if (qr) {
      if (config.pairingNumber) {
        if (!pairingAsked && !sock.authState.creds.registered) {
          pairingAsked = true;
          try {
            const raw = await sock.requestPairingCode(config.pairingNumber);
            const code = raw?.match(/.{1,4}/g)?.join('-') || raw;
            console.log('\n==============================================');
            console.log(`  YOUR PAIRING CODE:  ${code}`);
            console.log('  WhatsApp > Linked devices > Link a device >');
            console.log('  "Link with phone number instead" > enter code');
            console.log('==============================================\n');
          } catch (err) {
            pairingAsked = false;
            console.log('Could not get a pairing code:', err.message);
          }
        }
      } else {
        console.log('\nScan this QR code: WhatsApp > Linked devices > Link a device\n');
        qrcode.generate(qr, { small: true });
      }
    }

    if (connection === 'open') {
      console.log(`✅ ${brand.botName} is online as ${sock.user?.id}`);
      scheduler.start(sock);
      replay.open(); // for a few seconds, skip old messages WhatsApp re-delivers
      startWatchdog(sock, alive);
      const stable = setTimeout(() => {
        if (alive()) attempts = 0; // connected for a while: forget earlier failures
      }, 30000);
      if (stable.unref) stable.unref();

      // load the group list once, so the first command in a group never waits for WhatsApp
      setTimeout(async () => {
        if (!alive()) return;
        try {
          const all = await withTimeout(sock.groupFetchAllParticipating(), 30000, 'group list timed out');
          meta.prime(all);
        } catch (err) {
          // not important: groups are loaded one by one when needed
        }
      }, 3000);

      // an update that was just installed leaves a marker: turn it into an "update complete" note (once)
      startup.noteFromUpdateMarker();
      // the first time an account connects it gets a welcome message; after a restart or update it gets a short "I am back" message
      setTimeout(async () => {
        if (!alive()) return;
        try {
          await welcome.maybeSendWelcome(sock);
        } catch (e) {
          console.error('Welcome message error:', e.message);
        }
        try {
          if (alive()) await startup.announce(sock);
        } catch (e) {
          console.error('Restart message error:', e.message);
        }
      }, welcome.settings.delayMs);
      // The bot started fine, so a fresh update does not need to be rolled back
      try {
        fs.rmSync(path.join(__dirname, '..', 'data', 'rollback', 'pending'), { force: true });
      } catch (err) {
        // ignore
      }
    }

    if (connection === 'close') {
      scheduler.stop();
      stopWatchdog();
      const status = lastDisconnect?.error?.output?.statusCode;
      let delay;
      attempts += 1;
      if (status === DisconnectReason.loggedOut) {
        console.log('Logged out of WhatsApp. Clearing saved login, starting fresh...');
        fs.rmSync(config.sessionDir, { recursive: true, force: true });
        attempts = 0;
        delay = 3000;
      } else if (status === DisconnectReason.connectionReplaced) {
        // another copy of the bot is using this number. Fighting it makes both copies reconnect forever and makes
        // WhatsApp send the "Finished syncing" notification again and again, so wait longer each time.
        delay = Math.min(300000, 30000 * 2 ** Math.min(attempts - 1, 3));
        console.log(`⚠️ This WhatsApp number was opened somewhere else (another copy of the bot?). Make sure only ONE copy is running. Trying again in ${Math.round(delay / 1000)}s.`);
      } else if (status === DisconnectReason.restartRequired) {
        attempts = 0;
        delay = 500; // normal after linking: reconnect straight away
        console.log('Reconnecting after WhatsApp asked for a restart...');
      } else {
        delay = Math.min(30000, 2000 * 2 ** Math.min(attempts - 1, 4)) + Math.random() * 1000;
        console.log(`Connection closed (code ${status}). Reconnecting in ${Math.round(delay / 1000)}s...`);
      }
      clearTimeout(reconnectTimer);
      reconnectTimer = setTimeout(() => startWhatsApp().catch((e) => {
        console.error('Reconnect failed:', e.message);
        reconnectTimer = setTimeout(() => startWhatsApp().catch(console.error), 10000);
      }), delay);
    }
  });

  sock.ev.on('messages.upsert', ({ messages, type }) => {
    if (!alive()) return;
    const prefix = store.effectivePrefix();
    for (const msg of messages) {
      // WhatsApp statuses (auto view / like / save)
      if (msg.key.remoteJid === 'status@broadcast') {
        status.handleStatus(sock, msg).catch((e) => console.error('Status error:', e.message));
        continue;
      }
      // 'append' = messages that were waiting while the bot reconnected. Fresh ones are still answered (before, they were dropped).
      if (type !== 'notify' && !(type === 'append' && !msg.key.fromMe && isFresh(msg))) continue;
      if (replay.isReplay(msg)) {
        diag.stats.replaysIgnored += 1;
        continue;
      }
      const run = async () => {
        try {
          await withTimeout(handleMessage(sock, msg), 60000, 'Handling a message took too long');
        } catch (err) {
          console.error('Message error:', err);
        }
      };
      // commands never wait for other messages; everything else (game answers...) stays in order per chat
      if (isCommandText(getText(msg), prefix)) run();
      else enqueue(msg.key.remoteJid || 'unknown', run);
    }
  });

  // edits and deletions that WhatsApp reports as updates
  sock.ev.on('messages.update', (updates) => {
    if (!alive()) return;
    watchers.onUpdate(sock, updates).catch((e) => console.error('Update watcher error:', e.message));
  });

  // learn which phone number belongs to which hidden id
  const learn = (list) => {
    try {
      idmap.learnContacts(list);
    } catch (err) {
      // not important
    }
  };
  sock.ev.on('contacts.upsert', (list) => alive() && learn(list));
  sock.ev.on('contacts.update', (list) => alive() && learn(list));
  sock.ev.on('lid-mapping.update', (m) => alive() && idmap.learn(m?.lid, m?.pn));

  sock.ev.on('group-participants.update', async (update) => {
    if (!alive()) return;
    try {
      await handleParticipants(sock, update);
    } catch (err) {
      console.error('Group event error:', err);
    }
  });

  sock.ev.on('groups.update', (updates) => {
    if (!alive()) return;
    for (const u of updates || []) if (u.id) meta.invalidate(u.id);
  });
}

module.exports = { startWhatsApp };
