// Blocks / unblocks a person. WhatsApp sometimes wants the phone-number form of the id and
// sometimes the LID form, so every known form is tried until one works.
async function setBlock(sock, candidates, action) {
  let lastError = null;
  for (const id of candidates) {
    try {
      await sock.updateBlockStatus(id, action);
      return { ok: true, used: id };
    } catch (err) {
      lastError = err;
    }
  }
  return { ok: false, error: lastError };
}

module.exports = { setBlock };
