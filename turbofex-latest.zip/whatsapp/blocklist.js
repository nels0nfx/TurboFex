// Blocks / unblocks a person. WhatsApp changed how this works for accounts that use "LID" ids,
// so several request shapes are tried until one is accepted.
const isLid = (j) => String(j).endsWith('@lid');
const isPn = (j) => String(j).endsWith('@s.whatsapp.net');

async function pnFor(sock, lid) {
  try {
    const pn = await sock.signalRepository?.lidMapping?.getPNForLID?.(lid);
    return pn && isPn(pn) ? pn : null;
  } catch (err) {
    return null;
  }
}

async function lidFor(sock, pn) {
  try {
    const lid = await sock.signalRepository?.lidMapping?.getLIDForPN?.(pn);
    if (lid && isLid(lid)) return lid;
  } catch (err) {
    // try the next way
  }
  try {
    const res = await sock.onWhatsApp(pn);
    const lid = res?.[0]?.lid;
    return lid && isLid(lid) ? lid : null;
  } catch (err) {
    return null;
  }
}

// ids = every jid we know for the person (phone form and/or LID form)
async function setBlock(sock, ids, action) {
  let lid = ids.find(isLid);
  let pn = ids.find(isPn);
  if (lid && !pn) pn = await pnFor(sock, lid);
  if (pn && !lid) lid = await lidFor(sock, pn);

  const iq = (attrs) => () =>
    sock.query({
      tag: 'iq',
      attrs: { xmlns: 'blocklist', to: 's.whatsapp.net', type: 'set' },
      content: [{ tag: 'item', attrs: { action, ...attrs } }],
    });

  const attempts = [];
  if (lid && pn) attempts.push(['LID + number', iq({ jid: lid, pn_jid: pn })]);
  if (pn) attempts.push(['number', iq({ jid: pn })]);
  if (lid) attempts.push(['LID', iq({ jid: lid })]);
  for (const id of [lid, pn].filter(Boolean)) attempts.push([`library ${isLid(id) ? 'LID' : 'number'}`, () => sock.updateBlockStatus(id, action)]);

  const tried = [];
  let lastError = null;
  for (const [name, run] of attempts) {
    try {
      await run();
      return { ok: true, used: name, tried: [...tried, name] };
    } catch (err) {
      tried.push(name);
      lastError = err;
    }
  }
  return { ok: false, error: lastError, tried };
}

module.exports = { setBlock };
