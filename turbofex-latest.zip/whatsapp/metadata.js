// Remembers group details so a command never has to wait for WhatsApp.
//  - fresh (under 5 min): used straight away
//  - older: still used straight away, and refreshed in the background
//  - after a group change (promote, kick...): the next command refreshes first, but if WhatsApp is slow the old answer is used
const { withTimeout } = require('./timeout');

const cache = new Map(); // jid -> { t, meta, hard }
const refreshing = new Map(); // jid -> promise
const FRESH = 5 * 60 * 1000;
const USABLE = 6 * 3600 * 1000; // an old answer is better than waiting
const SLOW = 8000; // when a refresh is needed first, wait at most this long if we have an older answer

function fetchFresh(sock, jid) {
  if (refreshing.has(jid)) return refreshing.get(jid);
  const p = withTimeout(sock.groupMetadata(jid), 15000, 'WhatsApp took too long to send the group info')
    .then((meta) => {
      cache.set(jid, { t: Date.now(), meta, hard: false });
      return meta;
    })
    .finally(() => refreshing.delete(jid));
  refreshing.set(jid, p);
  p.catch(() => {}); // a failed background refresh is not an error
  return p;
}

async function getMeta(sock, jid) {
  const hit = cache.get(jid);
  const age = hit ? Date.now() - hit.t : Infinity;

  if (hit && !hit.hard && age < FRESH) return hit.meta;

  if (hit && !hit.hard && age < USABLE) {
    fetchFresh(sock, jid); // refresh quietly, answer now
    return hit.meta;
  }

  const pending = fetchFresh(sock, jid);
  if (hit) {
    // changed group: try to get the new info, but never keep the person waiting for long
    try {
      return await withTimeout(pending, SLOW, 'slow');
    } catch (err) {
      return hit.meta;
    }
  }
  return pending;
}

// the group changed: the next command asks WhatsApp again (the old answer is only a fallback)
function invalidate(jid) {
  const hit = cache.get(jid);
  if (hit) hit.hard = true;
}

// fill the cache from the list of all groups (done once after connecting)
function prime(all) {
  let n = 0;
  for (const g of Object.values(all || {})) {
    if (g && g.id && Array.isArray(g.participants)) {
      cache.set(g.id, { t: Date.now(), meta: g, hard: false });
      n += 1;
    }
  }
  return n;
}

const size = () => cache.size;

module.exports = { getMeta, invalidate, prime, size };
