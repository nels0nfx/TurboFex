// Remembers group details for a few seconds so WhatsApp isn't asked on every message
const cache = new Map();
const TTL = 20000;

async function getMeta(sock, jid) {
  const hit = cache.get(jid);
  if (hit && Date.now() - hit.t < TTL) return hit.meta;
  const meta = await sock.groupMetadata(jid);
  cache.set(jid, { t: Date.now(), meta });
  return meta;
}

function invalidate(jid) {
  cache.delete(jid);
}

module.exports = { getMeta, invalidate };
