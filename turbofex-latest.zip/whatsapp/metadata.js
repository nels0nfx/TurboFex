// Remembers group details for a few seconds so WhatsApp isn't asked on every message
const { withTimeout } = require('./timeout');

const cache = new Map();
const TTL = 5 * 60 * 1000; // group events (joins, promotions, edits) refresh it earlier

async function getMeta(sock, jid) {
  const hit = cache.get(jid);
  if (hit && Date.now() - hit.t < TTL) return hit.meta;
  try {
    const meta = await withTimeout(sock.groupMetadata(jid), 15000, 'WhatsApp took too long to send the group info');
    cache.set(jid, { t: Date.now(), meta });
    return meta;
  } catch (err) {
    if (hit) return hit.meta; // an older answer is better than none
    throw err;
  }
}

// marks the remembered answer as old (it is still used if WhatsApp does not answer)
function invalidate(jid) {
  const hit = cache.get(jid);
  if (hit) hit.t = 0;
}

module.exports = { getMeta, invalidate };
