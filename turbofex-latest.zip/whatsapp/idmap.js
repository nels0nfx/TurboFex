// WhatsApp hides phone numbers behind "LID" ids in many chats. Every group member's list shows both,
// so the groups this account is in are used to translate one into the other.
const { withTimeout } = require('./timeout');
const { num } = require('./utils');

const isLid = (j) => String(j).endsWith('@lid');
const isPn = (j) => String(j).endsWith('@s.whatsapp.net');
const TTL = 10 * 60 * 1000;

let cache = { at: 0, lidToPn: new Map(), pnToLid: new Map() };

async function load(sock) {
  if (Date.now() - cache.at < TTL && cache.lidToPn.size) return;
  const fresh = { at: Date.now(), lidToPn: new Map(), pnToLid: new Map() };
  try {
    const all = await withTimeout(sock.groupFetchAllParticipating(), 30000, 'group list timed out');
    for (const g of Object.values(all)) {
      for (const p of g.participants || []) {
        const ids = [p.id, p.lid, p.jid, p.phoneNumber].filter(Boolean);
        const lid = ids.find(isLid);
        const pn = ids.find(isPn);
        if (lid && pn) {
          fresh.lidToPn.set(num(lid), pn);
          fresh.pnToLid.set(num(pn), lid);
        }
      }
    }
    cache = fresh;
  } catch (err) {
    cache.at = Date.now() - TTL + 30000; // try again in 30 seconds
  }
}

async function pnFor(sock, lid) {
  await load(sock);
  return cache.lidToPn.get(num(lid)) || null;
}

async function lidFor(sock, pn) {
  await load(sock);
  return cache.pnToLid.get(num(pn)) || null;
}

module.exports = { pnFor, lidFor, isLid, isPn };
