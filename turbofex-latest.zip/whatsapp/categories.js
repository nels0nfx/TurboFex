// MENU CATEGORIES
// Every command file declares its own category, for example:  category: 'group',
// The menu builds itself from that (commands are listed A-Z inside each category).
// Categories with no commands stay hidden. A command without a valid category is
// shown under OTHER and the bot prints a warning at startup.
const info = {
  general: { title: 'GENERAL', icon: '⚡' },
  group: { title: 'GROUP', icon: '👥' },
  autoreply: { title: 'AUTOREPLY', icon: '💬' },
  tools: { title: 'TOOLS', icon: '🧰' },
  fun: { title: 'FUN', icon: '🎮' },
  budget: { title: 'BUDGET', icon: '💰' },
  media: { title: 'MEDIA', icon: '🎬' },
  owner: { title: 'OWNER', icon: '👑' },
  other: { title: 'OTHER', icon: '📦' },
};

// Returns [{ key, meta, cmds }] in menu order. Owner-only commands are hidden from non-owners.
function groupByCategory(commandList, isOwner) {
  const visible = commandList.filter((c) => isOwner || !(c.ownerOnly || c.realOwnerOnly));
  const groups = {};
  for (const c of visible) {
    const key = info[c.category] ? c.category : 'other';
    (groups[key] = groups[key] || []).push(c);
  }
  return Object.keys(info)
    .filter((k) => groups[k])
    .map((k) => ({
      key: k,
      meta: info[k],
      cmds: groups[k].sort((a, b) => a.name.localeCompare(b.name)),
    }));
}

module.exports = { info, groupByCategory };
