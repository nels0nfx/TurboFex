// HOW THE MENU IS ORGANISED
// Every command belongs in a meaningful category. When you add a command, put its
// name in the right list in "layout" below (the order here is the order in the menu).
// Categories with no commands are hidden, so unused ones cost nothing.
// If a command is missing from this file the bot prints a warning when it starts.
const info = {
  general: { title: 'GENERAL', icon: '⚡' },
  group: { title: 'GROUP', icon: '👥' },
  tools: { title: 'TOOLS', icon: '🧰' },
  fun: { title: 'FUN', icon: '🎮' },
  media: { title: 'MEDIA', icon: '🎬' },
  ai: { title: 'AI', icon: '🤖' },
  owner: { title: 'OWNER', icon: '👑' },
  other: { title: 'OTHER', icon: '📦' }, // only appears if a command was never categorised
};

const layout = {
  general: ['menu', 'ping'],
  group: [
    // info and tagging
    'groupinfo', 'tagall',
    // members
    'kick', 'promote', 'demote',
    // moderation
    'warn', 'warnings', 'resetwarn', 'warnlimit', 'antilink',
    // group settings
    'open', 'close',
    'welcome', 'setwelcome', 'goodbye', 'setgoodbye',
  ],
  tools: [],
  fun: [],
  media: [],
  ai: [],
  owner: ['mode', 'update', 'autoupdate', 'restart'],
};

const map = {}; // command name -> category
const rank = {}; // command name -> position inside its category
for (const [cat, names] of Object.entries(layout)) {
  names.forEach((name, i) => {
    map[name] = cat;
    rank[name] = i;
  });
}

module.exports = { info, map, rank };
