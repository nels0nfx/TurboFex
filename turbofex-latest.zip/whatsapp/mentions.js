// Makes tags show the person's NAME. WhatsApp shows "@Name" only when the tag uses the same kind of id the group uses for
// that member (new groups use hidden "LID" ids, older ones phone numbers). A tag with the other kind shows a bare number
// such as @245771534381197. This rewrites every tag of a message sent to a group (both the hidden list and the @number in
// the text) to the id the group itself uses.
const meta = require('./metadata');
const names = require('./names');
const { num, participantIds } = require('./utils');

const esc = (s) => s.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');

async function fix(sock, groupJid, content) {
  try {
    if (!content || !Array.isArray(content.mentions) || !content.mentions.length) return content;
    const info = await meta.getMeta(sock, groupJid);
    const members = info?.participants || [];
    if (!members.length) return content;

    const swaps = new Map(); // old number -> number the group uses
    const ids = content.mentions.map((m) => {
      const n = num(m);
      const p = members.find((x) => participantIds(x).includes(n));
      if (!p || !p.id) return m;
      if (num(p.id) !== n) swaps.set(n, num(p.id));
      return p.id;
    });
    if (!swaps.size) return { ...content, mentions: ids };

    const rewrite = (t) => {
      if (typeof t !== 'string') return t;
      let out = t;
      for (const [from, to] of swaps) out = out.replace(new RegExp(`@${esc(from)}(?!\\d)`, 'g'), `@${to}`);
      return out;
    };
    const next = { ...content, mentions: [...new Set(ids)] };
    if ('text' in next) next.text = rewrite(next.text);
    if ('caption' in next) next.caption = rewrite(next.caption);
    return next;
  } catch (err) {
    return content; // the message is sent as it is: a tag that shows a number is better than no message
  }
}

// In a private chat a tag only shows a number, so the person's name is written in the text instead (no tag)
function inPrivate(content) {
  try {
    if (!content || !Array.isArray(content.mentions) || !content.mentions.length) return content;
    let changed = false;
    const rewrite = (t) => {
      if (typeof t !== 'string') return t;
      let out = t;
      for (const m of content.mentions) {
        const n = num(m);
        const name = names.get(m);
        const label = name ? `*${name}*` : names.phoneOf(m) ? `*${names.phoneOf(m)}*` : null;
        if (!label) continue;
        const next = out.replace(new RegExp(`@${esc(n)}(?!\\d)`, 'g'), label);
        if (next !== out) changed = true;
        out = next;
      }
      return out;
    };
    const next = { ...content };
    if ('text' in next) next.text = rewrite(next.text);
    if ('caption' in next) next.caption = rewrite(next.caption);
    return changed ? { ...next, mentions: [] } : content;
  } catch (err) {
    return content;
  }
}

module.exports = { fix, inPrivate };
