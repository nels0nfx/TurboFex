// Gives the plain text replies of commands WhatsApp formatting: a bold title, bold labels, symbol bullets and
// commands in monospace. Replies that are already formatted by the command (they contain *, _ or `) are left alone,
// and so are commands whose reply is the content itself (fun, games, media, text tools...).
const SKIP_NAMES = new Set([
  'fancy', 'reverse', 'base64', 'hash', 'password', 'random', 'choose', 'coin', 'dice', 'calc', 'convert', 'tagall', 'hidetag',
  'say', 'echo', 'poll', 'play', 'qr', 'translate', 'tr', 'define', 'quote', 'summary', 'menu', 'list',
]);
const SKIP_CATEGORIES = new Set(['fun', 'games', 'media', 'audio', 'video', 'editor']);

const ALREADY = /[*_`~]|^>/m;
const EMOJI_START = /^(\p{Extended_Pictographic}|[✅❌⚠️ℹ️▸•◦✦])/u;

function applies(cmd) {
  return !!cmd && cmd.format !== false && !SKIP_NAMES.has(cmd.name) && !SKIP_CATEGORIES.has(cmd.category);
}

// isCmd(name) -> true when name is a real command (only those get the monospace treatment)
function format(text, isCmd, prefix) {
  if (typeof text !== 'string' || !text.trim() || ALREADY.test(text) || text.length > 3500) return text;
  const lines = text.split('\n');
  const esc = prefix.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  const inline = new RegExp(`(^|[\\s(])(${esc}[a-z0-9]{2,20})(?=$|[\\s).,:;!?])`, 'gi');
  let titled = false;

  const out = lines.map((raw, i) => {
    let line = raw;
    // title: the first short line without a final full stop
    if (i === 0 && lines.length > 1 && line.length <= 70 && !/[.?]$/.test(line) && EMOJI_START.test(line)) {
      titled = true;
      return `*${line.replace(/:$/, '')}*`;
    }
    // bullets
    line = line.replace(/^(\s*)[-•]\s+/, '$1▸ ');
    // "Label: value" -> "*Label:* value" (keeps a leading emoji)
    const m = /^(\s*(?:▸\s+)?(?:\p{Extended_Pictographic}\uFE0F?\s+)?)([A-Za-z][A-Za-z0-9 /()'-]{1,26}):\s+(\S.*)$/u.exec(line);
    if (m && m[2].trim().split(/\s+/).length <= 4 && !/^https?$/i.test(m[2])) line = `${m[1]}*${m[2]}:* ${m[3]}`;
    // commands that really exist: `.name`
    line = line.replace(inline, (all, pre, token) => (isCmd(token.slice(prefix.length).toLowerCase()) ? `${pre}\`${token}\`` : all));
    return line;
  });
  return titled || out.join('\n') !== text ? out.join('\n') : text;
}

module.exports = { format, applies };
