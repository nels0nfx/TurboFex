// Runs the chat games. One game per chat, in groups and in private chats, open to everybody.
// Quiz-style games play several rounds in a row by themselves, with a scoreboard at the end.
const { num, whoIds, whoJid } = require('../utils');
const ttt = require('./ttt');
const guess = require('./guess');
const hangman = require('./hangman');
const scramble = require('./scramble');
const trivia = require('./trivia');
const mathquiz = require('./mathquiz');

const handlers = { ttt, guess, hangman, scramble, trivia, mathquiz };
const active = new Map();
const EXPIRE_MS = 10 * 60 * 1000; // a game nobody touches for 10 minutes disappears
const settings = { pauseMs: 2500 }; // pause between rounds (changed only by tests)

function get(jid) {
  const g = active.get(jid);
  if (g && Date.now() - g.t > EXPIRE_MS) {
    end(jid);
    return null;
  }
  return g || null;
}

function end(jid) {
  const g = active.get(jid);
  if (g) clearTimeout(g.timer);
  active.delete(jid);
}

const busyText = (prefix) => `⚠️ A game is already running in this chat. Finish it, or type ${prefix}endgame`;

// "trivia 8" -> 8 rounds (1 to 20), nothing given -> the default
function parseRounds(args, fallback = 5) {
  const n = args.map((a) => parseInt(a, 10)).find((x) => Number.isInteger(x));
  return n ? Math.min(20, Math.max(1, n)) : fallback;
}

// Who may end the game: whoever started it, or a player in tic-tac-toe
function canEnd(game, ids) {
  if (ids.some((i) => game.starter.includes(i))) return true;
  return game.type === 'ttt' && (ttt.isPlayer(game.x, ids) || ttt.isPlayer(game.o, ids));
}

function standings(s) {
  const rows = Object.values(s.scores).sort((a, b) => b.n - a.n);
  if (!rows.length) return 'Nobody scored yet.';
  return rows.map((r, i) => `${['🥇', '🥈', '🥉'][i] || '▫️'} @${num(r.jid)} - ${r.n}`).join('\n');
}

function roundHeader(g) {
  const s = g.series;
  const rows = Object.values(s.scores).sort((a, b) => b.n - a.n);
  const line = rows.length ? `\nScores: ${rows.map((r) => `@${num(r.jid)} ${r.n}`).join(' • ')}` : '';
  return `🔔 *Round ${s.round}/${s.total}*${line}`;
}

// Starts a game. rounds > 1 makes it a series that continues by itself.
function start({ sock, jid, game, starterIds, rounds = 1, options = {} }) {
  const g = {
    ...game, opts: options, starter: starterIds || [], t: Date.now(), activity: false,
    roundId: 1, waiting: false, timer: null,
    series: rounds > 1 ? { total: rounds, round: 1, scores: {}, idle: 0 } : null,
  };
  active.set(jid, g);
  arm(sock, jid, g);
  return g;
}

// each round has a time limit; when it runs out the answer is shown and play continues
function arm(sock, jid, g) {
  clearTimeout(g.timer);
  const h = handlers[g.type];
  if (!h.timeoutMs) return;
  const roundId = g.roundId;
  g.timer = setTimeout(() => {
    onTimeout(sock, jid, g, roundId).catch((e) => console.error('Game timer error:', e.message));
  }, h.timeoutMs);
  if (g.timer.unref) g.timer.unref();
}

async function onTimeout(sock, jid, g, roundId) {
  if (active.get(jid) !== g || g.roundId !== roundId || g.waiting) return;
  await sock.sendMessage(jid, { text: `⌛ Time's up! ${handlers[g.type].reveal(g)}` });
  await finishRound(sock, jid, g, null);
}

// Called when a round is over (winner = who won it, or null)
async function finishRound(sock, jid, g, winner) {
  clearTimeout(g.timer);
  const s = g.series;
  if (!s) return end(jid);
  if (active.get(jid) !== g || g.waiting) return;

  if (winner) {
    const key = winner.ids[0] || winner.jid;
    s.scores[key] = s.scores[key] || { jid: winner.jid, n: 0 };
    s.scores[key].n += 1;
  }
  s.idle = g.activity ? 0 : s.idle + 1;
  const players = Object.values(s.scores).map((r) => r.jid);

  if (s.idle >= 2) {
    end(jid);
    return sock.sendMessage(jid, { text: `😴 Nobody is playing, so I stopped the game.\n\n${standings(s)}`, mentions: players });
  }
  if (s.round >= s.total) {
    end(jid);
    return sock.sendMessage(jid, { text: `🏁 *Game over!*\n\n${standings(s)}`, mentions: players });
  }

  g.waiting = true; // answers are ignored during the short pause
  setTimeout(() => {
    nextRound(sock, jid, g).catch((e) => console.error('Next round error:', e.message));
  }, settings.pauseMs);
}

async function nextRound(sock, jid, g) {
  if (active.get(jid) !== g) return;
  const h = handlers[g.type];
  g.series.round += 1;
  g.roundId += 1;
  Object.assign(g, h.create(g.opts));
  g.waiting = false;
  g.activity = false;
  g.t = Date.now();
  arm(sock, jid, g);
  await sock.sendMessage(jid, { text: `${roundHeader(g)}\n\n${h.intro(g)}` });
}

// Passes a normal chat message to the game running in that chat
async function route({ sock, msg, jid, text, botIds }) {
  const game = get(jid);
  const handler = game && handlers[game.type];
  if (!handler || game.waiting) return;
  const who = { ids: whoIds(msg, botIds), jid: whoJid(msg, sock) };
  const send = (t, mentions = []) => sock.sendMessage(jid, { text: t, mentions }, { quoted: msg });
  await handler.onMessage({
    game, text: text.trim(), who, send, sock, jid, botIds,
    end: (winner) => finishRound(sock, jid, game, winner),
    touch: () => {
      game.t = Date.now();
      game.activity = true;
    },
  });
}

const seriesNote = (g, prefix) => (g.series ? `\n\n🔁 ${g.series.total} rounds in a row. Type ${prefix}endgame to stop.` : '');

module.exports = {
  get, start, end, busyText, canEnd, parseRounds, seriesNote, route, settings,
  ttt, guess, hangman, scramble, trivia, mathquiz,
};
