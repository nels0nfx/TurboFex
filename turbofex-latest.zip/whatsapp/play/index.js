// Runs the chat games. Only one game can run in a chat at a time, in groups and in private chats.
const { whoIds, whoJid } = require('../utils');
const ttt = require('./ttt');
const guess = require('./guess');
const hangman = require('./hangman');
const scramble = require('./scramble');
const trivia = require('./trivia');
const mathquiz = require('./mathquiz');

const handlers = { ttt, guess, hangman, scramble, trivia, mathquiz };
const active = new Map();
const EXPIRE_MS = 10 * 60 * 1000;

function get(jid) {
  const g = active.get(jid);
  if (g && Date.now() - g.t > EXPIRE_MS) {
    active.delete(jid);
    return null;
  }
  return g || null;
}

// starterIds = who started it (they can end it)
function begin(jid, game, starterIds) {
  const g = { ...game, starter: starterIds || [], t: Date.now() };
  active.set(jid, g);
  return g;
}

function end(jid) {
  active.delete(jid);
}

const busyText = (prefix) => `⚠️ A game is already running in this chat. Finish it, or type ${prefix}endgame`;

// Who may end the game: whoever started it, or a player in tic-tac-toe
function canEnd(game, ids) {
  if (ids.some((i) => game.starter.includes(i))) return true;
  return game.type === 'ttt' && (ttt.isPlayer(game.x, ids) || ttt.isPlayer(game.o, ids));
}

// Passes a normal chat message to the game running in that chat
async function route({ sock, msg, jid, text, botIds }) {
  const game = get(jid);
  const handler = game && handlers[game.type];
  if (!handler) return;
  const who = { ids: whoIds(msg, botIds), jid: whoJid(msg, sock) };
  const send = (t, mentions = []) => sock.sendMessage(jid, { text: t, mentions }, { quoted: msg });
  await handler.onMessage({
    game, text: text.trim(), who, send, sock, jid, botIds,
    end: () => end(jid),
    touch: () => {
      game.t = Date.now();
    },
  });
}

module.exports = { get, begin, end, busyText, canEnd, route, ttt, guess, hangman, scramble, trivia, mathquiz };
