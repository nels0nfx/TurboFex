const fs = require('fs');
const path = require('path');

const dir = path.join(__dirname, '..', 'data');
const file = path.join(dir, 'seen.json');
const MAX = 400;

let list = [];
try {
  list = JSON.parse(fs.readFileSync(file, 'utf8'));
  if (!Array.isArray(list)) list = [];
} catch (err) {
  list = [];
}
const set = new Set(list);
let dirty = false;

function saveNow() {
  if (!dirty) return;
  try {
    fs.mkdirSync(dir, { recursive: true });
    fs.writeFileSync(file, JSON.stringify([...set]));
    dirty = false;
  } catch (err) {
    // not important
  }
}

setInterval(saveNow, 3000).unref();
process.on('exit', saveNow);

// Returns true if this message was already handled, otherwise remembers it
function check(jid, id) {
  if (!id) return false;
  const key = `${jid}|${id}`;
  if (set.has(key)) return true;
  set.add(key);
  if (set.size > MAX) set.delete(set.values().next().value);
  dirty = true;
  return false;
}

module.exports = { check, saveNow };
