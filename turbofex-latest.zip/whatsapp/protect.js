const store = require('./store');
const { peel } = require('./unwrap');
const { enforce } = require('./moderation');

const LINK_REGEX =
  /(https?:\/\/\S+|www\.\S+|chat\.whatsapp\.com\/\S+|wa\.me\/\S+|t\.me\/\S+|discord\.gg\/\S+)/i;

const SPAM_COUNT = 6; // this many messages...
const SPAM_SECONDS = 8; // ...within this many seconds counts as spam
const hits = new Map();

function isSpam(jid, sender) {
  const key = `${jid}|${sender}`;
  const now = Date.now();
  const list = (hits.get(key) || []).filter((t) => now - t < SPAM_SECONDS * 1000);
  list.push(now);
  if (list.length >= SPAM_COUNT) {
    hits.delete(key);
    return true;
  }
  hits.set(key, list);
  if (hits.size > 5000) hits.clear();
  return false;
}

// Does the message contain one of these WhatsApp message types (also inside wrappers)?
function hasType(obj, names, depth = 3) {
  if (!obj || typeof obj !== 'object' || depth < 0) return false;
  for (const k of Object.keys(obj)) {
    if (names.includes(k) && obj[k]) return true;
    if (depth > 0 && obj[k] && typeof obj[k] === 'object' && hasType(obj[k], names, depth - 1)) return true;
  }
  return false;
}

// which kind of media does a message hold? (also inside wrappers)
const MEDIA_KINDS = { stickerMessage: 'sticker', imageMessage: 'image', videoMessage: 'video', audioMessage: 'audio', documentMessage: 'document', ptvMessage: 'video' };
function mediaKindOf(message) {
  const { content } = peel(message);
  for (const [key, kind] of Object.entries(MEDIA_KINDS)) if (content[key]) return kind;
  return null;
}

// slow mode: when did each member last write? (a message that is too soon is deleted)
const lastPost = new Map();
function tooSoon(jid, sender, seconds) {
  if (!seconds) return false;
  const key = `${jid}|${sender}`;
  const now = Date.now();
  if (now - (lastPost.get(key) || 0) < seconds * 1000) return true;
  lastPost.set(key, now);
  if (lastPost.size > 20000) lastPost.clear();
  return false;
}

// a short notice, at most once in a while per person, so a flood of deleted messages is not answered with a flood of notices
const noticed = new Map();
async function notice(sock, jid, sender, text) {
  const key = `${jid}|${sender}`;
  if (Date.now() - (noticed.get(key) || 0) < 30000) return;
  noticed.set(key, Date.now());
  if (noticed.size > 5000) noticed.clear();
  try {
    await sock.sendMessage(jid, { text, mentions: [sender] });
  } catch (err) {
    // the message was deleted already: the notice is a courtesy
  }
}

const GROUP_MENTION = ['groupStatusMentionMessage']; // "X mentioned this group in a status"
const GROUP_POST = ['groupStatusMessage', 'groupStatusMessageV2']; // a status posted inside the group

const escapeRegex = (s) => s.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');

function findBadWord(text, words) {
  if (!words.length) return null;
  const lower = text.toLowerCase();
  return (
    words.find((w) =>
      new RegExp(`(^|[^\\p{L}\\p{N}])${escapeRegex(w)}($|[^\\p{L}\\p{N}])`, 'u').test(lower)
    ) || null
  );
}

// Returns true if the message broke a rule and was dealt with
async function runProtections({ sock, msg, jid, text, getRoles }) {
  const sender = msg.key.participant;
  if (!sender) return false;
  const g = store.getGroup(jid);

  const hasLink = g.antilinkMode !== 'off' && text && LINK_REGEX.test(text);
  const badWord = g.antiwordMode !== 'off' && text ? findBadWord(text, g.badWords) : null;
  const spam = g.antispam ? isSpam(jid, sender) : false;
  const groupMention = g.antigmMode !== 'off' && hasType(msg.message, GROUP_MENTION);
  const groupPost = g.antigstatusMode !== 'off' && hasType(msg.message, GROUP_POST);
  const media = Object.values(g.antimedia).some(Boolean) ? mediaKindOf(msg.message) : null;
  const blockedMedia = media && g.antimedia[media] ? media : null;
  const slow = g.slowmode ? tooSoon(jid, sender, g.slowmode) : false;
  if (!hasLink && !badWord && !spam && !groupMention && !groupPost && !blockedMedia && !slow) return false;

  const roles = await getRoles();
  if (!roles.isBotAdmin || roles.isAdmin || roles.isOwner) return false;

  if (blockedMedia) {
    await enforce({ sock, jid, sender, msg, mode: 'delete', reason: `sending a ${blockedMedia}`, rule: '' });
    await notice(sock, jid, sender, `🚫 @${String(sender).split('@')[0].split(':')[0]}, ${blockedMedia === 'audio' ? 'voice notes and audio are' : `${blockedMedia}s are`} not allowed in this group.`);
    return true;
  }
  if (slow) {
    await enforce({ sock, jid, sender, msg, mode: 'delete', reason: 'writing too fast', rule: '' });
    await notice(sock, jid, sender, `⏳ @${String(sender).split('@')[0].split(':')[0]}, slow mode is on: please wait ${g.slowmode} seconds between messages.`);
    return true;
  }
  if (groupMention) {
    await enforce({ sock, jid, sender, msg, mode: g.antigmMode, reason: 'mentioning the group in a status', rule: 'mentioning this group in a status is not allowed here' });
    return true;
  }
  if (groupPost) {
    await enforce({ sock, jid, sender, msg, mode: g.antigstatusMode, reason: 'posting a group status', rule: 'group status posts are not allowed here' });
    return true;
  }
  if (hasLink) {
    await enforce({ sock, jid, sender, msg, mode: g.antilinkMode, reason: 'sending a link', rule: 'links are not allowed here' });
    return true;
  }
  if (badWord) {
    await enforce({ sock, jid, sender, msg, mode: g.antiwordMode, reason: 'using a banned word', rule: 'banned words are not allowed here' });
    return true;
  }
  await enforce({ sock, jid, sender, msg, mode: 'warn', reason: 'spamming', rule: 'please do not spam', deleteMessage: false });
  return true;
}

module.exports = { mediaKindOf, runProtections, LINK_REGEX, findBadWord, hasType, GROUP_MENTION, GROUP_POST };
