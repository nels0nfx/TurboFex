const store = require('./store');
const { enforce } = require('./moderation');

const LINK_REGEX =
  /(https?:\/\/\S+|www\.\S+|chat\.whatsapp\.com\/\S+|wa\.me\/\S+|t\.me\/\S+|discord\.gg\/\S+)/i;

const SPAM_COUNT = 6; // this many messages...
const SPAM_SECONDS = 8; // ...within this many seconds counts as spam
const hits = new Map();

function isSpam(jid, sender) {
  const key = `${jid}|${sender}`;
  const now = Date.now();
  const list = (hits.get(key) || []).filter((t) => now - t < SPAM_SECONDS * 1000);
  list.push(now);
  if (list.length >= SPAM_COUNT) {
    hits.delete(key);
    return true;
  }
  hits.set(key, list);
  if (hits.size > 5000) hits.clear();
  return false;
}

const escapeRegex = (s) => s.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');

function findBadWord(text, words) {
  if (!words.length) return null;
  const lower = text.toLowerCase();
  return (
    words.find((w) =>
      new RegExp(`(^|[^\\p{L}\\p{N}])${escapeRegex(w)}($|[^\\p{L}\\p{N}])`, 'u').test(lower)
    ) || null
  );
}

// Returns true if the message broke a rule and was dealt with
async function runProtections({ sock, msg, jid, text, getRoles }) {
  const sender = msg.key.participant;
  if (!sender) return false;
  const g = store.getGroup(jid);

  const hasLink = g.antilinkMode !== 'off' && text && LINK_REGEX.test(text);
  const badWord = g.antiwordMode !== 'off' && text ? findBadWord(text, g.badWords) : null;
  const spam = g.antispam ? isSpam(jid, sender) : false;
  if (!hasLink && !badWord && !spam) return false;

  const roles = await getRoles();
  if (!roles.isBotAdmin || roles.isAdmin || roles.isOwner) return false;

  if (hasLink) {
    await enforce({ sock, jid, sender, msg, mode: g.antilinkMode, reason: 'sending a link' });
    return true;
  }
  if (badWord) {
    await enforce({ sock, jid, sender, msg, mode: g.antiwordMode, reason: 'using a banned word' });
    return true;
  }
  await enforce({ sock, jid, sender, msg, mode: 'warn', reason: 'spamming', deleteMessage: false });
  return true;
}

module.exports = { runProtections, LINK_REGEX, findBadWord };
