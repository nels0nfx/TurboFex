// WhatsApp Status: auto view, auto like (react) and auto save, with a natural delay
const store = require('./store');
const seen = require('./seen');
const media = require('./media');
const clock = require('../core/clock');
const { ownerChat, normalize } = require('./owner');
const idmap = require('./idmap');
const ack = require('./ack');
const { num, selfJid } = require('./utils');

const settings = { minimumDelayMs: 0 }; // tests can shorten delays
const stats = { seen: 0, viewed: 0, liked: 0, saved: 0, errors: 0, rejected: 0, route: '-', lagSec: null, last: null, lastError: null }; // shown by !statusinfo

const rand = (a, b) => (b > a ? a + Math.random() * (b - a) : a);
const pick = (list) => list[Math.floor(Math.random() * list.length)];

async function saveStatus(sock, msg, to, who) {
  const m = media.unwrap(msg.message) || {};
  const header = `📥 *Status saved*\n👤 From @${num(who)}\n🕒 ${clock.stamp(Date.now())}`;
  const mentions = who ? [who] : [];
  if (m.imageMessage || m.videoMessage || m.audioMessage) {
    const buffer = await media.download(sock, msg);
    if (m.imageMessage) return sock.sendMessage(to, { image: buffer, caption: `${header}${m.imageMessage.caption ? `\n\n${m.imageMessage.caption}` : ''}`, mentions });
    if (m.videoMessage) return sock.sendMessage(to, { video: buffer, caption: `${header}${m.videoMessage.caption ? `\n\n${m.videoMessage.caption}` : ''}`, mentions });
    await sock.sendMessage(to, { text: header, mentions });
    return sock.sendMessage(to, { audio: buffer, mimetype: m.audioMessage.mimetype || 'audio/ogg; codecs=opus', ptt: !!m.audioMessage.ptt });
  }
  const text = m.conversation || m.extendedTextMessage?.text;
  if (text) return sock.sendMessage(to, { text: `${header}\n\n${text}`, mentions });
}

const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const within = (promise, ms, label) =>
  Promise.race([promise, new Promise((_, rej) => setTimeout(() => rej(new Error(`${label} timed out`)), ms))]);

// Marks a status as viewed IN A WAY THE POSTER CAN SEE.
// sock.readMessages() only tells the poster when the bot account has "read receipts" on; otherwise it sends a private
// "read-self" receipt. So the real "read" receipt is sent directly (it is instant), and readMessages() runs in the
// background afterwards so the bot's own devices know it was seen. Nothing here can hold up the like.
async function markViewed(sock, msg, who) {
  const key = msg.key;
  let lastErr = null;
  let ok = false;
  for (const p of [...new Set([who, key.participantPn, key.participantAlt].filter(Boolean))]) {
    try {
      await within(sock.sendReceipt('status@broadcast', p, [key.id], 'read'), 8000, 'view receipt');
      ok = true;
      break;
    } catch (err) {
      lastErr = err;
    }
  }
  within(sock.readMessages([key]), 10000, 'readMessages').catch(() => {}); // background, never awaited
  if (!ok) throw lastErr || new Error('could not mark the status as viewed');
}

// Reacts to a status.
// Route 1 (the normal way): a message to status@broadcast with the poster on the list.
//   Problem: on accounts WhatsApp moved to "LID" addresses, some library versions get this REFUSED (error 479) while
//   looking successful. So the answer from WhatsApp is read, and when it says "refused":
// Route 2: the reaction is sent straight to the poster. Route 1 is then skipped for a while (saves time).
let route1BrokenUntil = 0;

async function react(sock, to, key, emoji, opts) {
  const id = ack.newId(sock);
  const answer = ack.listen(sock, id);
  await within(sock.sendMessage(to, { react: { key, text: emoji } }, { ...opts, ...(id ? { messageId: id } : {}) }), 20000, 'like');
  return answer();
}

async function likeStatus(sock, msg, who, emoji) {
  const key = msg.key;
  const me = selfJid(sock);

  if (Date.now() > route1BrokenUntil) {
    const lists = [[who, key.participantPn, key.participantAlt, me], [who, me]].map((l) => [...new Set(l.filter(Boolean))]);
    for (const list of lists) {
      try {
        const r = await react(sock, 'status@broadcast', key, emoji, { statusJidList: list });
        if (r.ok !== false) {
          stats.route = 'status';
          return;
        }
        stats.rejected += 1;
        console.log(`⚠️ WhatsApp refused the like sent to the status list (error ${r.error}).`);
        break; // other lists fail the same way
      } catch (err) {
        // try the next list
      }
    }
    route1BrokenUntil = Date.now() + 30 * 60 * 1000;
  }

  // route 2: straight to the poster, in the address form WhatsApp uses for him
  const poster = idmap.isLid(who) ? who : idmap.lidSync(who) || who;
  const r = await react(sock, poster, key, emoji, {});
  if (r.ok === false) {
    stats.rejected += 1;
    throw new Error(`WhatsApp refused the like (error ${r.error}). This is a known problem of the WhatsApp library with some accounts.`);
  }
  stats.route = 'direct';
}

// statuses are handled a few at a time: after a reconnect WhatsApp can hand over dozens at once, and sending
// views and likes for all of them together made everything slow
const MAX_PARALLEL = 3;
const waiting = [];
let running = 0;
function schedule(job) {
  waiting.push(job);
  pump();
}
function pump() {
  while (running < MAX_PARALLEL && waiting.length) {
    const job = waiting.shift();
    running += 1;
    job().catch(() => {}).finally(() => {
      running -= 1;
      pump();
    });
  }
}

async function handleStatus(sock, msg) {
  const cfg = store.statusCfg();
  if (!cfg.view && !cfg.like && !cfg.save) return;
  if (msg.key.fromMe || !msg.message || msg.message.protocolMessage) return; // our own status, or a status being deleted
  if (seen.statuses.check('status', msg.key.id)) return; // never twice, also after a restart

  const who = msg.key.participant || msg.participant;
  if (!who) return;
  const posted = Number(msg.messageTimestamp?.low ?? msg.messageTimestamp) || 0;
  if (posted && Date.now() / 1000 - posted > 24 * 3600) return; // older than a day: it has expired anyway
  stats.lagSec = posted ? Math.max(0, Math.round(Date.now() / 1000 - posted)) : null; // how long WhatsApp took to bring it to the bot
  stats.seen += 1;
  stats.last = Date.now();
  console.log(`📢 Status from ${num(who)} (${[cfg.view && 'view', cfg.like && 'like', cfg.save && 'save'].filter(Boolean).join(', ')})`);
  const fail = (what, err) => {
    stats.errors += 1;
    stats.lastError = `${what}: ${String(err?.message || err).slice(0, 80)}`;
    console.error(`Status ${what} failed:`, err?.message || err);
  };
  const wait = Math.max(settings.minimumDelayMs, rand(cfg.delayMin, cfg.delayMax) * 1000);
  const run = async () => {
    // view and like start together: the receipt goes out first, the like follows a split second later
    const viewing =
      cfg.view || cfg.like
        ? markViewed(sock, msg, who).then(
            () => {
              stats.viewed += 1;
            },
            (err) => fail('view', err)
          )
        : Promise.resolve();
    if (cfg.like) {
      await sleep(settings.likeGapMs ?? 300 + Math.random() * 400);
      try {
        await likeStatus(sock, msg, who, pick(cfg.emojis));
        stats.liked += 1;
        console.log(`❤️ Liked the status of ${num(who)}`);
      } catch (err) {
        fail('like', err);
      }
    }
    await viewing;
    if (cfg.save) {
      try {
        await saveStatus(sock, msg, normalize(sock, cfg.saveTo) || ownerChat(sock), who);
        stats.saved += 1;
      } catch (err) {
        fail('save', err);
      }
    }
  };
  const job = () => run().catch((e) => fail('status', e));
  if (wait > 0) {
    const t = setTimeout(() => schedule(job), wait);
    if (t.unref) t.unref();
  } else {
    schedule(job);
  }
}

module.exports = { handleStatus, settings, stats, markViewed, likeStatus };
