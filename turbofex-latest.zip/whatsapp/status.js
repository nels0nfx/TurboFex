// WhatsApp Status: auto view, auto like (react) and auto save, with a natural delay
const store = require('./store');
const seen = require('./seen');
const media = require('./media');
const clock = require('../core/clock');
const { ownerChat } = require('./owner');
const { num, selfJid } = require('./utils');

const settings = { minimumDelayMs: 0 }; // tests can shorten delays
const stats = { seen: 0, viewed: 0, liked: 0, saved: 0, errors: 0, last: null, lastError: null }; // shown by !statusinfo

const rand = (a, b) => (b > a ? a + Math.random() * (b - a) : a);
const pick = (list) => list[Math.floor(Math.random() * list.length)];

async function saveStatus(sock, msg, to, who) {
  const m = media.unwrap(msg.message) || {};
  const header = `📥 *Status saved*\n👤 From @${num(who)}\n🕒 ${clock.stamp(Date.now())}`;
  const mentions = who ? [who] : [];
  if (m.imageMessage || m.videoMessage || m.audioMessage) {
    const buffer = await media.download(sock, msg);
    if (m.imageMessage) return sock.sendMessage(to, { image: buffer, caption: `${header}${m.imageMessage.caption ? `\n\n${m.imageMessage.caption}` : ''}`, mentions });
    if (m.videoMessage) return sock.sendMessage(to, { video: buffer, caption: `${header}${m.videoMessage.caption ? `\n\n${m.videoMessage.caption}` : ''}`, mentions });
    await sock.sendMessage(to, { text: header, mentions });
    return sock.sendMessage(to, { audio: buffer, mimetype: m.audioMessage.mimetype || 'audio/ogg; codecs=opus', ptt: !!m.audioMessage.ptt });
  }
  const text = m.conversation || m.extendedTextMessage?.text;
  if (text) return sock.sendMessage(to, { text: `${header}\n\n${text}`, mentions });
}

async function handleStatus(sock, msg) {
  const cfg = store.statusCfg();
  if (!cfg.view && !cfg.like && !cfg.save) return;
  if (msg.key.fromMe || !msg.message || msg.message.protocolMessage) return; // our own status, or a status being deleted
  if (seen.statuses.check('status', msg.key.id)) return; // never twice, also after a restart

  const who = msg.key.participant || msg.participant;
  stats.seen += 1;
  stats.last = Date.now();
  console.log(`📢 Status from ${num(who)} (${[cfg.view && 'view', cfg.like && 'like', cfg.save && 'save'].filter(Boolean).join(', ')})`);
  const fail = (what, err) => {
    stats.errors += 1;
    stats.lastError = `${what}: ${String(err?.message || err).slice(0, 80)}`;
    console.error(`Status ${what} failed:`, err?.message || err);
  };
  const wait = Math.max(settings.minimumDelayMs, rand(cfg.delayMin, cfg.delayMax) * 1000);
  const run = async () => {
    if (cfg.view) {
      try {
        await sock.readMessages([msg.key]);
        stats.viewed += 1;
      } catch (err) {
        try {
          await sock.sendReceipt('status@broadcast', who, [msg.key.id], 'read'); // the plain way
          stats.viewed += 1;
        } catch (err2) {
          fail('view', err2);
        }
      }
    }
    if (cfg.like) {
      try {
        // the status owner (in both of his id forms) and ourselves must be on the list
        const list = [...new Set([who, msg.key.participantPn, msg.key.participantAlt, selfJid(sock)].filter(Boolean))];
        await sock.sendMessage('status@broadcast', { react: { key: msg.key, text: pick(cfg.emojis) } }, { statusJidList: list });
        stats.liked += 1;
      } catch (err) {
        fail('like', err);
      }
    }
    if (cfg.save) {
      try {
        await saveStatus(sock, msg, cfg.saveTo || ownerChat(sock), who);
        stats.saved += 1;
      } catch (err) {
        fail('save', err);
      }
    }
  };
  if (wait > 0) {
    const t = setTimeout(run, wait);
    if (t.unref) t.unref();
  } else {
    await run();
  }
}

module.exports = { handleStatus, settings, stats };
