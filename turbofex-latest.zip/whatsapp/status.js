// WhatsApp Status: auto view, auto like (react) and auto save, with a natural delay
const store = require('./store');
const seen = require('./seen');
const media = require('./media');
const clock = require('../core/clock');
const { ownerChat } = require('./owner');
const { num, selfJid } = require('./utils');

const settings = { minimumDelayMs: 0 }; // tests can shorten delays

const rand = (a, b) => (b > a ? a + Math.random() * (b - a) : a);
const pick = (list) => list[Math.floor(Math.random() * list.length)];

async function saveStatus(sock, msg, to, who) {
  const m = media.unwrap(msg.message) || {};
  const header = `📥 *Status saved*\n👤 From @${num(who)}\n🕒 ${clock.stamp(Date.now())}`;
  const mentions = who ? [who] : [];
  if (m.imageMessage || m.videoMessage || m.audioMessage) {
    const buffer = await media.download(sock, msg);
    if (m.imageMessage) return sock.sendMessage(to, { image: buffer, caption: `${header}${m.imageMessage.caption ? `\n\n${m.imageMessage.caption}` : ''}`, mentions });
    if (m.videoMessage) return sock.sendMessage(to, { video: buffer, caption: `${header}${m.videoMessage.caption ? `\n\n${m.videoMessage.caption}` : ''}`, mentions });
    await sock.sendMessage(to, { text: header, mentions });
    return sock.sendMessage(to, { audio: buffer, mimetype: m.audioMessage.mimetype || 'audio/ogg; codecs=opus', ptt: !!m.audioMessage.ptt });
  }
  const text = m.conversation || m.extendedTextMessage?.text;
  if (text) return sock.sendMessage(to, { text: `${header}\n\n${text}`, mentions });
}

async function handleStatus(sock, msg) {
  const cfg = store.statusCfg();
  if (!cfg.view && !cfg.like && !cfg.save) return;
  if (msg.key.fromMe || !msg.message || msg.message.protocolMessage) return; // our own status, or a status being deleted
  if (seen.statuses.check('status', msg.key.id)) return; // never twice, also after a restart

  const who = msg.key.participant || msg.participant;
  const wait = Math.max(settings.minimumDelayMs, rand(cfg.delayMin, cfg.delayMax) * 1000);
  const run = async () => {
    try {
      if (cfg.view) await sock.readMessages([msg.key]);
      if (cfg.like) {
        await sock.sendMessage(
          'status@broadcast',
          { react: { key: msg.key, text: pick(cfg.emojis) } },
          { statusJidList: [who, selfJid(sock)].filter(Boolean) }
        );
      }
      if (cfg.save) await saveStatus(sock, msg, cfg.saveTo || ownerChat(sock), who);
    } catch (err) {
      console.error('Status action failed:', err.message);
    }
  };
  if (wait > 0) {
    const t = setTimeout(run, wait);
    if (t.unref) t.unref();
  } else {
    await run();
  }
}

module.exports = { handleStatus, settings };
