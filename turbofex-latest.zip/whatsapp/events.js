const store = require('./store');
const meta = require('./metadata');
const { num } = require('./utils');

// Fills in @user, {group} and {count} in the saved message
function render(template, jid, name, count) {
  return template
    .replace(/@user/gi, () => `@${num(jid)}`)
    .replace(/\{group\}/gi, () => name)
    .replace(/\{count\}/gi, () => String(count ?? ''));
}

// Runs when people join, leave, or are promoted / demoted
async function handleParticipants(sock, update) {
  const { id, participants, action, author } = update;
  meta.invalidate(id);

  const g = store.getGroup(id);
  const botIds = [sock.user?.id, sock.user?.lid].filter(Boolean).map(num);
  const ids = (participants || [])
    .map((p) => (typeof p === 'string' ? p : p?.id))
    .filter(Boolean)
    .filter((j) => !botIds.includes(num(j)));
  if (!ids.length) return;

  // Promote / demote notices
  if (action === 'promote' || action === 'demote') {
    if (!g.pdm) return;
    const by = author ? ` by @${num(author)}` : '';
    const text = ids
      .map((j) => `${action === 'promote' ? '👑' : '⬇️'} @${num(j)} was ${action === 'promote' ? 'promoted to admin' : 'demoted'}${by}.`)
      .join('\n');
    return sock.sendMessage(id, { text, mentions: [...ids, ...(author ? [author] : [])] });
  }

  if (action !== 'add' && action !== 'remove') return;

  let removed = [];
  if (action === 'add' && g.antifake.length) {
    // Anti-fake: only numbers starting with the allowed country codes may join
    const bad = ids.filter(
      (j) => j.endsWith('@s.whatsapp.net') && !g.antifake.some((p) => num(j).startsWith(p))
    );
    if (bad.length) {
      try {
        await sock.groupParticipantsUpdate(id, bad, 'remove');
        removed = bad;
        meta.invalidate(id);
        await sock.sendMessage(id, {
          text: `🚫 Removed ${bad.map((j) => '@' + num(j)).join(' ')}: numbers from other countries are not allowed here.`,
          mentions: bad,
        });
      } catch (err) {
        // the bot is not an admin, nothing we can do
      }
    }
  }

  if (action === 'add' && !g.welcome) return;
  if (action === 'remove' && !g.goodbye) return;

  let info = null;
  try {
    info = await meta.getMeta(sock, id);
  } catch (err) {
    info = null;
  }
  const name = info?.subject || 'the group';
  const count = info?.participants?.length;
  const template =
    action === 'add'
      ? g.welcomeText || store.DEFAULT_WELCOME
      : g.goodbyeText || store.DEFAULT_GOODBYE;

  for (const j of ids.filter((x) => !removed.includes(x))) {
    await sock.sendMessage(id, { text: render(template, j, name, count), mentions: [j] });
  }
}

module.exports = { handleParticipants };
