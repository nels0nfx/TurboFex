// Auto view-once, anti-delete and anti-edit. Each has a mode (off / all / dm / group) and its own destination chat.
const store = require('./store');
const cache = require('./msgcache');
const meta = require('./metadata');
const clock = require('../core/clock');
const media = require('./media');
const { ownerChat } = require('./owner');
const { getText, getInner, num } = require('./utils');

const MAX_MEDIA = 3 * 1024 * 1024; // pictures/videos bigger than this are not kept for anti-delete

const inScope = (mode, isGroup) => mode === 'all' || (mode === 'dm' && !isGroup) || (mode === 'group' && isGroup);

// finds a view-once picture, video or voice note
function findViewOnce(message) {
  const wrap = message.viewOnceMessage || message.viewOnceMessageV2 || message.viewOnceMessageV2Extension;
  const inner = wrap?.message || message;
  for (const key of ['imageMessage', 'videoMessage', 'audioMessage']) {
    const node = inner[key];
    if (node && (wrap || node.viewOnce)) return { kind: key.replace('Message', ''), node };
  }
  return null;
}

async function chatName(sock, jid) {
  if (!jid.endsWith('@g.us')) return 'a private chat';
  try {
    return `the group "${(await meta.getMeta(sock, jid)).subject}"`;
  } catch (err) {
    return 'a group';
  }
}

const tagOf = (jid) => `@${num(jid)}`;
const typeIs = (t, number, name) => t === number || t === name;

// text of any message (also pictures/videos with a caption)
function textOf(message) {
  const m = getInner({ message }) || {};
  return m.conversation || m.extendedTextMessage?.text || m.imageMessage?.caption || m.videoMessage?.caption || m.documentMessage?.caption || '';
}

function kindName(message) {
  const m = getInner({ message }) || {};
  if (m.imageMessage) return 'picture';
  if (m.videoMessage) return 'video';
  if (m.audioMessage) return m.audioMessage.ptt ? 'voice note' : 'audio';
  if (m.stickerMessage) return 'sticker';
  if (m.documentMessage) return 'document';
  return null;
}

async function sendCopy(sock, to, item, header) {
  const caption = `${header}${item.text ? `\n\n${item.text}` : ''}`;
  const mentions = item.sender ? [item.sender] : [];
  if (item.buffer && item.kind) {
    const mime = item.mime;
    if (item.kind === 'picture') return sock.sendMessage(to, { image: item.buffer, caption, mentions });
    if (item.kind === 'video') return sock.sendMessage(to, { video: item.buffer, caption, mentions });
    if (item.kind === 'sticker') {
      await sock.sendMessage(to, { text: header, mentions });
      return sock.sendMessage(to, { sticker: item.buffer });
    }
    if (item.kind === 'voice note' || item.kind === 'audio') {
      await sock.sendMessage(to, { text: header, mentions });
      return sock.sendMessage(to, { audio: item.buffer, mimetype: mime || 'audio/ogg; codecs=opus', ptt: item.kind === 'voice note' });
    }
  }
  const note = item.kind ? `\n(the ${item.kind} was too big or could not be saved)` : '';
  return sock.sendMessage(to, { text: `${caption}${note}`, mentions });
}

// ---------------------------------------------------------------- view once
async function viewOnce(sock, msg, isGroup) {
  const cfg = store.watchCfg('viewonce');
  if (!inScope(cfg.mode, isGroup)) return;
  const vo = findViewOnce(msg.message);
  if (!vo) return;
  const jid = msg.key.remoteJid;
  const sender = isGroup ? msg.key.participant : jid;
  const buffer = await media.download(sock, msg);
  const header = `👁️ *View-once ${vo.kind === 'audio' ? (vo.node.ptt ? 'voice note' : 'audio') : vo.kind === 'image' ? 'picture' : 'video'}*\n👤 From ${tagOf(sender)} in ${await chatName(sock, jid)}\n🕒 ${clock.stamp(Date.now())}`;
  await sendCopy(sock, cfg.to || ownerChat(sock), {
    kind: vo.kind === 'image' ? 'picture' : vo.kind === 'video' ? 'video' : vo.node.ptt ? 'voice note' : 'audio',
    buffer, mime: vo.node.mimetype, text: vo.node.caption || '', sender,
  }, header);
}

// ---------------------------------------------------------------- remember messages for anti-delete / anti-edit
async function remember(sock, msg, isGroup) {
  const del = store.watchCfg('delete');
  const edit = store.watchCfg('edit');
  const wantDel = inScope(del.mode, isGroup);
  const wantEdit = inScope(edit.mode, isGroup);
  if (!wantDel && !wantEdit) return;

  const message = msg.message;
  const kind = kindName(message);
  const item = {
    jid: msg.key.remoteJid, sender: isGroup ? msg.key.participant : msg.key.remoteJid,
    text: textOf(message), kind, ts: Number(msg.messageTimestamp) || 0,
  };
  cache.remember(msg.key.id, item); // text is kept at once, media follows when it is downloaded

  if (wantDel && kind && kind !== 'document') {
    const inner = getInner({ message }) || {};
    const node = inner.imageMessage || inner.videoMessage || inner.audioMessage || inner.stickerMessage;
    const size = Number(node?.fileLength?.low ?? node?.fileLength) || 0;
    if (size && size > MAX_MEDIA) return;
    try {
      const buffer = await media.download(sock, msg);
      if (buffer.length <= MAX_MEDIA) cache.remember(msg.key.id, { ...item, buffer, mime: node?.mimetype });
    } catch (err) {
      // the text is still kept
    }
  }
}

// ---------------------------------------------------------------- deleted / edited
async function deleted(sock, msg, pm, isGroup) {
  const cfg = store.watchCfg('delete');
  if (!inScope(cfg.mode, isGroup)) return;
  const it = cache.get(pm.key?.id);
  if (!it) return; // we never saw the original
  const jid = msg.key.remoteJid;
  const deleter = isGroup ? msg.key.participant : jid;
  const by = deleter && it.sender && num(deleter) !== num(it.sender) ? `\n🧹 Deleted by ${tagOf(deleter)}` : '';
  const header = `🗑️ *Deleted message*\n👤 From ${tagOf(it.sender)} in ${await chatName(sock, jid)}${by}\n🕒 Sent ${it.ts ? clock.stamp(it.ts * 1000) : 'earlier'}`;
  await sendCopy(sock, cfg.to || ownerChat(sock), it, header);
  cache.drop(pm.key.id);
}

async function edited(sock, msg, pm, isGroup) {
  const cfg = store.watchCfg('edit');
  if (!inScope(cfg.mode, isGroup)) return;
  const id = pm.key?.id;
  const it = cache.get(id);
  const after = textOf(pm.editedMessage || {});
  if (!after) return;
  const jid = msg.key.remoteJid;
  const sender = it?.sender || (isGroup ? msg.key.participant : jid);
  const before = it?.text || '(I did not see the original text)';
  if (before === after) return;
  const header = `✏️ *Edited message*\n👤 ${tagOf(sender)} in ${await chatName(sock, jid)}\n🕒 ${clock.stamp(Date.now())}`;
  await sock.sendMessage(cfg.to || ownerChat(sock), { text: `${header}\n\n*Before:*\n${before}\n\n*After:*\n${after}`, mentions: [sender] });
  if (it) cache.remember(id, { ...it, text: after });
}

// called for every incoming message
async function run(sock, msg) {
  const message = msg.message;
  if (!message) return;
  const jid = msg.key.remoteJid;
  if (!jid || jid.endsWith('@broadcast') || jid.endsWith('@newsletter')) return;
  const isGroup = jid.endsWith('@g.us');

  const pm = message.protocolMessage || message.ephemeralMessage?.message?.protocolMessage;
  if (pm) {
    if (msg.key.fromMe) return;
    if (typeIs(pm.type, 0, 'REVOKE')) return deleted(sock, msg, pm, isGroup);
    if (typeIs(pm.type, 14, 'MESSAGE_EDIT')) return edited(sock, msg, pm, isGroup);
    return;
  }
  if (msg.key.fromMe) return;

  await Promise.all([
    viewOnce(sock, msg, isGroup).catch((e) => console.error('View-once error:', e.message)),
    remember(sock, msg, isGroup).catch(() => {}),
  ]);
}

module.exports = { run, findViewOnce, inScope };
