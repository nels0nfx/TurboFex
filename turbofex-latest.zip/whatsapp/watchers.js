// Auto view-once, anti-delete and anti-edit. Each has a mode (off / all / dm / group) and its own destination chat.
const store = require('./store');
const cache = require('./msgcache');
const meta = require('./metadata');
const clock = require('../core/clock');
const media = require('./media');
const { ownerChat } = require('./owner');
const { getInner, num } = require('./utils');

const MAX_MEDIA = 3 * 1024 * 1024; // pictures/videos bigger than this are not kept for anti-delete

const inScope = (mode, isGroup) => mode === 'all' || (mode === 'dm' && !isGroup) || (mode === 'group' && isGroup);
const typeIs = (t, number, name) => t === number || t === name;
const tagOf = (jid) => `@${num(jid)}`;
const handled = new Map(); // finished deletions / edits (the same event can arrive twice)

function once(key) {
  const now = Date.now();
  if (now - (handled.get(key) || 0) < 60000) return false;
  handled.set(key, now);
  if (handled.size > 2000) handled.clear();
  return true;
}

// finds a view-once picture, video or voice note
function findViewOnce(message) {
  const wrap = message.viewOnceMessage || message.viewOnceMessageV2 || message.viewOnceMessageV2Extension;
  const inner = wrap?.message || message;
  for (const key of ['imageMessage', 'videoMessage', 'audioMessage']) {
    const node = inner[key];
    if (node && (wrap || node.viewOnce)) return { kind: key.replace('Message', ''), node };
  }
  return null;
}

async function chatName(sock, jid) {
  if (!jid.endsWith('@g.us')) return 'a private chat';
  try {
    return `the group "${(await meta.getMeta(sock, jid)).subject}"`;
  } catch (err) {
    return 'a group';
  }
}

// text of any message (also pictures/videos with a caption)
function textOf(message) {
  const m = getInner({ message }) || {};
  return m.conversation || m.extendedTextMessage?.text || m.imageMessage?.caption || m.videoMessage?.caption || m.documentMessage?.caption || '';
}

function kindName(message) {
  const m = getInner({ message }) || {};
  if (m.imageMessage) return 'picture';
  if (m.videoMessage) return 'video';
  if (m.audioMessage) return m.audioMessage.ptt ? 'voice note' : 'audio';
  if (m.stickerMessage) return 'sticker';
  if (m.documentMessage) return 'document';
  return null;
}

// the original message as a "reply", so the copy points back to the chat it came from
function quotedOriginal(item, id) {
  const group = String(item.jid).endsWith('@g.us');
  return {
    key: { remoteJid: item.jid, fromMe: false, id, ...(group ? { participant: item.sender } : {}) },
    message: item.message || { conversation: item.text || '' },
  };
}

async function sendCopy(sock, to, item, header, quoted) {
  const caption = `${header}${item.text ? `\n\n${item.text}` : ''}`;
  const mentions = [...new Set([item.sender, ...(item.mentions || [])].filter(Boolean))];
  const opts = quoted ? { quoted } : undefined;
  if (item.buffer && item.kind) {
    if (item.kind === 'picture') return sock.sendMessage(to, { image: item.buffer, caption, mentions }, opts);
    if (item.kind === 'video') return sock.sendMessage(to, { video: item.buffer, caption, mentions }, opts);
    if (item.kind === 'sticker') {
      await sock.sendMessage(to, { text: header, mentions }, opts);
      return sock.sendMessage(to, { sticker: item.buffer });
    }
    if (item.kind === 'voice note' || item.kind === 'audio') {
      await sock.sendMessage(to, { text: header, mentions }, opts);
      return sock.sendMessage(to, { audio: item.buffer, mimetype: item.mime || 'audio/ogg; codecs=opus', ptt: item.kind === 'voice note' });
    }
  }
  const note = item.kind ? `\n(the ${item.kind} was too big or could not be saved)` : '';
  return sock.sendMessage(to, { text: `${caption}${note}`, mentions }, opts);
}

// when something fails the owner is told, instead of silence (at most once a minute)
let lastWarn = 0;
async function warnOwner(sock, text) {
  if (Date.now() - lastWarn < 60000) return;
  lastWarn = Date.now();
  try {
    await sock.sendMessage(ownerChat(sock), { text });
  } catch (err) {
    // nothing more we can do
  }
}

// ---------------------------------------------------------------- view once
async function viewOnce(sock, msg, isGroup) {
  const cfg = store.watchCfg('viewonce');
  if (!inScope(cfg.mode, isGroup)) return;
  const vo = findViewOnce(msg.message);
  if (!vo) return;
  const jid = msg.key.remoteJid;
  const sender = isGroup ? msg.key.participant : jid;
  const kind = vo.kind === 'image' ? 'picture' : vo.kind === 'video' ? 'video' : vo.node.ptt ? 'voice note' : 'audio';
  const where = await chatName(sock, jid);
  let buffer;
  try {
    buffer = await media.download(sock, msg);
  } catch (err) {
    console.error('View-once download failed:', err.message);
    return warnOwner(sock, `👁️ A view-once ${kind} from ${tagOf(sender)} arrived in ${where}, but WhatsApp would not let me save it.\nReason: ${String(err.message).slice(0, 100)}\n(Some phones only allow view-once media to be opened on the phone itself.)`);
  }
  const header = `👁️ *View-once ${kind}*\n👤 From ${tagOf(sender)} in ${where}\n🕒 ${clock.stamp(Date.now())}`;
  await sendCopy(sock, cfg.to || ownerChat(sock), { kind, buffer, mime: vo.node.mimetype, text: vo.node.caption || '', sender }, header);
}

// ---------------------------------------------------------------- remember messages for anti-delete / anti-edit
async function remember(sock, msg, isGroup) {
  const wantDel = inScope(store.watchCfg('delete').mode, isGroup);
  const wantEdit = inScope(store.watchCfg('edit').mode, isGroup);
  if (!wantDel && !wantEdit) return;

  const message = msg.message;
  const kind = kindName(message);
  const item = {
    jid: msg.key.remoteJid, sender: isGroup ? msg.key.participant : msg.key.remoteJid,
    text: textOf(message), kind, message, ts: Number(msg.messageTimestamp) || 0,
  };
  cache.remember(msg.key.id, item); // text and the original message are kept at once, media follows

  if (wantDel && kind && kind !== 'document') {
    const inner = getInner({ message }) || {};
    const node = inner.imageMessage || inner.videoMessage || inner.audioMessage || inner.stickerMessage;
    const size = Number(node?.fileLength?.low ?? node?.fileLength) || 0;
    if (size && size > MAX_MEDIA) return;
    try {
      const buffer = await media.download(sock, msg);
      if (buffer.length <= MAX_MEDIA) cache.remember(msg.key.id, { ...item, buffer, mime: node?.mimetype });
    } catch (err) {
      // the text is still kept
    }
  }
}

// ---------------------------------------------------------------- deleted / edited (shared by both ways WhatsApp tells us)
async function deletedCore(sock, { jid, id, deleter }) {
  const isGroup = jid.endsWith('@g.us');
  const cfg = store.watchCfg('delete');
  if (!inScope(cfg.mode, isGroup)) return;
  const it = cache.get(id);
  if (!it) return; // we never saw the original
  if (!once(`del|${id}`)) return;

  const by = deleter && num(deleter) !== num(it.sender) ? `🧹 Deleted by ${tagOf(deleter)}` : '🧹 Deleted by the sender';
  const header = `🗑️ *Deleted message*\n👤 Sent by ${tagOf(it.sender)}\n${by}\n💬 In ${await chatName(sock, jid)}\n🕒 Sent ${it.ts ? clock.stamp(it.ts * 1000) : 'earlier'}`;
  await sendCopy(sock, cfg.to || ownerChat(sock), { ...it, mentions: deleter ? [deleter] : [] }, header, quotedOriginal(it, id));
  cache.drop(id);
}

async function editedCore(sock, { jid, id, after, editor }) {
  const isGroup = jid.endsWith('@g.us');
  const cfg = store.watchCfg('edit');
  if (!inScope(cfg.mode, isGroup) || !after) return;
  const it = cache.get(id);
  const before = it?.text || '(I did not see the original text)';
  if (before === after || !once(`edit|${id}|${after}`)) return;

  const sender = it?.sender || editor || jid;
  const header = `✏️ *Edited message*\n👤 By ${tagOf(sender)}\n💬 In ${await chatName(sock, jid)}\n🕒 ${clock.stamp(Date.now())}`;
  await sock.sendMessage(
    cfg.to || ownerChat(sock),
    { text: `${header}\n\n*Before:*\n${before}\n\n*After:*\n${after}`, mentions: [sender] },
    it ? { quoted: quotedOriginal(it, id) } : undefined
  );
  if (it) cache.remember(id, { ...it, text: after });
}

// ---------------------------------------------------------------- entry points
// called for every incoming message
async function run(sock, msg) {
  const message = msg.message;
  if (!message) return;
  const jid = msg.key.remoteJid;
  if (!jid || jid.endsWith('@broadcast') || jid.endsWith('@newsletter')) return;
  const isGroup = jid.endsWith('@g.us');

  const pm = message.protocolMessage || message.ephemeralMessage?.message?.protocolMessage;
  if (pm) {
    if (msg.key.fromMe) return;
    const who = isGroup ? msg.key.participant : jid;
    if (typeIs(pm.type, 0, 'REVOKE')) return deletedCore(sock, { jid, id: pm.key?.id, deleter: who });
    if (typeIs(pm.type, 14, 'MESSAGE_EDIT')) return editedCore(sock, { jid, id: pm.key?.id, after: textOf(pm.editedMessage || {}), editor: who });
    return;
  }
  // an edit that arrives wrapped as a message of its own
  const em = message.editedMessage?.message;
  if (em && !msg.key.fromMe) return editedCore(sock, { jid, id: message.editedMessage?.key?.id || msg.key.id, after: textOf(em), editor: isGroup ? msg.key.participant : jid });
  if (msg.key.fromMe) return;

  await Promise.all([
    viewOnce(sock, msg, isGroup).catch((e) => {
      console.error('View-once error:', e.message);
      return warnOwner(sock, `👁️ I could not handle a view-once message.\nReason: ${String(e.message).slice(0, 100)}`);
    }),
    remember(sock, msg, isGroup).catch(() => {}),
  ]);
}

// called for "message updates": the other way WhatsApp reports edits and deletions
async function onUpdate(sock, updates) {
  for (const u of updates || []) {
    const key = u.key;
    if (!key || key.fromMe || !key.remoteJid || key.remoteJid.endsWith('@broadcast')) continue;
    const isGroup = key.remoteJid.endsWith('@g.us');
    const who = isGroup ? key.participant : key.remoteJid;
    const upd = u.update || {};

    const edited = upd.message?.editedMessage;
    if (edited) {
      await editedCore(sock, { jid: key.remoteJid, id: key.id, after: textOf(edited.message || edited), editor: who });
      continue;
    }
    if (upd.messageStubType === 1 || upd.messageStubType === 'REVOKE') {
      await deletedCore(sock, { jid: key.remoteJid, id: key.id, deleter: upd.key?.participant || who });
    }
  }
}

module.exports = { run, onUpdate, findViewOnce, inScope };
