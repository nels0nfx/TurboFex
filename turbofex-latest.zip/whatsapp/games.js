// Tic-tac-toe: one game per chat, played by sending 1-9
const { num, memberIds } = require('./utils');

const games = new Map();
const LINES = [[0, 1, 2], [3, 4, 5], [6, 7, 8], [0, 3, 6], [1, 4, 7], [2, 5, 8], [0, 4, 8], [2, 4, 6]];
const NUMS = ['1️⃣', '2️⃣', '3️⃣', '4️⃣', '5️⃣', '6️⃣', '7️⃣', '8️⃣', '9️⃣'];
const MARK = { X: '❌', O: '⭕' };
const EXPIRE_MS = 10 * 60 * 1000;

function render(board) {
  const cell = (i) => (board[i] ? MARK[board[i]] : NUMS[i]);
  return [0, 3, 6].map((r) => `${cell(r)}${cell(r + 1)}${cell(r + 2)}`).join('\n');
}

function winnerOf(board) {
  for (const [a, b, c] of LINES) {
    if (board[a] && board[a] === board[b] && board[a] === board[c]) return board[a];
  }
  return null;
}

function get(jid) {
  const g = games.get(jid);
  if (g && Date.now() - g.t > EXPIRE_MS) {
    games.delete(jid);
    return null;
  }
  return g || null;
}

// x and o look like { jid, ids: ['2782...'] }
function start(jid, x, o) {
  const g = { board: Array(9).fill(null), x, o, turn: 'X', t: Date.now() };
  games.set(jid, g);
  return g;
}

function end(jid) {
  games.delete(jid);
}

const isPlayer = (player, ids) => ids.some((i) => player.ids.includes(i));

async function move(sock, msg, jid, cellNumber) {
  const g = get(jid);
  if (!g) return;
  const ids = memberIds(msg);
  const side = isPlayer(g.x, ids) ? 'X' : isPlayer(g.o, ids) ? 'O' : null;
  if (!side) return; // somebody who is not playing
  const send = (text, mentions) => sock.sendMessage(jid, { text, mentions }, { quoted: msg });

  if (side !== g.turn) return send("⏳ It's not your turn yet.", []);
  if (g.board[cellNumber - 1]) return send('⚠️ That spot is taken. Pick another number.', []);

  g.board[cellNumber - 1] = side;
  g.t = Date.now();
  const me = side === 'X' ? g.x : g.o;
  const other = side === 'X' ? g.o : g.x;
  const board = render(g.board);

  if (winnerOf(g.board)) {
    end(jid);
    return send(`🎉 @${num(me.jid)} wins!\n\n${board}`, [me.jid]);
  }
  if (g.board.every(Boolean)) {
    end(jid);
    return send(`🤝 It's a draw!\n\n${board}`, []);
  }
  g.turn = side === 'X' ? 'O' : 'X';
  return send(`${board}\n\n${MARK[g.turn]} Your turn @${num(other.jid)}`, [other.jid]);
}

module.exports = { render, get, start, end, move, isPlayer, MARK };
