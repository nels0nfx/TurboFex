// Helpers for commands that work on pictures, stickers, videos and audio.
// The heavy tools are OPTIONAL: "sharp" (pictures) and ffmpeg (video/audio) are loaded only when needed,
// so the bot keeps working even where they cannot be installed.
const fs = require('fs');
const os = require('os');
const path = require('path');
const crypto = require('crypto');
const { execFile } = require('child_process');
const { getQuoted, num } = require('./utils');

const MAX_BYTES = 20 * 1024 * 1024;
const silent = { level: 'silent', info() {}, error() {}, warn() {}, debug() {}, trace() {}, fatal() {}, child() { return silent; } };

const unwrap = (m) =>
  m?.ephemeralMessage?.message || m?.viewOnceMessage?.message || m?.viewOnceMessageV2?.message || m?.documentWithCaptionMessage?.message || m;

function kindOf(message) {
  if (!message) return null;
  if (message.imageMessage) return 'image';
  if (message.videoMessage) return 'video';
  if (message.stickerMessage) return 'sticker';
  if (message.audioMessage) return 'audio';
  const doc = message.documentMessage?.mimetype || '';
  if (doc.startsWith('image/')) return 'image';
  if (doc.startsWith('video/')) return 'video';
  return null;
}

// the media in the command message itself, or in the message it replies to
function findMedia(msg, jid, botIds) {
  const own = unwrap(msg.message);
  if (kindOf(own)) return { kind: kindOf(own), source: msg, animated: false };

  const q = getQuoted(msg);
  if (!q) return null;
  const inner = unwrap(q.message);
  const kind = kindOf(inner);
  if (!kind) return null;
  return {
    kind,
    animated: !!inner.stickerMessage?.isAnimated,
    source: { key: { remoteJid: jid, id: q.id, participant: q.participant, fromMe: botIds.includes(num(q.participant)) }, message: q.message },
  };
}

async function download(sock, source) {
  const { downloadMediaMessage } = require('@whiskeysockets/baileys');
  const buffer = await downloadMediaMessage(source, 'buffer', {}, { logger: silent, reuploadRequest: sock.updateMediaMessage });
  if (buffer.length > MAX_BYTES) throw Object.assign(new Error('That file is too big (the limit is 20 MB).'), { code: 'TOO_BIG' });
  return buffer;
}

function loadSharp() {
  try {
    return require('sharp');
  } catch (err) {
    throw Object.assign(new Error('sharp is not installed'), { code: 'NEED_SHARP' });
  }
}

function ffmpegBinary() {
  try {
    return require('@ffmpeg-installer/ffmpeg').path;
  } catch (err) {
    return 'ffmpeg';
  }
}

// runs ffmpeg on a buffer and returns the result
async function ffmpeg(input, outExt, makeArgs) {
  const id = crypto.randomBytes(6).toString('hex');
  const inFile = path.join(os.tmpdir(), `tfx-${id}-in`);
  const outFile = path.join(os.tmpdir(), `tfx-${id}-out.${outExt}`);
  fs.writeFileSync(inFile, input);
  try {
    await new Promise((resolve, reject) => {
      execFile(ffmpegBinary(), ['-y', '-hide_banner', '-loglevel', 'error', ...makeArgs(inFile, outFile)], { timeout: 90000 }, (err, _out, stderr) => {
        if (err) {
          const code = err.code === 'ENOENT' ? 'NEED_FFMPEG' : 'FFMPEG_FAILED';
          return reject(Object.assign(new Error(String(stderr || err.message).slice(0, 200)), { code }));
        }
        resolve();
      });
    });
    return fs.readFileSync(outFile);
  } finally {
    fs.rmSync(inFile, { force: true });
    fs.rmSync(outFile, { force: true });
  }
}

const NEED_SHARP = '⚠️ This needs the "sharp" package, which is not installed on this server. Restart the bot with npm install enabled, or ask the bot owner.';
const NEED_FFMPEG = '⚠️ This needs ffmpeg, which is not installed on this server. Restart the bot with npm install enabled, or ask the bot owner.';

// shared flow: find the media, download it, run the work, explain problems clearly
async function handle(ctx, kinds, usage, worker) {
  const { sock, msg, jid, reply, botIds } = ctx;
  const found = findMedia(msg, jid, botIds);
  if (!found || !kinds.includes(found.kind)) return reply(usage);
  try {
    if (found.kind === 'video' || found.kind === 'audio') await reply('⏳ Working on it, this can take a few seconds...');
    const buffer = await download(sock, found.source);
    await worker(found, buffer);
  } catch (err) {
    if (err.code === 'NEED_SHARP') return reply(NEED_SHARP);
    if (err.code === 'NEED_FFMPEG') return reply(NEED_FFMPEG);
    if (err.code === 'TOO_BIG') return reply(`⚠️ ${err.message}`);
    console.error('Media command failed:', err.message);
    return reply(`⚠️ I could not do that with this file.\nReason: ${String(err.message).slice(0, 120)}`);
  }
}

module.exports = { handle, kindOf, findMedia, unwrap, loadSharp, ffmpeg, MAX_BYTES };
