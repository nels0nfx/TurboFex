const config = require('../config');
const { num, selfJid } = require('./utils');

// The owner's own chat: their DM when the bot runs on another number, otherwise the bot's own chat
function ownerChat(sock) {
  const owner = config.ownerNumber;
  const account = num(sock.user?.id);
  return owner && owner !== account ? `${owner}@s.whatsapp.net` : selfJid(sock);
}

module.exports = { ownerChat };
