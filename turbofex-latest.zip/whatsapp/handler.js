const fs = require('fs');
const path = require('path');
const config = require('../config');
const store = require('./store');
const meta = require('./metadata');
const activity = require('./activity');
const categories = require('./categories');
const { runProtections } = require('./protect');
const { getText, num, participantIds, senderIds } = require('./utils');

const commands = new Map(); // name or alias -> command
const commandList = [];

function loadCommands() {
  const dir = path.join(__dirname, '..', 'commands');
  for (const file of fs.readdirSync(dir)) {
    if (!file.endsWith('.js')) continue;
    try {
      const cmd = require(path.join(dir, file));
      if (!categories.info[cmd.category]) {
        console.warn(`⚠️ Command "${cmd.name}" has no valid menu category (set category: '...' in its file)`);
      }
      commandList.push(cmd);
      commands.set(cmd.name, cmd);
      (cmd.aliases || []).forEach((a) => commands.set(a, cmd));
    } catch (err) {
      console.error(`Could not load command ${file}:`, err.message);
    }
  }
  commandList.sort((a, b) => a.name.localeCompare(b.name));
  console.log(`Loaded ${commandList.length} commands.`);
}
loadCommands();

// Works out who sent the message and what rights they (and the bot) have
async function getRoles(sock, msg, jid, isGroup) {
  const sIds = senderIds(msg);
  const botIds = [sock.user?.id, sock.user?.lid].filter(Boolean).map(num);
  const ownerNum = config.ownerNumber;
  const sudo = store.getSudo();
  const banned = store.getBanned();

  let isRealOwner = !!msg.key.fromMe || !!(ownerNum && sIds.includes(ownerNum));
  let isSudo = sudo.some((n) => sIds.includes(n));
  let isBanned = banned.some((n) => sIds.includes(n));
  let groupMetadata = null;
  let isAdmin = false;
  let isBotAdmin = false;

  if (isGroup) {
    groupMetadata = await meta.getMeta(sock, jid);
    for (const p of groupMetadata.participants) {
      const ids = participantIds(p);
      const isSender = ids.some((i) => sIds.includes(i));
      if (isSender) {
        if (ownerNum && ids.includes(ownerNum)) isRealOwner = true;
        if (sudo.some((n) => ids.includes(n))) isSudo = true;
        if (banned.some((n) => ids.includes(n))) isBanned = true;
      }
      if (p.admin === 'admin' || p.admin === 'superadmin') {
        if (isSender) isAdmin = true;
        if (ids.some((i) => botIds.includes(i))) isBotAdmin = true;
      }
    }
  }
  return {
    botIds, sIds, isRealOwner, isOwner: isRealOwner || isSudo, isBanned,
    groupMetadata, isAdmin, isBotAdmin,
  };
}

async function handleMessage(sock, msg) {
  if (!msg.message) return;
  const jid = msg.key.remoteJid;
  if (!jid || jid === 'status@broadcast' || jid.endsWith('@broadcast') || jid.endsWith('@newsletter')) return;

  const text = getText(msg).trim();
  const isGroup = jid.endsWith('@g.us');
  const prefix = store.getPrefix() || config.prefix;

  let cached = null;
  const roles = () => (cached = cached || getRoles(sock, msg, jid, isGroup));

  // Banned users are ignored completely
  if (!msg.key.fromMe && store.getBanned().length) {
    const r = await roles();
    if (r.isBanned && !r.isOwner) return;
  }

  // Passive protections (anti-link, anti-word, anti-spam) and message counting
  if (isGroup && !msg.key.fromMe) {
    activity.count(jid, msg.key.participant);
    if (await runProtections({ sock, msg, jid, text, getRoles: roles })) return;
  }

  if (!text.startsWith(prefix)) return;

  const body = text.slice(prefix.length).trim();
  const [rawName, ...args] = body.split(/\s+/);
  const cmdName = (rawName || '').toLowerCase();
  const cmd = commands.get(cmdName);
  if (!cmd) return;
  const rest = body.slice((rawName || '').length).trim(); // everything after the command, keeps new lines

  const reply = (t, extra = {}) => sock.sendMessage(jid, { text: t, ...extra }, { quoted: msg });
  const r = await roles();
  const { botIds, isOwner, isRealOwner, groupMetadata, isAdmin, isBotAdmin } = r;

  // Private mode: only the owner can use commands
  if (store.getMode() === 'private' && !isOwner) return;

  if (cmd.groupOnly && !isGroup) return reply('⚠️ This command only works in groups.');
  if (cmd.realOwnerOnly && !isRealOwner) return reply('⚠️ Only the main bot owner can use this command.');
  if (cmd.ownerOnly && !isOwner) return reply('⚠️ Only the bot owner can use this command.');
  if (cmd.adminOnly && !(isAdmin || isOwner)) return reply('⚠️ Only group admins can use this command.');
  if (cmd.botAdminRequired && !isBotAdmin) {
    return reply('⚠️ Please make me a group admin first, then try again.');
  }

  try {
    await cmd.run({
      sock, msg, jid, args, rest, reply, cmdName, prefix, config, commandList, botIds,
      isGroup, isAdmin, isOwner, isRealOwner, isBotAdmin, groupMetadata,
    });
  } catch (err) {
    console.error(`Error in command ${cmd.name}:`, err);
    await reply('❌ Something went wrong running that command.');
  }
}

module.exports = { handleMessage };
