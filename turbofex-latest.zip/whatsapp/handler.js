const fs = require('fs');
const path = require('path');
const config = require('../config');
const store = require('./store');
const meta = require('./metadata');
const activity = require('./activity');
const categories = require('./categories');
const seen = require('./seen');
const sent = require('./sent');
const replay = require('./replay');
const idmap = require('./idmap');
const watchers = require('./watchers');
const cmdreact = require('./cmdreact');
const watermark = require('./watermark');
const fmt = require('./format');
const capacity = require('../core/capacity');
const { runProtections } = require('./protect');
const { runPassive } = require('./passive');
const { peel } = require('./unwrap');
const ownerInfo = require('./owner');
const { getText, num, whoIds, whoJid, participantIds, senderIds, isCommandText } = require('./utils');

const commands = new Map(); // name or alias -> command
const commandList = [];
const diag = {
  loadErrors: [],
  stats: { handled: 0, replaysIgnored: 0, duplicatesIgnored: 0 },
  timing: { n: 0, total: 0, max: 0, slow: [] }, // how long the bot takes to answer (shown by !status and !ping)
}; // shown by !status

// slow tasks (media, long commands) run on their own so they never block the chat
const running = new Set();
const idle = () => Promise.all([...running]);

function loadCommands() {
  const dir = path.join(__dirname, '..', 'commands');
  for (const file of fs.readdirSync(dir)) {
    if (!file.endsWith('.js')) continue;
    try {
      // what the commands in this file need from the server (tools, memory): the capacity guard uses it
      const source = fs.readFileSync(path.join(dir, file), 'utf8');
      // a file exports one command, or a list of related commands
      for (const cmd of [].concat(require(path.join(dir, file)))) {
        cmd.capacity = capacity.describe(cmd, source);
        if (!categories.info[cmd.category]) {
          console.warn(`⚠️ Command "${cmd.name}" has no valid menu category (set category: '...' in its file)`);
        }
        commandList.push(cmd);
        commands.set(cmd.name, cmd);
        (cmd.aliases || []).forEach((a) => commands.set(a, cmd));
      }
    } catch (err) {
      diag.loadErrors.push(`${file}: ${err.message}`);
      console.error(`Could not load command ${file}:`, err.message);
    }
  }
  commandList.sort((a, b) => a.name.localeCompare(b.name));
  console.log(`Loaded ${commandList.length} commands.`);
}
loadCommands();

// Works out who sent the message and what rights they (and the bot) have
async function getRoles(sock, msg, jid, isGroup) {
  const sIds = senderIds(msg);
  const botIds = [sock.user?.id, sock.user?.lid].filter(Boolean).map(num);
  const ownerNum = config.ownerNumber;
  const sudo = store.getSudo();
  const banned = store.getBanned();

  let isRealOwner = !!msg.key.fromMe || !!(ownerNum && sIds.includes(ownerNum));
  let isSudo = sudo.some((n) => sIds.includes(n));
  let isBanned = banned.some((n) => sIds.includes(n));
  let groupMetadata = null;
  let isAdmin = false;
  let isBotAdmin = false;

  if (isGroup) {
    groupMetadata = await meta.getMeta(sock, jid);
    for (const p of groupMetadata.participants) {
      const ids = participantIds(p);
      const isSender = ids.some((i) => sIds.includes(i));
      if (isSender) {
        if (ownerNum && ids.includes(ownerNum)) isRealOwner = true;
        if (sudo.some((n) => ids.includes(n))) isSudo = true;
        if (banned.some((n) => ids.includes(n))) isBanned = true;
      }
      if (p.admin === 'admin' || p.admin === 'superadmin') {
        if (isSender) isAdmin = true;
        if (ids.some((i) => botIds.includes(i))) isBotAdmin = true;
        // a message typed on the bot's own account counts as the bot being the sender
        if (msg.key.fromMe && ids.some((i) => botIds.includes(i))) isAdmin = true;
      }
    }
  }
  return {
    botIds, sIds, isRealOwner, isOwner: isRealOwner || isSudo, isBanned,
    groupMetadata, isAdmin, isBotAdmin,
  };
}

async function handleMessage(sock, msg) {
  if (!msg.message) {
    // WhatsApp sent a message but not its content (typical for view-once on a linked device): tell the watcher, do not stay silent
    watchers.noContent(sock, msg).catch(() => {});
    return;
  }
  const jid = msg.key.remoteJid;
  if (!jid || jid === 'status@broadcast' || jid.endsWith('@broadcast') || jid.endsWith('@newsletter')) return;

  // Edit / delete notices are not chat messages: they go straight to the watcher, BEFORE the "seen before" check
  // (an edit can carry the id of the message it edits, and would wrongly be thrown away as a duplicate).
  const early = peel(msg.message).content;
  if (early.protocolMessage || early.secretEncryptedMessage) {
    watchers.run(sock, msg).catch((e) => console.error('Watcher error:', e.message));
    return;
  }

  // never answer our own replies, and never handle one message twice (also after a restart)
  if (sent.has(msg.key.id)) return;
  if (seen.check(jid, msg.key.id)) {
    diag.stats.duplicatesIgnored += 1;
    return;
  }
  diag.stats.handled += 1;
  const t0 = Date.now();
  idmap.learnKey(msg.key);
  // remember how WhatsApp addresses the owner, so notifications to him can always be opened
  if (!jid.endsWith('@g.us') && !msg.key.fromMe && config.ownerNumber && !jid.endsWith('@broadcast')) {
    const pn = idmap.isPn(jid) ? jid : msg.key.remoteJidAlt || idmap.pnSync(jid);
    if (pn && num(pn) === config.ownerNumber) ownerInfo.remember(jid);
  }

  const text = getText(msg).trim();
  const isGroup = jid.endsWith('@g.us');
  const prefix = store.effectivePrefix();
  const botIds = [sock.user?.id, sock.user?.lid].filter(Boolean).map(num);

  let cached = null;
  const roles = () => (cached = cached || getRoles(sock, msg, jid, isGroup));

  // view-once / deleted / edited message watchers run on their own
  watchers.run(sock, msg, botIds).catch((e) => console.error('Watcher error:', e.message));

  // Banned users are ignored completely
  if (!msg.key.fromMe && store.getBanned().length) {
    const r = await roles();
    if (r.isBanned && !r.isOwner) return;
  }

  // Passive protections (anti-link, anti-word, anti-spam) and message counting
  if (isGroup && !msg.key.fromMe) {
    activity.count(jid, msg.key.participant);
    if (await runProtections({ sock, msg, jid, text, getRoles: roles })) return;
  }

  const isCommand = isCommandText(text, prefix);

  // Games, AFK notices and auto-replies work for everyone, in every mode.
  // For commands they run alongside, so they never delay the answer.
  const passive = runPassive({ sock, msg, jid, text, isGroup, isCommand, prefix, botIds });
  if (!isCommand) return passive;

  const body = text.slice(prefix.length).trim();
  const [rawName, ...args] = body.split(/\s+/);
  const cmdName = (rawName || '').toLowerCase();
  const cmd = commands.get(cmdName);
  const rawReply = (t, extra = {}) => sock.sendMessage(jid, { text: t, ...extra }, { quoted: msg });

  if (!cmd) {
    // a command file that failed to load: tell the owner why instead of staying silent (nobody else is answered)
    const failed = diag.loadErrors.find((e) => e.startsWith(`${cmdName}.js:`));
    if (failed && (await roles()).isOwner) {
      return rawReply(`⚠️ The command "${cmdName}" could not be loaded.\nReason: ${failed.slice(failed.indexOf(':') + 1).trim().slice(0, 150)}`);
    }
    return;
  }
  const rest = body.slice((rawName || '').length).trim(); // everything after the command, keeps new lines

  let r;
  try {
    r = await roles();
  } catch (err) {
    console.error('Could not read group info:', err.message);
    return rawReply('⚠️ WhatsApp is slow right now and I could not check this group. Please try again in a moment.');
  }
  const { isOwner, isRealOwner, groupMetadata, isAdmin, isBotAdmin } = r;

  // Private mode (the default): only the owner can use commands. Everybody else gets NO answer at all.
  // (Games that are already running, auto-replies and group protection still work, they are not commands.)
  if (store.getMode() === 'private' && !isOwner) return;

  if (cmd.groupOnly && !isGroup) return rawReply('⚠️ This command only works in groups.');
  if (cmd.realOwnerOnly && !isRealOwner) return rawReply('⚠️ Only the main bot owner can use this command.');
  if (cmd.ownerOnly && !isOwner) return rawReply('⚠️ Only the bot owner can use this command.');
  if (cmd.adminOnly && !(isAdmin || isOwner)) return rawReply('⚠️ Only group admins can use this command.');
  if (cmd.botAdminRequired && !isBotAdmin) {
    return rawReply('⚠️ Please make me a group admin first, then try again.');
  }

  const tStart = Date.now();
  const ts = replay.timestampOf(msg);
  const timing = {
    receivedAt: t0,
    thinkMs: tStart - t0, // time inside the bot before the command started (roles, group info)
    deliveryMs: ts ? Math.max(0, t0 - ts * 1000) : null, // time since WhatsApp stamped the message (includes clock differences)
  };

  const execute = async () => {
    // 1) can the server really handle this command right now? (tools, memory, load, parallel jobs)
    const who = isOwner ? null : r.sIds[0] || jid;
    const gate = store.getGuard() ? await capacity.enter(cmd, who) : { ok: true, release() {} };
    if (!gate.ok) {
      console.log(`🛡️ Blocked "${cmd.name}": ${gate.why} - ${gate.detail}`);
      await rawReply(capacity.refusal(gate, isOwner)).catch(() => {});
      return;
    }

    // 2) ⏳ on the command while it works, ✅ when it is done
    const react = cmd.noReact ? { finish() {} } : cmdreact.begin(sock, msg);

    // 3) the command gets its own copy of "sock": results of some commands get a watermark, and we notice warnings
    const mark = watermark.applies(cmd) ? watermark.text() : null;
    const styled = fmt.applies(cmd);
    let warned = false;
    const csock = Object.create(sock);
    csock.sendMessage = (to, content, opts) => {
      if (typeof content?.text === 'string' && /^\s*(⚠️|❌|🚫)/.test(content.text)) warned = true;
      if (styled && typeof content?.text === 'string' && !content.edit) content = { ...content, text: fmt.format(content.text, (n) => commands.has(n), prefix) };
      return sock.sendMessage(to, mark ? watermark.mark(content, mark) : content, opts);
    };
    const reply = (t, extra = {}) => csock.sendMessage(jid, { text: t, ...extra }, { quoted: msg });

    let outcome = 'ok';
    try {
      await cmd.run({
        sock: csock, msg, jid, args, rest, reply, cmdName, prefix, config, commandList, botIds, diag, timing,
        myIds: whoIds(msg, botIds), myJid: whoJid(msg, sock),
        isGroup, isAdmin, isOwner, isRealOwner, isBotAdmin, groupMetadata,
      });
      if (warned) outcome = 'warn';
    } catch (err) {
      outcome = 'fail';
      console.error(`Error in command ${cmd.name}:`, err);
      // only the owner sees the reason (it is technical); everybody else gets a simple message
      const detail = isOwner ? `\nReason: ${String(err?.message || err).slice(0, 150)}` : '\nPlease try again in a moment.';
      await rawReply(`❌ Something went wrong running that command.${detail}`).catch(() => {});
    } finally {
      gate.release();
      react.finish(outcome);
      const total = Date.now() - t0;
      const t = diag.timing;
      t.n += 1;
      t.total += total;
      t.max = Math.max(t.max, total);
      if (total > 2500) {
        t.slow.push(`${cmd.name} ${total}ms (thinking ${timing.thinkMs}ms)`);
        if (t.slow.length > 5) t.slow.shift();
        console.log(`⏱️ Slow command: ${cmd.name} took ${total} ms (${timing.thinkMs} ms before it started)`);
      }
    }
  };

  // long jobs (pictures, video, audio) must not hold up the other messages of the chat
  if (cmd.slow) {
    const job = execute().finally(() => running.delete(job));
    running.add(job);
    return;
  }
  await execute();
}

module.exports = { handleMessage, diag, idle };
