// Owner automation: typing / recording indicators, always online, auto bio, auto reactions, private message blocker.
const store = require('./store');
const clock = require('../core/clock');

let current = null;
let onlineTimer = null;
let bioTimer = null;
let lastBio = '';

const DEFAULT_BIO = '🤖 TurboFex • {time} • {date}';
const DEFAULT_EMOJIS = ['❤️', '😂', '🔥', '👍', '😮', '🎉'];

const fillBio = (t) => {
  const p = clock.parts();
  return String(t || DEFAULT_BIO).replace(/\{time\}/g, p.time).replace(/\{date\}/g, p.date).replace(/\{day\}/g, p.day || '').slice(0, 139);
};

async function updateBio(force = false) {
  const cfg = store.getAuto('bio');
  if (!current || !cfg?.on) return;
  const text = fillBio(cfg.text);
  if (!force && text === lastBio) return;
  lastBio = text;
  try {
    await current.updateProfileStatus(text);
  } catch (err) {
    console.log(`Auto bio failed: ${err.message}`);
  }
}

// (re)starts the loops that are switched on; called when the bot connects and when a setting changes
function apply(sock) {
  if (sock) current = sock;
  clearInterval(onlineTimer);
  clearInterval(bioTimer);
  onlineTimer = bioTimer = null;
  if (!current) return;
  if (store.getAuto('online')) {
    const ping = () => current.sendPresenceUpdate('available').catch(() => {});
    ping();
    onlineTimer = setInterval(ping, 25000);
    if (onlineTimer.unref) onlineTimer.unref();
  }
  if (store.getAuto('bio')?.on) {
    updateBio(true);
    bioTimer = setInterval(() => updateBio(false), 10 * 60 * 1000); // WhatsApp does not like faster changes
    if (bioTimer.unref) bioTimer.unref();
  }
}

// "typing..." or "recording audio..." while a command is being answered
function show(sock, jid) {
  const kind = store.getAuto('recording') ? 'recording' : store.getAuto('typing') ? 'composing' : null;
  if (kind) sock.sendPresenceUpdate(kind, jid).catch(() => {});
}

const lastReact = new Map();
// a reaction under a message of someone else (at most one in 20 seconds per chat, so it never floods)
function reactTo(sock, msg, jid) {
  const cfg = store.getAuto('react');
  if (!cfg?.on || msg.key.fromMe) return;
  if (Date.now() - (lastReact.get(jid) || 0) < 20000) return;
  lastReact.set(jid, Date.now());
  if (lastReact.size > 2000) lastReact.clear();
  const list = cfg.emojis?.length ? cfg.emojis : DEFAULT_EMOJIS;
  sock.sendMessage(jid, { react: { text: list[Math.floor(Math.random() * list.length)], key: msg.key } }).catch(() => {});
}

// private message blocker: strangers who write to the bot in private get a notice, and with "block" they are blocked on the next message
const warned = new Map();
const WARN_AGAIN_MS = 24 * 60 * 60 * 1000;
const NOTICE = '🚫 This bot does not answer private messages. Please use it in a group.';
async function pmGuard(sock, jid, mode) {
  const at = warned.get(jid);
  const fresh = at && Date.now() - at < WARN_AGAIN_MS;
  if (!fresh) {
    warned.set(jid, Date.now());
    if (warned.size > 5000) warned.clear();
    await sock.sendMessage(jid, { text: mode === 'block' ? `${NOTICE}\n⚠️ If you write again you will be blocked.` : NOTICE }).catch(() => {});
    return;
  }
  if (mode === 'block') {
    await sock.updateBlockStatus(jid, 'block').catch(() => {});
    warned.delete(jid);
  }
}

module.exports = { apply, show, reactTo, pmGuard, updateBio, fillBio, DEFAULT_BIO, DEFAULT_EMOJIS };
