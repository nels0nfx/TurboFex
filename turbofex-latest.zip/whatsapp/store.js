// Saves each group's settings and the bot's own settings in data/groups.json
const fs = require('fs');
const path = require('path');
const config = require('../config');
const { num } = require('./utils');

const MAX_WARNINGS = Number(config.maxWarnings) || 3;
const DEFAULT_WELCOME = '👋 Welcome @user to *{group}*!\n👥 You are member #{count}.';
const DEFAULT_GOODBYE = '🚪 @user has left *{group}*. Goodbye! 👋';
const ANTILINK_MODES = ['off', 'delete', 'warn', 'kick'];
const BOT_KEY = '__bot';

const dir = path.join(__dirname, '..', 'data');
const file = path.join(dir, 'groups.json');

let db = {};
try {
  db = JSON.parse(fs.readFileSync(file, 'utf8'));
} catch (err) {
  db = {};
}

function save() {
  try {
    fs.mkdirSync(dir, { recursive: true });
    fs.writeFileSync(file, JSON.stringify(db, null, 2));
  } catch (err) {
    console.error('Could not save settings:', err.message);
  }
}

function getGroup(jid) {
  const g = db[jid] || (db[jid] = {});
  if (!ANTILINK_MODES.includes(g.antilinkMode)) g.antilinkMode = g.antilink === true ? 'warn' : 'off';
  delete g.antilink; // old v0.0.2 setting
  if (!ANTILINK_MODES.includes(g.antiwordMode)) g.antiwordMode = 'off';
  for (const k of ['welcome', 'goodbye', 'antispam', 'pdm']) {
    if (typeof g[k] !== 'boolean') g[k] = false;
  }
  if (typeof g.welcomeText !== 'string') g.welcomeText = null;
  if (typeof g.goodbyeText !== 'string') g.goodbyeText = null;
  if (!Number.isInteger(g.warnLimit)) g.warnLimit = null;
  if (!g.warnings) g.warnings = {};
  if (!Array.isArray(g.badWords)) g.badWords = [];
  if (!Array.isArray(g.antifake)) g.antifake = [];
  if (!g.filters || typeof g.filters !== 'object' || Array.isArray(g.filters)) g.filters = {};
  if (!g.autoMute || typeof g.autoMute !== 'object') g.autoMute = { mute: null, unmute: null };
  return g;
}

function update(jid, fn) {
  const g = getGroup(jid);
  fn(g);
  save();
  return g;
}

function forEachGroup(fn) {
  for (const jid of Object.keys(db)) {
    if (jid.endsWith('@g.us')) fn(jid, getGroup(jid));
  }
}

// ----- warnings -----
function getLimit(jid) {
  return getGroup(jid).warnLimit || MAX_WARNINGS;
}

function setLimit(jid, n) {
  return update(jid, (g) => {
    g.warnLimit = n;
  });
}

function addWarning(jid, id) {
  const g = getGroup(jid);
  const key = num(id);
  const count = (g.warnings[key]?.count || 0) + 1;
  g.warnings[key] = { jid: id, count };
  save();
  return { count, max: getLimit(jid) };
}

function resetWarnings(jid, id) {
  const g = getGroup(jid);
  delete g.warnings[num(id)];
  save();
}

function getWarnings(jid, id) {
  return getGroup(jid).warnings[num(id)]?.count || 0;
}

function allWarnings(jid) {
  return Object.values(getGroup(jid).warnings).filter((w) => w.count > 0);
}

// ----- bot-wide settings -----
function bot() {
  return db[BOT_KEY] || (db[BOT_KEY] = {});
}

function getMode() {
  return bot().mode === 'private' ? 'private' : 'public';
}

function setMode(mode) {
  bot().mode = mode;
  save();
}

function getAutoUpdate() {
  return bot().autoUpdate !== false;
}

function setAutoUpdate(on) {
  bot().autoUpdate = !!on;
  save();
}

function getPrefix() {
  return bot().prefix || null;
}

function setPrefix(p) {
  bot().prefix = p || null;
  save();
}

// lists of phone numbers (digits only): extra owners and banned users
function listOf(key) {
  const b = bot();
  return Array.isArray(b[key]) ? b[key] : (b[key] = []);
}

function addTo(key, id) {
  const n = num(id);
  const list = listOf(key);
  if (n && !list.includes(n)) {
    list.push(n);
    save();
  }
}

function removeFrom(key, id) {
  const n = num(id);
  const list = listOf(key);
  const i = list.indexOf(n);
  if (i !== -1) {
    list.splice(i, 1);
    save();
    return true;
  }
  return false;
}

// ----- filters that apply everywhere (owner) -----
function getGlobalFilters() {
  const b = bot();
  if (!b.filters || typeof b.filters !== 'object' || Array.isArray(b.filters)) b.filters = {};
  return b.filters;
}

// filters for private chats (owner)
function getPrivateFilters() {
  const b = bot();
  if (!b.pfilters || typeof b.pfilters !== 'object' || Array.isArray(b.pfilters)) b.pfilters = {};
  return b.pfilters;
}

// the filters of one chat without creating an empty record for it
function peekFilters(jid) {
  const f = db[jid]?.filters;
  return f && typeof f === 'object' && !Array.isArray(f) ? f : {};
}

function saveNow() {
  save();
}

// ----- AFK (away) -----
function afkMap() {
  const b = bot();
  if (!b.afk || typeof b.afk !== 'object') b.afk = {};
  return b.afk;
}

function afkGet(ids) {
  const map = afkMap();
  for (const id of ids) if (map[id]) return map[id];
  return null;
}

function afkSet(ids, reason) {
  const map = afkMap();
  const record = { reason: reason || '', since: Date.now(), ids: [...ids] };
  for (const id of ids) map[id] = record;
  save();
}

function afkDel(ids) {
  const map = afkMap();
  const record = afkGet(ids);
  if (!record) return;
  for (const id of record.ids) delete map[id];
  save();
}

// ----- scheduled messages -----
function schedules() {
  const b = bot();
  return Array.isArray(b.schedules) ? b.schedules : (b.schedules = []);
}

function addSchedule({ jid, time, text, once }) {
  const b = bot();
  b.scheduleSeq = (b.scheduleSeq || 0) + 1;
  const item = { id: b.scheduleSeq, jid, time, text, once: !!once };
  schedules().push(item);
  save();
  return item;
}

function removeSchedule(id) {
  const list = schedules();
  const i = list.findIndex((s) => s.id === id);
  if (i === -1) return false;
  list.splice(i, 1);
  save();
  return true;
}

// ----- reminders (!remind) -----
function reminders() {
  const b = bot();
  return Array.isArray(b.reminders) ? b.reminders : (b.reminders = []);
}

function addReminder({ jid, who, ids, at, text }) {
  const b = bot();
  b.reminderSeq = (b.reminderSeq || 0) + 1;
  const item = { id: b.reminderSeq, jid, who, ids, at, text };
  reminders().push(item);
  save();
  return item;
}

function removeReminder(id) {
  const list = reminders();
  const i = list.findIndex((r) => r.id === id);
  if (i === -1) return false;
  list.splice(i, 1);
  save();
  return true;
}

// ----- greeting for people who write privately (!setgreet) -----
const getGreet = () => bot().greet || null;

function setGreet(text) {
  bot().greet = text || null;
  save();
}

function wasGreeted(jid, withinMs) {
  const t = (bot().greeted || {})[jid];
  return !!t && Date.now() - t < withinMs;
}

function markGreeted(jid) {
  const b = bot();
  if (!b.greeted) b.greeted = {};
  b.greeted[jid] = Date.now();
  const keys = Object.keys(b.greeted);
  if (keys.length > 2000) {
    keys.sort((a, c) => b.greeted[a] - b.greeted[c]).slice(0, keys.length - 2000).forEach((k) => delete b.greeted[k]);
  }
  save();
}

module.exports = {
  reminders, addReminder, removeReminder, getGreet, setGreet, wasGreeted, markGreeted,
  getGlobalFilters, getPrivateFilters, peekFilters, saveNow,
  afkGet, afkSet, afkDel,
  schedules, addSchedule, removeSchedule,
  MAX_WARNINGS, DEFAULT_WELCOME, DEFAULT_GOODBYE, ANTILINK_MODES,
  getGroup, update, forEachGroup,
  getLimit, setLimit, addWarning, resetWarnings, getWarnings, allWarnings,
  getMode, setMode, getAutoUpdate, setAutoUpdate, getPrefix, setPrefix,
  getSudo: () => listOf('sudo'),
  addSudo: (id) => addTo('sudo', id),
  removeSudo: (id) => removeFrom('sudo', id),
  getBanned: () => listOf('banned'),
  addBanned: (id) => addTo('banned', id),
  removeBanned: (id) => removeFrom('banned', id),
};
