// Turns "27821234567:12@s.whatsapp.net" into "27821234567"
const num = (jid) => String(jid || '').split('@')[0].split(':')[0];

function getInner(msg) {
  const m = msg.message || {};
  return (
    m.ephemeralMessage?.message ||
    m.viewOnceMessage?.message ||
    m.documentWithCaptionMessage?.message ||
    m
  );
}

function getText(msg) {
  const m = getInner(msg);
  return (
    m.conversation ||
    m.extendedTextMessage?.text ||
    m.imageMessage?.caption ||
    m.videoMessage?.caption ||
    ''
  );
}

function getContextInfo(msg) {
  const m = getInner(msg);
  const part = m.extendedTextMessage || m.imageMessage || m.videoMessage || {};
  return part.contextInfo || {};
}

// People tagged in the message, or the person whose message was replied to
function getTargets(msg) {
  const info = getContextInfo(msg);
  const list = [...(info.mentionedJid || [])];
  if (!list.length && info.participant) list.push(info.participant);
  return [...new Set(list)];
}

// All the ways WhatsApp might identify a group member
function participantIds(p) {
  return [p.id, p.lid, p.jid, p.phoneNumber].filter(Boolean).map(num);
}

// All the ways WhatsApp might identify the sender of a message
function senderIds(msg) {
  const k = msg.key || {};
  return [k.participant, k.participantAlt, k.participantPn, k.remoteJid, k.remoteJidAlt]
    .filter(Boolean)
    .map(num);
}

module.exports = { num, getText, getTargets, participantIds, senderIds };
