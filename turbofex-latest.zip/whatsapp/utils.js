// Turns "27821234567:12@s.whatsapp.net" into "27821234567"
const num = (jid) => String(jid || '').split('@')[0].split(':')[0];

function getInner(msg) {
  const m = msg.message || {};
  return (
    m.ephemeralMessage?.message ||
    m.viewOnceMessage?.message ||
    m.documentWithCaptionMessage?.message ||
    m
  );
}

function getText(msg) {
  const m = getInner(msg);
  return (
    m.conversation ||
    m.extendedTextMessage?.text ||
    m.imageMessage?.caption ||
    m.videoMessage?.caption ||
    ''
  );
}

function getContextInfo(msg) {
  const m = getInner(msg);
  const part = m.extendedTextMessage || m.imageMessage || m.videoMessage || {};
  return part.contextInfo || {};
}

// People tagged in the message, or the person whose message was replied to
function getTargets(msg) {
  const info = getContextInfo(msg);
  const list = [...(info.mentionedJid || [])];
  if (!list.length && info.participant) list.push(info.participant);
  return [...new Set(list)];
}

// The message that was replied to (or null)
function getQuoted(msg) {
  const info = getContextInfo(msg);
  if (!info.quotedMessage) return null;
  return { id: info.stanzaId, participant: info.participant, message: info.quotedMessage };
}

function quotedText(quoted) {
  const m = quoted?.message || {};
  return (
    m.conversation ||
    m.extendedTextMessage?.text ||
    m.imageMessage?.caption ||
    m.videoMessage?.caption ||
    ''
  );
}

// A tagged person, a replied-to person, or a phone number typed in the command
function resolveTarget(msg, args = []) {
  const tagged = getTargets(msg);
  if (tagged.length) return tagged[0];
  for (const a of args) {
    const d = String(a).replace(/\D/g, '');
    if (d.length >= 7 && d.length <= 15) return `${d}@s.whatsapp.net`;
  }
  return null;
}

// All the ways WhatsApp might identify a group member
function participantIds(p) {
  return [p.id, p.lid, p.jid, p.phoneNumber].filter(Boolean).map(num);
}

// All the ways WhatsApp might identify the sender of a message
function senderIds(msg) {
  const k = msg.key || {};
  return [k.participant, k.participantAlt, k.participantPn, k.remoteJid, k.remoteJidAlt]
    .filter(Boolean)
    .map(num);
}

// The ids that identify the SENDER as a person (never the group id)
function memberIds(msg) {
  const k = msg.key || {};
  return [...new Set([k.participant, k.participantAlt, k.participantPn].filter(Boolean).map(num))];
}

// True when `phrase` appears in `text` as whole word(s), ignoring capital letters
function hasPhrase(text, phrase) {
  const esc = String(phrase).toLowerCase().replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  return new RegExp(`(^|[^\\p{L}\\p{N}])${esc}($|[^\\p{L}\\p{N}])`, 'u').test(String(text).toLowerCase());
}

module.exports = {
  memberIds, hasPhrase, num, getText, getTargets, getQuoted, quotedText, resolveTarget, participantIds, senderIds,
};
