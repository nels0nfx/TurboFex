// Things the bot does on normal messages (not commands): games, AFK notices, auto-replies
const store = require('./store');
const games = require('./games');
const clock = require('../core/clock');
const { num, memberIds, getTargets, hasPhrase } = require('./utils');

const cooldown = new Map();

function cooledDown(key, seconds) {
  const now = Date.now();
  if (now - (cooldown.get(key) || 0) < seconds * 1000) return true;
  cooldown.set(key, now);
  if (cooldown.size > 5000) cooldown.clear();
  return false;
}

async function afk({ sock, msg, jid, text, isCommand, prefix }) {
  const ids = memberIds(msg);
  const sender = msg.key.participant;

  // The away person came back (unless they are just setting AFK again)
  const mine = ids.length ? store.afkGet(ids) : null;
  if (mine) {
    const cmd = isCommand ? text.slice(prefix.length).trim().split(/\s+/)[0].toLowerCase() : '';
    if (cmd !== 'afk') {
      store.afkDel(ids);
      await sock.sendMessage(
        jid,
        { text: `👋 Welcome back @${num(sender)}! You were away for ${clock.duration(Date.now() - mine.since)}.`, mentions: [sender] },
        { quoted: msg }
      );
    }
  }

  // Someone mentioned or replied to an away person
  for (const target of getTargets(msg)) {
    const record = store.afkGet([num(target)]);
    if (!record || ids.some((i) => record.ids.includes(i))) continue;
    if (cooledDown(`afk|${jid}|${record.ids[0]}`, 60)) continue;
    const why = record.reason ? `: ${record.reason}` : '';
    await sock.sendMessage(
      jid,
      { text: `😴 @${num(target)} is AFK${why}\n⏱️ Away for ${clock.duration(Date.now() - record.since)}`, mentions: [target] },
      { quoted: msg }
    );
  }
}

async function filters({ sock, msg, jid, text, isGroup }) {
  const sets = [];
  if (isGroup) sets.push(store.getGroup(jid).filters);
  sets.push(store.getGlobalFilters());
  for (const set of sets) {
    for (const [word, answer] of Object.entries(set)) {
      if (!hasPhrase(text, word)) continue;
      if (cooledDown(`filter|${jid}|${word}`, 10)) return;
      await sock.sendMessage(jid, { text: answer }, { quoted: msg });
      return; // one auto-reply per message
    }
  }
}

async function runPassive(ctx) {
  const { sock, msg, jid, text, isGroup, isCommand } = ctx;
  try {
    if (isGroup && !isCommand && /^[1-9]$/.test(text)) await games.move(sock, msg, jid, Number(text));
    if (isGroup) await afk(ctx);
    if (!isCommand && text) await filters(ctx);
  } catch (err) {
    console.error('Passive feature error:', err.message);
  }
}

module.exports = { runPassive };
