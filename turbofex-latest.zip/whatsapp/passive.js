// Things the bot does on normal messages: games, AFK notices, auto-replies
const config = require('../config');
const store = require('./store');
const games = require('./play');
const clock = require('../core/clock');
const { num, whoIds, getTargets, hasPhrase } = require('./utils');

const cooldown = new Map();

function cooledDown(key, seconds) {
  const now = Date.now();
  if (now - (cooldown.get(key) || 0) < seconds * 1000) return true;
  cooldown.set(key, now);
  if (cooldown.size > 5000) cooldown.clear();
  return false;
}

async function afk({ sock, msg, jid, text, isGroup, isCommand, prefix, botIds }) {
  const fromMe = !!msg.key.fromMe;
  const ids = whoIds(msg, botIds);
  const sender = msg.key.participant;

  // The away person wrote something again (unless they are just setting AFK again)
  const mine = ids.length ? store.afkGet(ids) : null;
  if (mine) {
    const cmd = isCommand ? text.slice(prefix.length).trim().split(/\s+/)[0].toLowerCase() : '';
    if (cmd !== 'afk') {
      store.afkDel(ids);
      if (isGroup) {
        const tag = sender || `${botIds[0]}@s.whatsapp.net`;
        await sock.sendMessage(
          jid,
          { text: `👋 Welcome back @${num(tag)}! You were away for ${clock.duration(Date.now() - mine.since)}.`, mentions: [tag] },
          { quoted: msg }
        );
      }
    }
  }
  if (fromMe) return;

  // Someone mentioned or replied to an away person in a group
  if (isGroup) {
    for (const target of getTargets(msg)) {
      const record = store.afkGet([num(target)]);
      if (!record || ids.some((i) => record.ids.includes(i))) continue;
      if (cooledDown(`afk|${jid}|${record.ids[0]}`, 60)) continue;
      const why = record.reason ? `: ${record.reason}` : '';
      await sock.sendMessage(
        jid,
        { text: `😴 @${num(target)} is AFK${why}\n⏱️ Away for ${clock.duration(Date.now() - record.since)}`, mentions: [target] },
        { quoted: msg }
      );
    }
    return;
  }

  // Someone wrote privately to an away owner
  if (!isCommand) {
    const owner = store.afkGet([...botIds, config.ownerNumber].filter(Boolean));
    if (owner && !cooledDown(`afkdm|${jid}`, 600)) {
      const why = owner.reason ? `: ${owner.reason}` : '';
      await sock.sendMessage(
        jid,
        { text: `😴 I am AFK right now${why}\n⏱️ Away for ${clock.duration(Date.now() - owner.since)}\nI will reply when I am back.` },
        { quoted: msg }
      );
    }
  }
}

async function filters({ sock, msg, jid, text, isGroup }) {
  const sets = [store.peekFilters(jid)]; // this chat only
  if (!isGroup) sets.push(store.getPrivateFilters()); // all private chats (!pfilter)
  sets.push(store.getGlobalFilters()); // every chat (!gfilter)
  for (const set of sets) {
    for (const [word, answer] of Object.entries(set)) {
      if (!hasPhrase(text, word)) continue;
      if (cooledDown(`filter|${jid}|${word}`, 10)) return;
      await sock.sendMessage(jid, { text: answer }, { quoted: msg });
      return; // one auto-reply per message
    }
  }
}

async function runPassive(ctx) {
  const { sock, msg, jid, text, isCommand, botIds } = ctx;
  try {
    if (!isCommand && text && games.get(jid)) await games.route({ sock, msg, jid, text, botIds });
    await afk(ctx);
    if (!isCommand && text) await filters(ctx);
  } catch (err) {
    console.error('Passive feature error:', err.message);
  }
}

module.exports = { runPassive };
