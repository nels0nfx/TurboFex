// Debounced JSON persistence. Disk I/O is asynchronous during normal operation so
// a growing economy/market file cannot pause the WhatsApp event loop while it is written.
const fs = require('node:fs');
const fsp = require('node:fs/promises');
const path = require('node:path');
const { DATA } = require('./paths');
const { onFlush } = require('./flush');

const writers = [];
process.on('exit', () => writers.forEach((w) => { try { w(); } catch {} }));

function open(name, initial) {
  const file = path.join(DATA, `${name}.json`);
  let data;
  try {
    data = JSON.parse(fs.readFileSync(file, 'utf8'));
  } catch {
    data = typeof initial === 'function' ? initial() : JSON.parse(JSON.stringify(initial));
  }

  let dirty = false;
  let revision = 0;
  let timer = null;
  let writing = null;

  // Last-resort synchronous save for an abrupt process exit. Normal saves use write().
  const writeSync = () => {
    if (!dirty) return;
    try {
      fs.mkdirSync(DATA, { recursive: true });
      const tmp = `${file}.exit.tmp`;
      fs.writeFileSync(tmp, JSON.stringify(data));
      fs.renameSync(tmp, file);
      dirty = false;
    } catch (err) {
      console.error(`Could not save ${name} on exit:`, err.message);
    }
  };

  const write = () => {
    if (!dirty) return writing || Promise.resolve();
    if (writing) return writing;
    const savedRevision = revision;
    let payload;
    try {
      // Serialization is kept to one coalesced pass per store; disk writes themselves are async.
      payload = JSON.stringify(data);
    } catch (err) {
      console.error(`Could not serialize ${name}:`, err.message);
      return Promise.resolve();
    }
    dirty = false;
    writing = (async () => {
      try {
        await fsp.mkdir(DATA, { recursive: true });
        const tmp = `${file}.tmp`;
        await fsp.writeFile(tmp, payload);
        await fsp.rename(tmp, file);
      } catch (err) {
        dirty = true;
        console.error(`Could not save ${name}:`, err.message);
      } finally {
        writing = null;
        // If data changed while the snapshot was being written, schedule the newer state too.
        if (revision !== savedRevision) dirty = true;
        if (dirty && !timer) {
          timer = setTimeout(() => {
            timer = null;
            void write();
          }, 250);
          timer.unref?.();
        }
      }
    })();
    return writing;
  };

  onFlush(write);
  writers.push(writeSync);

  return {
    get data() { return data; },
    touch() {
      dirty = true;
      revision += 1;
      if (!timer && !writing) {
        timer = setTimeout(() => {
          timer = null;
          void write();
        }, 2000);
        timer.unref?.();
      }
    },
    flush: write,
  };
}

module.exports = { open };
