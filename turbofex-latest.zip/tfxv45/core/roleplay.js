// Persistent careers, gangs, and territory state. Everything is scoped to a group.
const jsonstore = require('./jsonstore');
const db = jsonstore.open('roleplay', { groups: {} });
const economy = require('./economy');
const DISTRICTS = {
  oldtown: { name: 'Old Town', cost: 3000, income: 180 },
  docks: { name: 'Harbour Docks', cost: 4500, income: 240 },
  hills: { name: 'Royal Hills', cost: 6000, income: 300 },
  industrial: { name: 'Industrial Zone', cost: 5000, income: 270 },
  plaza: { name: 'City Plaza', cost: 4000, income: 210 },
};
const CAREERS = {
  police: { name: 'Police Officer', icon: '👮', salary: 300, duty: 180, rep: 1 },
  doctor: { name: 'Doctor', icon: '🩺', salary: 360, duty: 220, rep: 1 },
  royalguard: { name: 'Royal Guard', icon: '🛡️', salary: 330, duty: 200, rep: 1 },
  soldier: { name: 'Soldier', icon: '🎖️', salary: 320, duty: 190, rep: 1 },
  mechanic: { name: 'Mechanic', icon: '🔧', salary: 250, duty: 160, rep: 1 },
  criminal: { name: 'Gang Operative', icon: '🕶️', salary: 280, duty: 170, rep: 1 },
};
const HOUR = 3600000;
const LUXURIES = {
  supercar: { name: 'Supercar', icon: '🏎️', cost: 10000000, prestige: 10 },
  penthouse: { name: 'Luxury Penthouse', icon: '🏙️', cost: 75000000, prestige: 25 },
  yacht: { name: 'Private Yacht', icon: '🛥️', cost: 150000000, prestige: 50 },
  island: { name: 'Private Island', icon: '🏝️', cost: 500000000, prestige: 100 },
  orbitalhotel: { name: 'Orbital Hotel Suite', icon: '🛰️', cost: 2000000000, prestige: 250 },
};
const blank = () => ({ users: {}, gangs: {}, territories: Object.fromEntries(Object.keys(DISTRICTS).map(k => [k, { gang: null, paidAt: Date.now(), war: null }])) });
function state(group) {
  const key = String(group || 'private');
  if (!db.data.groups[key]) db.data.groups[key] = blank();
  const g = db.data.groups[key];
  if (!g.users) g.users = {};
  if (!g.gangs) g.gangs = {};
  if (!g.territories) g.territories = blank().territories;
  if (g.territories.market && !g.territories.oldtown) { g.territories.oldtown = g.territories.market; delete g.territories.market; }
  if (!g.president) g.president = null;
  if (!g.careerHolders) g.careerHolders = {};
  g.economySettings = Object.assign({ presidentSalary: 1000000, presidentSalaryInterval: 10 * 60000, robChance: 40, robCap: 5000 }, g.economySettings || {});
  if (!g.careerSalary) g.careerSalary = {};
  if (!g.governmentStaff) g.governmentStaff = {};
  if (!g.governmentAppointmentOffers) g.governmentAppointmentOffers = {};
  if (!Number.isSafeInteger(g.governmentTreasury)) g.governmentTreasury = 0;
  if (!Array.isArray(g.governmentAudit)) g.governmentAudit = [];
  if (!Array.isArray(g.governmentSalaryNotices)) g.governmentSalaryNotices = [];
  if (!Array.isArray(g.governmentStaffRemovalNotices)) g.governmentStaffRemovalNotices = [];
  if (!Array.isArray(g.careerRemovalNotices)) g.careerRemovalNotices = [];
  if (!Array.isArray(g.governmentLedger)) g.governmentLedger = [];
  if (!Array.isArray(g.courtCases)) g.courtCases = [];
  if (!g.governmentElection || typeof g.governmentElection !== 'object') g.governmentElection = null;
  if (!g.governmentImpeachment || typeof g.governmentImpeachment !== 'object') g.governmentImpeachment = null;
  if (!Array.isArray(g.governmentPetitions)) g.governmentPetitions = [];
  if (!g.governmentActionCooldowns || typeof g.governmentActionCooldowns !== 'object') g.governmentActionCooldowns = {};
  if (!Number.isSafeInteger(g.nextGovernmentPetitionId)) g.nextGovernmentPetitionId = 1;
  if (!Number.isSafeInteger(g.nextCourtCaseId)) g.nextCourtCaseId = 1;
  for (const staff of Object.values(g.governmentStaff)) { if (!Array.isArray(staff.powers)) staff.powers = []; if (!Number.isFinite(staff.lastPaidAt)) staff.lastPaidAt = Number.isFinite(staff.lastClaimAt) ? staff.lastClaimAt : Date.now(); if (!Number.isFinite(staff.until)) staff.until = Date.now() + 2 * HOUR; if (!Number.isFinite(staff.lastDutyAt)) staff.lastDutyAt = staff.since || Date.now(); }
  expireInactiveGovernmentStaff(g, Date.now(), key);
  if (!Number.isFinite(g.careerSalaryLimit)) g.careerSalaryLimit = 100000;
  if (!g.kingSettingsRevoked) g.kingSettingsRevoked = {};
  if (!Number.isFinite(g.presidentTax)) g.presidentTax = 0;
  if (!Number.isFinite(g.presidentKingTax)) g.presidentKingTax = 0;
  if (!Number.isFinite(g.curfewUntil)) g.curfewUntil = 0;
  for (const k of Object.keys(DISTRICTS)) if (!g.territories[k]) g.territories[k] = { gang: null, paidAt: Date.now(), war: null };
  return g;
}
function touch() { db.touch(); }
function memberKey(jid) { return String(jid || '').split('@')[0].split(':')[0]; }
function user(group, jid) {
  const g = state(group), k = memberKey(jid);
  if (!g.users[k]) g.users[k] = { jid, career: null, rank: 1, duties: 0, lastDuty: 0, lastSalary: Date.now(), gang: null, lastAttack: 0, territoryPaid: {}, wanted: 0, jailedUntil: 0, bail: 0, ghostUntil: 0, nickname: null, nicknameUntil: 0, lastCrime: 0, crimeRecordAt: 0, servedSentenceAt: 0, protectedUntil: 0, luxuries: [], careerUntil: 0, lastFine: 0 };
  const u = g.users[k];
  if (!u.jid) u.jid = jid;
  if (!Array.isArray(u.luxuries)) u.luxuries = [];
  for (const [field, value] of Object.entries({ wanted: 0, jailedUntil: 0, bail: 0, jailReason: '', jailedBy: '', jailType: '', ghostUntil: 0, nickname: null, nicknameUntil: 0, lastCrime: 0, crimeRecordAt: 0, servedSentenceAt: 0, protectedUntil: 0, luxuries: [], careerUntil: 0, lastFine: 0, arrests: 0, lastEscape: 0, kidnappedUntil: 0, kidnappedBy: null, ransom: 0 })) if (u[field] === undefined) u[field] = value;
  return u;
}
function jailLeft(group, jid, now = Date.now()) {
  const g = db.data.groups[String(group || 'private')], u = g?.users?.[memberKey(jid)];
  if (u && u.jailedUntil && u.jailedUntil <= now) {
    // Completing a real crime-system sentence rehabilitates the criminal record; bail/escape do not.
    if (u.jailType !== 'presidential' && ((u.crimeRecordAt || u.lastCrime || 0) > 0 || (u.arrests || 0) > 0)) u.servedSentenceAt = Math.max(u.servedSentenceAt || 0, now);
    // Wanted status clears when a sentence is completed, not while the suspect is inside.
    u.jailedUntil = 0; u.bail = 0; u.wanted = 0; u.jailReason = ''; u.jailedBy = ''; u.jailType = '';
    touch();
  }
  return Math.max(0, (u?.jailedUntil || 0) - now);
}
function expireDetentions(now = Date.now()) {
  let released = 0;
  for (const g of Object.values(db.data.groups || {})) {
    for (const u of Object.values(g.users || {})) {
      if (u && u.jailedUntil && u.jailedUntil <= now) {
        if (u.jailType !== 'presidential' && ((u.crimeRecordAt || u.lastCrime || 0) > 0 || (u.arrests || 0) > 0)) u.servedSentenceAt = Math.max(u.servedSentenceAt || 0, now);
        u.jailedUntil = 0; u.bail = 0; u.wanted = 0; u.jailReason = ''; u.jailedBy = ''; u.jailType = ''; released++;
      }
    }
  }
  if (released) touch();
  return released;
}
function addWanted(group, jid, amount = 1, now = Date.now()) {
  const g = state(group), u = user(group, jid); u.wanted = Math.max(0, Math.min(5, (u.wanted || 0) + amount)); u.lastCrime = now; u.crimeRecordAt = now;
  // Wanted officers immediately lose law-enforcement powers and government office.
  removeWantedGovernmentStaffFromState(g, group, memberKey(jid), now);
  removeLawEnforcementCareer(g, group, memberKey(jid), 'wanted', now); touch(); return u.wanted;
}
function setWantedLevel(group, jid, level, now = Date.now()) {
  const n = Number(level); if (!Number.isInteger(n) || n < 0 || n > 5) return { ok:false, why:'level' };
  const g = state(group), u = user(group, jid); u.wanted = n; if (n > 0) { u.lastCrime = now; u.crimeRecordAt = now; }
  const removed = n > 0 ? removeWantedGovernmentStaffFromState(g, group, memberKey(jid), now) : false;
  const careerRemoved = n > 0 ? removeLawEnforcementCareer(g, group, memberKey(jid), 'wanted', now) : false; touch();
  return { ok:true, wanted:n, removed:!!removed, careerRemoved:!!careerRemoved };
}
function arrest(group, jid, now = Date.now(), options = {}) {
  const u = user(group, jid);
  if ((u.jailedUntil || 0) > now) return { ok: false, why: 'jailed', until: u.jailedUntil };
  if (!(u.wanted > 0)) return { ok: false, why: 'clean' };
  const level = u.wanted;
  const minutes = options.minutes === undefined ? Math.min(30, 5 + level * 5) : Number(options.minutes);
  const bail = options.bail === undefined ? Math.max(100, level * 150) : Number(options.bail);
  if (!Number.isInteger(minutes) || minutes < 1 || minutes > 120) return { ok: false, why: 'duration' };
  if (!Number.isSafeInteger(bail) || bail < 0 || bail > 1000000000000) return { ok: false, why: 'bail' };
  const duration = minutes * 60000;
  u.jailedUntil = now + duration; u.bail = bail; u.jailReason = `Wanted level ${level}/5`; u.jailedBy = 'police'; u.jailType = 'police'; touch();
  return { ok: true, until: u.jailedUntil, duration, bail: u.bail, wanted: level };
}
function payBail(group, jid, now = Date.now()) {
  const u = user(group, jid);
  if (!(u.jailedUntil > now)) { u.jailedUntil = 0; u.bail = 0; return { ok: false, why: 'free' }; }
  const amount = Math.max(0, u.bail || 0); u.jailedUntil = 0; u.bail = 0; u.wanted = 0; u.jailReason = ''; u.jailedBy = ''; u.jailType = ''; touch(); return { ok: true, amount };
}
function prisonWork(group, jid, now = Date.now()) {
  const u = user(group, jid), remaining = (u.jailedUntil || 0) - now;
  if (remaining <= 0) { jailLeft(group, jid, now); return { ok: false, why: 'free' }; }
  const cooldown = 3 * 60000;
  if (u.lastPrisonWork && now - u.lastPrisonWork < cooldown) return { ok: false, why: 'cooldown', wait: cooldown - (now - u.lastPrisonWork) };
  const reduction = Math.min(60000, remaining);
  u.jailedUntil -= reduction; u.lastPrisonWork = now; touch();
  if (u.jailedUntil <= now) { if (u.jailType !== 'presidential' && ((u.crimeRecordAt || u.lastCrime || 0) > 0 || (u.arrests || 0) > 0)) u.servedSentenceAt = Math.max(u.servedSentenceAt || 0, now); u.jailedUntil = 0; u.bail = 0; u.wanted = 0; u.jailReason = ''; u.jailedBy = ''; u.jailType = ''; }
  return { ok: true, reduction, remaining: Math.max(0, u.jailedUntil - now) };
}
function presidentialJail(group, president, target, minutes, reason = '', now = Date.now()) {
  if (!isPresident(group, president, now)) return { ok: false, why: 'notpresident' };
  if (!target || memberKey(target) === memberKey(president)) return { ok: false, why: 'target' };
  const duration = Number(minutes);
  if (!Number.isInteger(duration) || duration < 1 || duration > 120) return { ok: false, why: 'duration' };
  const g = state(group), targetKey = memberKey(target), cooldownKey = `detain:${targetKey}`, nextAllowed = g.governmentActionCooldowns[cooldownKey] || 0;
  if (nextAllowed > now) return { ok: false, why: 'cooldown', wait: nextAllowed - now };
  const u = user(group, target);
  if (u.jailedUntil > now) return { ok: false, why: 'jailed', until: u.jailedUntil };
  g.governmentActionCooldowns[cooldownKey] = now + 5 * 60000;
  u.jailedUntil = now + duration * 60000; u.bail = 0; u.jailedBy = president; u.jailType = 'presidential';
  u.jailReason = String(reason || 'Presidential detention').trim().slice(0, 120); touch();
  return { ok: true, until: u.jailedUntil, duration: duration * 60000, reason: u.jailReason };
}
function releaseDetainee(group, jid, target, now = Date.now()) {
  const g = state(group), u = g.users[memberKey(target)];
  if (!u || !(u.jailedUntil > now)) return { ok: false, why: 'free' };
  const president = isPresident(group, jid, now), staff = governmentStaffCan(group, jid, 'security');
  if (!president && !staff) return { ok: false, why: 'permission' };
  u.jailedUntil = 0; u.bail = 0; u.wanted = 0; u.jailReason = ''; u.jailedBy = ''; u.jailType = ''; touch();
  return { ok: true, target };
}
function fileCourtAppeal(group, jid, reason = '', now = Date.now()) {
  const g = state(group), u = user(group, jid);
  if (!(u.jailedUntil > now)) return { ok: false, why: 'free' };
  if (g.courtCases.some(c => c && c.status === 'pending' && memberKey(c.appellant) === memberKey(jid))) return { ok: false, why: 'pending' };
  const text = String(reason || '').trim().slice(0, 240);
  if (!text) return { ok: false, why: 'reason' };
  const c = { id: g.nextCourtCaseId++, type: 'detention-appeal', appellant: jid, jailedBy: u.jailedBy || null, jailType: u.jailType || 'unknown', jailReason: u.jailReason || 'No reason recorded', filedReason: text, filedAt: now, status: 'pending', reviewedBy: null, decision: null, decisionReason: '' };
  g.courtCases.push(c); if (g.courtCases.length > 100) g.courtCases = g.courtCases.slice(-100); touch(); return { ok: true, case: c };
}
function courtCases(group, status = 'pending', limit = 10) {
  return state(group).courtCases.filter(c => c && (!status || status === 'all' || c.status === status)).slice(-Math.max(1, Math.min(30, limit))).reverse();
}
function reviewCourtCase(group, reviewer, id, decision, reason = '', now = Date.now()) {
  const g = state(group), c = g.courtCases.find(x => x && x.id === Number(id));
  if (!isPresident(group, reviewer, now) && !governmentStaffCan(group, reviewer, 'justice')) return { ok: false, why: 'permission' };
  if (!c) return { ok: false, why: 'missing' };
  // A President cannot judge an appeal against their own detention or action. Justice staff remain eligible.
  if (isPresident(group, reviewer, now) && (memberKey(c.jailedBy) === memberKey(reviewer) || (c.jailType === 'presidential' && !c.jailedBy))) return { ok: false, why: 'conflict' };
  if (c.status !== 'pending') return { ok: false, why: 'reviewed', case: c };
  if (!['uphold', 'dismiss'].includes(decision)) return { ok: false, why: 'decision' };
  const appellant = user(group, c.appellant);
  c.status = decision === 'dismiss' ? 'dismissed' : 'upheld'; c.reviewedBy = reviewer; c.reviewedAt = now; c.decisionReason = String(reason || '').trim().slice(0, 240); c.decision = decision;
  if (decision === 'dismiss') {
    appellant.jailedUntil = 0; appellant.bail = 0; appellant.wanted = 0; appellant.jailReason = ''; appellant.jailedBy = ''; appellant.jailType = '';
  } else if (appellant.jailedUntil > now) {
    const cap = now + 120 * 60000; appellant.jailedUntil = Math.min(cap, appellant.jailedUntil + 5 * 60000);
  }
  recordGovernmentStaffAction(group, reviewer, `Court ${decision}`, `Case #${c.id}: ${memberKey(c.appellant)}${c.decisionReason ? ` · ${c.decisionReason}` : ''}`);
  touch(); return { ok: true, case: c };
}
function attemptPrisonEscape(group, jid, now = Date.now(), random = Math.random()) {
  const u = user(group, jid), remaining = (u.jailedUntil || 0) - now;
  if (remaining <= 0) { jailLeft(group, jid, now); return { ok: false, why: 'free' }; }
  const cooldown = 10 * 60000;
  if (u.lastEscape && now - u.lastEscape < cooldown) return { ok: false, why: 'cooldown', wait: cooldown - (now - u.lastEscape) };
  u.lastEscape = now;
  const chance = u.jailType === 'presidential' ? 0.15 : 0.25;
  if (random < chance) {
    u.jailedUntil = 0; u.bail = 0; u.jailReason = ''; u.jailedBy = ''; u.jailType = ''; addWanted(group, jid, 2, now); touch();
    return { ok: true, chance, wanted: u.wanted };
  }
  const extension = (u.jailType === 'presidential' ? 10 : 5) * 60000;
  const previousUntil = u.jailedUntil; u.jailedUntil = Math.min(now + 120 * 60000, previousUntil + extension); const added = u.jailedUntil - previousUntil; addWanted(group, jid, 1, now); touch();
  return { ok: false, why: 'caught', chance, extension: added, until: u.jailedUntil, wanted: u.wanted };
}
function recordPoliceArrest(group, officerJid, now = Date.now()) {
  const u = user(group, officerJid);
  if (u.career !== 'police') return { ok: false, why: 'career' };
  u.arrests = (u.arrests || 0) + 1;
  const thresholds = [0, 3, 6, 10, 15];
  const oldRank = Math.max(1, u.rank || 1);
  let rank = oldRank;
  while (rank < 5 && u.arrests >= thresholds[rank]) rank++;
  u.rank = rank; u.lastArrest = now; touch();
  return { ok: true, arrests: u.arrests, oldRank, rank, promoted: rank > oldRank };
}
function applyNickname(group, jid, nickname, now = Date.now()) {
  const u = user(group, jid); const text = String(nickname || '').trim().replace(/[\r\n]/g, ' ').slice(0, 32);
  if (!text) return { ok: false, why: 'empty' };
  u.nickname = text; u.nicknameUntil = now + 3600000; touch(); return { ok: true, nickname: text, until: u.nicknameUntil };
}
function activeNickname(group, jid, now = Date.now()) { const u = user(group, jid); return u.nicknameUntil > now ? u.nickname : null; }


const PRESIDENT_COST = 5000000;
const PRESIDENT_TERM = 2 * HOUR;
const CAREER_TERM = 2 * HOUR;
function careerHolder(group, career, now = Date.now()) {
  const g = state(group), h = g.careerHolders[career];
  if (h && h.until <= now) { delete g.careerHolders[career]; const u = g.users[h.key]; if (u && u.career === career) { u.career = null; u.careerUntil = 0; } touch(); return null; }
  return h || null;
}
function refreshCareer(group, jid, now = Date.now()) {
  const g = state(group), u = user(group, jid), key = memberKey(jid);
  if (u.career && (!u.careerUntil || u.careerUntil <= now)) {
    const h = g.careerHolders[u.career];
    if (h && h.key === key) delete g.careerHolders[u.career];
    u.career = null; u.careerUntil = 0; u.rank = 1; u.duties = 0; touch();
  }
  // Migrate old saves: legacy wanted, jailed, or gang-affiliated law-enforcement holders lose their powers.
  if (u.career && ['police','royalguard','soldier'].includes(u.career)) {
    const recordAt = Math.max(u.crimeRecordAt || 0, u.lastCrime || 0);
    const unrehabilitated = recordAt > 0 && !((u.servedSentenceAt || 0) >= recordAt && (u.servedSentenceAt || 0) > 0);
    if ((u.wanted || 0) > 0) removeLawEnforcementCareer(g, group, key, 'wanted', now);
    else if ((u.jailedUntil || 0) > now) removeLawEnforcementCareer(g, group, key, 'jailed', now);
    else if (u.gang) removeLawEnforcementCareer(g, group, key, 'gang-affiliation', now);
    else if (unrehabilitated) removeLawEnforcementCareer(g, group, key, 'active criminal record', now);
  }
  return u;
}
function isPresident(group, jid, now = Date.now()) { const p = presidentInfo(group, now).president; return !!p && p.key === memberKey(jid); }
function isGovernmentLeader(group, jid, now = Date.now()) { return isPresident(group, jid, now) || require('./throne').isKing(group, jid); }
function removeLawEnforcementCareer(g, group, key, reason = 'wanted', now = Date.now()) {
  const u = g.users?.[key];
  if (!u || !['police','royalguard','soldier'].includes(u.career)) return false;
  const career = u.career, holder = g.careerHolders?.[career];
  if (holder && holder.key === key) delete g.careerHolders[career];
  u.career = null; u.careerUntil = 0; u.rank = 1; u.duties = 0;
  g.careerRemovalNotices.push({ group, jid: u.jid, career, reason, wanted: u.wanted || 0, at: now, noticeId: `career-removal:${group}:${key}:${now}` });
  if (g.careerRemovalNotices.length > 100) g.careerRemovalNotices.splice(0, g.careerRemovalNotices.length - 100);
  return true;
}
function careerEligibility(group, jid, career, now = Date.now()) {
  const u = user(group, jid), c = String(career || '').toLowerCase();
  if (!Object.hasOwn(CAREERS, c)) return { ok: false, why: 'career' };
  if (['police','royalguard','soldier'].includes(c)) {
    if ((u.wanted || 0) > 0) return { ok: false, why: 'wanted' };
    if ((u.jailedUntil || 0) > now) return { ok: false, why: 'jailed' };
    if (u.gang) return { ok: false, why: 'gang' };
    const recordAt = Math.max(u.crimeRecordAt || 0, u.lastCrime || 0);
    if (recordAt > 0 && !((u.servedSentenceAt || 0) >= recordAt && (u.servedSentenceAt || 0) > 0)) return { ok: false, why: 'criminal_record' };
  }
  return { ok: true };
}
function claimCareer(group, jid, career, now = Date.now()) {
  const g = state(group), u = refreshCareer(group, jid, now), c = String(career || '').toLowerCase();
  if (!Object.hasOwn(CAREERS, c)) return { ok: false, why: 'career' };
  if (isGovernmentLeader(group, jid)) return { ok: false, why: 'leader' };
  if (u.career) return { ok: false, why: 'hascareer', career: u.career };
  const eligible = careerEligibility(group, jid, c, now); if (!eligible.ok) return eligible;
  const h = careerHolder(group, c, now);
  if (h && h.key !== memberKey(jid)) return { ok: false, why: 'occupied', holder: h };
  u.career = c; u.careerUntil = now + CAREER_TERM; u.rank = 1; u.duties = 0; u.lastSalary = now;
  g.careerHolders[c] = { jid, key: memberKey(jid), since: now, until: u.careerUntil };
  touch(); return { ok: true, until: u.careerUntil };
}
function releaseCareer(group, jid, now = Date.now()) {
  const g = state(group), u = refreshCareer(group, jid, now);
  if (!u.career) return { ok: false, why: 'none' };
  const old = u.career, h = g.careerHolders[old]; if (h && h.key === memberKey(jid)) delete g.careerHolders[old];
  u.career = null; u.careerUntil = 0; u.rank = 1; u.duties = 0; touch(); return { ok: true, career: old };
}
function economySettings(group) { return { ...state(group).economySettings }; }
function careerSalary(group, career, rank = 1) { const g = state(group), base = Number.isFinite(g.careerSalary[career]) ? g.careerSalary[career] : CAREERS[career]?.salary || 0; return Math.min(g.careerSalaryLimit, Math.max(0, base + (Math.max(1, rank) - 1) * 50)); }
function setCareerSalary(group, career, amount) { const g = state(group), n = Number(amount); if (!['all', ...Object.keys(CAREERS)].includes(career) || !Number.isSafeInteger(n) || n < 1 || n > 1000000000) return false; if (career === 'all') for (const key of Object.keys(CAREERS)) g.careerSalary[key] = n; else g.careerSalary[career] = n; touch(); return true; }
function setCareerSalaryLimit(group, amount) { const g = state(group), n = Number(amount); if (!Number.isSafeInteger(n) || n < 1 || n > 1000000000) return false; g.careerSalaryLimit = n; touch(); return true; }
function removeCareerHolder(group, jid) { const g=state(group), key=memberKey(jid), u=g.users[key]; if(!u || !u.career) return {ok:false,why:'nocareer'}; const career=u.career, h=g.careerHolders[career]; if(h && h.key===key) delete g.careerHolders[career]; u.career=null; u.careerUntil=0; u.rank=1; u.duties=0; touch(); return {ok:true,career}; }
function appointCareer(group, president, target, career, now=Date.now()) {
  const g=state(group), key=memberKey(target), c=String(career||'').toLowerCase();
  if(!isPresident(group,president,now)) return {ok:false,why:'notpresident'};
  if(!target || key===memberKey(president) || !CAREERS[c]) return {ok:false,why:'invalid'};
  if(isGovernmentLeader(group,target)) return {ok:false,why:'leader'};
  const u=refreshCareer(group,target,now), eligible=careerEligibility(group,target,c,now);
  if(!eligible.ok) return eligible;
  const occupied=careerHolder(group,c,now);
  if(occupied && occupied.key!==key) return {ok:false,why:'occupied',holder:occupied};
  if(u.career && g.careerHolders[u.career]?.key===key) delete g.careerHolders[u.career];
  u.career=c; u.careerUntil=now+CAREER_TERM; u.rank=1; u.duties=0; u.lastSalary=now;
  g.careerHolders[c]={jid:target,key,since:now,until:u.careerUntil,appointedBy:president}; touch(); return {ok:true,career:c,until:u.careerUntil};
}
function appointGovernmentStaff(group, jid, target, title, salary) { const g=state(group), amount=Number(salary), name=String(title||'').trim().replace(/[\r\n]/g,' ').slice(0,50); if(!isPresident(group,jid)) return {ok:false,why:'notpresident'}; if(!target || memberKey(target)===memberKey(jid) || !name || !Number.isSafeInteger(amount) || amount<1 || amount>1000000000) return {ok:false,why:'invalid'}; if ((user(group,target).wanted || 0) > 0) return {ok:false,why:'wanted'}; const now=Date.now(); g.governmentStaff[memberKey(target)]={jid:target,title:name,salary:amount,since:now,until:now+2*HOUR,lastClaimAt:now,lastPaidAt:now,appointedBy:jid,powers:[]}; touch(); return {ok:true,staff:g.governmentStaff[memberKey(target)]}; }
function appointGovernmentPosition(group, jid, target, position) {
  const g = state(group), key = memberKey(target), id = String(position || '').toLowerCase(), spec = GOVERNMENT_POSITIONS[id], now = Date.now();
  if (!isPresident(group, jid)) return { ok: false, why: 'notpresident' };
  if (!target || key === memberKey(jid) || !spec) return { ok: false, why: 'position' };
  if ((user(group, target).wanted || 0) > 0) return { ok: false, why: 'wanted' };
  if (g.governmentStaff[key] && g.governmentStaff[key].until > now) return { ok: false, why: 'already_staff' };
  for (const [offerKey, offer] of Object.entries(g.governmentAppointmentOffers)) if (offer.expiresAt <= now) delete g.governmentAppointmentOffers[offerKey];
  if (Object.values(g.governmentStaff).some(x => x.position === id && x.until > now && memberKey(x.jid) !== key) || Object.values(g.governmentAppointmentOffers).some(x => x.position === id && x.expiresAt > now && memberKey(x.jid) !== key)) return { ok: false, why: 'occupied' };
  const offer = { jid: target, title: spec.title, position: id, salary: spec.salary, appointedBy: jid, offeredAt: now, expiresAt: now + 30 * 60000, powers: [spec.power] };
  g.governmentAppointmentOffers[key] = offer; touch(); return { ok: true, pending: true, staff: offer };
}
function acceptGovernmentAppointment(group, jid, now = Date.now()) {
  const g = state(group), key = memberKey(jid), offer = g.governmentAppointmentOffers[key];
  if (!offer) return { ok: false, why: 'missing' };
  if (offer.expiresAt <= now) { delete g.governmentAppointmentOffers[key]; touch(); return { ok: false, why: 'expired' }; }
  if ((user(group, jid).wanted || 0) > 0) { delete g.governmentAppointmentOffers[key]; touch(); return { ok: false, why: 'wanted' }; }
  if (g.governmentStaff[key] && g.governmentStaff[key].until > now) return { ok: false, why: 'already_staff' };
  if (Object.values(g.governmentStaff).some(x => x.position === offer.position && x.until > now)) return { ok: false, why: 'occupied' };
  const staff = { jid: offer.jid, title: offer.title, position: offer.position, salary: offer.salary, since: now, until: now + 2 * HOUR, lastClaimAt: now, lastPaidAt: now, lastDutyAt: now, appointedBy: offer.appointedBy, powers: offer.powers || [] };
  g.governmentStaff[key] = staff; delete g.governmentAppointmentOffers[key];
  g.governmentAudit.push({ jid, title: staff.title, action: 'Appointment accepted', details: `Accepted appointment to ${staff.title}`, at: now, qualifying: false });
  touch(); return { ok: true, staff };
}
function governmentPositions(group) {
  const g = state(group);
  return Object.entries(GOVERNMENT_POSITIONS).map(([id, spec]) => ({ id, ...spec, holder: Object.values(g.governmentStaff).find(x => x.position === id && x.until > Date.now()) || null }));
}
function governmentStaff(group) { return Object.values(state(group).governmentStaff||{}).filter(x => x.until > Date.now()); }
function setGovernmentStaffSalary(group, jid, target, salary) {
  if(!isPresident(group,jid)) return {ok:false,why:'notpresident'};
  const g=state(group), staff=g.governmentStaff[memberKey(target)], amount=Number(salary);
  if(!staff || staff.until <= Date.now()) return {ok:false,why:'missing'};
  if(!Number.isSafeInteger(amount)||amount<1||amount>10000000) return {ok:false,why:'amount'};
  const now=Date.now(), oldPayment=payGovernmentStaff(staff,group,now); if(oldPayment) g.governmentSalaryNotices.push(oldPayment);
  const previousSalary=staff.pendingSalary || staff.salary; staff.pendingSalary=amount; staff.salaryEffectiveAt=(staff.lastPaidAt || staff.since || now)+20*60000;
  g.governmentAudit.push({jid, title:'President', action:'Staff salary changed', details:`${memberKey(target)}: ${previousSalary} -> ${amount} coins per 20 minutes; effective next pay interval`, at:now, qualifying:true});
  if(g.governmentAudit.length>100) g.governmentAudit.splice(0,g.governmentAudit.length-100);
  touch(); return {ok:true,staff,previousSalary};
}
function removeGovernmentStaff(group, jid, target) { if(!isPresident(group,jid)) return {ok:false,why:'notpresident'}; const g=state(group), key=memberKey(target), staff=g.governmentStaff[key]; if(!staff) return {ok:false,why:'missing'}; delete g.governmentStaff[key]; touch(); return {ok:true,staff}; }
const GOVERNMENT_POWERS = {
  security: 'Security: view group intelligence, assign wanted levels, arrest and release roleplay detainees',
  finance: 'Finance: view government treasury and issue grants from it',
  justice: 'Justice: fine players into the treasury and pardon wanted/jail records',
  health: 'Health: grant temporary robbery protection to players',
  interior: 'Interior: set or lift group curfew',
  communications: 'Communications: publish official government announcements',
};
const GOVERNMENT_POSITIONS = {
  security: { title: 'Minister of Security', power: 'security', salary: 1200, duty: 'Maintain the security roster, investigate wanted players, make justified arrests and process releases.' },
  finance: { title: 'Minister of Finance', power: 'finance', salary: 1200, duty: 'Monitor the government treasury and issue properly justified grants.' },
  justice: { title: 'Minister of Justice', power: 'justice', salary: 1200, duty: 'Review offences, issue proportionate fines and process justified pardons.' },
  health: { title: 'Minister of Health', power: 'health', salary: 1000, duty: 'Provide temporary protection when members report credible robbery risks.' },
  interior: { title: 'Minister of Interior', power: 'interior', salary: 1000, duty: 'Manage public safety curfews and announce changes when needed.' },
  communications: { title: 'Minister of Communications', power: 'communications', salary: 1000, duty: 'Publish useful official announcements and government updates.' },
};
function removeWantedGovernmentStaffFromState(g, group, key, now = Date.now()) {
  const staff = g.governmentStaff?.[key];
  if (!staff || !((g.users?.[key]?.wanted || 0) > 0)) return false;
  // Pay any fully completed interval before removing the official.
  const payment = payGovernmentStaff(staff, group, Math.min(now, staff.until || now));
  if (payment) g.governmentSalaryNotices.push(payment);
  delete g.governmentStaff[key];
  g.governmentAudit.push({ jid:staff.jid, title:staff.title, action:'Removed: wanted', details:`Automatically removed at wanted level ${g.users?.[key]?.wanted || 0}`, at:now });
  g.governmentStaffRemovalNotices.push({ group, jid:staff.jid, title:staff.title, wanted:g.users?.[key]?.wanted || 0, at:now, noticeId:`wanted:${group}:${key}:${now}` });
  if (g.governmentAudit.length > 100) g.governmentAudit.splice(0, g.governmentAudit.length - 100);
  return true;
}
function expireInactiveGovernmentStaff(g, now = Date.now(), group = 'private') {
  let changed = false;
  for (const [key, staff] of Object.entries(g.governmentStaff || {})) {
    if (removeWantedGovernmentStaffFromState(g, group, key, now)) { changed = true; continue; }
    if (staff.until <= now || now - (staff.lastDutyAt || staff.since || now) >= 20 * 60000) {
      const payment = payGovernmentStaff(staff, group, Math.min(now, staff.until || now));
      if (payment) g.governmentSalaryNotices.push(payment);
      delete g.governmentStaff[key]; changed = true;
      if (Array.isArray(g.governmentAudit)) g.governmentAudit.push({ jid: staff.jid, title: staff.title, action: staff.until <= now ? 'Term expired' : 'Removed for inactivity', details: staff.until <= now ? 'Office term ended' : 'No qualifying duty completed within 20 minutes', at: now });
    }
  }
  if (g.governmentAudit?.length > 100) g.governmentAudit.splice(0, g.governmentAudit.length - 100);
  if (changed) touch();
}
function setGovernmentStaffPowers(group, jid, target, powers) {
  if (!isPresident(group, jid)) return {ok:false,why:'notpresident'};
  const staff=state(group).governmentStaff[memberKey(target)];
  if (!staff) return {ok:false,why:'missing'};
  const list=[...new Set((Array.isArray(powers)?powers:String(powers||'').split(',')).map(x=>String(x).trim().toLowerCase()).filter(x=>Object.hasOwn(GOVERNMENT_POWERS,x)))];
  staff.powers=list; touch(); return {ok:true,staff};
}
function setGovernmentStaffTitle(group, jid, target, title) {
  if (!isPresident(group, jid)) return {ok:false,why:'notpresident'};
  const staff=state(group).governmentStaff[memberKey(target)], name=String(title||'').trim().replace(/[\r\n]/g,' ').slice(0,50);
  if (!staff) return {ok:false,why:'missing'}; if (!name) return {ok:false,why:'title'};
  staff.title=name; touch(); return {ok:true,staff};
}
function governmentStaffInfo(group, target) {
  const g=state(group), staff=g.governmentStaff[memberKey(target)];
  if (!staff || staff.until <= Date.now()) return null;
  const interval=20*60000, now=Date.now(), units=Math.floor(Math.max(0,now-(staff.lastPaidAt||staff.lastClaimAt||now))/interval);
  return {...staff, accrued:units*staff.salary, treasury:g.governmentTreasury||0};
}
function recordTreasuryTransaction(group, type, amount, actor = null, details = '') {
  const g=state(group), entry={type:String(type).slice(0,50),amount:Math.floor(Number(amount)||0),actor:actor||null,details:String(details).slice(0,160),balance:g.governmentTreasury||0,at:Date.now()};
  g.governmentLedger.push(entry); if(g.governmentLedger.length>100) g.governmentLedger.splice(0,g.governmentLedger.length-100); touch(); return entry;
}
function governmentLedger(group, limit=10) { return [...(state(group).governmentLedger||[])].slice(-Math.max(1,Math.min(30,Number(limit)||10))).reverse(); }
function governmentTreasury(group) { return state(group).governmentTreasury||0; }
function depositGovernmentTreasury(group, jid, amount) {
  if (!isPresident(group,jid)) return {ok:false,why:'notpresident'};
  const n=Number(amount); if(!Number.isSafeInteger(n)||n<1) return {ok:false,why:'amount'};
  if(!economy.take(jid,n)) return {ok:false,why:'poor'};
  const g=state(group); g.governmentTreasury=(g.governmentTreasury||0)+n; recordTreasuryTransaction(group,'President deposit',n,jid,'Personal funds deposited into public treasury'); touch(); return {ok:true,balance:g.governmentTreasury,amount:n};
}
function recordGovernmentStaffAction(group, jid, action, details = '') {
  const g=state(group), staff=g.governmentStaff[memberKey(jid)];
  if(!staff) return false;
  const label = String(action).slice(0,60);
  // Read-only reviews are logged, but cannot be repeated to evade the 20-minute work rule.
  const qualifying = !/^(treasury review|security roster review|status review|staff list|salary check)$/i.test(label);
  const at = Date.now();
  if (qualifying) staff.lastDutyAt = at;
  g.governmentAudit.push({jid:staff.jid,title:staff.title,action:label,details:String(details).slice(0,180),at,qualifying});
  if(g.governmentAudit.length>100) g.governmentAudit.splice(0,g.governmentAudit.length-100);
  touch(); return true;
}
function governmentStaffAudit(group, target = null, limit = 15) {
  const rows=state(group).governmentAudit||[];
  return rows.filter(x=>!target||memberKey(x.jid)===memberKey(target)).slice(-Math.max(1,Math.min(50,limit))).reverse();
}
function governmentStaffCan(group, jid, power) { const staff=state(group).governmentStaff[memberKey(jid)]; return !!staff && staff.until > Date.now() && Array.isArray(staff.powers) && staff.powers.includes(power); }
function governmentGrant(group, jid, target, amount) {
  if(!governmentStaffCan(group,jid,'finance')) return {ok:false,why:'power'};
  const n=Number(amount), g=state(group); if(!target||!Number.isSafeInteger(n)||n<1) return {ok:false,why:'amount'};
  if((g.governmentTreasury||0)<n) return {ok:false,why:'poor',balance:g.governmentTreasury||0};
  g.governmentTreasury-=n; economy.runIn(group,()=>economy.add(target,n)); recordTreasuryTransaction(group,'Government grant',-n,jid,`Recipient ${memberKey(target)}`); touch(); return {ok:true,amount:n,balance:g.governmentTreasury};
}
function applyGovernmentFine(group, jid, target, amount, reason = '', type = 'Justice fine', now = Date.now()) {
  const n=Number(amount), text=String(reason||'').trim().slice(0,160);
  if(!target || memberKey(target) === memberKey(jid)) return {ok:false,why:'target'};
  if(!Number.isSafeInteger(n)||n<1) return {ok:false,why:'amount'};
  if(!text) return {ok:false,why:'reason'};
  const g=state(group), cooldownKey=`fine:${memberKey(target)}`, nextAllowed=g.governmentActionCooldowns[cooldownKey]||0;
  if(nextAllowed>now) return {ok:false,why:'cooldown',wait:nextAllowed-now};
  const wallet=economy.runIn(group,()=>economy.balance(target)), maxFine=Math.min(100000,Math.floor(wallet*0.1));
  if(n>maxFine) return {ok:false,why:'limit',max:maxFine};
  const paid=Math.min(n,wallet); if(!paid) return {ok:false,why:'poor'};
  economy.runIn(group,()=>economy.take(target,paid)); g.governmentTreasury=(g.governmentTreasury||0)+paid;
  g.governmentActionCooldowns[cooldownKey]=now+5*60000;
  recordTreasuryTransaction(group,type,paid,jid,`From ${memberKey(target)} · ${text}`);
  recordGovernmentAction(group,jid,type,`${memberKey(target)} · ${paid} · ${text}`);
  touch(); return {ok:true,amount:paid,balance:g.governmentTreasury,previousWallet:wallet,newWallet:economy.runIn(group,()=>economy.balance(target))};
}
function governmentFine(group, jid, target, amount, reason = '') {
  if(!governmentStaffCan(group,jid,'justice')) return {ok:false,why:'power'};
  return applyGovernmentFine(group,jid,target,amount,reason,'Justice fine');
}
function presidentialFine(group, jid, target, amount, reason = '') {
  if(!isPresident(group,jid)) return {ok:false,why:'notpresident'};
  return applyGovernmentFine(group,jid,target,amount,reason,'Presidential fine');
}
function payGovernmentStaff(staff, group, now=Date.now()) {
  const interval=20*60000, last=Number.isFinite(staff.lastPaidAt)?staff.lastPaidAt:(Number.isFinite(staff.lastClaimAt)?staff.lastClaimAt:now);
  const end=Number.isFinite(staff.until)?Math.min(now,staff.until):now;
  const units=Math.floor(Math.max(0,end-last)/interval);
  if(units<1) return null;
  let amount=units*staff.salary;
  if (Number.isSafeInteger(staff.pendingSalary) && Number.isFinite(staff.salaryEffectiveAt)) {
    const oldUnits=Math.max(0,Math.min(units,Math.floor((staff.salaryEffectiveAt-last)/interval)));
    amount=oldUnits*staff.salary+(units-oldUnits)*staff.pendingSalary;
    if (units>oldUnits) { staff.salary=staff.pendingSalary; delete staff.pendingSalary; delete staff.salaryEffectiveAt; }
  }
  staff.lastPaidAt=last+units*interval;
  const previousBalance=economy.runIn(group,()=>economy.balance(staff.jid));
  const balance=economy.runIn(group,()=>economy.add(staff.jid,amount));
  return {group,jid:staff.jid,title:staff.title,amount,previousBalance,balance,paidAt:now,noticeId:`${group}:${memberKey(staff.jid)}:${now}:${amount}:${previousBalance}`};
}
function distributeGovernmentPayroll(now=Date.now()) {
  let paid=0, recipients=0; const payments=[];
  for(const group of Object.keys(db.data.groups||{})) {
    presidentInfo(group, now);
    const g=state(group);
    for(const staff of Object.values(g.governmentStaff||{})) {
      const payment=payGovernmentStaff(staff,group,now);
      if(payment) { paid+=payment.amount; recipients++; g.governmentSalaryNotices.push(payment); }
    }
    if(g.governmentSalaryNotices?.length) payments.push(...g.governmentSalaryNotices);
  }
  if(paid || payments.length) touch();
  return {paid,recipients,payments};
}
function collectGovernmentSalary(group, jid, now=Date.now()) {
  const g=state(group), staff=g.governmentStaff[memberKey(jid)];
  if(!staff || staff.until <= now) return {ok:false,why:'notstaff'};
  const payment=payGovernmentStaff(staff,group,now);
  if(payment) touch();
  const interval=20*60000;
  const balance=economy.runIn(group,()=>economy.balance(jid));
  return {ok:true,amount:payment?.amount||0,previousBalance:payment?.previousBalance??balance,balance:payment?.balance??balance,accrued:Math.floor(Math.max(0,now-(staff.lastPaidAt||staff.lastClaimAt||now))/interval)*staff.salary,staff};
}
function careerRoster(group) { const g = state(group); return Object.values(g.users).filter(u => u && u.jid).map(u => ({ jid:u.jid, career:u.career, rank:u.rank || 1, arrests:u.arrests || 0, duties:u.duties || 0, wanted:u.wanted || 0, jailedUntil:u.jailedUntil || 0, bail:u.bail || 0, gang:u.gang || null, lastCrime:u.lastCrime || 0, protectedUntil:u.protectedUntil || 0, ghostUntil:u.ghostUntil || 0, luxuries:u.luxuries || [], careerUntil:u.careerUntil || 0 })); }
// Sweep inactive officials in the background so expired offices are removed even if nobody runs a command.
const governmentStaffSweep = setInterval(() => {
  for (const group of Object.keys(db.data.groups || {})) {
    try { state(group); } catch (error) { console.error('Government staff expiry sweep failed:', error.message); }
  }
}, 30 * 1000);
if (typeof governmentStaffSweep.unref === 'function') governmentStaffSweep.unref();
function robberySettings(group) { const x = economySettings(group); return { chance: x.robChance / 100, cap: x.robCap }; }
function setEconomySetting(group, key, value) {
  const g = state(group), n = Number(value);
  const ranges = { presidentSalary: [1, Number.MAX_SAFE_INTEGER], presidentSalaryInterval: [1, 1440], robChance: [1, 90], robCap: [100, Number.MAX_SAFE_INTEGER] };
  if (!ranges[key] || !Number.isSafeInteger(n) || n < ranges[key][0] || n > ranges[key][1]) return false;
  g.economySettings[key] = key === 'presidentSalaryInterval' ? n * 60000 : n; touch(); return true;
}

function recordGovernmentAction(group, jid, action, details = '') {
  const g = state(group), at = Date.now();
  g.governmentAudit.push({ jid, title: isPresident(group, jid) ? 'President' : 'Government', action: String(action).slice(0, 60), details: String(details).slice(0, 180), at, qualifying: true });
  if (g.governmentAudit.length > 100) g.governmentAudit.splice(0, g.governmentAudit.length - 100);
  touch(); return true;
}
function presidentSalaryPayment(group, now = Date.now()) {
  const p = state(group).president;
  if (!p) return { amount: 0, previousBalance: 0, balance: 0, jid: null };
  const previousBalance = economy.runIn(group, () => economy.balance(p.jid));
  const amount = collectPresidentSalary(group, now);
  const balance = economy.runIn(group, () => economy.balance(p.jid));
  return { amount, previousBalance, balance, jid: p.jid, title: 'President' };
}
function takeGovernmentSalaryNotices(group) { return [...(state(group).governmentSalaryNotices || [])]; }
function markGovernmentSalaryNotice(group, noticeId, channel) {
  const g=state(group), notice=g.governmentSalaryNotices.find(x=>x.noticeId===noticeId); if(!notice) return false;
  if(channel==='group') notice.groupNotified=true; else if(channel==='user') notice.userNotified=true; else return false;
  if(notice.groupNotified && notice.userNotified) g.governmentSalaryNotices=g.governmentSalaryNotices.filter(x=>x.noticeId!==noticeId);
  touch(); return true;
}
function governmentGroupsForScheduler() { return Object.keys(db.data.groups || {}); }
function takeGovernmentStaffRemovalNotices(group) { return [...(state(group).governmentStaffRemovalNotices || [])]; }
function ackGovernmentStaffRemovalNotice(group, noticeId) { const g=state(group), before=g.governmentStaffRemovalNotices.length; g.governmentStaffRemovalNotices=g.governmentStaffRemovalNotices.filter(x=>x.noticeId!==noticeId); if(g.governmentStaffRemovalNotices.length!==before) touch(); return g.governmentStaffRemovalNotices.length!==before; }
function takeCareerRemovalNotices(group) { return [...(state(group).careerRemovalNotices || [])]; }
function ackCareerRemovalNotice(group, noticeId) { const g=state(group), before=g.careerRemovalNotices.length; g.careerRemovalNotices=g.careerRemovalNotices.filter(x=>x.noticeId!==noticeId); if(g.careerRemovalNotices.length!==before) touch(); return g.careerRemovalNotices.length!==before; }
function ackGovernmentSalaryNotice(group, noticeId) {
  const g=state(group), before=g.governmentSalaryNotices.length;
  g.governmentSalaryNotices=g.governmentSalaryNotices.filter(x=>x.noticeId!==noticeId);
  if(g.governmentSalaryNotices.length!==before) touch();
  return g.governmentSalaryNotices.length!==before;
}

function presidentSalaryAccrued(group, now = Date.now()) { const g=state(group), p=g.president; if(!p) return 0; const settings=economySettings(group), end=Math.min(now,p.until), last=p.lastSalary||p.since; return Math.floor(Math.max(0,end-last)/settings.presidentSalaryInterval)*settings.presidentSalary; }
function collectPresidentSalary(group, now = Date.now()) {
  const g = state(group), p = g.president; if (!p) return 0;
  const settings = economySettings(group), end = Math.min(now, p.until), last = p.lastSalary || p.since;
  const units = Math.floor(Math.max(0, end - last) / settings.presidentSalaryInterval);
  if (units < 1) return 0;
  const amount = units * settings.presidentSalary;
  p.lastSalary = last + units * settings.presidentSalaryInterval; p.lastSalaryPaid = amount; p.lastSalaryPaidAt = now;
  economy.runIn(group, () => economy.add(p.jid, amount)); touch(); return amount;
}
function presidentInfo(group, now = Date.now()) {
  const g = state(group), p = g.president;
  if (p && p.until <= now) { const previousBalance=economy.runIn(group,()=>economy.balance(p.jid)); const amount=collectPresidentSalary(group, now); const balance=economy.runIn(group,()=>economy.balance(p.jid)); if (amount > 0) g.governmentSalaryNotices.push({ group, jid:p.jid, title:'President', amount, previousBalance, balance, paidAt:now, noticeId:`${group}:${memberKey(p.jid)}:${now}:${amount}:${previousBalance}` }); g.lastPresidentKey = p.key || memberKey(p.jid); g.lastPresidentJid = p.jid; g.president = null; g.presidentTax = 0; g.presidentKingTax = 0; g.curfewUntil = 0; touch(); }
  return { president: g.president, tax: g.presidentTax || 0, kingTax: g.presidentKingTax || 0, curfew: Math.max(0, g.curfewUntil - now), cost: PRESIDENT_COST, term: PRESIDENT_TERM, settings: economySettings(group) };
}
function resignPresident(group, jid, now = Date.now()) {
  const g = state(group), p = presidentInfo(group, now).president;
  if (!p || p.key !== memberKey(jid)) return { ok: false, why: 'notpresident' };
  // Pay only completed salary intervals before vacating the office.
  const salaryPaid = collectPresidentSalary(group, now);
  g.lastPresidentKey = p.key || memberKey(p.jid);
  g.lastPresidentJid = p.jid;
  g.president = null;
  g.presidentTax = 0;
  g.presidentKingTax = 0;
  g.curfewUntil = 0;
  touch();
  return { ok: true, president: p, salaryPaid };
}
function takePresident(group, jid, now = Date.now()) {
  governmentElectionStatus(group, now);
  const g = state(group), p = presidentInfo(group, now).president;
  if (g.governmentElection && g.governmentElection.status === 'open' && g.governmentElection.endsAt > now) return { ok: false, why: 'election' };
  const candidate = user(group, jid);
  if (candidate.gang) return { ok: false, why: 'gang' };
  if (require('./throne').isKing(group, jid)) return { ok: false, why: 'king' };
  if ((candidate.jailedUntil || 0) > now) return { ok: false, why: 'jailed', until: candidate.jailedUntil };
  if ((candidate.wanted || 0) > 0) return { ok: false, why: 'wanted' };
  // Only a timestamped crime record should block eligibility. `arrests` is also
  // used for police career milestones and may exist on legacy profiles without
  // proving that this member committed a crime or owes a prison sentence.
  const recordAt = Math.max(candidate.crimeRecordAt || 0, candidate.lastCrime || 0);
  const hasRecord = recordAt > 0;
  if (hasRecord && !((candidate.servedSentenceAt || 0) >= recordAt && (candidate.servedSentenceAt || 0) > 0)) return { ok: false, why: 'criminal_record', recordAt, servedSentenceAt: candidate.servedSentenceAt || 0 };
  if (candidate.career) releaseCareer(group, jid, now);
  if (p && p.key === memberKey(jid)) return { ok: false, why: 'already' };
  if (p && p.until > now) return { ok: false, why: 'occupied', president: p };
  if (g.lastPresidentKey && g.lastPresidentKey === memberKey(jid)) return { ok: false, why: 'previous', previous: g.lastPresidentJid || jid };
  if (!economy.take(jid, PRESIDENT_COST)) return { ok: false, why: 'poor', wallet: economy.balance(jid), cost: PRESIDENT_COST };
  g.president = { jid, key: memberKey(jid), since: now, lastSalary: now, until: now + PRESIDENT_TERM };
  g.lastPresidentKey = memberKey(jid); g.lastPresidentJid = jid;
  g.presidentTax = 0; g.presidentKingTax = 0; g.curfewUntil = 0; touch();
  return { ok: true, until: g.president.until, cost: PRESIDENT_COST };
}
function setPresidentTax(group, jid, pct, now = Date.now()) {
  if (!isPresident(group, jid, now)) return { ok: false, why: 'notpresident' };
  const n = Math.round(Number(pct) * 10) / 10;
  if (!Number.isFinite(n) || n < 0 || n > 25) return { ok: false, why: 'range' };
  state(group).presidentTax = n; touch(); return { ok: true, tax: n };
}
function setPresidentKingTax(group, jid, pct, now = Date.now()) {
  if (!isPresident(group, jid, now)) return { ok: false, why: 'notpresident' };
  const n = Math.round(Number(pct) * 10) / 10;
  if (!Number.isFinite(n) || n < 0 || n > 25) return { ok: false, why: 'range' };
  state(group).presidentKingTax = n; touch(); return { ok: true, tax: n };
}

function protectionLeft(group, jid, now = Date.now()) { const g = db.data.groups[String(group || 'private')]; const u = g?.users?.[memberKey(jid)]; return Math.max(0, (u?.protectedUntil || 0) - now); }
function protect(group, jid, target, duration = 30 * 60000, now = Date.now()) { const u = user(group, target); u.protectedUntil = Math.max(u.protectedUntil || 0, now + duration); touch(); return u.protectedUntil; }
function stimulus(group, jid, perPerson) {
  if (!isPresident(group, jid)) return { ok: false, why: 'notpresident' };
  const g = state(group), people = Object.values(g.users).filter((u) => u && u.career !== undefined).map((u) => u.jid).filter(Boolean);
  // Include users who have used roleplay/economy in this group; never mint an unlimited group-wide payout.
  const ids = [...new Set(people)].filter((id) => memberKey(id) !== memberKey(jid));
  const total = ids.length * perPerson;
  if (!Number.isSafeInteger(perPerson) || perPerson < 1 || ids.length < 1) return { ok: false, why: 'amount', count: ids.length };
  if (!economy.take(jid, total)) return { ok: false, why: 'poor', total, count: ids.length };
  for (const id of ids) economy.add(id, perPerson);
  touch(); return { ok: true, total, count: ids.length, perPerson };
}

function gangName(s) { return String(s || '').trim().toLowerCase().replace(/[^a-z0-9_-]/g, '').slice(0, 20); }
function getGang(group, jid) { const u = user(group, jid); return u.gang ? state(group).gangs[u.gang] || null : null; }
function makeGang(group, jid, name) {
  const g = state(group), u = user(group, jid), key = gangName(name);
  if (isGovernmentLeader(group, jid)) return { ok: false, why: 'leader' };
  if (['police','royalguard','soldier'].includes(user(group, jid).career)) return { ok: false, why: 'career' };
  if (!key || key.length < 3) return { ok: false, why: 'name' };
  if (u.gang) return { ok: false, why: 'member' };
  if (g.gangs[key]) return { ok: false, why: 'taken' };
  g.gangs[key] = { key, name: key, leader: memberKey(jid), members: [memberKey(jid)], treasury: 0, createdAt: Date.now() };
  u.gang = key; touch(); return { ok: true, gang: g.gangs[key] };
}
function joinGang(group, jid, name) {
  const g = state(group), u = user(group, jid), key = gangName(name), gang = g.gangs[key];
  if (isGovernmentLeader(group, jid)) return { ok: false, why: 'leader' };
  if (['police','royalguard','soldier'].includes(u.career)) return { ok: false, why: 'career' };
  if (u.gang) return { ok: false, why: 'member' };
  if (!gang) return { ok: false, why: 'missing' };
  gang.members = [...new Set([...(gang.members || []), memberKey(jid)])]; u.gang = key; touch(); return { ok: true, gang };
}
function leaveGang(group, jid) {
  const g = state(group), u = user(group, jid), key = u.gang, gang = key && g.gangs[key];
  if (!gang) return { ok: false, why: 'none' };
  if (gang.leader === memberKey(jid) && gang.members.length > 1) return { ok: false, why: 'leader' };
  gang.members = (gang.members || []).filter(x => x !== memberKey(jid));
  if (!gang.members.length) {
    delete g.gangs[key];
    for (const t of Object.values(g.territories)) if (t.gang === key) t.gang = null;
  } else if (gang.leader === memberKey(jid)) gang.leader = gang.members[0];
  u.gang = null; touch(); return { ok: true };
}

function gangOperation(group, jid, type, target, now=Date.now()) {
  const g=state(group), gang=getGang(group,jid), actor=user(group,jid), victim=user(group,target); jailLeft(group,jid,now); jailLeft(group,target,now);
  if(!gang) return {ok:false,why:'gang'};
  if((actor.jailedUntil||0)>now) return {ok:false,why:'actorjailed'};
  if(!target || memberKey(target)===memberKey(jid)) return {ok:false,why:'target'};
  if(isGovernmentLeader(group,jid) || ['police','royalguard','soldier'].includes(refreshCareer(group,jid,now).career)) return {ok:false,why:'role'};
  if(['police','royalguard','soldier'].includes(refreshCareer(group,target,now).career)) return {ok:false,why:'protected'};
  const last=Number(gang.lastOperationAt||0); if(now-last<10*60000) return {ok:false,why:'cooldown',wait:10*60000-(now-last)};
  if((victim.jailedUntil||0)>now) return {ok:false,why:'jailed'};
  if(type==='bandit') {
    jailLeft(group,jid,now);
    const amount=Math.min(50000, Math.max(500, Math.floor(economy.balance(target)*0.2)));
    if(amount<1 || economy.balance(target)<500) return {ok:false,why:'poor'};
    let paid=0, success=Math.random()<0.65; if(success) { paid=Math.min(amount,economy.balance(target)); economy.take(target,paid); gang.treasury=(gang.treasury||0)+paid; addWanted(group,jid,2,now); }
    else { addWanted(group,jid,3,now); actor.jailedUntil=Math.max(actor.jailedUntil||0,now+3*60000); actor.jailType='crime'; actor.jailReason='Failed gang banditry'; }
    gang.lastOperationAt=now; touch(); return {ok:true,type,success,amount:paid,gang:gang.name,wanted:actor.wanted};
  }
  if(type==='kidnap') {
    if((victim.kidnappedUntil||0)>now) return {ok:false,why:'kidnapped'};
    const ransom=Math.min(100000,Math.max(1000,Math.floor(economy.balance(target)*0.1)));
    victim.kidnappedUntil=now+10*60000; victim.kidnappedBy=gang.key; victim.ransom=ransom; addWanted(group,jid,3,now);
    gang.lastOperationAt=now; touch(); return {ok:true,type,success:true,ransom,until:victim.kidnappedUntil,gang:gang.name,wanted:actor.wanted};
  }
  return {ok:false,why:'type'};
}
function payRansom(group,jid,now=Date.now()) { const u=user(group,jid); if(!(u.kidnappedUntil>now)) {u.kidnappedUntil=0;u.kidnappedBy=null;u.ransom=0;touch();return {ok:false,why:'free'};} const amount=Math.max(0,Number(u.ransom)||0); if(economy.balance(jid)<amount)return {ok:false,why:'poor',amount}; economy.take(jid,amount); const g=state(group), gang=g.gangs[u.kidnappedBy]; if(gang)gang.treasury=(gang.treasury||0)+amount; u.kidnappedUntil=0;u.kidnappedBy=null;u.ransom=0;touch();return {ok:true,amount}; }

function resolveWar(group, territoryKey, now = Date.now()) {
  const t = state(group).territories[territoryKey];
  if (!t || !t.war || now < t.war.endsAt) return null;
  const war = t.war; t.war = null;
  if (war.attackScore > war.defendScore) t.gang = war.attacker;
  touch(); return { ...war, won: war.attackScore > war.defendScore, owner: t.gang };
}

// Democratic accountability tools. These extend the existing group-scoped government
// state; they do not replace legacy presidential, throne, treasury, or court commands.
const ELECTION_WINDOW = 10 * 60000;
const IMPEACHMENT_WINDOW = 10 * 60000;
function presidentialEligibility(group, jid, now = Date.now()) {
  const candidate = user(group, jid), p = presidentInfo(group, now).president;
  if (!jid) return { ok: false, why: 'candidate' };
  if (candidate.gang) return { ok: false, why: 'gang' };
  if (require('./throne').isKing(group, jid)) return { ok: false, why: 'king' };
  if ((candidate.jailedUntil || 0) > now) return { ok: false, why: 'jailed', until: candidate.jailedUntil };
  if ((candidate.wanted || 0) > 0) return { ok: false, why: 'wanted' };
  const recordAt = Math.max(candidate.crimeRecordAt || 0, candidate.lastCrime || 0);
  if (recordAt > 0 && !((candidate.servedSentenceAt || 0) >= recordAt && (candidate.servedSentenceAt || 0) > 0)) return { ok: false, why: 'criminal_record', recordAt, servedSentenceAt: candidate.servedSentenceAt || 0 };
  if (p && p.key === memberKey(jid)) return { ok: false, why: 'already' };
  if (p && p.until > now) return { ok: false, why: 'occupied', president: p };
  const g = state(group);
  if (g.lastPresidentKey && g.lastPresidentKey === memberKey(jid)) return { ok: false, why: 'previous', previous: g.lastPresidentJid || jid };
  if (economy.runIn(group, () => economy.balance(jid)) < PRESIDENT_COST) return { ok: false, why: 'poor', wallet: economy.runIn(group, () => economy.balance(jid)), cost: PRESIDENT_COST };
  return { ok: true };
}
function startGovernmentElection(group, jid, now = Date.now()) {
  governmentElectionStatus(group, now);
  const g = state(group), p = presidentInfo(group, now).president;
  if (p && p.until > now) return { ok: false, why: 'occupied', president: p };
  if (g.governmentElection && g.governmentElection.endsAt > now) return { ok: false, why: 'active', election: g.governmentElection };
  g.governmentElection = { startedAt: now, endsAt: now + ELECTION_WINDOW, startedBy: jid || null, candidates: {}, votes: {}, status: 'open', result: null };
  recordGovernmentAction(group, jid || 'system', 'Election opened', `Voting closes at ${g.governmentElection.endsAt}`);
  touch(); return { ok: true, election: g.governmentElection };
}
function registerElectionCandidate(group, jid, now = Date.now()) {
  const g = state(group), e = g.governmentElection;
  if (!e || e.status !== 'open' || e.endsAt <= now) return { ok: false, why: 'closed' };
  const eligible = presidentialEligibility(group, jid, now);
  if (!eligible.ok) return eligible;
  e.candidates[memberKey(jid)] = { jid, key: memberKey(jid), registeredAt: now };
  touch(); return { ok: true, candidate: e.candidates[memberKey(jid)] };
}
function castElectionVote(group, voter, candidateJid, now = Date.now()) {
  const g = state(group), e = g.governmentElection;
  if (!e || e.status !== 'open' || e.endsAt <= now) return { ok: false, why: 'closed' };
  const key = memberKey(candidateJid), voterKey = memberKey(voter);
  if (!e.candidates[key]) return { ok: false, why: 'candidate' };
  if (voterKey === key) return { ok: false, why: 'self' };
  if (e.votes[voterKey]) return { ok: false, why: 'voted' };
  e.votes[voterKey] = { voter, candidateKey: key, at: now };
  touch(); return { ok: true, candidate: e.candidates[key], votes: Object.values(e.votes).filter(v => v.candidateKey === key).length };
}
function governmentElectionStatus(group, now = Date.now()) {
  const g = state(group), e = g.governmentElection;
  if (!e) return null;
  const counts = {};
  for (const candidate of Object.values(e.candidates || {})) counts[candidate.key] = 0;
  for (const vote of Object.values(e.votes || {})) if (counts[vote.candidateKey] !== undefined) counts[vote.candidateKey]++;
  if (e.status === 'open' && e.endsAt <= now) {
    const ranked = Object.entries(counts).sort((a,b) => b[1] - a[1]);
    const winner = ranked.length && ranked[0][1] > 0 && (!ranked[1] || ranked[0][1] > ranked[1][1]) ? e.candidates[ranked[0][0]] : null;
    e.status = winner ? 'completed' : 'no-winner';
    if (winner) {
      // Close the ballot before using the existing appointment logic so it cannot be
      // bypassed during an open election. Eligibility is checked again at settlement.
      g.governmentElection = null;
      const result = takePresident(group, winner.jid, now);
      g.governmentElection = e;
      e.status = result.ok ? 'completed' : 'no-winner';
      e.result = result.ok ? { winner: winner.jid, votes: ranked[0][1], at: now } : { winner: null, reason: result.why, at: now };
    } else e.result = { winner: null, reason: ranked.length && ranked[0][1] === ranked[1]?.[1] ? 'tie' : 'no_votes', at: now };
    recordGovernmentAction(group, 'system', 'Election resolved', e.result.winner ? `Winner ${memberKey(e.result.winner)}` : `No winner: ${e.result.reason}`);
    touch();
  }
  return { ...e, candidateCounts: counts, votesCast: Object.keys(e.votes || {}).length, remaining: Math.max(0, e.endsAt - now) };
}
function startImpeachment(group, jid, reason, now = Date.now()) {
  governmentImpeachmentStatus(group, now);
  const g = state(group), p = presidentInfo(group, now).president, text = String(reason || '').trim().slice(0, 200);
  if (!p || p.until <= now) return { ok: false, why: 'vacant' };
  if (memberKey(p.jid) === memberKey(jid)) return { ok: false, why: 'self' };
  if (g.governmentImpeachment && g.governmentImpeachment.status === 'open' && g.governmentImpeachment.endsAt > now) return { ok: false, why: 'active' };
  if (!text) return { ok: false, why: 'reason' };
  g.governmentImpeachment = { president: p.jid, presidentKey: p.key, openedBy: jid, reason: text, startedAt: now, endsAt: now + IMPEACHMENT_WINDOW, votes: {}, status: 'open', result: null };
  recordGovernmentAction(group, jid, 'Impeachment opened', `${memberKey(p.jid)} · ${text}`); touch(); return { ok: true, impeachment: g.governmentImpeachment };
}
function voteImpeachment(group, jid, vote, now = Date.now()) {
  const g = state(group), imp = g.governmentImpeachment, choice = String(vote || '').toLowerCase();
  if (!imp || imp.status !== 'open' || imp.endsAt <= now) return { ok: false, why: 'closed' };
  if (memberKey(jid) === imp.presidentKey) return { ok: false, why: 'president' };
  if (!['yes','no'].includes(choice)) return { ok: false, why: 'vote' };
  const key = memberKey(jid); if (imp.votes[key]) return { ok: false, why: 'voted' };
  imp.votes[key] = { jid, vote: choice, at: now }; touch(); return { ok: true, yes: Object.values(imp.votes).filter(v=>v.vote==='yes').length, no: Object.values(imp.votes).filter(v=>v.vote==='no').length, total: Object.keys(imp.votes).length };
}
function governmentImpeachmentStatus(group, now = Date.now()) {
  const g = state(group), imp = g.governmentImpeachment; if (!imp) return null;
  const votes = Object.values(imp.votes || {}), yes = votes.filter(v=>v.vote==='yes').length, no = votes.length - yes;
  if (imp.status === 'open' && imp.endsAt <= now) {
    const passes = votes.length >= 3 && yes / votes.length >= (2/3);
    const p = presidentInfo(group, now).president;
    if (passes && p && memberKey(p.jid) === imp.presidentKey) {
      const r = resignPresident(group, p.jid, now); imp.status = r.ok ? 'passed' : 'failed';
    } else imp.status = 'failed';
    imp.result = { yes, no, total: votes.length, passed: imp.status === 'passed', at: now };
    recordGovernmentAction(group, 'system', 'Impeachment resolved', `${imp.presidentKey} · ${imp.status} · ${yes}-${no}`); touch();
  }
  return { ...imp, yes, no, total: votes.length, remaining: Math.max(0, imp.endsAt - now) };
}
function createGovernmentPetition(group, jid, message, now = Date.now()) {
  const g = state(group), text = String(message || '').trim().replace(/[\r\n]+/g, ' ').slice(0, 240);
  if (!text) return { ok: false, why: 'text' };
  const petition = { id: g.nextGovernmentPetitionId++, author: jid, text, createdAt: now, signatures: { [memberKey(jid)]: jid }, status: 'open' };
  g.governmentPetitions.push(petition); if (g.governmentPetitions.length > 50) g.governmentPetitions.splice(0, g.governmentPetitions.length - 50);
  touch(); return { ok: true, petition, threshold: 5 };
}
function signGovernmentPetition(group, jid, id) {
  const g = state(group), p = g.governmentPetitions.find(x => x.id === Number(id));
  if (!p) return { ok: false, why: 'missing' };
  if (p.status !== 'open') return { ok: false, why: 'closed' };
  const key = memberKey(jid); if (p.signatures[key]) return { ok: false, why: 'signed' };
  p.signatures[key] = jid;
  if (Object.keys(p.signatures).length >= 5) { p.status = 'submitted'; p.submittedAt = Date.now(); recordGovernmentAction(group, jid, 'Petition reached threshold', `#${p.id}: ${p.text}`); }
  touch(); return { ok: true, petition: p, count: Object.keys(p.signatures).length, threshold: 5 };
}
function governmentPetitions(group, limit = 10) { return state(group).governmentPetitions.slice(-Math.max(1, Math.min(20, Number(limit)||10))).reverse().map(p => ({ ...p, signatureCount: Object.keys(p.signatures || {}).length })); }

module.exports = { DISTRICTS, CAREERS, LUXURIES, HOUR, state, startGovernmentElection, registerElectionCandidate, castElectionVote, governmentElectionStatus, startImpeachment, voteImpeachment, governmentImpeachmentStatus, createGovernmentPetition, signGovernmentPetition, governmentPetitions, presidentialEligibility, user, memberKey, gangName, getGang, makeGang, joinGang, leaveGang, gangOperation, payRansom, resolveWar, jailLeft, expireDetentions, addWanted, arrest, payBail, prisonWork, presidentialJail, releaseDetainee, fileCourtAppeal, courtCases, reviewCourtCase, attemptPrisonEscape, recordPoliceArrest, applyNickname, activeNickname, protectionLeft, protect, presidentInfo, takePresident, resignPresident, isPresident, isGovernmentLeader, setPresidentTax, setPresidentKingTax, stimulus, careerHolder, refreshCareer, claimCareer, releaseCareer, economySettings, robberySettings, setEconomySetting, careerSalary, setCareerSalary, setCareerSalaryLimit, removeCareerHolder, appointCareer, appointGovernmentStaff, appointGovernmentPosition, acceptGovernmentAppointment, governmentPositions, GOVERNMENT_POSITIONS, governmentStaff, setGovernmentStaffSalary, removeGovernmentStaff, setWantedLevel, takeGovernmentStaffRemovalNotices, ackGovernmentStaffRemovalNotice, takeCareerRemovalNotices, ackCareerRemovalNotice, careerEligibility, markGovernmentSalaryNotice, governmentGroupsForScheduler, setGovernmentStaffPowers, setGovernmentStaffTitle, governmentStaffInfo, governmentStaffCan, governmentTreasury, depositGovernmentTreasury, governmentGrant, governmentFine, presidentialFine, recordGovernmentStaffAction, recordGovernmentAction, recordTreasuryTransaction, governmentLedger, governmentStaffAudit, GOVERNMENT_POWERS, collectGovernmentSalary, distributeGovernmentPayroll, takeGovernmentSalaryNotices, ackGovernmentSalaryNotice, careerRoster, presidentSalaryAccrued, collectPresidentSalary, presidentSalaryPayment, CAREER_TERM, PRESIDENT_COST, PRESIDENT_TERM, touch };
