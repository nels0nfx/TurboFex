// Persistent careers, gangs, and territory state. Everything is scoped to a group.
const jsonstore = require('./jsonstore');
const db = jsonstore.open('roleplay', { groups: {} });
const economy = require('./economy');
const DISTRICTS = {
  market: { name: 'Central Market', cost: 3000, income: 180 },
  docks: { name: 'Harbour Docks', cost: 4500, income: 240 },
  hills: { name: 'Royal Hills', cost: 6000, income: 300 },
  industrial: { name: 'Industrial Zone', cost: 5000, income: 270 },
  plaza: { name: 'City Plaza', cost: 4000, income: 210 },
};
const CAREERS = {
  police: { name: 'Police Officer', icon: '👮', salary: 300, duty: 180, rep: 1 },
  doctor: { name: 'Doctor', icon: '🩺', salary: 360, duty: 220, rep: 1 },
  royalguard: { name: 'Royal Guard', icon: '🛡️', salary: 330, duty: 200, rep: 1 },
  soldier: { name: 'Soldier', icon: '🎖️', salary: 320, duty: 190, rep: 1 },
  mechanic: { name: 'Mechanic', icon: '🔧', salary: 250, duty: 160, rep: 1 },
  criminal: { name: 'Gang Operative', icon: '🕶️', salary: 280, duty: 170, rep: 1 },
};
const HOUR = 3600000;
const LUXURIES = {
  supercar: { name: 'Supercar', icon: '🏎️', cost: 10000000, prestige: 10 },
  penthouse: { name: 'Luxury Penthouse', icon: '🏙️', cost: 75000000, prestige: 25 },
  yacht: { name: 'Private Yacht', icon: '🛥️', cost: 150000000, prestige: 50 },
  island: { name: 'Private Island', icon: '🏝️', cost: 500000000, prestige: 100 },
  orbitalhotel: { name: 'Orbital Hotel Suite', icon: '🛰️', cost: 2000000000, prestige: 250 },
};
const blank = () => ({ users: {}, gangs: {}, territories: Object.fromEntries(Object.keys(DISTRICTS).map(k => [k, { gang: null, paidAt: Date.now(), war: null }])) });
function state(group) {
  const key = String(group || 'private');
  if (!db.data.groups[key]) db.data.groups[key] = blank();
  const g = db.data.groups[key];
  if (!g.users) g.users = {};
  if (!g.gangs) g.gangs = {};
  if (!g.territories) g.territories = blank().territories;
  if (!g.president) g.president = null;
  if (!Number.isFinite(g.presidentTax)) g.presidentTax = 0;
  if (!Number.isFinite(g.curfewUntil)) g.curfewUntil = 0;
  for (const k of Object.keys(DISTRICTS)) if (!g.territories[k]) g.territories[k] = { gang: null, paidAt: Date.now(), war: null };
  return g;
}
function touch() { db.touch(); }
function memberKey(jid) { return String(jid || '').split('@')[0].split(':')[0]; }
function user(group, jid) {
  const g = state(group), k = memberKey(jid);
  if (!g.users[k]) g.users[k] = { jid, career: null, rank: 1, duties: 0, lastDuty: 0, lastSalary: Date.now(), gang: null, lastAttack: 0, territoryPaid: {}, wanted: 0, jailedUntil: 0, bail: 0, ghostUntil: 0, nickname: null, nicknameUntil: 0, lastCrime: 0, protectedUntil: 0, luxuries: [] };
  const u = g.users[k];
  if (!u.jid) u.jid = jid;
  if (!Array.isArray(u.luxuries)) u.luxuries = [];
  for (const [field, value] of Object.entries({ wanted: 0, jailedUntil: 0, bail: 0, ghostUntil: 0, nickname: null, nicknameUntil: 0, lastCrime: 0, protectedUntil: 0, luxuries: [] })) if (u[field] === undefined) u[field] = value;
  return u;
}
function jailLeft(group, jid, now = Date.now()) { const g = db.data.groups[String(group || 'private')]; const u = g?.users?.[memberKey(jid)]; return Math.max(0, (u?.jailedUntil || 0) - now); }
function addWanted(group, jid, amount = 1, now = Date.now()) {
  const u = user(group, jid); u.wanted = Math.max(0, Math.min(5, (u.wanted || 0) + amount)); u.lastCrime = now; touch(); return u.wanted;
}
function arrest(group, jid, now = Date.now()) {
  const u = user(group, jid);
  if ((u.jailedUntil || 0) > now) return { ok: false, why: 'jailed', until: u.jailedUntil };
  if (!(u.wanted > 0)) return { ok: false, why: 'clean' };
  const duration = Math.min(30, 5 + u.wanted * 5) * 60000;
  u.jailedUntil = now + duration; u.bail = Math.max(100, u.wanted * 150); u.wanted = 0; touch();
  return { ok: true, until: u.jailedUntil, duration, bail: u.bail };
}
function payBail(group, jid, now = Date.now()) {
  const u = user(group, jid);
  if (!(u.jailedUntil > now)) { u.jailedUntil = 0; u.bail = 0; return { ok: false, why: 'free' }; }
  const amount = Math.max(0, u.bail || 0); u.jailedUntil = 0; u.bail = 0; touch(); return { ok: true, amount };
}
function applyNickname(group, jid, nickname, now = Date.now()) {
  const u = user(group, jid); const text = String(nickname || '').trim().replace(/[\r\n]/g, ' ').slice(0, 32);
  if (!text) return { ok: false, why: 'empty' };
  u.nickname = text; u.nicknameUntil = now + 3600000; touch(); return { ok: true, nickname: text, until: u.nicknameUntil };
}
function activeNickname(group, jid, now = Date.now()) { const u = user(group, jid); return u.nicknameUntil > now ? u.nickname : null; }


const PRESIDENT_COST = 5000000;
const PRESIDENT_TERM = 2 * HOUR;
function presidentInfo(group, now = Date.now()) {
  const g = state(group), p = g.president;
  if (p && p.until <= now) { g.president = null; g.presidentTax = 0; g.curfewUntil = 0; touch(); }
  return { president: g.president, tax: g.presidentTax || 0, curfew: Math.max(0, g.curfewUntil - now), cost: PRESIDENT_COST, term: PRESIDENT_TERM };
}
function takePresident(group, jid, now = Date.now()) {
  const g = state(group), p = presidentInfo(group, now).president;
  if (p && p.key === memberKey(jid)) return { ok: false, why: 'already' };
  if (p && p.until > now) return { ok: false, why: 'occupied', president: p };
  if (!economy.take(jid, PRESIDENT_COST)) return { ok: false, why: 'poor', wallet: economy.balance(jid), cost: PRESIDENT_COST };
  g.president = { jid, key: memberKey(jid), since: now, until: now + PRESIDENT_TERM };
  g.presidentTax = 0; g.curfewUntil = 0; touch();
  return { ok: true, until: g.president.until, cost: PRESIDENT_COST };
}
function isPresident(group, jid, now = Date.now()) { const p = presidentInfo(group, now).president; return !!p && p.key === memberKey(jid); }
function setPresidentTax(group, jid, pct, now = Date.now()) {
  if (!isPresident(group, jid, now)) return { ok: false, why: 'notpresident' };
  const n = Math.round(Number(pct) * 10) / 10;
  if (!Number.isFinite(n) || n < 0 || n > 5) return { ok: false, why: 'range' };
  state(group).presidentTax = n; touch(); return { ok: true, tax: n };
}
function protectionLeft(group, jid, now = Date.now()) { const g = db.data.groups[String(group || 'private')]; const u = g?.users?.[memberKey(jid)]; return Math.max(0, (u?.protectedUntil || 0) - now); }
function protect(group, jid, target, duration = 30 * 60000, now = Date.now()) { const u = user(group, target); u.protectedUntil = Math.max(u.protectedUntil || 0, now + duration); touch(); return u.protectedUntil; }
function stimulus(group, jid, perPerson) {
  if (!isPresident(group, jid)) return { ok: false, why: 'notpresident' };
  const g = state(group), people = Object.values(g.users).filter((u) => u && u.career !== undefined).map((u) => u.jid).filter(Boolean);
  // Include users who have used roleplay/economy in this group; never mint an unlimited group-wide payout.
  const ids = [...new Set(people)].filter((id) => memberKey(id) !== memberKey(jid));
  const total = ids.length * perPerson;
  if (!Number.isSafeInteger(perPerson) || perPerson < 1 || perPerson > 1000000 || ids.length < 1) return { ok: false, why: 'amount', count: ids.length };
  if (!economy.take(jid, total)) return { ok: false, why: 'poor', total, count: ids.length };
  for (const id of ids) economy.add(id, perPerson);
  touch(); return { ok: true, total, count: ids.length, perPerson };
}

function gangName(s) { return String(s || '').trim().toLowerCase().replace(/[^a-z0-9_-]/g, '').slice(0, 20); }
function getGang(group, jid) { const u = user(group, jid); return u.gang ? state(group).gangs[u.gang] || null : null; }
function makeGang(group, jid, name) {
  const g = state(group), u = user(group, jid), key = gangName(name);
  if (!key || key.length < 3) return { ok: false, why: 'name' };
  if (u.gang) return { ok: false, why: 'member' };
  if (g.gangs[key]) return { ok: false, why: 'taken' };
  g.gangs[key] = { key, name: key, leader: memberKey(jid), members: [memberKey(jid)], treasury: 0, createdAt: Date.now() };
  u.gang = key; touch(); return { ok: true, gang: g.gangs[key] };
}
function joinGang(group, jid, name) {
  const g = state(group), u = user(group, jid), key = gangName(name), gang = g.gangs[key];
  if (u.gang) return { ok: false, why: 'member' };
  if (!gang) return { ok: false, why: 'missing' };
  gang.members = [...new Set([...(gang.members || []), memberKey(jid)])]; u.gang = key; touch(); return { ok: true, gang };
}
function leaveGang(group, jid) {
  const g = state(group), u = user(group, jid), key = u.gang, gang = key && g.gangs[key];
  if (!gang) return { ok: false, why: 'none' };
  if (gang.leader === memberKey(jid) && gang.members.length > 1) return { ok: false, why: 'leader' };
  gang.members = (gang.members || []).filter(x => x !== memberKey(jid));
  if (!gang.members.length) {
    delete g.gangs[key];
    for (const t of Object.values(g.territories)) if (t.gang === key) t.gang = null;
  } else if (gang.leader === memberKey(jid)) gang.leader = gang.members[0];
  u.gang = null; touch(); return { ok: true };
}
function resolveWar(group, territoryKey, now = Date.now()) {
  const t = state(group).territories[territoryKey];
  if (!t || !t.war || now < t.war.endsAt) return null;
  const war = t.war; t.war = null;
  if (war.attackScore > war.defendScore) t.gang = war.attacker;
  touch(); return { ...war, won: war.attackScore > war.defendScore, owner: t.gang };
}
module.exports = { DISTRICTS, CAREERS, LUXURIES, HOUR, state, user, memberKey, gangName, getGang, makeGang, joinGang, leaveGang, resolveWar, jailLeft, addWanted, arrest, payBail, applyNickname, activeNickname, protectionLeft, protect, presidentInfo, takePresident, isPresident, setPresidentTax, stimulus, PRESIDENT_COST, PRESIDENT_TERM, touch };
