// Persistent careers, gangs, and territory state. Everything is scoped to a group.
const jsonstore = require('./jsonstore');
const db = jsonstore.open('roleplay', { groups: {} });
const economy = require('./economy');
const DISTRICTS = {
  oldtown: { name: 'Old Town', cost: 3000, income: 180 },
  docks: { name: 'Harbour Docks', cost: 4500, income: 240 },
  hills: { name: 'Royal Hills', cost: 6000, income: 300 },
  industrial: { name: 'Industrial Zone', cost: 5000, income: 270 },
  plaza: { name: 'City Plaza', cost: 4000, income: 210 },
};
const CAREERS = {
  police: { name: 'Police Officer', icon: '👮', salary: 300, duty: 180, rep: 1 },
  doctor: { name: 'Doctor', icon: '🩺', salary: 360, duty: 220, rep: 1 },
  royalguard: { name: 'Royal Guard', icon: '🛡️', salary: 330, duty: 200, rep: 1 },
  soldier: { name: 'Soldier', icon: '🎖️', salary: 320, duty: 190, rep: 1 },
  mechanic: { name: 'Mechanic', icon: '🔧', salary: 250, duty: 160, rep: 1 },
  criminal: { name: 'Gang Operative', icon: '🕶️', salary: 280, duty: 170, rep: 1 },
};
const HOUR = 3600000;
const LUXURIES = {
  supercar: { name: 'Supercar', icon: '🏎️', cost: 10000000, prestige: 10 },
  penthouse: { name: 'Luxury Penthouse', icon: '🏙️', cost: 75000000, prestige: 25 },
  yacht: { name: 'Private Yacht', icon: '🛥️', cost: 150000000, prestige: 50 },
  island: { name: 'Private Island', icon: '🏝️', cost: 500000000, prestige: 100 },
  orbitalhotel: { name: 'Orbital Hotel Suite', icon: '🛰️', cost: 2000000000, prestige: 250 },
};
const blank = () => ({ users: {}, gangs: {}, territories: Object.fromEntries(Object.keys(DISTRICTS).map(k => [k, { gang: null, paidAt: Date.now(), war: null }])) });
function state(group) {
  const key = String(group || 'private');
  if (!db.data.groups[key]) db.data.groups[key] = blank();
  const g = db.data.groups[key];
  if (!g.users) g.users = {};
  if (!g.gangs) g.gangs = {};
  if (!g.territories) g.territories = blank().territories;
  if (g.territories.market && !g.territories.oldtown) { g.territories.oldtown = g.territories.market; delete g.territories.market; }
  if (!g.president) g.president = null;
  if (!g.careerHolders) g.careerHolders = {};
  g.economySettings = Object.assign({ presidentSalary: 1000000, presidentSalaryInterval: 10 * 60000, robChance: 40, robCap: 5000 }, g.economySettings || {});
  if (!g.careerSalary) g.careerSalary = {};
  if (!g.governmentStaff) g.governmentStaff = {};
  if (!Number.isSafeInteger(g.governmentTreasury)) g.governmentTreasury = 0;
  if (!Array.isArray(g.governmentAudit)) g.governmentAudit = [];
  for (const staff of Object.values(g.governmentStaff)) { if (!Array.isArray(staff.powers)) staff.powers = []; if (!Number.isFinite(staff.lastPaidAt)) staff.lastPaidAt = Number.isFinite(staff.lastClaimAt) ? staff.lastClaimAt : Date.now(); }
  if (!Number.isFinite(g.careerSalaryLimit)) g.careerSalaryLimit = 100000;
  if (!g.kingSettingsRevoked) g.kingSettingsRevoked = {};
  if (!Number.isFinite(g.presidentTax)) g.presidentTax = 0;
  if (!Number.isFinite(g.presidentKingTax)) g.presidentKingTax = 0;
  if (!Number.isFinite(g.curfewUntil)) g.curfewUntil = 0;
  for (const k of Object.keys(DISTRICTS)) if (!g.territories[k]) g.territories[k] = { gang: null, paidAt: Date.now(), war: null };
  return g;
}
function touch() { db.touch(); }
function memberKey(jid) { return String(jid || '').split('@')[0].split(':')[0]; }
function user(group, jid) {
  const g = state(group), k = memberKey(jid);
  if (!g.users[k]) g.users[k] = { jid, career: null, rank: 1, duties: 0, lastDuty: 0, lastSalary: Date.now(), gang: null, lastAttack: 0, territoryPaid: {}, wanted: 0, jailedUntil: 0, bail: 0, ghostUntil: 0, nickname: null, nicknameUntil: 0, lastCrime: 0, protectedUntil: 0, luxuries: [], careerUntil: 0, lastFine: 0 };
  const u = g.users[k];
  if (!u.jid) u.jid = jid;
  if (!Array.isArray(u.luxuries)) u.luxuries = [];
  for (const [field, value] of Object.entries({ wanted: 0, jailedUntil: 0, bail: 0, ghostUntil: 0, nickname: null, nicknameUntil: 0, lastCrime: 0, protectedUntil: 0, luxuries: [], careerUntil: 0, lastFine: 0 })) if (u[field] === undefined) u[field] = value;
  return u;
}
function jailLeft(group, jid, now = Date.now()) { const g = db.data.groups[String(group || 'private')]; const u = g?.users?.[memberKey(jid)]; return Math.max(0, (u?.jailedUntil || 0) - now); }
function addWanted(group, jid, amount = 1, now = Date.now()) {
  const u = user(group, jid); u.wanted = Math.max(0, Math.min(5, (u.wanted || 0) + amount)); u.lastCrime = now; touch(); return u.wanted;
}
function arrest(group, jid, now = Date.now()) {
  const u = user(group, jid);
  if ((u.jailedUntil || 0) > now) return { ok: false, why: 'jailed', until: u.jailedUntil };
  if (!(u.wanted > 0)) return { ok: false, why: 'clean' };
  const duration = Math.min(30, 5 + u.wanted * 5) * 60000;
  u.jailedUntil = now + duration; u.bail = Math.max(100, u.wanted * 150); u.wanted = 0; touch();
  return { ok: true, until: u.jailedUntil, duration, bail: u.bail };
}
function payBail(group, jid, now = Date.now()) {
  const u = user(group, jid);
  if (!(u.jailedUntil > now)) { u.jailedUntil = 0; u.bail = 0; return { ok: false, why: 'free' }; }
  const amount = Math.max(0, u.bail || 0); u.jailedUntil = 0; u.bail = 0; touch(); return { ok: true, amount };
}
function applyNickname(group, jid, nickname, now = Date.now()) {
  const u = user(group, jid); const text = String(nickname || '').trim().replace(/[\r\n]/g, ' ').slice(0, 32);
  if (!text) return { ok: false, why: 'empty' };
  u.nickname = text; u.nicknameUntil = now + 3600000; touch(); return { ok: true, nickname: text, until: u.nicknameUntil };
}
function activeNickname(group, jid, now = Date.now()) { const u = user(group, jid); return u.nicknameUntil > now ? u.nickname : null; }


const PRESIDENT_COST = 5000000;
const PRESIDENT_TERM = 2 * HOUR;
const CAREER_TERM = 2 * HOUR;
function careerHolder(group, career, now = Date.now()) {
  const g = state(group), h = g.careerHolders[career];
  if (h && h.until <= now) { delete g.careerHolders[career]; const u = g.users[h.key]; if (u && u.career === career) { u.career = null; u.careerUntil = 0; } touch(); return null; }
  return h || null;
}
function refreshCareer(group, jid, now = Date.now()) {
  const u = user(group, jid);
  if (u.career && (!u.careerUntil || u.careerUntil <= now)) {
    const g = state(group), h = g.careerHolders[u.career];
    if (h && h.key === memberKey(jid)) delete g.careerHolders[u.career];
    u.career = null; u.careerUntil = 0; u.rank = 1; u.duties = 0; touch();
  }
  return u;
}
function isPresident(group, jid, now = Date.now()) { const p = presidentInfo(group, now).president; return !!p && p.key === memberKey(jid); }
function isGovernmentLeader(group, jid, now = Date.now()) { return isPresident(group, jid, now) || require('./throne').isKing(group, jid); }
function claimCareer(group, jid, career, now = Date.now()) {
  const g = state(group), u = refreshCareer(group, jid, now), h = careerHolder(group, career, now);
  if (isGovernmentLeader(group, jid, now)) return { ok: false, why: 'leader' };
  if (u.career) return { ok: false, why: 'hascareer', career: u.career };
  if (h && h.key !== memberKey(jid)) return { ok: false, why: 'occupied', holder: h };
  u.career = career; u.careerUntil = now + CAREER_TERM; u.rank = 1; u.duties = 0; u.lastSalary = now;
  g.careerHolders[career] = { jid, key: memberKey(jid), since: now, until: u.careerUntil };
  touch(); return { ok: true, until: u.careerUntil };
}
function releaseCareer(group, jid, now = Date.now()) {
  const g = state(group), u = refreshCareer(group, jid, now);
  if (!u.career) return { ok: false, why: 'none' };
  const old = u.career, h = g.careerHolders[old]; if (h && h.key === memberKey(jid)) delete g.careerHolders[old];
  u.career = null; u.careerUntil = 0; u.rank = 1; u.duties = 0; touch(); return { ok: true, career: old };
}
function economySettings(group) { return { ...state(group).economySettings }; }
function careerSalary(group, career, rank = 1) { const g = state(group), base = Number.isFinite(g.careerSalary[career]) ? g.careerSalary[career] : CAREERS[career]?.salary || 0; return Math.min(g.careerSalaryLimit, Math.max(0, base + (Math.max(1, rank) - 1) * 50)); }
function setCareerSalary(group, career, amount) { const g = state(group), n = Number(amount); if (!['all', ...Object.keys(CAREERS)].includes(career) || !Number.isSafeInteger(n) || n < 1 || n > 1000000000) return false; if (career === 'all') for (const key of Object.keys(CAREERS)) g.careerSalary[key] = n; else g.careerSalary[career] = n; touch(); return true; }
function setCareerSalaryLimit(group, amount) { const g = state(group), n = Number(amount); if (!Number.isSafeInteger(n) || n < 1 || n > 1000000000) return false; g.careerSalaryLimit = n; touch(); return true; }
function removeCareerHolder(group, jid) { const g=state(group), key=memberKey(jid), u=g.users[key]; if(!u || !u.career) return {ok:false,why:'nocareer'}; const career=u.career, h=g.careerHolders[career]; if(h && h.key===key) delete g.careerHolders[career]; u.career=null; u.careerUntil=0; u.rank=1; u.duties=0; touch(); return {ok:true,career}; }
function appointCareer(group, president, target, career, now=Date.now()) { const g=state(group), key=memberKey(target), c=String(career||'').toLowerCase(); if(!isPresident(group,president,now)) return {ok:false,why:'notpresident'}; if(!target || key===memberKey(president) || !CAREERS[c]) return {ok:false,why:'invalid'}; if(isGovernmentLeader(group,target)) return {ok:false,why:'leader'}; const u=user(group,target); if(u.gang && ['police','royalguard','soldier'].includes(c)) return {ok:false,why:'gang'}; const occupied=careerHolder(group,c,now); if(occupied && occupied.key!==key) return {ok:false,why:'occupied',holder:occupied}; if(u.career && g.careerHolders[u.career]?.key===key) delete g.careerHolders[u.career]; u.career=c; u.careerUntil=now+CAREER_TERM; u.rank=1; u.duties=0; u.lastSalary=now; g.careerHolders[c]={jid:target,key,since:now,until:u.careerUntil,appointedBy:president}; touch(); return {ok:true,career:c,until:u.careerUntil}; }
function appointGovernmentStaff(group, jid, target, title, salary) { const g=state(group), amount=Number(salary), name=String(title||'').trim().replace(/[\r\n]/g,' ').slice(0,50); if(!isPresident(group,jid)) return {ok:false,why:'notpresident'}; if(!target || memberKey(target)===memberKey(jid) || !name || !Number.isSafeInteger(amount) || amount<1 || amount>1000000000) return {ok:false,why:'invalid'}; g.governmentStaff[memberKey(target)]={jid:target,title:name,salary:amount,lastClaimAt:Date.now(),lastPaidAt:Date.now(),appointedBy:jid,powers:[]}; touch(); return {ok:true,staff:g.governmentStaff[memberKey(target)]}; }
function governmentStaff(group) { return Object.values(state(group).governmentStaff||{}); }
function setGovernmentStaffSalary(group, jid, target, salary) { if(!isPresident(group,jid)) return {ok:false,why:'notpresident'}; const staff=state(group).governmentStaff[memberKey(target)], amount=Number(salary); if(!staff) return {ok:false,why:'missing'}; if(!Number.isSafeInteger(amount)||amount<1||amount>1000000000) return {ok:false,why:'amount'}; staff.salary=amount; touch(); return {ok:true,staff}; }
function removeGovernmentStaff(group, jid, target) { if(!isPresident(group,jid)) return {ok:false,why:'notpresident'}; const g=state(group), key=memberKey(target), staff=g.governmentStaff[key]; if(!staff) return {ok:false,why:'missing'}; delete g.governmentStaff[key]; touch(); return {ok:true,staff}; }
const GOVERNMENT_POWERS = {
  security: 'Security: view group intelligence, assign wanted levels, arrest and release roleplay detainees',
  finance: 'Finance: view government treasury and issue grants from it',
  justice: 'Justice: fine players into the treasury and pardon wanted/jail records',
  health: 'Health: grant temporary robbery protection to players',
  interior: 'Interior: set or lift group curfew',
  communications: 'Communications: publish official government announcements',
};
function setGovernmentStaffPowers(group, jid, target, powers) {
  if (!isPresident(group, jid)) return {ok:false,why:'notpresident'};
  const staff=state(group).governmentStaff[memberKey(target)];
  if (!staff) return {ok:false,why:'missing'};
  const list=[...new Set((Array.isArray(powers)?powers:String(powers||'').split(',')).map(x=>String(x).trim().toLowerCase()).filter(x=>Object.hasOwn(GOVERNMENT_POWERS,x)))];
  staff.powers=list; touch(); return {ok:true,staff};
}
function setGovernmentStaffTitle(group, jid, target, title) {
  if (!isPresident(group, jid)) return {ok:false,why:'notpresident'};
  const staff=state(group).governmentStaff[memberKey(target)], name=String(title||'').trim().replace(/[\r\n]/g,' ').slice(0,50);
  if (!staff) return {ok:false,why:'missing'}; if (!name) return {ok:false,why:'title'};
  staff.title=name; touch(); return {ok:true,staff};
}
function governmentStaffInfo(group, target) {
  const g=state(group), staff=g.governmentStaff[memberKey(target)];
  if (!staff) return null;
  const interval=20*60000, now=Date.now(), units=Math.floor(Math.max(0,now-(staff.lastPaidAt||staff.lastClaimAt||now))/interval);
  return {...staff, accrued:units*staff.salary, treasury:g.governmentTreasury||0};
}
function governmentTreasury(group) { return state(group).governmentTreasury||0; }
function depositGovernmentTreasury(group, jid, amount) {
  if (!isPresident(group,jid)) return {ok:false,why:'notpresident'};
  const n=Number(amount); if(!Number.isSafeInteger(n)||n<1) return {ok:false,why:'amount'};
  if(!economy.take(jid,n)) return {ok:false,why:'poor'};
  const g=state(group); g.governmentTreasury=(g.governmentTreasury||0)+n; touch(); return {ok:true,balance:g.governmentTreasury,amount:n};
}
function recordGovernmentStaffAction(group, jid, action, details = '') {
  const g=state(group), staff=g.governmentStaff[memberKey(jid)];
  if(!staff) return false;
  g.governmentAudit.push({jid:staff.jid,title:staff.title,action:String(action).slice(0,60),details:String(details).slice(0,180),at:Date.now()});
  if(g.governmentAudit.length>100) g.governmentAudit.splice(0,g.governmentAudit.length-100);
  touch(); return true;
}
function governmentStaffAudit(group, target = null, limit = 15) {
  const rows=state(group).governmentAudit||[];
  return rows.filter(x=>!target||memberKey(x.jid)===memberKey(target)).slice(-Math.max(1,Math.min(50,limit))).reverse();
}
function governmentStaffCan(group, jid, power) { const staff=state(group).governmentStaff[memberKey(jid)]; return !!staff && Array.isArray(staff.powers) && staff.powers.includes(power); }
function governmentGrant(group, jid, target, amount) {
  if(!governmentStaffCan(group,jid,'finance')) return {ok:false,why:'power'};
  const n=Number(amount), g=state(group); if(!target||!Number.isSafeInteger(n)||n<1) return {ok:false,why:'amount'};
  if((g.governmentTreasury||0)<n) return {ok:false,why:'poor',balance:g.governmentTreasury||0};
  g.governmentTreasury-=n; economy.add(target,n); touch(); return {ok:true,amount:n,balance:g.governmentTreasury};
}
function governmentFine(group, jid, target, amount) {
  if(!governmentStaffCan(group,jid,'justice')) return {ok:false,why:'power'};
  const n=Number(amount); if(!target||!Number.isSafeInteger(n)||n<1) return {ok:false,why:'amount'};
  const paid=Math.min(n,economy.balance(target)); if(!paid) return {ok:false,why:'poor'};
  economy.take(target,paid); const g=state(group); g.governmentTreasury=(g.governmentTreasury||0)+paid; touch(); return {ok:true,amount:paid,balance:g.governmentTreasury};
}
function payGovernmentStaff(staff, now=Date.now()) {
  const interval=20*60000, last=Number.isFinite(staff.lastPaidAt)?staff.lastPaidAt:(Number.isFinite(staff.lastClaimAt)?staff.lastClaimAt:now);
  const units=Math.floor(Math.max(0,now-last)/interval);
  if(units<1) return 0;
  const amount=units*staff.salary;
  staff.lastPaidAt=last+units*interval;
  economy.add(staff.jid,amount);
  return amount;
}
function distributeGovernmentPayroll(now=Date.now()) {
  let paid=0, recipients=0;
  for(const group of Object.keys(db.data.groups||{})) {
    const g=state(group);
    for(const staff of Object.values(g.governmentStaff||{})) {
      const amount=payGovernmentStaff(staff,now);
      if(amount>0) { paid+=amount; recipients++; }
    }
  }
  if(paid) touch();
  return {paid,recipients};
}
function collectGovernmentSalary(group, jid, now=Date.now()) {
  const staff=state(group).governmentStaff[memberKey(jid)];
  if(!staff) return {ok:false,why:'notstaff'};
  const amount=payGovernmentStaff(staff,now);
  if(amount) touch();
  const interval=20*60000;
  return {ok:true,amount,accrued:Math.floor(Math.max(0,now-(staff.lastPaidAt||now))/interval)*staff.salary,staff};
}
function careerRoster(group) { const g = state(group); return Object.values(g.users).filter(u => u && u.jid).map(u => ({ jid:u.jid, career:u.career, rank:u.rank || 1, duties:u.duties || 0, wanted:u.wanted || 0, jailedUntil:u.jailedUntil || 0, bail:u.bail || 0, gang:u.gang || null, lastCrime:u.lastCrime || 0, protectedUntil:u.protectedUntil || 0, ghostUntil:u.ghostUntil || 0, luxuries:u.luxuries || [], careerUntil:u.careerUntil || 0 })); }
function robberySettings(group) { const x = economySettings(group); return { chance: x.robChance / 100, cap: x.robCap }; }
function setEconomySetting(group, key, value) {
  const g = state(group), n = Number(value);
  const ranges = { presidentSalary: [1, Number.MAX_SAFE_INTEGER], presidentSalaryInterval: [1, 1440], robChance: [1, 90], robCap: [100, Number.MAX_SAFE_INTEGER] };
  if (!ranges[key] || !Number.isSafeInteger(n) || n < ranges[key][0] || n > ranges[key][1]) return false;
  g.economySettings[key] = key === 'presidentSalaryInterval' ? n * 60000 : n; touch(); return true;
}
function presidentSalaryAccrued(group, now = Date.now()) { const g=state(group), p=g.president; if(!p) return 0; const settings=economySettings(group), end=Math.min(now,p.until), last=p.lastSalary||p.since; return Math.floor(Math.max(0,end-last)/settings.presidentSalaryInterval)*settings.presidentSalary; }
function collectPresidentSalary(group, now = Date.now()) {
  const g = state(group), p = g.president; if (!p) return 0;
  const settings = economySettings(group), end = Math.min(now, p.until), last = p.lastSalary || p.since;
  const units = Math.floor(Math.max(0, end - last) / settings.presidentSalaryInterval);
  if (units < 1) return 0;
  const amount = units * settings.presidentSalary;
  p.lastSalary = last + units * settings.presidentSalaryInterval; p.lastSalaryPaid = amount; p.lastSalaryPaidAt = now;
  economy.add(p.jid, amount); touch(); return amount;
}
function presidentInfo(group, now = Date.now()) {
  const g = state(group), p = g.president;
  if (p && p.until <= now) { collectPresidentSalary(group, now); g.president = null; g.presidentTax = 0; g.presidentKingTax = 0; g.curfewUntil = 0; touch(); }
  return { president: g.president, tax: g.presidentTax || 0, kingTax: g.presidentKingTax || 0, curfew: Math.max(0, g.curfewUntil - now), cost: PRESIDENT_COST, term: PRESIDENT_TERM, settings: economySettings(group) };
}
function takePresident(group, jid, now = Date.now()) {
  const g = state(group), p = presidentInfo(group, now).president;
  if (user(group, jid).gang) return { ok: false, why: 'gang' };
  if (require('./throne').isKing(group, jid)) return { ok: false, why: 'king' };
  if (user(group, jid).career) releaseCareer(group, jid, now);
  if (p && p.key === memberKey(jid)) return { ok: false, why: 'already' };
  if (p && p.until > now) return { ok: false, why: 'occupied', president: p };
  if (!economy.take(jid, PRESIDENT_COST)) return { ok: false, why: 'poor', wallet: economy.balance(jid), cost: PRESIDENT_COST };
  g.president = { jid, key: memberKey(jid), since: now, lastSalary: now, until: now + PRESIDENT_TERM };
  g.presidentTax = 0; g.presidentKingTax = 0; g.curfewUntil = 0; touch();
  return { ok: true, until: g.president.until, cost: PRESIDENT_COST };
}
function setPresidentTax(group, jid, pct, now = Date.now()) {
  if (!isPresident(group, jid, now)) return { ok: false, why: 'notpresident' };
  const n = Math.round(Number(pct) * 10) / 10;
  if (!Number.isFinite(n) || n < 0 || n > 100) return { ok: false, why: 'range' };
  state(group).presidentTax = n; touch(); return { ok: true, tax: n };
}
function setPresidentKingTax(group, jid, pct, now = Date.now()) {
  if (!isPresident(group, jid, now)) return { ok: false, why: 'notpresident' };
  const n = Math.round(Number(pct) * 10) / 10;
  if (!Number.isFinite(n) || n < 0 || n > 100) return { ok: false, why: 'range' };
  state(group).presidentKingTax = n; touch(); return { ok: true, tax: n };
}

function protectionLeft(group, jid, now = Date.now()) { const g = db.data.groups[String(group || 'private')]; const u = g?.users?.[memberKey(jid)]; return Math.max(0, (u?.protectedUntil || 0) - now); }
function protect(group, jid, target, duration = 30 * 60000, now = Date.now()) { const u = user(group, target); u.protectedUntil = Math.max(u.protectedUntil || 0, now + duration); touch(); return u.protectedUntil; }
function stimulus(group, jid, perPerson) {
  if (!isPresident(group, jid)) return { ok: false, why: 'notpresident' };
  const g = state(group), people = Object.values(g.users).filter((u) => u && u.career !== undefined).map((u) => u.jid).filter(Boolean);
  // Include users who have used roleplay/economy in this group; never mint an unlimited group-wide payout.
  const ids = [...new Set(people)].filter((id) => memberKey(id) !== memberKey(jid));
  const total = ids.length * perPerson;
  if (!Number.isSafeInteger(perPerson) || perPerson < 1 || ids.length < 1) return { ok: false, why: 'amount', count: ids.length };
  if (!economy.take(jid, total)) return { ok: false, why: 'poor', total, count: ids.length };
  for (const id of ids) economy.add(id, perPerson);
  touch(); return { ok: true, total, count: ids.length, perPerson };
}

function gangName(s) { return String(s || '').trim().toLowerCase().replace(/[^a-z0-9_-]/g, '').slice(0, 20); }
function getGang(group, jid) { const u = user(group, jid); return u.gang ? state(group).gangs[u.gang] || null : null; }
function makeGang(group, jid, name) {
  const g = state(group), u = user(group, jid), key = gangName(name);
  if (isGovernmentLeader(group, jid)) return { ok: false, why: 'leader' };
  if (['police','royalguard','soldier'].includes(user(group, jid).career)) return { ok: false, why: 'career' };
  if (!key || key.length < 3) return { ok: false, why: 'name' };
  if (u.gang) return { ok: false, why: 'member' };
  if (g.gangs[key]) return { ok: false, why: 'taken' };
  g.gangs[key] = { key, name: key, leader: memberKey(jid), members: [memberKey(jid)], treasury: 0, createdAt: Date.now() };
  u.gang = key; touch(); return { ok: true, gang: g.gangs[key] };
}
function joinGang(group, jid, name) {
  const g = state(group), u = user(group, jid), key = gangName(name), gang = g.gangs[key];
  if (isGovernmentLeader(group, jid)) return { ok: false, why: 'leader' };
  if (['police','royalguard','soldier'].includes(u.career)) return { ok: false, why: 'career' };
  if (u.gang) return { ok: false, why: 'member' };
  if (!gang) return { ok: false, why: 'missing' };
  gang.members = [...new Set([...(gang.members || []), memberKey(jid)])]; u.gang = key; touch(); return { ok: true, gang };
}
function leaveGang(group, jid) {
  const g = state(group), u = user(group, jid), key = u.gang, gang = key && g.gangs[key];
  if (!gang) return { ok: false, why: 'none' };
  if (gang.leader === memberKey(jid) && gang.members.length > 1) return { ok: false, why: 'leader' };
  gang.members = (gang.members || []).filter(x => x !== memberKey(jid));
  if (!gang.members.length) {
    delete g.gangs[key];
    for (const t of Object.values(g.territories)) if (t.gang === key) t.gang = null;
  } else if (gang.leader === memberKey(jid)) gang.leader = gang.members[0];
  u.gang = null; touch(); return { ok: true };
}
function resolveWar(group, territoryKey, now = Date.now()) {
  const t = state(group).territories[territoryKey];
  if (!t || !t.war || now < t.war.endsAt) return null;
  const war = t.war; t.war = null;
  if (war.attackScore > war.defendScore) t.gang = war.attacker;
  touch(); return { ...war, won: war.attackScore > war.defendScore, owner: t.gang };
}
module.exports = { DISTRICTS, CAREERS, LUXURIES, HOUR, state, user, memberKey, gangName, getGang, makeGang, joinGang, leaveGang, resolveWar, jailLeft, addWanted, arrest, payBail, applyNickname, activeNickname, protectionLeft, protect, presidentInfo, takePresident, isPresident, isGovernmentLeader, setPresidentTax, setPresidentKingTax, stimulus, careerHolder, refreshCareer, claimCareer, releaseCareer, economySettings, robberySettings, setEconomySetting, careerSalary, setCareerSalary, setCareerSalaryLimit, removeCareerHolder, appointCareer, appointGovernmentStaff, governmentStaff, setGovernmentStaffSalary, removeGovernmentStaff, setGovernmentStaffPowers, setGovernmentStaffTitle, governmentStaffInfo, governmentStaffCan, governmentTreasury, depositGovernmentTreasury, governmentGrant, governmentFine, recordGovernmentStaffAction, governmentStaffAudit, GOVERNMENT_POWERS, collectGovernmentSalary, distributeGovernmentPayroll, careerRoster, presidentSalaryAccrued, collectPresidentSalary, CAREER_TERM, PRESIDENT_COST, PRESIDENT_TERM, touch };
