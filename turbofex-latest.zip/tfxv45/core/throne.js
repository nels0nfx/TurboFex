// The throne: one person is King of the group. Anybody can take the throne by paying its price. The old king gets most of
// it back (so being dethroned is a profit), the rest of the coins are gone. The price goes up when somebody takes the throne
// and slides down by itself every hour. A king earns coins every hour for as long as he keeps the throne.
const jsonstore = require('./jsonstore');
const economy = require('./economy');
const roleplay = require('./roleplay');

const js = jsonstore.open('throne', { groups: {} });

const RULES = {
  base: 500, raise: 1.25, decayPerHour: 0.96, payback: 0.7, incomePerHour: 100, storeHours: 24, decreeMax: 100,
  maxTax: 5, // the king's tax on jobs and daily, in % (the bot owner can change the limit)
  feastMin: 300, feastCooldownMs: 3 * 3600000, feastBonus: 0.1, feastMinPeople: 3, feastMax: 15, activeMs: 3600000,
  jailCost: 400, jailMs: 30 * 60000, jailCooldownMs: 2 * 3600000,
  peaceCost: 600, peaceMs: 12 * 3600000, peaceCooldownMs: 24 * 3600000, // "peace law": nobody can rob
  holidayCost: 1000, holidayMs: 2 * 3600000, holidayCooldownMs: 12 * 3600000, holidayBoost: 1.25, // "bank holiday": everybody earns more
};
const HOUR = 3600000;

const stateOf = (group) => js.data.groups[group] || (js.data.groups[group] = { king: null, price: RULES.base, at: 0, since: 0, collected: 0, decree: '' });
// ---- the income of a king (coins an hour): the owner can set it for one group or for all groups
const incomeOf = (G) => (Number.isFinite(G.income) ? G.income : Number.isFinite(js.data.income) ? js.data.income : RULES.incomePerHour);
const maxTaxOf = (G) => (Number.isFinite(G?.maxTax) ? G.maxTax : Number.isFinite(js.data.maxTax) ? js.data.maxTax : RULES.maxTax);
function setIncome(group, n) {
  // what the king already earned at the old rate is kept, then the new rate starts
  const list = group ? [stateOf(group)] : Object.values(js.data.groups);
  const now = Date.now();
  for (const G of list) {
    if (G.king) {
      G.stash = Math.min(incomeOf(G) * RULES.storeHours, waiting(G, now));
      G.collected = now;
    }
    if (group) G.income = n;
  }
  if (!group) {
    js.data.income = n;
    for (const G of Object.values(js.data.groups)) delete G.income;
  }
  js.touch();
}
function resetIncome(group) {
  if (group) delete stateOf(group).income;
  else {
    delete js.data.income;
    for (const G of Object.values(js.data.groups)) delete G.income;
  }
  js.touch();
}
function setMaxTax(n) {
  js.data.maxTax = n;
  for (const G of Object.values(js.data.groups)) if ((G.tax || 0) > n) G.tax = n;
  js.touch();
}
const incomeInfo = (group) => {
  const G = group ? stateOf(group) : null;
  return { global: Number.isFinite(js.data.income) ? js.data.income : null, group: G && Number.isFinite(G.income) ? G.income : null, now: G ? incomeOf(G) : Number.isFinite(js.data.income) ? js.data.income : RULES.incomePerHour, base: RULES.incomePerHour };
};
// what it costs now: the price slides down every hour, never under the base price
const priceNow = (G, now) => Math.max(RULES.base, Math.round(G.price * Math.pow(RULES.decayPerHour, Math.max(0, now - G.at) / HOUR)));
const waiting = (G, now) => (G.king ? (G.stash || 0) + Math.floor((Math.min(RULES.storeHours * HOUR, Math.max(0, now - G.collected)) / HOUR) * incomeOf(G)) : 0);
const wallet = (group, jid) => economy.runIn(group, () => economy.balance(jid));

function info(group, now = Date.now()) {
  const G = stateOf(group);
  return { king: G.king, since: G.since, price: priceNow(G, now), waiting: waiting(G, now), decree: G.decree, rules: RULES, income: incomeOf(G), tax: 0, maxTax: 0, jailed: 0, peace: 0, holiday: 0 };
}

function take(group, jid, now = Date.now()) {
  const G = stateOf(group);
  const key = economy.keyOf(jid);
  if (roleplay.state(group).users[roleplay.memberKey(jid)]?.gang) return { ok: false, why: 'gang' };
  if (roleplay.isPresident(group, jid, now)) return { ok: false, why: 'president' };
  if (G.king?.appointedBy) return { ok: false, why: 'appointed' };
  if (roleplay.user(group, jid).career) roleplay.releaseCareer(group, jid, now);
  if (G.king && G.king.key === key) return { ok: false, why: 'already' };
  if (economy.runIn(group, () => economy.inDebt(jid))) return { ok: false, why: 'debt' };
  const price = priceNow(G, now);
  if (wallet(group, jid) < price) return { ok: false, why: 'poor', price, wallet: wallet(group, jid) };
  if (!economy.runIn(group, () => economy.take(jid, price))) return { ok: false, why: 'poor', price, wallet: wallet(group, jid) };
  const prev = G.king;
  let prevGot = 0;
  let prevIncome = 0;
  if (prev) {
    prevIncome = waiting(G, now); // what the old king earned is paid out to him
    prevGot = Math.floor(price * RULES.payback);
    economy.runIn(group, () => economy.add(prev.jid, prevGot + prevIncome));
  }
  G.king = { jid, key };
  G.price = Math.round(price * RULES.raise);
  G.at = now;
  G.since = now;
  G.collected = now;
  G.stash = 0;
  G.decree = '';
  G.tax = 0;
  G.jail = {};
  js.touch();
  return { ok: true, price, prev, prevGot, prevIncome, next: G.price, burned: price - prevGot, wallet: wallet(group, jid) };
}


function kingSettings(group) { const G = stateOf(group); return { tax:0, decree:G.decree||'', income:incomeOf(G), peace:0, holiday:0, jailed:[], jailCount:0 }; }
function removeKing(group, jid) { if(!roleplay.isPresident(group,jid)) return {ok:false,why:'notpresident'}; const G=stateOf(group), previous=G.king; if(!previous) return {ok:false,why:'noking'}; G.king=null; G.decree=''; G.tax=0; G.jail={}; G.laws={}; G.stash=0; G.collected=Date.now(); G.since=0; js.touch(); return {ok:true,king:previous}; }
function appointKing(group, president, target) { if(!roleplay.isPresident(group,president)) return {ok:false,why:'notpresident'}; if(!target || roleplay.memberKey(target)===roleplay.memberKey(president)) return {ok:false,why:'invalid'}; if(roleplay.user(group,target).gang) return {ok:false,why:'gang'}; if(roleplay.user(group,target).career) roleplay.releaseCareer(group,target); const G=stateOf(group), previous=G.king; G.king={jid:target,key:economy.keyOf(target),appointedBy:president}; G.since=Date.now(); G.collected=Date.now(); G.stash=0; G.decree=''; G.tax=0; G.jail={}; G.laws={}; js.touch(); return {ok:true,king:G.king,previous}; }
function setGroupMaxTax(group, jid, amount) { if(!roleplay.isPresident(group,jid)) return {ok:false,why:'notpresident'}; const n=Number(amount), G=stateOf(group); if(!Number.isFinite(n)||n<0||n>100) return {ok:false,why:'range'}; G.maxTax=n; if((G.tax||0)>n) G.tax=n; js.touch(); return {ok:true,maxTax:n,tax:G.tax||0}; }
function removeKingSetting(group, jid, setting, target) {
  if (!roleplay.isPresident(group, jid)) return { ok:false, why:'notpresident' };
  const G=stateOf(group), k=String(setting||'').toLowerCase();
  if(k==='tax'){G.tax=0;} else if(k==='decree'){G.decree='';} else if(k==='income'){G.stash=0; G.collected=Date.now(); G.income=RULES.incomePerHour;} else return {ok:false,why:'setting'};
  roleplay.state(group).kingSettingsRevoked[k]=Date.now(); js.touch(); roleplay.touch(); return {ok:true,setting:k};
}

function collect(group, jid, now = Date.now()) {
  const G = stateOf(group);
  if (!G.king || G.king.key !== economy.keyOf(jid)) return { ok: false, why: 'notking' };
  const n = waiting(G, now);
  if (n < 1) return { ok: false, why: 'nothing' };
  G.collected = now;
  G.stash = 0;
  const pres = roleplay.presidentInfo(group);
  const kingTaxPct = pres.president && pres.president.key !== economy.keyOf(jid) ? Math.max(0, Math.min(100, Number(pres.kingTax) || 0)) : 0;
  const kingTax = Math.min(Math.max(0, n - 1), Math.floor(n * kingTaxPct / 100));
  economy.runIn(group, () => economy.add(jid, n - kingTax));
  if (kingTax) { const government = roleplay.state(group); government.governmentTreasury = (government.governmentTreasury || 0) + kingTax; roleplay.recordTreasuryTransaction(group, 'Royal income tax', kingTax, jid, `Collected from King ${economy.keyOf(jid)}`); roleplay.touch(); }
  js.touch();
  return { ok: true, amount: n - kingTax, gross: n, tax: kingTax, taxRate: kingTaxPct, wallet: wallet(group, jid), treasury: roleplay.governmentTreasury(group) };
}

function decree(group, jid, text) {
  const G = stateOf(group);
  if (!G.king || G.king.key !== economy.keyOf(jid)) return { ok: false, why: 'notking' };
  const t = String(text || '').replace(/\s+/g, ' ').trim().slice(0, RULES.decreeMax);
  if (!t) return { ok: false, why: 'empty' };
  G.decree = t;
  js.touch();
  return { ok: true, decree: t };
}


// ---- what a king can do to the people of the group
// the tax: a share of what people earn from jobs and daily goes to the king
function setTax(group, jid, pct) {
  const G = stateOf(group);
  if (!G.king || G.king.key !== economy.keyOf(jid)) return { ok: false, why: 'notking' };
  const n = Math.round(Number(pct) * 10) / 10;
  if (!Number.isFinite(n) || n < 0 || n > maxTaxOf(G)) return { ok: false, why: 'range', max: maxTaxOf(G) };
  return { ok: false, why: 'government' };
}
// who chatted lately (the feast is shared among them)
function seen(group, jid, now = Date.now()) {
  if (!group || !jid) return;
  const G = stateOf(group);
  const R = G.recent || (G.recent = {});
  R[economy.keyOf(jid)] = { jid, at: now };
  const keys = Object.keys(R);
  if (keys.length > 200) for (const k of keys) if (now - R[k].at > RULES.activeMs) delete R[k];
}
// the royal feast: the king pays, the people who chatted in the last hour share it (with a small bonus from the crown)
function feast(group, jid, amount, now = Date.now()) {
  const G = stateOf(group);
  const key = economy.keyOf(jid);
  if (!G.king || G.king.key !== key) return { ok: false, why: 'notking' };
  if (!(amount >= RULES.feastMin)) return { ok: false, why: 'min', min: RULES.feastMin };
  const wait = (G.feastAt || 0) + RULES.feastCooldownMs - now;
  if (wait > 0) return { ok: false, why: 'wait', waitMs: wait };
  const guests = Object.values(G.recent || {}).filter((r) => now - r.at < RULES.activeMs && economy.keyOf(r.jid) !== key).sort((a, b) => b.at - a.at).slice(0, RULES.feastMax);
  if (guests.length < RULES.feastMinPeople) return { ok: false, why: 'quiet', have: guests.length, need: RULES.feastMinPeople };
  if (wallet(group, jid) < amount) return { ok: false, why: 'poor', wallet: wallet(group, jid) };
  economy.runIn(group, () => economy.take(jid, amount));
  const each = Math.floor((amount * (1 + RULES.feastBonus)) / guests.length);
  for (const g of guests) economy.runIn(group, () => economy.add(g.jid, each));
  G.feastAt = now;
  js.touch();
  return { ok: true, each, guests: guests.map((g) => g.jid), amount };
}
// the king sends somebody to jail for a short time: no gambling and no robbing
function jail(group, jid, target, now = Date.now()) { return { ok:false, why:'government' }; }

// The king can fund direct grants and a shared bounty from their own wallet.
function grant(group, jid, target, amount) {
  const G = stateOf(group);
  if (!G.king || G.king.key !== economy.keyOf(jid)) return { ok: false, why: 'notking' };
  if (economy.keyOf(target) === economy.keyOf(jid)) return { ok: false, why: 'self' };
  if (!Number.isSafeInteger(amount) || amount < 1 || amount > 1000000) return { ok: false, why: 'amount' };
  if (!economy.runIn(group, () => economy.take(jid, amount))) return { ok: false, why: 'poor', wallet: wallet(group, jid) };
  economy.runIn(group, () => economy.add(target, amount)); js.touch(); return { ok: true, amount };
}
function bounty(group, jid, amount, now = Date.now()) {
  const G = stateOf(group), key = economy.keyOf(jid);
  if (!G.king || G.king.key !== key) return { ok: false, why: 'notking' };
  if (!Number.isSafeInteger(amount) || amount < 1 || amount > 1000000) return { ok: false, why: 'amount' };
  const people = Object.values(G.recent || {}).filter((r) => now-r.at < RULES.activeMs && economy.keyOf(r.jid) !== key).map((r) => r.jid);
  const unique = [...new Map(people.map((x) => [economy.keyOf(x), x])).values()];
  if (!unique.length) return { ok: false, why: 'quiet' };
  const total = amount * unique.length;
  if (wallet(group, jid) < total) return { ok: false, why: 'poor', wallet: wallet(group, jid), total, count: unique.length };
  economy.runIn(group, () => economy.take(jid, total));
  for (const target of unique) economy.runIn(group, () => economy.add(target, amount));
  js.touch(); return { ok: true, amount, total, guests: unique };
}

// ---- government: free somebody, free everybody, a peace law and a bank holiday
function unjail(group, jid, target, now = Date.now()) { return { ok:false, why:'government' }; }
function amnesty(group, jid, now = Date.now()) { return { ok:false, why:'government' }; }

// a law that costs the king coins and lasts for a while: kind = 'peace' | 'holiday'
function law(group, jid, kind, now = Date.now()) { return { ok:false, why:'government' }; }
const lawLeft = () => 0;
const jailLeft = () => 0; // King-controlled detention has been retired.
const jailedList = () => []; // Detention is now handled by police and government staff, never the King.
const isKing = (group, jid) => {
  const G = js.data.groups[group];
  return !!(G && G.king && G.king.key === economy.keyOf(jid));
};

// the coin module asks us for the tax and the jail
economy.setHooks({
  tax: (group, key, gross) => {
    const president = roleplay.presidentInfo(group);
    if (!president.president || president.tax <= 0) return null;
    // Compare both canonical economy IDs and WhatsApp JIDs. Older account records
    // can represent the same President in different JID formats (including device suffixes).
    const normalize = (value) => {
      const raw = String(value || '').split('@')[0].split(':')[0];
      const digits = raw.replace(/\D/g, '');
      return digits || raw.toLowerCase();
    };
    const presidentIds = new Set([roleplay.memberKey(president.president.jid), normalize(president.president.jid), normalize(economy.keyOf(president.president.jid))]);
    const earnerIds = [roleplay.memberKey(key), normalize(key), normalize(economy.keyOf(key))];
    if (earnerIds.some((id) => id && presidentIds.has(id))) return null;
    return { tax: Math.min(gross - 1, Math.floor((gross * president.tax) / 100)), to: null, kind: 'government_treasury' };
  },
  jail: (group, key) => roleplay.jailLeft(group, key),
  king: (group, key) => (!!(js.data.groups[group]?.king && js.data.groups[group].king.key === key)) || roleplay.isPresident(group, key),
  peace: (group) => { const g = roleplay.state(group); return (g.presidentialLaws?.robbery || g.presidentialLaws?.peace) ? Number.MAX_SAFE_INTEGER : roleplay.presidentInfo(group).curfew; },
  boost: (group) => { const g = roleplay.state(group); return g.presidentialLaws?.payboost ? Math.max(2, RULES.holidayBoost) : 1; },
  robbery: (group) => roleplay.robberySettings(group),
  protect: (group, key) => roleplay.protectionLeft(group, key),
});

module.exports = { RULES, info, take, collect, decree, setIncome, resetIncome, setMaxTax, incomeInfo, setTax, seen, feast, grant, bounty, jail, jailedList, unjail, amnesty, law, lawLeft, jailLeft, isKing, kingSettings, removeKingSetting, removeKing, appointKing, setGroupMaxTax }  

