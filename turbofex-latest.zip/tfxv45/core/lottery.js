// A lottery for each group: members buy tickets, an admin draws, the winner takes the pool.
const jsonstore = require('./jsonstore');
const economy = require('./economy');

const js = jsonstore.open('lottery', { groups: {} });
const PRICE = 100;
const MAX_TICKETS = 10; // per person

const room = (g) => js.data.groups[g] || (js.data.groups[g] = { tickets: {}, pool: 0 });

function info(group, jid) {
  const r = room(group);
  const mine = jid ? (r.tickets[require('../whatsapp/levels').keyOf(jid)] || { n: 0 }).n : 0;
  const total = Object.values(r.tickets).reduce((t, x) => t + x.n, 0);
  return { pool: r.pool, total, players: Object.keys(r.tickets).length, mine };
}

function buy(group, jid, count) {
  const levels = require('../whatsapp/levels');
  const r = room(group);
  const key = levels.keyOf(jid);
  const have = (r.tickets[key] || { n: 0 }).n;
  const n = Math.min(count, MAX_TICKETS - have);
  if (n < 1) return { ok: false, why: 'max' };
  if (!economy.take(jid, n * PRICE)) return { ok: false, why: 'poor' };
  r.tickets[key] = { n: have + n, jid };
  r.pool += n * PRICE;
  js.touch();
  return { ok: true, bought: n, cost: n * PRICE };
}

// picks a winner by tickets and pays the pool
function draw(group, rand = Math.random) {
  const r = room(group);
  const entries = Object.values(r.tickets);
  const total = entries.reduce((t, x) => t + x.n, 0);
  if (!total) return null;
  let pick = Math.floor(rand() * total);
  let winner = entries[0];
  for (const e of entries) {
    if (pick < e.n) {
      winner = e;
      break;
    }
    pick -= e.n;
  }
  const prize = r.pool;
  economy.add(winner.jid, prize);
  js.data.groups[group] = { tickets: {}, pool: 0 };
  js.touch();
  return { jid: winner.jid, prize, tickets: total };
}

module.exports = { info, buy, draw, PRICE, MAX_TICKETS };
