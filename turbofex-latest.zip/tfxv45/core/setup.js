// First start: the bot asks which number to use (it becomes the bot's number AND the owner), and how to link it:
// a pairing code or a QR code. Only the chosen one is shown. Once the bot is linked it never asks again.
const fs = require('fs');
const path = require('path');
const readline = require('readline');
const { DATA } = require('./paths');

const FILE = path.join(DATA, 'setup.json');
const line = '==============================================';

function saveNumber(number) {
  try {
    fs.mkdirSync(path.dirname(FILE), { recursive: true });
    fs.writeFileSync(FILE, JSON.stringify({ number }));
  } catch (err) {
    console.log('Could not save the number:', err.message);
  }
}

// is the bot already linked? (then nothing is asked)
function linkedAccount(sessionDir) {
  try {
    const creds = JSON.parse(fs.readFileSync(path.join(sessionDir, 'creds.json'), 'utf8'));
    if (creds && creds.registered) return { registered: true, number: String(creds.me?.id || '').split('@')[0].split(':')[0].replace(/\D/g, '') };
  } catch (err) {
    // no login yet
  }
  return { registered: false };
}

// questions in the console. ask() gives null when nobody can answer (no keyboard, closed, or too slow)
function consoleIo(timeoutMs) {
  const rl = readline.createInterface({ input: process.stdin, output: process.stdout });
  let closed = false;
  rl.on('close', () => {
    closed = true;
  });
  return {
    ask: (q) =>
      new Promise((resolve) => {
        if (closed) return resolve(null);
        let done = false;
        const finish = (v) => {
          if (done) return;
          done = true;
          clearTimeout(timer);
          resolve(v);
        };
        const timer = timeoutMs ? setTimeout(() => finish(null), timeoutMs) : null;
        rl.once('close', () => finish(null));
        rl.question(q, (a) => finish(String(a).trim()));
      }),
    close: () => rl.close(),
  };
}

function apply(config, number, method) {
  config.number = number;
  config.pairingNumber = number;
  if (!config.legacyOwner) config.ownerNumber = number; // one number is both the bot and its owner
  if (method) config.pairMethod = method;
}

async function ensure(config, io) {
  const linked = linkedAccount(config.sessionDir);
  if (linked.registered) {
    if (!config.number && linked.number) apply(config, linked.number, '');
    return;
  }

  let number = config.number;
  let method = config.pairMethod;
  if (number && method) {
    console.log(`\n📱 Using number +${number} (${method === 'code' ? 'pairing code' : 'QR code'}).`);
    return apply(config, number, method);
  }

  const own = !io;
  const talk = io || consoleIo(process.stdin.isTTY ? 0 : 180000); // without a keyboard it waits 3 minutes, then continues
  try {
    if (!number) {
      console.log(`\n${line}\n  📱 WHICH NUMBER DO YOU WANT TO USE?\n  This is the WhatsApp number the bot will be linked to,\n  and it will also be the OWNER of the bot.\n  Country code first, digits only, no +   (example: 2348012345678)\n${line}`);
      for (let tries = 0; tries < 5 && !number; tries += 1) {
        const answer = await talk.ask('Number: ');
        if (answer === null) break;
        const d = answer.replace(/\D/g, '');
        if (d.length >= 8 && d.length <= 15) number = d;
        else console.log('⚠️ That does not look right. Write the country code and the number, digits only (8 to 15 digits).');
      }
      if (!number) {
        console.log('\nNo number was given, so the bot starts without an owner and shows a QR code.\nTo set it: put NUMBER=2348012345678 in the environment, or restart and answer the question.\n');
        return;
      }
      saveNumber(number);
      console.log(`✅ Number saved: +${number}`);
    }

    if (!method) {
      console.log(`\n${line}\n  🔗 HOW DO YOU WANT TO LINK THE BOT?\n\n    1) Pairing code  (an 8-letter code you type on the phone)\n    2) QR code       (you scan it with the phone)\n${line}`);
      for (let tries = 0; tries < 5 && !method; tries += 1) {
        const answer = await talk.ask('Choose 1 or 2: ');
        if (answer === null) break;
        if (/^(1|code|pairing|pair)$/i.test(answer)) method = 'code';
        else if (/^(2|qr)$/i.test(answer)) method = 'qr';
        else console.log('⚠️ Please write 1 or 2.');
      }
    }
  } finally {
    if (own) talk.close();
  }
  console.log(method === 'code' ? '\n🔗 Linking with a PAIRING CODE...' : method === 'qr' ? '\n🔗 Linking with a QR CODE...' : '');
  apply(config, number, method || '');
}

module.exports = { ensure, linkedAccount, consoleIo, FILE };
