// Coins. One purse per person PER GROUP (every group is its own economy), kept under the person's phone number when known.
// Coins come from chatting in groups with ranks on, from the daily bonus, and from games. They are spent in the shop and
// invested in the market.
// Which group's purse is used is decided by the chat the message came from: the message handler wraps every message in
// runIn(chat, ...), so games, shop and market all see the right purse without passing the group around (it also survives
// awaits). In a private chat there is no group and the old bot-wide purse is used. The first time a person's coins are
// touched in a group, their old bot-wide purse moves into that group (once), so nothing is lost when upgrading.
const { AsyncLocalStorage } = require('node:async_hooks');
const jsonstore = require('./jsonstore');
const levels = require('../whatsapp/levels');

const js = jsonstore.open('economy', { users: {} });
const DAY = 24 * 60 * 60 * 1000;

const scope = new AsyncLocalStorage();
const currentGroup = () => scope.getStore()?.group || null;
const runIn = (chat, fn) => scope.run({ group: typeof chat === 'string' && chat.endsWith('@g.us') ? chat : null }, fn);

// the bank pays a little interest (and it cannot be robbed): 0.3% a day on up to 50,000 coins, added when you look at your account
const BANK = { rate: 0.003, cap: 50000, maxDays: 7 };
function bankInterest(u, now = Date.now()) {
  if (!u.bank || u.bank < 1) {
    u.bt = now;
    return 0;
  }
  const days = Math.min(BANK.maxDays, (now - (u.bt || now)) / DAY);
  const gain = Math.floor(Math.min(u.bank, BANK.cap) * BANK.rate * days);
  if (gain < 1) {
    if (!u.bt) u.bt = now;
    return 0;
  }
  u.bank += gain;
  u.bt = now;
  js.touch();
  return gain;
}

const blank = () => ({ coins: 0, streak: 0, lastDaily: 0, items: {}, title: null });
function fromLegacy(key) {
  const old = js.data.users[key];
  if (!old || old.moved) return blank();
  const had = old.coins || old.bank || old.title || old.streak || old.spouse || Object.keys(old.items || {}).length;
  if (!had) return blank();
  const copy = JSON.parse(JSON.stringify(old));
  Object.assign(old, { moved: true, coins: 0, bank: 0, title: null, streak: 0, items: {}, spouse: null, spouseJid: null });
  return copy;
}

// The market plugs in here: it changes shop prices and job pay with the mood, and it tells us who owes money
// (someone in debt cannot give coins away, bank them, gamble or rob: otherwise a loan could be sent to a friend)
const hooks = { shop: () => 1, pay: () => 1, debt: () => 0, tax: () => null, jail: () => 0, king: () => false, peace: () => 0, boost: () => 1, protect: () => 0, robbery: () => null };
const setHooks = (h) => Object.assign(hooks, h);
// ---- owner settings: bot-wide multipliers for pay (jobs, daily), chat coins and shop prices (1 = normal)
const cfg = () => (js.data.cfg = Object.assign({ pay: 1, shop: 1, chat: 1 }, js.data.cfg));
const getCfg = () => ({ ...cfg() });
function setCfg(name, value) {
  if (!['pay', 'shop', 'chat'].includes(name)) return false;
  const n = Number(value);
  if (!Number.isFinite(n) || n < 0.1 || n > 20) return false;
  cfg()[name] = Math.round(n * 100) / 100;
  js.touch();
  return true;
}
const resetCfg = () => {
  js.data.cfg = { pay: 1, shop: 1, chat: 1 };
  js.touch();
};
const chatMult = () => cfg().chat;

const shopMult = () => (currentGroup() ? hooks.shop(currentGroup()) || 1 : 1) * cfg().shop;
const payMult = () => (currentGroup() ? (hooks.pay(currentGroup()) || 1) * (hooks.boost(currentGroup()) || 1) : 1) * cfg().pay;

// ---- luck: the owner can set the gamble chance of a person (in one group, or in all). until = a time, or null = until removed
const luckKey = (jid) => (typeof jid === 'string' && jid.includes('@') ? levels.keyOf(jid) : String(jid));
function setLuck(jid, group, chance, until = null) {
  if (!js.data.luck) js.data.luck = {};
  const key = luckKey(jid);
  const mine = js.data.luck[key] || (js.data.luck[key] = {});
  mine[group || '*'] = { chance: Math.min(1, Math.max(0, chance)), until };
  js.touch();
}
function clearLuck(jid, group = null) {
  const key = luckKey(jid);
  const mine = js.data.luck?.[key];
  if (!mine) return false;
  if (group) delete mine[group];
  else delete js.data.luck[key];
  if (js.data.luck[key] && !Object.keys(js.data.luck[key]).length) delete js.data.luck[key];
  js.touch();
  return true;
}
// the chance the owner set for this person in the current group (a group setting wins over an "all groups" one), or null
function luckOf(jid, now = Date.now()) {
  const mine = js.data.luck?.[luckKey(jid)];
  if (!mine) return null;
  for (const slot of [currentGroup(), '*']) {
    const l = slot && mine[slot];
    if (l && (!l.until || l.until > now)) return l.chance;
  }
  return null;
}
function luckList(now = Date.now()) {
  const out = [];
  for (const [key, slots] of Object.entries(js.data.luck || {})) {
    for (const [group, l] of Object.entries(slots)) if (!l.until || l.until > now) out.push({ key, group: group === '*' ? null : group, chance: l.chance, until: l.until });
  }
  return out;
}

// Owner-controlled default gamble odds: per-user overrides win, then group odds, then global odds, then charm/default.
function setGambleChance(group, chance) {
  if (!js.data.gambleOdds) js.data.gambleOdds = {};
  const key = group || '*';
  if (chance === null || chance === undefined) delete js.data.gambleOdds[key];
  else {
    const n = Number(chance);
    if (!Number.isFinite(n) || n < 0.01 || n > 1) return false;
    js.data.gambleOdds[key] = Math.round(n * 10000) / 10000;
  }
  js.touch();
  return true;
}
function gambleChanceSettings() {
  return { global: js.data.gambleOdds?.['*'] ?? null, groups: { ...(js.data.gambleOdds || {}) } };
}
function gambleChanceOf(jid, now = Date.now()) {
  const personal = luckOf(jid, now);
  if (personal !== null) return personal;
  const odds = js.data.gambleOdds || {};
  const group = currentGroup();
  if (group && Number.isFinite(odds[group])) return odds[group];
  if (Number.isFinite(odds['*'])) return odds['*'];
  return hasCharm(jid, now) ? 0.5 : 0.45;
}
const inDebt = (jid) => !!currentGroup() && hooks.debt(currentGroup(), levels.keyOf(jid)) > 0;

// ---- the economy switch of a group: "economy off" turns off EVERY coin command there (the handler checks this before it runs one)
const isOff = (group) => !!(group && js.data.off && js.data.off[group]);
function setOff(group, off) {
  if (!group) return false;
  if (!js.data.off) js.data.off = {};
  if (off) js.data.off[group] = Date.now();
  else delete js.data.off[group];
  js.touch();
  return true;
}
// random coin drops in the chat can be muted per group
const dropsOn = (group) => !(js.data.nodrops && js.data.nodrops[group]);
function setDrops(group, on) {
  if (!js.data.nodrops) js.data.nodrops = {};
  if (on) delete js.data.nodrops[group];
  else js.data.nodrops[group] = true;
  js.touch();
}
const touch = () => js.touch();

// ---- couples: love points grow when partners do things together; they give a bonus on pay
const LOVE = [
  { min: 0, name: 'Newlyweds', boost: 0.02 },
  { min: 50, name: 'Sweethearts', boost: 0.04 },
  { min: 150, name: 'Soulmates', boost: 0.06 },
  { min: 400, name: 'Power Couple', boost: 0.08 },
  { min: 1000, name: 'Legends of Love', boost: 0.1 },
];
const loveTier = (pts) => [...LOVE].reverse().find((t) => (pts || 0) >= t.min) || LOVE[0];
const loveBoost = (u) => (u.spouse ? loveTier(u.love).boost : 0);
const isKing = (jid) => !!currentGroup() && !!hooks.king(currentGroup(), levels.keyOf(jid));
const peaceLeft = () => (currentGroup() ? Math.max(0, hooks.peace(currentGroup()) || 0) : 0);
const jailLeft = (jid) => (currentGroup() ? Math.max(0, hooks.jail(currentGroup(), levels.keyOf(jid)) || 0) : 0);

const keyOf = (jid) => levels.keyOf(jid);
const idmap = require('../whatsapp/idmap');
function user(key, jid, group = currentGroup()) {
  const slot = group ? `${group}|${key}` : key;
  const u = js.data.users[slot] || (js.data.users[slot] = group ? fromLegacy(key) : blank());
  if (!u.items) u.items = {};
  bankInterest(u);
  // remember an id to tag the person with (a phone number id is preferred over a hidden one)
  if (jid && jid.includes('@') && (!u.j || (idmap.isLid(u.j) && !idmap.isLid(jid)))) u.j = jid;
  return u;
}

const balance = (jid) => user(keyOf(jid), jid).coins;
const peek = (jid) => user(keyOf(jid), jid);

function add(jid, n) {
  const u = user(keyOf(jid), jid);
  u.coins = Math.max(0, Math.floor(u.coins + n));
  js.touch();
  return u.coins;
}

function addRep(jid, n = 1) {
  const u = user(keyOf(jid), jid);
  u.rep = Math.max(0, Math.floor((u.rep || 0) + n));
  js.touch();
  return u.rep;
}

function take(jid, n) {
  const u = user(keyOf(jid), jid);
  if (!Number.isInteger(n) || n <= 0 || u.coins < n) return false;
  u.coins -= n;
  js.touch();
  return true;
}

function transfer(from, to, n) {
  if (keyOf(from) === keyOf(to) || inDebt(from) || !take(from, n)) return false;
  add(to, n);
  return true;
}

// daily bonus: 500 coins, +50 for every day in a row (up to +500). Missing a whole day starts the streak again.
// (the owner's pay multiplier applies)
function daily(jid, now = Date.now()) {
  const u = user(keyOf(jid), jid);
  const since = now - u.lastDaily;
  if (u.lastDaily && since < DAY) return { ok: false, waitMs: DAY - since };
  u.streak = u.lastDaily && since < 2 * DAY ? u.streak + 1 : 1;
  const base = Math.round((500 + Math.min(500, (u.streak - 1) * 50)) * cfg().pay * (currentGroup() ? hooks.boost(currentGroup()) || 1 : 1));
  const boost = loveBoost(u);
  const gross = Math.round(base * (1 + boost));
  const tax = taxOn(jid, gross);
  const amount = gross - tax.tax;
  u.lastDaily = now;
  u.coins += amount;
  if (tax.tax) add(tax.to, tax.tax);
  js.touch();
  return { ok: true, amount, streak: u.streak, coins: u.coins, tax: tax.tax, love: boost };
}

// The king's tax: a share of what people earn from jobs and the daily bonus goes to the king of the group
function taxOn(jid, gross) {
  const group = currentGroup();
  if (!group) return { tax: 0, to: null };
  const t = hooks.tax(group, keyOf(jid), gross);
  if (!t || !t.tax || t.tax < 1) return { tax: 0, to: null };
  return { tax: Math.min(gross - 1, Math.floor(t.tax)), to: t.to };
}

// Pay for a job (work, fish, hunt, mine, crime...): the market mood, a Toolbox, a loving partner and the king's tax all count.
// Returns { gross, net, tax, tools, love }
function payout(jid, base, opts = {}) {
  const u = user(keyOf(jid), jid);
  const tools = opts.tools !== false && (u.items.tools || 0) > Date.now();
  const love = loveBoost(u);
  const gross = Math.max(1, Math.round(base * payMult() * (tools ? 1.25 : 1) * (1 + love)));
  const tax = opts.tax === false ? { tax: 0, to: null } : taxOn(jid, gross);
  u.coins += gross - tax.tax;
  if (tax.tax) add(tax.to, tax.tax);
  js.touch();
  return { gross, net: gross - tax.tax, tax: tax.tax, tools, love };
}

const ITEMS = {
  charm: { name: '🍀 Lucky Charm', price: 800, about: '+5% chance to win in gamble for 24 hours', ms: DAY },
  shield: { name: '🛡️ Shield', price: 1500, about: 'nobody can rob your wallet for 24 hours', ms: DAY },
  tools: { name: '🧰 Toolbox', price: 2000, about: '+25% pay from work, fish, hunt, mine and crime for 3 days', ms: 3 * DAY },
  lockpick: { name: '🗝️ Lockpick', price: 1800, about: '+15% chance when you rob, for 24 hours', ms: DAY },
  vip: { name: '👑 VIP', price: 2500, about: 'a title next to your name in balance' },
  legend: { name: '🔥 Legend', price: 10000, about: 'a title next to your name in balance' },
  rich: { name: '💎 Rich', price: 25000, about: 'a title next to your name in balance' },
};

// the shop follows the market mood (inflation makes everything dearer)
const priceOf = (id) => Math.max(1, Math.round(ITEMS[id].price * shopMult()));

function buy(jid, id, now = Date.now()) {
  const item = ITEMS[id];
  if (!item) return { ok: false, why: 'unknown' };
  const u = user(keyOf(jid), jid);
  if (item.ms && u.items[id] > now) return { ok: false, why: 'active', item, left: u.items[id] - now };
  if (!item.ms && u.title === item.name) return { ok: false, why: 'owned' };
  const price = priceOf(id);
  if (u.coins < price) return { ok: false, why: 'poor', need: price - u.coins };
  u.coins -= price;
  if (item.ms) u.items[id] = now + item.ms;
  else u.title = item.name;
  js.touch();
  return { ok: true, item, price };
}

// how long an item still works (0 = not active)
const itemLeft = (jid, id, now = Date.now()) => Math.max(0, (user(keyOf(jid), jid).items[id] || 0) - now);

const hasCharm = (jid, now = Date.now()) => (user(keyOf(jid), jid).items.charm || 0) > now;

// gamble: 45% to win (50% with a Lucky Charm). A win pays the bet once more, a loss loses the bet.
function gamble(jid, bet, rand = Math.random, now = Date.now()) {
  const u = user(keyOf(jid), jid);
  if (inDebt(jid)) return { ok: false, why: 'debt' };
  if (jailLeft(jid) > 0) return { ok: false, why: 'jail', left: jailLeft(jid) };
  if (!Number.isInteger(bet) || bet < 10) return { ok: false, why: 'min' };
  if (bet > u.coins) return { ok: false, why: 'poor' };
  const chance = gambleChanceOf(jid, now);
  const win = rand() < chance;
  u.coins += win ? bet : -bet;
  js.touch();
  return { ok: true, win, coins: u.coins, chance };
}

// the richest people: [{ key, coins, title, jid }]
function richest(limit = 10, only = null) {
  const worth = (u) => u.coins + (u.bank || 0);
  const group = currentGroup(); // only the purses of this group (or the old bot-wide ones in a private chat)
  return Object.entries(js.data.users)
    .map(([slot, u]) => {
      const at = slot.indexOf('|');
      return { key: at < 0 ? slot : slot.slice(at + 1), group: at < 0 ? null : slot.slice(0, at), u };
    })
    .filter((e) => e.group === group && worth(e.u) > 0 && (!only || only(e.key, e.u)))
    .sort((a, b) => worth(b.u) - worth(a.u))
    .slice(0, limit)
    .map((e) => ({ key: e.key, coins: worth(e.u), title: e.u.title, jid: e.u.j || `${e.key}@s.whatsapp.net` }));
}

// ---- cooldowns (work, fish, hunt, mine, rob): ok, or how long to wait
function cooldown(jid, name, ms, now = Date.now()) {
  const u = user(keyOf(jid), jid);
  if (!u.cd) u.cd = {};
  const since = now - (u.cd[name] || 0);
  if (since < ms) return { ok: false, waitMs: ms - since };
  u.cd[name] = now;
  js.touch();
  return { ok: true };
}

// how long until a cooldown is over, WITHOUT using it (0 = ready)
const cooldownLeft = (jid, name, ms, now = Date.now()) => Math.max(0, ms - (now - ((user(keyOf(jid), jid).cd || {})[name] || 0)));

const resetCooldown = (jid, name) => {
  const u = user(keyOf(jid), jid);
  if (u.cd) u.cd[name] = 0;
  js.touch();
};

// ---- the bank: coins in the bank cannot be robbed
const bankOf = (jid) => user(keyOf(jid), jid).bank || 0;
function deposit(jid, n) {
  const u = user(keyOf(jid), jid);
  if (inDebt(jid) || !Number.isInteger(n) || n < 1 || n > u.coins) return false;
  u.coins -= n;
  u.bank = (u.bank || 0) + n;
  js.touch();
  return true;
}
function withdraw(jid, n) {
  const u = user(keyOf(jid), jid);
  if (!Number.isInteger(n) || n < 1 || n > (u.bank || 0)) return false;
  u.bank -= n;
  u.coins += n;
  js.touch();
  return true;
}

// ---- robbing the wallet of someone (never the bank): 40% success, a failure costs a fine that goes to the victim
function rob(thief, victim, rand = Math.random) {
  const t = user(keyOf(thief), thief);
  const v = user(keyOf(victim), victim);
  if (keyOf(thief) === keyOf(victim)) return { ok: false, why: 'self' };
  if (inDebt(thief)) return { ok: false, why: 'debt' };
  if (jailLeft(thief) > 0) return { ok: false, why: 'jail', left: jailLeft(thief) };
  if (isKing(thief)) return { ok: false, why: 'king' };
  if (isKing(victim)) return { ok: false, why: 'kingsafe' };
  if (peaceLeft() > 0) return { ok: false, why: 'peace', left: peaceLeft() };
  if ((v.items.shield || 0) > Date.now() || (currentGroup() && hooks.protect(currentGroup(), keyOf(victim)) > 0)) return { ok: false, why: 'shield' };
  if (t.coins < 100) return { ok: false, why: 'poor' };
  if (v.coins < 200) return { ok: false, why: 'empty' };
  const robCfg = currentGroup() ? (hooks.robbery(currentGroup()) || {}) : {};
  const chance = Math.max(0.01, Math.min(0.95, Number(robCfg.chance ?? 0.4) + ((t.items.lockpick || 0) > Date.now() ? 0.15 : 0)));
  const cap = Number.isSafeInteger(robCfg.cap) && robCfg.cap > 0 ? robCfg.cap : 5000;
  if (rand() < chance) {
    const amount = Math.min(cap, Math.max(10, Math.floor(v.coins * (0.1 + rand() * 0.2))));
    v.coins -= amount;
    t.coins += amount;
    js.touch();
    return { ok: true, success: true, amount };
  }
  const fine = Math.min(t.coins, Math.max(50, Math.floor(t.coins * 0.15)));
  t.coins -= fine;
  v.coins += fine;
  js.touch();
  return { ok: true, success: false, amount: fine };
}

// ---- marriage: marry @user (a proposal for 2 minutes), the other person accepts with "marry accept"
const proposals = new Map(); // group|key of the one asked -> { from, fromJid, at }
const pk = (jid) => `${currentGroup() || ''}|${keyOf(jid)}`;
const PROPOSAL_MS = 2 * 60 * 1000;
const spouseOf = (jid) => {
  const u = user(keyOf(jid), jid);
  return u.spouse ? { key: u.spouse, jid: u.spouseJid } : null;
};
function propose(from, to, now = Date.now()) {
  if (keyOf(from) === keyOf(to)) return { ok: false, why: 'self' };
  if (spouseOf(from)) return { ok: false, why: 'married' };
  if (spouseOf(to)) return { ok: false, why: 'taken' };
  proposals.set(pk(to), { from: keyOf(from), fromJid: from, at: now });
  if (proposals.size > 500) proposals.clear();
  return { ok: true };
}
function accept(to, now = Date.now()) {
  const p = proposals.get(pk(to));
  if (!p || now - p.at > PROPOSAL_MS) return { ok: false, why: 'none' };
  proposals.delete(pk(to));
  if (spouseOf(to) || spouseOf(p.fromJid)) return { ok: false, why: 'taken' };
  const a = user(p.from, p.fromJid);
  const b = user(keyOf(to), to);
  a.spouse = keyOf(to);
  a.spouseJid = to;
  b.spouse = p.from;
  b.spouseJid = p.fromJid;
  a.love = b.love = 0;
  a.wed = b.wed = now;
  js.touch();
  return { ok: true, fromJid: p.fromJid };
}
function decline(to) {
  return proposals.delete(pk(to));
}
function divorce(jid) {
  const mine = spouseOf(jid);
  if (!mine) return false;
  const a = user(keyOf(jid), jid);
  const b = user(mine.key);
  a.spouse = a.spouseJid = b.spouse = b.spouseJid = null;
  a.love = b.love = 0;
  a.wed = b.wed = null;
  js.touch();
  return mine;
}


// ---- things partners do together (all need a partner; the waiting time is shared by both)
const partnerOf = (jid) => {
  const sp = spouseOf(jid);
  return sp ? { key: sp.key, jid: sp.jid || `${sp.key}@s.whatsapp.net` } : null;
};
function addLove(jid, n) {
  const sp = partnerOf(jid);
  const a = user(keyOf(jid), jid);
  a.love = (a.love || 0) + n;
  if (sp) user(sp.key, sp.jid).love = a.love;
  js.touch();
  return a.love;
}
function coupleInfo(jid, now = Date.now()) {
  const sp = partnerOf(jid);
  if (!sp) return null;
  const u = user(keyOf(jid), jid);
  const tier = loveTier(u.love);
  const next = LOVE.find((t) => t.min > (u.love || 0)) || null;
  return { partner: sp, love: u.love || 0, tier, next, days: u.wed ? Math.max(0, Math.floor((now - u.wed) / DAY)) : 0 };
}
// a shared waiting time: both partners get the same start time
function coupleCooldown(jid, name, ms, now = Date.now()) {
  const sp = partnerOf(jid);
  if (!sp) return { ok: false, why: 'single' };
  const a = user(keyOf(jid), jid);
  const b = user(sp.key, sp.jid);
  a.cd = a.cd || {};
  b.cd = b.cd || {};
  const last = Math.max(a.cd[name] || 0, b.cd[name] || 0);
  if (now - last < ms) return { ok: false, why: 'wait', waitMs: ms - (now - last) };
  a.cd[name] = b.cd[name] = now;
  js.touch();
  return { ok: true, partner: sp };
}
const coupleWait = (jid, name, ms, now = Date.now()) => {
  const sp = partnerOf(jid);
  if (!sp) return 0;
  const a = (user(keyOf(jid), jid).cd || {})[name] || 0;
  const b = (user(sp.key, sp.jid).cd || {})[name] || 0;
  return Math.max(0, ms - (now - Math.max(a, b)));
};

// ---- the owner moves (or copies) the progress of people from one group to another
// who: a key, or null for everybody. mode: 'move' | 'copy'. Purses are added together when the person already has one there.
function moveGroup(from, to, who = null, mode = 'move') {
  const moved = [];
  for (const [slot, u] of Object.entries(js.data.users)) {
    const at = slot.indexOf('|');
    if (at < 0 || slot.slice(0, at) !== from) continue;
    const key = slot.slice(at + 1);
    if (who && key !== who) continue;
    const dest = user(key, u.j, to);
    dest.coins += u.coins || 0;
    dest.bank = (dest.bank || 0) + (u.bank || 0);
    dest.streak = Math.max(dest.streak || 0, u.streak || 0);
    dest.lastDaily = Math.max(dest.lastDaily || 0, u.lastDaily || 0);
    dest.title = dest.title || u.title;
    dest.rep = (dest.rep || 0) + (u.rep || 0);
    for (const [id, until] of Object.entries(u.items || {})) dest.items[id] = Math.max(dest.items[id] || 0, until);
    if (!who && u.spouse && !dest.spouse) {
      Object.assign(dest, { spouse: u.spouse, spouseJid: u.spouseJid, love: u.love || 0, wed: u.wed || null });
    }
    if (!dest.j && u.j) dest.j = u.j;
    moved.push({ key, coins: (u.coins || 0) + (u.bank || 0) });
    if (mode === 'move') delete js.data.users[slot];
  }
  js.touch();
  return moved;
}
const groupsWithData = () => {
  const out = new Map();
  for (const slot of Object.keys(js.data.users)) {
    const at = slot.indexOf('|');
    if (at > 0) out.set(slot.slice(0, at), (out.get(slot.slice(0, at)) || 0) + 1);
  }
  return out;
};

const fmt = (n) => Number(n).toLocaleString('en-US');

// a person's purse in a given group, by key (the market uses this when no chat message is being handled)
const accountIn = (group, key, jid) => user(key, jid, group);

module.exports = { BANK, isKing, peaceLeft, isOff, setOff, dropsOn, setDrops, touch, payout, itemLeft, cooldownLeft, jailLeft, loveTier, loveBoost, LOVE, partnerOf, addLove, coupleInfo, coupleCooldown, coupleWait, moveGroup, groupsWithData, getCfg, setCfg, resetCfg, chatMult, setLuck, clearLuck, luckOf, luckList, setGambleChance, gambleChanceSettings, gambleChanceOf, runIn, withGroup: runIn, currentGroup, setHooks, shopMult, payMult, inDebt, priceOf, accountIn, keyOf, balance, peek, add, addRep, take, transfer, daily, buy, gamble, richest, hasCharm, cooldown, resetCooldown, bankOf, deposit, withdraw, rob, propose, accept, decline, divorce, spouseOf, ITEMS, fmt, DAY };
