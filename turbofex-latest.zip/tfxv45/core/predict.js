// Predictions: an admin asks a yes/no question about something real ("Will Super Eagles win on Saturday?"). Members put coins
// on YES or NO. When the answer is known the admin settles it and the people who were right share the pool (5% of it is gone).
// If one side has nobody, or the question is cancelled or never settled, everybody gets their coins back.
const jsonstore = require('./jsonstore');
const economy = require('./economy');

const js = jsonstore.open('predict', { groups: {} });

const RULES = { fee: 0.05, minStake: 50, maxStake: 5000, maxOpen: 5, questionMax: 140, refundAfterMs: 7 * 24 * 3600000, minDurationMs: 60000, maxDurationMs: 30 * 24 * 3600000 };

const stateOf = (group) => js.data.groups[group] || (js.data.groups[group] = { next: 1, items: {} });
const spend = (group, jid, n) => economy.runIn(group, () => economy.take(jid, n));
const earn = (group, jid, n) => economy.runIn(group, () => economy.add(jid, n));
const poolOf = (it) => {
  let yes = 0;
  let no = 0;
  for (const b of Object.values(it.bets)) {
    yes += b.yes || 0;
    no += b.no || 0;
  }
  return { yes, no, total: yes + no };
};

// questions that were never settled are refunded after a week
function sweep(group, now = Date.now()) {
  const G = stateOf(group);
  let n = 0;
  for (const it of Object.values(G.items)) {
    if (it.state === 'open' && now > it.closes + RULES.refundAfterMs) {
      refund(group, it);
      it.state = 'cancelled';
      it.why = 'nobody settled it in a week';
      n += 1;
    }
  }
  if (n) js.touch();
  return n;
}
function refund(group, it) {
  for (const b of Object.values(it.bets)) {
    const n = (b.yes || 0) + (b.no || 0);
    if (n > 0) earn(group, b.j, n);
  }
}

function create(group, jid, question, durationMs, now = Date.now()) {
  sweep(group, now);
  const G = stateOf(group);
  const q = String(question || '').replace(/\s+/g, ' ').trim().slice(0, RULES.questionMax);
  if (q.length < 8) return { ok: false, why: 'short' };
  if (!(durationMs >= RULES.minDurationMs && durationMs <= RULES.maxDurationMs)) return { ok: false, why: 'duration' };
  if (Object.values(G.items).filter((i) => i.state === 'open').length >= RULES.maxOpen) return { ok: false, why: 'many', max: RULES.maxOpen };
  const id = G.next++;
  G.items[id] = { id, q, by: jid, byKey: economy.keyOf(jid), created: now, closes: now + durationMs, state: 'open', bets: {} };
  // old finished ones are forgotten (the last 30 stay)
  const done = Object.values(G.items).filter((i) => i.state !== 'open').sort((a, b) => a.id - b.id);
  while (done.length > 30) delete G.items[done.shift().id];
  js.touch();
  return { ok: true, id, closes: G.items[id].closes };
}

function list(group, now = Date.now()) {
  sweep(group, now);
  return Object.values(stateOf(group).items)
    .filter((i) => i.state === 'open')
    .sort((a, b) => a.id - b.id)
    .map((i) => ({ ...i, pool: poolOf(i), betting: now < i.closes }));
}
const get = (group, id) => stateOf(group).items[id] || null;

function odds(it, side) {
  const p = poolOf(it);
  const mine = side === 'yes' ? p.yes : p.no;
  return mine > 0 ? (p.total * (1 - RULES.fee)) / mine : null; // what 1 coin on this side returns if it wins right now
}

function stake(group, jid, id, side, amount, now = Date.now()) {
  sweep(group, now);
  const it = get(group, id);
  if (!it || it.state !== 'open') return { ok: false, why: 'none' };
  if (!['yes', 'no'].includes(side)) return { ok: false, why: 'side' };
  if (now >= it.closes) return { ok: false, why: 'closed' };
  const key = economy.keyOf(jid);
  if (key === it.byKey) return { ok: false, why: 'creator' };
  if (economy.runIn(group, () => economy.inDebt(jid))) return { ok: false, why: 'debt' };
  const b = it.bets[key] || (it.bets[key] = { j: jid, yes: 0, no: 0 });
  const other = side === 'yes' ? b.no : b.yes;
  if (other > 0) return { ok: false, why: 'otherside' };
  const have = (side === 'yes' ? b.yes : b.no) || 0;
  if (!Number.isInteger(amount) || amount < RULES.minStake) return { ok: false, why: 'min', min: RULES.minStake };
  if (have + amount > RULES.maxStake) return { ok: false, why: 'max', max: RULES.maxStake, have };
  if (!spend(group, jid, amount)) {
    if (!b.yes && !b.no) delete it.bets[key];
    return { ok: false, why: 'poor', wallet: economy.runIn(group, () => economy.balance(jid)) };
  }
  b[side] = have + amount;
  b.j = jid;
  js.touch();
  return { ok: true, item: it, side, total: b[side], pool: poolOf(it), payoutPerCoin: odds(it, side) };
}

// the question is answered: yes or no. Returns the winners.
function settle(group, jid, id, outcome, isOwner = false, now = Date.now()) {
  const it = get(group, id);
  if (!it || it.state !== 'open') return { ok: false, why: 'none' };
  if (!isOwner && economy.keyOf(jid) !== it.byKey) return { ok: false, why: 'notyours' };
  if (!['yes', 'no'].includes(outcome)) return { ok: false, why: 'side' };
  const p = poolOf(it);
  const winPool = outcome === 'yes' ? p.yes : p.no;
  const winners = [];
  let refunded = false;
  if (winPool === 0 || winPool === p.total) {
    refund(group, it); // nobody on one of the sides: nothing was won or lost
    refunded = true;
  } else {
    const pot = Math.floor(p.total * (1 - RULES.fee));
    for (const b of Object.values(it.bets)) {
      const s = outcome === 'yes' ? b.yes : b.no;
      if (!s) continue;
      const got = Math.floor((s / winPool) * pot);
      earn(group, b.j, got);
      winners.push({ jid: b.j, stake: s, got });
    }
  }
  it.state = 'resolved';
  it.outcome = outcome;
  it.resolvedAt = now;
  js.touch();
  return { ok: true, item: it, outcome, pool: p, winners: winners.sort((a, b) => b.got - a.got), refunded, burned: refunded ? 0 : p.total - winners.reduce((s, w) => s + w.got, 0) };
}

function cancel(group, jid, id, isOwner = false) {
  const it = get(group, id);
  if (!it || it.state !== 'open') return { ok: false, why: 'none' };
  if (!isOwner && economy.keyOf(jid) !== it.byKey) return { ok: false, why: 'notyours' };
  refund(group, it);
  it.state = 'cancelled';
  it.why = 'cancelled';
  js.touch();
  return { ok: true, item: it, players: Object.keys(it.bets).length };
}

module.exports = { RULES, create, list, get, stake, settle, cancel, odds, poolOf, sweep };
