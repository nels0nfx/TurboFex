// Coin drops: in a group that chats a lot, a bag of coins now and then "drops". The first person to send "grab" wins it.
// It keeps the chat alive: nothing drops in a quiet group, and nothing drops where the economy is off.
const economy = require('./economy');
const quests = require('./quests');

const RULES = { minMessages: 40, minGapMs: 15 * 60000, chance: 0.12, lifeMs: 3 * 60000, min: 100, max: 350 };
const rooms = new Map(); // group -> { count, last, drop }

const room = (g) => rooms.get(g) || (rooms.set(g, { count: 0, last: Date.now(), drop: null }).get(g));
const live = (r, now) => r.drop && now - r.drop.at < RULES.lifeMs;

// called for every chat message of a group. Sends the drop notice when it is time.
async function onMessage(sock, group, now = Date.now(), rand = Math.random) {
  if (economy.isOff(group) || !economy.dropsOn(group)) return false;
  const r = room(group);
  if (live(r, now)) return false;
  r.drop = null;
  r.count += 1;
  if (r.count < RULES.minMessages || now - r.last < RULES.minGapMs || rand() > RULES.chance) return false;
  r.count = 0;
  r.last = now;
  const prize = Math.round((RULES.min + Math.floor(rand() * (RULES.max - RULES.min + 1))) * economy.runIn(group, () => economy.payMult()));
  r.drop = { at: now, prize };
  if (rooms.size > 1000) rooms.clear(), rooms.set(group, r);
  await sock.sendMessage(group, { text: `💰 *A bag of coins just dropped!*\nThe first person to send *grab* wins *${economy.fmt(prize)} coins*.\n_It is gone in 3 minutes._` });
  return true;
}

// "grab": returns { ok, prize } or { ok: false, why }
function grab(group, jid, now = Date.now()) {
  const r = rooms.get(group);
  if (!r || !r.drop) return { ok: false, why: 'none' };
  if (!live(r, now)) {
    r.drop = null;
    return { ok: false, why: 'gone' };
  }
  const prize = r.drop.prize;
  r.drop = null;
  economy.add(jid, prize);
  return { ok: true, prize, quest: quests.note(quests.track(group, jid, 'grab')) };
}

// the owner or an admin can drop one right now (for an event)
function drop(group, prize, now = Date.now()) {
  const r = room(group);
  r.drop = { at: now, prize };
  r.last = now;
  r.count = 0;
}

module.exports = { RULES, onMessage, grab, drop };
