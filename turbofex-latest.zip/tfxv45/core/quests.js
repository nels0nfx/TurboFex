// Quests: every day each group gets 3 small missions (chat, work, games...) that pay coins. Finishing all 3 pays a bonus, and
// finishing many daily quests in a week pays a weekly prize. They push people towards the parts of the bot they do not use yet.
// Everything is per group (like the coins). The 3 quests of a day are the same for everybody in the group.
const jsonstore = require('./jsonstore');
const clock = require('./clock');
const economy = require('./economy');

const js = jsonstore.open('quests', { groups: {} });

const POOL = [
  { id: 'chat', icon: '💬', text: 'Send 15 chat messages', event: 'chat', n: 15, reward: 100 },
  { id: 'daily', icon: '🎁', text: 'Collect your daily bonus', event: 'daily', n: 1, reward: 50 },
  { id: 'jobs', icon: '💼', text: 'Work, fish, hunt or mine 3 times', event: 'job', n: 3, reward: 150 },
  { id: 'gamble', icon: '🎲', text: 'Win a gamble', event: 'gamblewin', n: 1, reward: 100 },
  { id: 'grab', icon: '💰', text: 'Grab a coin drop', event: 'grab', n: 1, reward: 120 },
  { id: 'garden', icon: '🌱', text: 'Harvest your garden', event: 'harvest', n: 1, reward: 100 },
  { id: 'rep', icon: '⭐', text: 'Give reputation to a member', event: 'rep', n: 1, reward: 80 },
  { id: 'crime', icon: '🦹', text: 'Try a crime', event: 'crime', n: 1, reward: 120 },
];
const RULES = { picks: 3, sweep: 250, weeklyNeed: 12, weekly: 1000 };

const dayId = (now) => {
  const p = clock.parts(new Date(now));
  return `${p.y}-${String(p.mo).padStart(2, '0')}-${String(p.dom).padStart(2, '0')}`;
};
const weekOf = (now) => { const d = new Date(now); const start = new Date(Date.UTC(d.getUTCFullYear(), d.getUTCMonth(), d.getUTCDate())); start.setUTCDate(start.getUTCDate() + 4 - (start.getUTCDay() || 7)); const yearStart = new Date(Date.UTC(start.getUTCFullYear(), 0, 1)); return `${start.getUTCFullYear()}-${Math.ceil((((start-yearStart)/86400000)+1)/7)}`; };

// a small repeatable random generator, so the same group gets the same quests all day
function seeded(text) {
  let h = 2166136261;
  for (const c of text) h = Math.imul(h ^ c.charCodeAt(0), 16777619) >>> 0;
  return () => {
    h = (Math.imul(h, 1664525) + 1013904223) >>> 0;
    return h / 4294967296;
  };
}

function groupState(group, now) {
  const G = js.data.groups[group] || (js.data.groups[group] = { day: null, week: null });
  const today = dayId(now);
  if (!G.day || G.day.id !== today) {
    const pool = POOL;
    const rnd = seeded(`${group}|${today}`);
    const picks = [];
    const left = [...pool];
    while (picks.length < RULES.picks && left.length) picks.push(left.splice(Math.floor(rnd() * left.length), 1)[0].id);
    G.day = { id: today, picks, players: {} };
    js.touch();
  }
  const wk = weekOf(now);
  if (!G.week || G.week.id !== wk) {
    G.week = { id: wk, count: {}, paid: {} };
    js.touch();
  }
  return G;
}
const byId = (id) => POOL.find((q) => q.id === id);

function playerOf(G, jid) {
  const key = economy.keyOf(jid);
  const P = G.day.players[key] || (G.day.players[key] = { prog: {}, done: {}, sweep: false, j: jid });
  return { key, P };
}
const pay = (group, jid, n) => economy.runIn(group, () => economy.add(jid, n));

// something happened (event): count it for the quests that want it. Returns what was completed: { done: [{quest, reward}], sweep, weekly }
function track(group, jid, event, n = 1, now = Date.now()) {
  const out = { done: [], sweep: 0, weekly: 0 };
  if (!group || !jid || !String(group).endsWith('@g.us')) return out;
  const G = groupState(group, now);
  const { key, P } = playerOf(G, jid);
  for (const id of G.day.picks) {
    const q = byId(id);
    if (!q || q.event !== event || P.done[id]) continue;
    P.prog[id] = (P.prog[id] || 0) + n;
    if (P.prog[id] >= q.n) {
      P.done[id] = true;
      pay(group, jid, q.reward);
      out.done.push({ quest: q, reward: q.reward });
      G.week.count[key] = (G.week.count[key] || 0) + 1;
      if (G.week.count[key] >= RULES.weeklyNeed && !G.week.paid[key]) {
        G.week.paid[key] = true;
        out.weekly = RULES.weekly;
        pay(group, jid, RULES.weekly);
      }
    }
  }
  if (out.done.length && !P.sweep && G.day.picks.every((id) => P.done[id])) {
    P.sweep = true;
    out.sweep = RULES.sweep;
    pay(group, jid, RULES.sweep);
  }
  if (out.done.length) js.touch();
  return out;
}

function status(group, jid, now = Date.now()) {
  const G = groupState(group, now);
  const { key, P } = playerOf(G, jid);
  return {
    day: G.day.id,
    quests: G.day.picks.map((id) => ({ ...byId(id), progress: Math.min(byId(id).n, P.prog[id] || 0), done: !!P.done[id] })),
    sweep: P.sweep, sweepReward: RULES.sweep,
    week: { count: G.week.count[key] || 0, need: RULES.weeklyNeed, reward: RULES.weekly, paid: !!G.week.paid[key] },
  };
}

// a short text for a reply: what the person just completed
function note(res, tag) {
  if (!res || (!res.done.length && !res.sweep)) return null;
  const lines = res.done.map((d) => `${d.quest.icon} *Quest done:* ${d.quest.text} → *+${d.reward} coins*`);
  if (res.sweep) lines.push(`🏆 *All quests of the day done!* Bonus *+${res.sweep} coins*`);
  if (res.weekly) lines.push(`🌟 *Weekly quest prize!* *+${res.weekly} coins*`);
  return `🎯 ${tag ? `${tag}\n` : ''}${lines.join('\n')}`;
}

module.exports = { POOL, RULES, track, status, note, dayId };
