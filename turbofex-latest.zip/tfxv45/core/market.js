// The market: every group that switches it on gets its own economy. The same rules everywhere, but each group has its own
// mood, news, prices, investors and coins (the purses are per group too, see core/economy.js).
//
//  - A mood (Boom, Stable, Recession, Inflation, Crash) lasts a few hours, then shifts and comes with a headline.
//  - Prices update every 30 minutes, for everybody at the same moment. The mood moves the prices, the bond yield, the loan
//    rate, the shop prices, the job pay, the rent and the profit of businesses.
//  - Sinks that keep coins from growing forever: trading fees, property stamp duty and tax, business tax, loan fees and interest.
//  - Protection: one trade can use a share of the wallet only, there is a wait between trades, and no price can fall more
//    than a fixed share in 24 hours (so no crash can take more than that from a portfolio in one day).
//  - Every week the investor with the best profit in % gets a title and a prize.
const jsonstore = require('./jsonstore');
const clock = require('./clock');
const economy = require('./economy');
const D = require('./marketdata');

const { RULES: R, MOODS } = D;
const js = jsonstore.open('market', { groups: {} });

const HOUR = 3600000;
const DAY = 24 * HOUR;
const PER_DAY = DAY / R.tickMs; // price updates per day (48)
const ALL = [...D.ASSETS, D.PROPERTY_INDEX];

// ---- randomness (the tests can replace it)
let rnd = Math.random;
const setRandom = (fn) => { rnd = fn || Math.random; };
const between = (a, b) => a + rnd() * (b - a);
function gauss() {
  let u = 0;
  while (u === 0) u = rnd();
  return Math.sqrt(-2 * Math.log(u)) * Math.cos(2 * Math.PI * rnd());
}
function pickWeighted(table) {
  const entries = Object.entries(table);
  let x = rnd() * entries.reduce((s, [, w]) => s + w, 0);
  for (const [k, w] of entries) if ((x -= w) <= 0) return k;
  return entries[entries.length - 1][0];
}
const pick = (list) => list[Math.floor(rnd() * list.length) % list.length];
const clamp = (n, lo, hi) => Math.min(hi, Math.max(lo, n));
const round2 = (n) => Math.round(n * 100) / 100;
const round6 = (n) => Math.round(n * 1e6) / 1e6;
const fmt = economy.fmt;

// ---- finding things
const norm = (t) => String(t || '').trim().toLowerCase();
function findAsset(text) {
  const t = norm(text);
  if (!t) return null;
  if (/^bonds?$/.test(t)) return { kind: 'bond', ...D.BOND };
  const exact = D.ASSETS.find((a) => a.id.toLowerCase() === t || a.name.toLowerCase() === t || a.name.toLowerCase().split(' ')[0] === t);
  if (exact) return exact;
  if (t.length < 3) return null;
  const hits = D.ASSETS.filter((a) => a.id.toLowerCase().startsWith(t) || a.name.toLowerCase().startsWith(t));
  return hits.length === 1 ? hits[0] : null;
}
function findIn(table, text) {
  const t = norm(text);
  if (!t) return null;
  return Object.keys(table).find((id) => id === t || table[id].name.toLowerCase() === t || table[id].name.toLowerCase().split(' ')[0] === t) || null;
}
const findProperty = (text) => findIn(D.PROPERTIES, text);
const findBusiness = (text) => findIn(D.BUSINESSES, text);

// "500", "2k", "1,500", "all", "50%"
function parseAmount(text) {
  const t = norm(text).replace(/[,_\s]/g, '');
  if (t === 'all' || t === 'max') return { all: true };
  let m = /^(\d+(?:\.\d+)?)%$/.exec(t);
  if (m) return Number(m[1]) > 0 && Number(m[1]) <= 100 ? { pct: Number(m[1]) } : null;
  m = /^(\d+(?:\.\d+)?)(k|m)?$/.exec(t);
  if (!m) return null;
  const n = Math.floor(Number(m[1]) * ({ k: 1e3, m: 1e6 }[m[2]] || 1));
  return n > 0 ? { n } : null;
}

// ---- the week (it starts on Monday, 00:00 in the bot's time zone)
function weekId(t) {
  const p = clock.parts(new Date(t));
  const idx = Math.max(0, ['mon', 'tue', 'wed', 'thu', 'fri', 'sat', 'sun'].indexOf(p.dow));
  return new Date(Date.UTC(p.y, p.mo - 1, p.dom - idx)).toISOString().slice(0, 10);
}

// ---- the state of a group
const groupState = (group) => js.data.groups[group] || null;
const isOn = (group) => !!groupState(group)?.on;
const allGroups = () => js.data.groups;

function fresh(now) {
  const prices = {};
  const hist = {};
  for (const a of ALL) {
    prices[a.id] = a.base;
    hist[a.id] = [a.base];
  }
  return {
    on: true, news: false, created: now, valv: 2,
    mood: 'stable', since: now, until: now + between(4, 6) * HOUR, inflation: 3,
    headline: { t: 'The market opens for business', tilt: {} }, tilt: {},
    lastNews: null,
    ticked: now, prices, hist, shift: { ...prices },
    players: {}, week: weekId(now), hall: [],
  };
}

function enable(group, now = Date.now()) {
  let G = groupState(group);
  const wasOn = !!G?.on;
  if (!G) G = js.data.groups[group] = fresh(now);
  else if (!G.on) {
    G.on = true;
    G.ticked = Math.max(G.ticked, now - R.maxCatchUp * R.tickMs); // after a pause the time is played back, but not for ever
  }
  js.touch();
  return { ok: true, already: wasOn };
}
function disable(group) {
  const G = groupState(group);
  if (!G || !G.on) return false;
  G.on = false;
  js.touch();
  return true;
}
function setNews(group, on) {
  const G = groupState(group);
  if (!G) return false;
  G.news = !!on;
  js.touch();
  return true;
}
// the owner can wipe the market of a group: everybody's investments and the history are gone (coins in purses stay)
function wipe(group, now = Date.now()) {
  const G = groupState(group);
  if (!G) return false;
  js.data.groups[group] = Object.assign(fresh(now), { on: G.on, news: G.news });
  js.touch();
  return true;
}

// ---- the mood
const shopMult = (G) => clamp(1 + (G.inflation - 3) / 50, 0.9, 1.4);
const payMult = (G) => MOODS[G.mood].pay;
const loanRate = (G) => R.loanBaseRate + G.inflation * 0.1; // % per day
const bondRate = (G) => MOODS[G.mood].bond; // % per day

function movers(G) {
  const rows = D.ASSETS.filter((a) => a.kind !== 'stock').map((a) => ({ id: a.id, pct: (G.prices[a.id] / G.shift[a.id] - 1) * 100 }));
  const up = rows.filter((r) => r.pct >= 0.3).sort((a, b) => b.pct - a.pct).slice(0, 3);
  const down = rows.filter((r) => r.pct <= -0.3).sort((a, b) => a.pct - b.pct).slice(0, 3);
  return { up, down };
}

function shiftMood(G, t, force = null) {
  const mood = force || pickWeighted(D.NEXT[G.mood]);
  const item = pick(D.NEWS[mood]);
  const before = movers(G); // how prices moved during the mood that just ended
  const prev = G.mood;
  G.mood = mood;
  G.since = t;
  G.until = t + between(...MOODS[mood].hours) * HOUR;
  G.inflation = Math.round(between(...MOODS[mood].inflation) * 10) / 10;
  G.headline = { t: item.t, tilt: item.tilt };
  G.tilt = { ...item.tilt };
  G.lastNews = { mood, prev, text: item.t, at: t, moves: before };
  G.shift = { ...G.prices };
  return G.lastNews;
}

// one price update
function stepPrices(G) {
  for (const a of ALL) {
    const p = G.prices[a.id];
    const h = G.hist[a.id];
    const ret = (a.fx[G.mood] + (G.tilt[a.sector] || 0) + a.vol * gauss()) / 100 - a.k * Math.log(p / a.base);
    let next = p * Math.exp(ret);
    next = clamp(next, h[0] * (1 - a.drop), h[0] * (1 + a.rise)); // crash protection: h[0] is the price 24 hours ago
    next = clamp(next, a.base * 0.15, a.base * 8);
    next = a.kind === 'index' ? Math.round(next * 1e4) / 1e4 : Math.max(0.01, round2(next));
    G.prices[a.id] = next;
    h.push(next);
    if (h.length > PER_DAY) h.shift();
  }
}

const change24 = (G, id) => (G.prices[id] / G.hist[id][0] - 1) * 100;

// ---- people
function ledgerOf(G, P) {
  if (!P.w || P.w.wk !== G.week) P.w = { wk: G.week, open: investedValue(G, P), flow: 0, dep: 0, inc: 0, cost: 0 };
  return P.w;
}
// the week's ledger and the lifetime ledger (P.life) are kept together. fields: flow, dep, inc, cost (they count for the
// profit), and fees, tax, interest (only to show where the money went)
function led(P, field, n) {
  if (P.w && field in P.w) P.w[field] += n;
  if (!P.life) P.life = { open: 0, flow: 0, dep: 0, inc: 0, cost: 0, fees: 0, tax: 0, interest: 0, since: Date.now() };
  P.life[field] = (P.life[field] || 0) + n;
}
const idmap = () => require('../whatsapp/idmap'); // loaded late: no circular import
function player(group, G, jid) {
  const key = economy.keyOf(jid);
  let P = G.players[key];
  if (!P) {
    P = G.players[key] = { j: jid, hold: {}, cost: {}, bond: 0, bondCost: 0, props: {}, pcost: {}, rent: 0, tax: 0, biz: {}, loan: null, last: 0, real: 0, crown: null, crowns: 0, w: null };
  } else if (jid && (!P.j || (idmap().isLid(P.j) && !idmap().isLid(jid)))) {
    P.j = jid;
  }
  ledgerOf(G, P);
  if (!P.life) P.life = { open: investedValue(G, P), flow: 0, dep: 0, inc: 0, cost: 0, fees: 0, tax: 0, interest: 0, since: Date.now() };
  return { key, P };
}

const propValue = (G, id) => Math.round(D.PROPERTIES[id].value * G.prices.PROP);
const holdingsValue = (G, P) => Object.entries(P.hold).reduce((s, [id, u]) => s + u * G.prices[id], 0);
const propertyValue = (G, P) => Object.entries(P.props).reduce((s, [id, n]) => s + n * propValue(G, id), 0);
const bizResale = (P) => Object.values(P.biz).reduce((s, b) => s + b.spent * R.bizResale, 0);
const bizCost = (P) => Object.values(P.biz).reduce((s, b) => s + b.spent, 0);
// income that waits to be collected (rent after tax, business profit after tax, dividends): it is yours, so it counts for profit
const pendingIncome = (P) => Math.max(0, Math.floor(P.rent || 0) - Math.floor(P.tax || 0)) + Object.values(P.biz).reduce((s, b) => s + Math.floor(b.acc) * (1 - R.bizTax), 0) + Math.floor(P.div || 0);
// what you own, for the PROFIT numbers: a business counts at what you put in (it is not a loss until you sell it), and income waiting to be collected counts too
const investedValue = (G, P) => holdingsValue(G, P) + P.bond + propertyValue(G, P) + bizCost(P) + pendingIncome(P);


// saved markets used the old way of counting (businesses at 70%, waiting income not counted): move the opening numbers by the
// difference so a person's profit does not jump
(function migrateValuation() {
  let changed = false;
  for (const G of Object.values(js.data.groups)) {
    if (G.valv === 2) continue;
    for (const P of Object.values(G.players || {})) {
      const delta = bizCost(P) - bizResale(P) + pendingIncome(P);
      if (P.w) P.w.open += delta;
      if (P.life) P.life.open += delta;
    }
    G.valv = 2;
    changed = true;
  }
  if (changed) js.touch();
})();

function worthOf(group, G, key, P) {
  const acct = economy.accountIn(group, key, P.j);
  const wallet = acct.coins;
  const bank = acct.bank || 0;
  const hold = holdingsValue(G, P);
  const prop = propertyValue(G, P);
  const biz = bizResale(P);
  const debt = P.loan ? P.loan.debt : 0;
  const gross = wallet + bank + hold + P.bond + prop + biz;
  return { wallet, bank, hold, bond: P.bond, prop, biz, debt, gross, total: gross - debt, invested: hold + P.bond + prop + biz };
}

// profit of the week in coins and in % (only what investing made: not the coins from work, fish or daily)
function weekScore(G, P) {
  const w = ledgerOf(G, P);
  const profit = investedValue(G, P) - w.open - w.flow + w.inc - w.cost;
  const base = Math.max(1000, w.open + w.dep);
  return { profit, pct: (profit / base) * 100, eligible: w.dep >= R.weekMinInvested || w.open >= R.weekMinInvested };
}

// ---- wallet helpers (the coins live in core/economy, in the purse of that group)
const walletOf = (group, jid) => economy.runIn(group, () => economy.balance(jid));
const spend = (group, jid, n) => economy.runIn(group, () => economy.take(jid, n));
const earn = (group, jid, n) => economy.runIn(group, () => economy.add(jid, n));

const open = (group) => {
  const G = groupState(group);
  return G && G.on ? G : null;
};
const fail = (why, extra = {}) => ({ ok: false, why, ...extra });
const waitLeft = (P, now) => Math.max(0, P.last + R.cooldownMs - now);
const feeOf = (kind, n) => Math.max(1, Math.round(n * R.fee[kind]));

// ---- stocks and coins
function invest(group, jid, assetText, amountText, now = Date.now()) {
  const G = open(group);
  if (!G) return fail('closed');
  const asset = findAsset(assetText);
  if (!asset) return fail('unknown');
  if (asset.kind === 'bond') return bondBuy(group, jid, amountText, now);
  const { key, P } = player(group, G, jid);
  const left = waitLeft(P, now);
  if (left) return fail('wait', { waitMs: left });
  const wallet = walletOf(group, jid);
  const cap = Math.max(Math.floor(wallet * R.capShare), Math.min(wallet, R.capFloor));
  const a = parseAmount(amountText);
  if (!a) return fail('amount');
  const amount = a.all ? cap : a.pct ? Math.floor((wallet * a.pct) / 100) : a.n;
  if (wallet < R.minTrade) return fail('poor', { wallet });
  if (amount < R.minTrade) return fail('min', { min: R.minTrade });
  if (amount > wallet) return fail('poor', { wallet });
  if (amount > cap) return fail('cap', { cap });
  if (!spend(group, jid, amount)) return fail('poor', { wallet });
  const price = G.prices[asset.id];
  const fee = feeOf(asset.kind, amount);
  const units = round6((amount - fee) / price);
  P.hold[asset.id] = round6((P.hold[asset.id] || 0) + units);
  P.cost[asset.id] = (P.cost[asset.id] || 0) + amount;
  led(P, 'fees', fee);
  const breakEven = P.cost[asset.id] / (P.hold[asset.id] * (1 - R.fee[asset.kind])); // the price where selling everything gives back what you paid
  led(P, 'flow', (amount));
  led(P, 'dep', (amount));
  P.last = now;
  js.touch();
  return { ok: true, asset, amount, fee, units, price, breakEven, held: P.hold[asset.id], wallet: walletOf(group, jid), key };
}

// sells units of one holding at the current price. Returns { gross, fee, proceeds }
function sellUnits(group, G, P, id, units, forced = false) {
  const asset = byId(id);
  const held = P.hold[id] || 0;
  units = Math.min(units, held);
  const gross = units * G.prices[id];
  const fee = feeOf(asset.kind, gross);
  const proceeds = Math.max(0, Math.floor(gross - fee));
  const costPart = held > 0 ? (P.cost[id] || 0) * (units / held) : 0;
  P.hold[id] = round6(held - units);
  P.cost[id] = (P.cost[id] || 0) - costPart;
  if (P.hold[id] * G.prices[id] < 1 || P.hold[id] <= 0) {
    delete P.hold[id];
    delete P.cost[id];
  }
  P.real += proceeds - costPart;
  led(P, 'flow', -(proceeds));
  led(P, 'fees', fee);
  if (proceeds > 0) earn(group, P.j, proceeds);
  js.touch();
  return { gross, fee, proceeds, costPart, forced };
}
const byId = (id) => ALL.find((a) => a.id === id);

function sell(group, jid, assetText, amountText, now = Date.now()) {
  const G = open(group);
  if (!G) return fail('closed');
  const asset = findAsset(assetText);
  if (!asset) return fail('unknown');
  if (asset.kind === 'bond') return bondSell(group, jid, amountText, now);
  const { P } = player(group, G, jid);
  const held = P.hold[asset.id] || 0;
  if (!held) return fail('none', { asset });
  const left = waitLeft(P, now);
  if (left) return fail('wait', { waitMs: left });
  const price = G.prices[asset.id];
  const value = held * price;
  const a = parseAmount(amountText);
  if (!a) return fail('amount');
  let units;
  if (a.all || (a.pct && a.pct >= 100)) units = held;
  else if (a.pct) units = (held * a.pct) / 100;
  else {
    if (a.n > value + 0.5) return fail('over', { value: Math.floor(value), asset });
    units = a.n >= value - 0.5 ? held : a.n / price;
  }
  if (units * price < R.minTrade && units < held) return fail('min', { min: R.minTrade });
  const r = sellUnits(group, G, P, asset.id, units);
  P.last = now;
  js.touch();
  return { ok: true, asset, units, price, ...r, held: P.hold[asset.id] || 0, wallet: walletOf(group, jid) };
}

// ---- bonds (the safe place: they pay a little every day, more in a recession)
function bondBuy(group, jid, amountText, now = Date.now()) {
  const G = open(group);
  if (!G) return fail('closed');
  const { P } = player(group, G, jid);
  const left = waitLeft(P, now);
  if (left) return fail('wait', { waitMs: left });
  const wallet = walletOf(group, jid);
  const room = Math.max(0, R.bondCap - Math.floor(P.bond));
  const a = parseAmount(amountText);
  if (!a) return fail('amount');
  if (room <= 0) return fail('bondcap', { cap: R.bondCap });
  const room2 = Math.floor(room / (1 - R.fee.bond)); // the most you can pay so that what is kept (after the fee) fits
  const amount = a.all ? Math.min(wallet, room2) : a.pct ? Math.floor((wallet * a.pct) / 100) : a.n;
  if (wallet < R.minTrade) return fail('poor', { wallet });
  if (amount > room2 || (a.all && amount < R.minTrade && wallet >= R.minTrade)) return fail('bondcap', { cap: R.bondCap, room });
  if (amount < R.minTrade) return fail('min', { min: R.minTrade });
  if (amount > wallet) return fail('poor', { wallet });
  if (!spend(group, jid, amount)) return fail('poor', { wallet });
  const fee = feeOf('bond', amount);
  P.bond = round6(P.bond + amount - fee);
  P.bondCost += amount;
  led(P, 'fees', fee);
  led(P, 'flow', (amount));
  led(P, 'dep', (amount));
  P.last = now;
  js.touch();
  return { ok: true, bond: true, amount, fee, held: P.bond, rate: bondRate(G), wallet: walletOf(group, jid) };
}
function bondSellAmount(group, G, P, value, forced) {
  const gross = Math.min(value, P.bond);
  const fee = feeOf('bond', gross);
  const proceeds = Math.max(0, Math.floor(gross - fee));
  const part = P.bond > 0 ? P.bondCost * (gross / P.bond) : 0;
  P.bond = round6(P.bond - gross);
  P.bondCost -= part;
  if (P.bond < 1) {
    P.bond = 0;
    P.bondCost = 0;
  }
  P.real += proceeds - part;
  led(P, 'fees', fee);
  led(P, 'flow', -(proceeds));
  if (proceeds > 0) earn(group, P.j, proceeds);
  js.touch();
  return { gross, fee, proceeds, forced };
}
function bondSell(group, jid, amountText, now = Date.now()) {
  const G = open(group);
  if (!G) return fail('closed');
  const { P } = player(group, G, jid);
  if (P.bond < 1) return fail('none', { asset: { id: 'BOND', name: 'Bonds' } });
  const left = waitLeft(P, now);
  if (left) return fail('wait', { waitMs: left });
  const a = parseAmount(amountText);
  if (!a) return fail('amount');
  const value = a.all ? P.bond : a.pct ? (P.bond * a.pct) / 100 : a.n;
  if (value > P.bond + 0.5) return fail('over', { value: Math.floor(P.bond), asset: { id: 'BOND', name: 'Bonds' } });
  const r = bondSellAmount(group, G, P, value >= P.bond - 0.5 ? P.bond : value, false);
  P.last = now;
  js.touch();
  return { ok: true, bond: true, ...r, held: P.bond, wallet: walletOf(group, jid) };
}

// ---- property
function propertyBuy(group, jid, text) {
  const G = open(group);
  if (!G) return fail('closed');
  const id = findProperty(text);
  if (!id) return fail('unknown');
  const { P } = player(group, G, jid);
  if ((P.props[id] || 0) >= R.propertyMax) return fail('max', { max: R.propertyMax, id });
  const price = propValue(G, id);
  const stamp = Math.round(price * R.propertyStamp);
  if (!spend(group, jid, price + stamp)) return fail('poor', { need: price + stamp, wallet: walletOf(group, jid), id });
  P.props[id] = (P.props[id] || 0) + 1;
  P.pcost[id] = (P.pcost[id] || 0) + price + stamp;
  led(P, 'fees', stamp);
  led(P, 'flow', (price + stamp));
  led(P, 'dep', (price + stamp));
  js.touch();
  return { ok: true, id, def: D.PROPERTIES[id], price, stamp, owned: P.props[id], wallet: walletOf(group, jid) };
}
function propertySell(group, jid, text) {
  const G = open(group);
  if (!G) return fail('closed');
  const id = findProperty(text);
  if (!id) return fail('unknown');
  const { P } = player(group, G, jid);
  const n = P.props[id] || 0;
  if (!n) return fail('none', { id });
  return { ok: true, id, def: D.PROPERTIES[id], ...sellOneProperty(group, G, P, id) };
}
function sellOneProperty(group, G, P, id) {
  const n = P.props[id];
  const price = propValue(G, id);
  const stamp = Math.round(price * R.propertyStamp);
  const proceeds = price - stamp;
  const costPart = (P.pcost[id] || 0) / n;
  P.props[id] = n - 1;
  P.pcost[id] = (P.pcost[id] || 0) - costPart;
  if (!P.props[id]) {
    delete P.props[id];
    delete P.pcost[id];
  }
  P.real += proceeds - costPart;
  led(P, 'fees', stamp);
  led(P, 'flow', -(proceeds));
  earn(group, P.j, proceeds);
  js.touch();
  return { price, stamp, proceeds, left: P.props[id] || 0, wallet: walletOf(group, P.j) };
}
const rentPerDay = (G, P) => Object.entries(P.props).reduce((s, [id, n]) => s + n * propValue(G, id) * R.rentPerDay * MOODS[G.mood].rent, 0);
const taxPerDay = (G, P) => Object.entries(P.props).reduce((s, [id, n]) => s + n * propValue(G, id) * R.taxPerDay, 0);

// ---- businesses
const bizProfitDay = (G, id, lv) => D.BUSINESSES[id].cost * R.bizProfitPerDay * (1 + R.bizLevelBonus * (lv - 1)) * MOODS[G.mood].biz;
const bizUpgradeCost = (id, lv) => Math.round(D.BUSINESSES[id].cost * 0.5 * lv);

function businessBuy(group, jid, text) {
  const G = open(group);
  if (!G) return fail('closed');
  const id = findBusiness(text);
  if (!id) return fail('unknown');
  const { P } = player(group, G, jid);
  if (P.biz[id]) return fail('owned', { id });
  const cost = D.BUSINESSES[id].cost;
  if (!spend(group, jid, cost)) return fail('poor', { need: cost, wallet: walletOf(group, jid), id });
  P.biz[id] = { lv: 1, acc: 0, spent: cost };
  led(P, 'flow', (cost));
  led(P, 'dep', (cost));
  js.touch();
  return { ok: true, id, def: D.BUSINESSES[id], cost, profitDay: bizProfitDay(G, id, 1), wallet: walletOf(group, jid) };
}
function businessUpgrade(group, jid, text) {
  const G = open(group);
  if (!G) return fail('closed');
  const id = findBusiness(text);
  if (!id) return fail('unknown');
  const { P } = player(group, G, jid);
  const b = P.biz[id];
  if (!b) return fail('none', { id });
  if (b.lv >= R.bizMaxLevel) return fail('maxlevel', { id });
  const cost = bizUpgradeCost(id, b.lv);
  if (!spend(group, jid, cost)) return fail('poor', { need: cost, wallet: walletOf(group, jid), id });
  b.lv += 1;
  b.spent += cost;
  led(P, 'flow', (cost));
  led(P, 'dep', (cost));
  js.touch();
  return { ok: true, id, def: D.BUSINESSES[id], cost, level: b.lv, profitDay: bizProfitDay(G, id, b.lv), wallet: walletOf(group, jid) };
}
function businessSell(group, jid, text) {
  const G = open(group);
  if (!G) return fail('closed');
  const id = findBusiness(text);
  if (!id) return fail('unknown');
  const { P } = player(group, G, jid);
  const b = P.biz[id];
  if (!b) return fail('none', { id });
  const refund = Math.floor(b.spent * R.bizResale);
  const profit = Math.floor(b.acc * (1 - R.bizTax));
  delete P.biz[id];
  led(P, 'flow', -(refund));
  led(P, 'inc', (profit));
  P.real += refund - b.spent;
  earn(group, jid, refund + profit);
  js.touch();
  return { ok: true, id, def: D.BUSINESSES[id], refund, profit, wallet: walletOf(group, jid) };
}

// rent and business profit wait for you (up to 3 and 2 days) until you collect them
function collect(group, jid, what = 'all') {
  const G = open(group);
  if (!G) return fail('closed');
  const { P } = player(group, G, jid);
  const out = { ok: true, rent: null, biz: null, total: 0 };
  if (what === 'all' || what === 'property') {
    const gross = Math.floor(P.rent);
    const tax = Math.min(gross, Math.floor(P.tax));
    if (gross > 0) out.rent = { gross, tax, net: gross - tax };
    P.rent = 0;
    P.tax = 0;
  }
  if (what === 'all' || what === 'business') {
    const list = [];
    for (const [id, b] of Object.entries(P.biz)) {
      const gross = Math.floor(b.acc);
      if (gross < 1) continue;
      const tax = Math.round(gross * R.bizTax);
      list.push({ id, def: D.BUSINESSES[id], gross, tax, net: gross - tax });
      b.acc -= gross;
    }
    if (list.length) out.biz = { list, gross: list.reduce((s, x) => s + x.gross, 0), tax: list.reduce((s, x) => s + x.tax, 0), net: list.reduce((s, x) => s + x.net, 0) };
  }
  if (what === 'all' || what === 'dividends') {
    const div = Math.floor(P.div || 0);
    if (div > 0) {
      out.div = { net: div };
      P.div -= div;
    }
  }
  out.total = (out.rent?.net || 0) + (out.biz?.net || 0) + (out.div?.net || 0);
  led(P, 'tax', (out.rent?.tax || 0) + (out.biz?.tax || 0));
  if (out.total > 0) {
    earn(group, jid, out.total);
    led(P, 'inc', (out.total));
  }
  js.touch();
  out.wallet = walletOf(group, jid);
  return out;
}

// ---- price alerts: "alert TECH above 300" pings you in the group when the price gets there (once)
function alertSet(group, jid, assetText, dir, priceText) {
  const G = open(group);
  if (!G) return fail('closed');
  const asset = findAsset(assetText);
  if (!asset || asset.kind === 'bond') return fail('unknown');
  const target = Number(String(priceText).replace(/,/g, ''));
  if (!['above', 'below'].includes(dir) || !(target > 0)) return fail('amount');
  const { P } = player(group, G, jid);
  P.alerts = P.alerts || [];
  const price = G.prices[asset.id];
  if (dir === 'above' && price >= target) return fail('already', { price });
  if (dir === 'below' && price <= target) return fail('already', { price });
  if (P.alerts.length >= 5) return fail('alertmax', { max: 5 });
  P.alerts.push({ id: asset.id, dir, price: target });
  js.touch();
  return { ok: true, asset, dir, target, price };
}
function alertList(group, jid) {
  const G = open(group);
  if (!G) return fail('closed');
  const P = G.players[economy.keyOf(jid)];
  return { ok: true, alerts: (P?.alerts || []).map((a) => ({ ...a, now: G.prices[a.id] })) };
}
function alertClear(group, jid) {
  const G = open(group);
  const P = G?.players[economy.keyOf(jid)];
  const n = P?.alerts?.length || 0;
  if (P) P.alerts = [];
  js.touch();
  return n;
}

// ---- loans
function creditLimit(group, G, key, P) {
  const w = worthOf(group, G, key, P);
  return clamp(Math.floor(w.gross * R.loanShare), R.loanMin, R.loanMax);
}
function loanInfo(group, jid, now = Date.now()) {
  const G = open(group);
  if (!G) return fail('closed');
  const { key, P } = player(group, G, jid);
  const L = P.loan;
  return {
    ok: true, rate: loanRate(G), fee: R.loanFee, days: R.loanDays,
    limit: creditLimit(group, G, key, P),
    debt: L ? Math.ceil(L.debt) : 0, due: L ? L.due : null, overdue: !!L?.overdue, since: L ? L.since : null,
    wallet: walletOf(group, jid), now,
  };
}
function borrow(group, jid, amountText, now = Date.now()) {
  const G = open(group);
  if (!G) return fail('closed');
  const { key, P } = player(group, G, jid);
  if (P.loan) return fail('has', { debt: Math.ceil(P.loan.debt) });
  const limit = creditLimit(group, G, key, P);
  const a = parseAmount(amountText);
  if (!a) return fail('amount');
  const amount = a.all ? limit : a.pct ? Math.floor((limit * a.pct) / 100) : a.n;
  if (amount < 100) return fail('min', { min: 100 });
  if (amount > limit) return fail('limit', { limit });
  const fee = Math.round(amount * R.loanFee);
  P.loan = { debt: amount, principal: amount, since: now, due: now + R.loanDays * DAY, overdue: false };
  led(P, 'cost', (fee));
  led(P, 'fees', fee);
  earn(group, jid, amount - fee);
  js.touch();
  return { ok: true, amount, fee, got: amount - fee, rate: loanRate(G), due: P.loan.due, wallet: walletOf(group, jid) };
}
// pays n coins of the debt from the wallet. Returns what was paid
function payDebt(group, P, n) {
  if (!P.loan || n <= 0) return 0;
  const pay = Math.min(Math.ceil(n), Math.ceil(P.loan.debt), walletOf(group, P.j));
  if (pay <= 0 || !spend(group, P.j, pay)) return 0;
  P.loan.debt -= pay;
  if (P.loan.debt < 0.5) P.loan = null;
  js.touch();
  return pay;
}
function repay(group, jid, amountText) {
  const G = open(group);
  if (!G) return fail('closed');
  const { P } = player(group, G, jid);
  if (!P.loan) return fail('noloan');
  const a = parseAmount(amountText || 'all');
  if (!a) return fail('amount');
  const debt = Math.ceil(P.loan.debt);
  const want = a.all ? debt : a.pct ? Math.ceil((debt * a.pct) / 100) : a.n;
  const wallet = walletOf(group, jid);
  if (wallet < 1) return fail('poor', { wallet, debt });
  const paid = payDebt(group, P, Math.min(want, debt));
  if (!paid) return fail('poor', { wallet, debt });
  return { ok: true, paid, left: P.loan ? Math.ceil(P.loan.debt) : 0, wallet: walletOf(group, jid) };
}

// raises coins for a loan: the wallet, the bank, then investments that are sold (biggest first), bonds, last property.
// opts.cash = false: only investments (a margin call never takes the wallet). Returns the coins that went to the debt.
function raise(group, G, key, P, need, opts = {}) {
  let paid = 0;
  const still = () => P.loan && need - paid > 0.5;
  if (opts.cash !== false && still()) paid += payDebt(group, P, need - paid);
  if (opts.cash !== false && still()) {
    const bank = economy.accountIn(group, key, P.j).bank || 0;
    if (bank > 0) economy.runIn(group, () => economy.withdraw(P.j, Math.min(bank, Math.ceil(need - paid))));
    paid += payDebt(group, P, need - paid);
  }
  const ids = Object.keys(P.hold).sort((a, b) => P.hold[b] * G.prices[b] - P.hold[a] * G.prices[a]);
  for (const id of ids) {
    if (!still()) break;
    const asset = byId(id);
    const netValue = P.hold[id] * G.prices[id] * (1 - R.fee[asset.kind]);
    const units = netValue <= need - paid ? P.hold[id] : P.hold[id] * ((need - paid) / netValue);
    const sold = sellUnits(group, G, P, id, units, true);
    paid += payDebt(group, P, Math.min(need - paid, sold.proceeds));
  }
  if (still() && P.bond >= 1) {
    const netValue = P.bond * (1 - R.fee.bond);
    const sold = bondSellAmount(group, G, P, netValue <= need - paid ? P.bond : P.bond * ((need - paid) / netValue), true);
    paid += payDebt(group, P, Math.min(need - paid, sold.proceeds));
  }
  for (const id of Object.keys(P.props)) {
    while (still() && P.props[id]) {
      const sold = sellOneProperty(group, G, P, id);
      paid += payDebt(group, P, Math.min(need - paid, sold.proceeds));
    }
  }
  return paid;
}

// at every update: a loan that is due is collected, a loan that is too big for what you own sells your investments
function settleLoan(group, G, key, P, t, events) {
  const L = P.loan;
  if (!L) return;
  if (L.overdue) {
    const paid = payDebt(group, P, walletOf(group, P.j)); // everything in the wallet goes to the debt until it is gone
    if (paid && !P.loan) events.push({ type: 'cleared', jid: P.j, amount: paid });
    return;
  }
  if (t >= L.due) {
    const owed = Math.ceil(L.debt);
    const paid = raise(group, G, key, P, owed);
    if (P.loan) {
      P.loan.overdue = true;
      events.push({ type: 'overdue', jid: P.j, paid, left: Math.ceil(P.loan.debt) });
    } else {
      events.push({ type: 'collected', jid: P.j, paid });
    }
    return;
  }
  const w = worthOf(group, G, key, P);
  if (w.invested > 0 && L.debt > R.margin * w.gross) {
    const need = Math.min(L.debt, Math.max(1, 2 * L.debt - w.gross));
    const paid = raise(group, G, key, P, need, { cash: false });
    if (paid > 0) events.push({ type: 'margin', jid: P.j, paid, left: P.loan ? Math.ceil(P.loan.debt) : 0 });
  }
}

// what one person earns or owes during one price update
function accrue(group, G, key, P) {
  if (P.bond > 0) P.bond = round6(P.bond * (1 + bondRate(G) / 100 / PER_DAY));
  // dividends of the stocks you hold wait for you with the rent and profit
  const divDay = Object.entries(P.hold).reduce((sum, [id, u]) => sum + (D.DIVIDENDS[id] ? (u * G.prices[id] * D.DIVIDENDS[id]) / 100 : 0), 0);
  if (divDay > 0) P.div = Math.min((P.div || 0) + divDay / PER_DAY, divDay * R.rentStoreDays);
  const rentDay = rentPerDay(G, P);
  if (rentDay > 0) {
    P.rent = Math.min(P.rent + rentDay / PER_DAY, rentDay * R.rentStoreDays);
    const taxDay = taxPerDay(G, P);
    P.tax = Math.min(P.tax + taxDay / PER_DAY, taxDay * R.rentStoreDays);
  }
  for (const [id, b] of Object.entries(P.biz)) {
    const day = bizProfitDay(G, id, b.lv);
    b.acc = Math.min(b.acc + day / PER_DAY, day * R.bizStoreDays);
  }
  if (P.loan) {
    const add = P.loan.debt * (loanRate(G) / 100 / PER_DAY);
    P.loan.debt += add;
    led(P, 'cost', add);
    led(P, 'interest', add);
  }
}


// the owner moves (or copies) the investments of people from one group to another. The destination market is opened if needed.
// Holdings are bought at the destination's prices for the same VALUE (the person keeps what they were worth, not the units).
function transferPlayers(from, to, who = null, mode = 'move', now = Date.now()) {
  const F = groupState(from);
  if (!F) return 0;
  if (!groupState(to)) js.data.groups[to] = fresh(now);
  const T = groupState(to);
  let n = 0;
  for (const [key, P] of Object.entries(F.players)) {
    if (who && key !== who) continue;
    const D2 = T.players[key] || (T.players[key] = { j: P.j, hold: {}, cost: {}, bond: 0, bondCost: 0, props: {}, pcost: {}, rent: 0, tax: 0, biz: {}, loan: null, last: 0, real: 0, crown: null, crowns: 0, w: null });
    for (const [id, units] of Object.entries(P.hold)) {
      const value = units * F.prices[id];
      D2.hold[id] = round6((D2.hold[id] || 0) + value / T.prices[id]);
      D2.cost[id] = (D2.cost[id] || 0) + (P.cost[id] || value);
    }
    D2.bond += P.bond;
    D2.bondCost += P.bondCost;
    for (const [id, c] of Object.entries(P.props)) {
      D2.props[id] = (D2.props[id] || 0) + c;
      D2.pcost[id] = (D2.pcost[id] || 0) + (P.pcost[id] || 0);
    }
    for (const [id, b] of Object.entries(P.biz)) if (!D2.biz[id] || D2.biz[id].lv < b.lv) D2.biz[id] = { ...b };
    D2.rent += P.rent;
    D2.tax += P.tax;
    D2.real += P.real;
    if (!D2.loan && P.loan) D2.loan = { ...P.loan };
    D2.w = null;
    D2.life = null;
    ledgerOf(T, D2);
    if (mode === 'move') delete F.players[key];
    n += 1;
  }
  js.touch();
  return n;
}

// ---- the weekly prize
function settleWeek(group, G, t, events) {
  const ranked = Object.entries(G.players)
    .map(([key, P]) => ({ key, P, ...weekScore(G, P) }))
    .filter((e) => e.eligible && e.profit > 0)
    .sort((a, b) => b.pct - a.pct)
    .slice(0, R.weekPrizes.length);
  if (ranked.length) {
    for (const P of Object.values(G.players)) P.crown = null;
    const winners = ranked.map((e, i) => {
      const prize = R.weekPrizes[i];
      earn(group, e.P.j, prize);
      return { jid: e.P.j, pct: e.pct, profit: Math.round(e.profit), prize };
    });
    ranked[0].P.crown = G.week;
    ranked[0].P.crowns += 1;
    G.hall.push({ week: G.week, jid: ranked[0].P.j, pct: ranked[0].pct, profit: Math.round(ranked[0].profit) });
    if (G.hall.length > 12) G.hall.shift();
    events.push({ type: 'week', week: G.week, winners });
  }
  G.week = weekId(t);
  for (const P of Object.values(G.players)) P.w = { wk: G.week, open: investedValue(G, P), flow: 0, dep: 0, inc: 0, cost: 0 };
}

// ---- time
function stepOnce(group, G, t, ev) {
  if (t >= G.until) ev.news = shiftMood(G, t);
  stepPrices(G);
  for (const [key, P] of Object.entries(G.players)) {
    for (const a of P.alerts || []) {
      const price = G.prices[a.id];
      if (a.dir === 'above' ? price >= a.price : price <= a.price) ev.notes.push({ type: 'alert', jid: P.j, asset: a.id, price, dir: a.dir, target: a.price });
    }
    if (P.alerts) P.alerts = P.alerts.filter((a) => !(a.dir === 'above' ? G.prices[a.id] >= a.price : G.prices[a.id] <= a.price));
    ledgerOf(G, P);
    if (!P.life) P.life = { open: investedValue(G, P), flow: 0, dep: 0, inc: 0, cost: 0, fees: 0, tax: 0, interest: 0, since: Date.now() }; // markets saved before profit tracking
    accrue(group, G, key, P);
    settleLoan(group, G, key, P, t, ev.notes);
  }
  if (weekId(t) !== G.week) settleWeek(group, G, t, ev.notes);
}

// plays the price updates that are due. A bot that was off catches up (at most 2 days). Returns { news, notes }
function advance(group, now = Date.now(), maxSteps = R.maxCatchUp) {
  const G = groupState(group);
  const ev = { news: null, notes: [] };
  if (!G || !G.on) return ev;
  let steps = Math.floor((now - G.ticked) / R.tickMs);
  if (steps <= 0) return ev;
  if (steps > R.maxCatchUp) {
    G.ticked += (steps - R.maxCatchUp) * R.tickMs;
    steps = R.maxCatchUp;
  }
  // The regular background scheduler limits work per pass; direct calls keep the full catch-up behavior.
  steps = Math.min(steps, Math.max(1, Number(maxSteps) || R.maxCatchUp));
  for (let i = 0; i < steps; i++) {
    const t = G.ticked + R.tickMs;
    stepOnce(group, G, t, ev);
    G.ticked = t;
  }
  js.touch();
  return ev;
}

// the owner can make the mood change right now
function forceMood(group, mood, now = Date.now()) {
  const G = open(group);
  if (!G || !MOODS[mood]) return null;
  const news = shiftMood(G, now, mood);
  js.touch();
  return news;
}


// ---- the outlook: is this one likely to give profit? An honest estimate from what moves the price right now
// (the mood, the news push and the pull back to the normal price), over the time the current mood has left, minus the
// fees of buying and selling. It is NOT a promise: prices also have random swings.
const SIGNALS = {
  strong: { icon: '🟢🟢', label: 'Strong buy', verdict: 'Likely profit' },
  buy: { icon: '🟢', label: 'Buy', verdict: 'Probably profit' },
  neutral: { icon: '⚪', label: 'Neutral', verdict: 'Not worth a quick trade (fees would eat the gain)' },
  weak: { icon: '🔴', label: 'Weak', verdict: 'Probably a loss' },
  avoid: { icon: '🔴🔴', label: 'Avoid', verdict: 'Likely loss' },
};
function outlook(group, id, now = Date.now()) {
  const G = groupState(group);
  const a = byId(id);
  if (!G || !a || a.kind === 'index') return null;
  const hours = clamp((G.until - now) / HOUR, 0.5, 6);
  const ticks = hours * (HOUR / R.tickMs);
  const drift = a.fx[G.mood] + (G.tilt[a.sector] || 0); // % per update
  const pull = -a.k * Math.log(G.prices[id] / a.base) * 100; // % per update
  const div = ((D.DIVIDENDS[id] || 0) / 24) * hours; // dividends over the same time (%)
  const gross = (drift + pull) * ticks + div;
  const fees = R.fee[a.kind] * 2 * 100; // buying and selling
  const net = gross - fees;
  const swing = a.vol * Math.sqrt(ticks); // the usual random swing over this time (%)
  const key = net >= 3 ? 'strong' : net >= 0.8 ? 'buy' : gross > -0.8 ? 'neutral' : gross > -3 ? 'weak' : 'avoid';
  const reason = drift > 0.05
    ? `${MOODS[G.mood].name} lifts ${a.sector === 'crypto' ? 'coins' : a.sector}`
    : drift < -0.05 ? `${MOODS[G.mood].name} pushes ${a.sector === 'crypto' ? 'coins' : a.sector} down` : pull > 0.02 ? 'cheap against its normal price' : pull < -0.02 ? 'dear against its normal price' : 'nothing moves it now';
  return { id, key, ...SIGNALS[key], net, gross, fees, swing, hours, reason, chance: clamp(0.5 + net / (2.5 * Math.max(swing, 0.1)), 0.05, 0.95) };
}

function picks(group) {
  const G = groupState(group);
  if (!G) return [];
  return D.ASSETS.map((a) => ({ asset: a, o: outlook(group, a.id) })).sort((x, y) => y.o.net - x.o.net);
}

// ---- what the commands show
function quotes(group) {
  const G = groupState(group);
  if (!G) return [];
  return D.ASSETS.map((a) => ({ asset: a, price: G.prices[a.id], change: change24(G, a.id), hist: G.hist[a.id], outlook: outlook(group, a.id) }));
}

function status(group, now = Date.now()) {
  const G = groupState(group);
  if (!G) return null;
  return {
    on: G.on, news: G.news, mood: G.mood, def: MOODS[G.mood], since: G.since, until: G.until, inflation: G.inflation,
    headline: G.headline.t, shopMult: shopMult(G), payMult: payMult(G), bondRate: bondRate(G), loanRate: loanRate(G),
    propertyIndex: G.prices.PROP, propertyChange: change24(G, 'PROP'), lastNews: G.lastNews, hall: G.hall, nextUpdate: G.ticked + R.tickMs, now,
    players: Object.keys(G.players).length,
  };
}

function portfolio(group, jid, now = Date.now()) {
  const G = open(group);
  if (!G) return fail('closed');
  const key = economy.keyOf(jid);
  const P = G.players[key];
  if (!P) {
    const acct = economy.accountIn(group, key, jid);
    return { ok: true, empty: true, wallet: acct.coins, bank: acct.bank || 0, crown: null };
  }
  const w = worthOf(group, G, key, P);
  const positions = Object.entries(P.hold).map(([id, units]) => {
    const asset = byId(id);
    const value = units * G.prices[id];
    const cost = P.cost[id] || 0;
    return { asset, units, price: G.prices[id], value, cost, outlook: outlook(group, id), pl: value - cost, plPct: cost > 0 ? ((value - cost) / cost) * 100 : 0, change: change24(G, id) };
  }).sort((a, b) => b.value - a.value);
  const props = Object.entries(P.props).map(([id, n]) => ({ id, def: D.PROPERTIES[id], n, value: n * propValue(G, id), cost: P.pcost[id] || 0 }));
  const biz = Object.entries(P.biz).map(([id, b]) => ({ id, def: D.BUSINESSES[id], level: b.lv, waiting: Math.floor(b.acc), profitDay: bizProfitDay(G, id, b.lv) }));
  const score = weekScore(G, P);
  const board = weeklyBoard(group, 1000);
  const at = board.findIndex((r) => r.key === key);
  const L = P.loan;
  return {
    ok: true, key, jid: P.j, worth: w, positions, bond: P.bond, bondEarned: P.bond - P.bondCost, props, biz,
    rent: Math.floor(P.rent), tax: Math.floor(P.tax), div: Math.floor(P.div || 0), rentDay: rentPerDay(G, P), taxDay: taxPerDay(G, P),
    loan: L ? { debt: Math.ceil(L.debt), due: L.due, overdue: L.overdue } : null,
    realized: P.real, week: { ...score, rank: at >= 0 ? at + 1 : null, of: board.length },
    crown: P.crown, crowns: P.crowns, invested: w.invested - 0, now,
  };
}

// "Am I making profit?" in plain numbers: overall, this week, the last 24 hours and where it comes from
function profit(group, jid, now = Date.now()) {
  const G = open(group);
  if (!G) return fail('closed');
  const key = economy.keyOf(jid);
  const P = G.players[key];
  if (!P) return { ok: true, empty: true };
  ledgerOf(G, P);
  const L = P.life || (P.life = { open: 0, flow: 0, dep: 0, inc: 0, cost: 0, fees: 0, tax: 0, interest: 0, since: now });
  const worth = investedValue(G, P);
  const total = worth - L.open - L.flow + L.inc - L.cost;
  const base = Math.max(1000, L.open + L.dep);
  const day = Object.entries(P.hold).reduce((sum, [id, u]) => sum + u * (G.prices[id] - G.hist[id][0]), 0);
  const wk = weekScore(G, P);
  return {
    ok: true, since: L.since, now,
    overall: { profit: total, pct: (total / base) * 100 },
    week: { profit: wk.profit, pct: wk.pct },
    day,
    parts: { putIn: L.flow + L.open, worth, waiting: pendingIncome(P), income: L.inc, loanCost: L.cost, fees: L.fees - 0, tax: L.tax, interest: L.interest },
    holding: worth > 1,
  };
}

// the ranking of the week (only people who invested enough), best % first
function weeklyBoard(group, limit = 10) {
  const G = groupState(group);
  if (!G) return [];
  return Object.entries(G.players)
    .map(([key, P]) => ({ key, jid: P.j, crown: P.crown, ...weekScore(G, P) }))
    .filter((e) => e.eligible)
    .sort((a, b) => b.pct - a.pct)
    .slice(0, limit);
}
// the richest by everything they own (minus debt)
function wealthBoard(group, limit = 10) {
  const G = groupState(group);
  if (!G) return [];
  return Object.entries(G.players)
    .map(([key, P]) => ({ key, jid: P.j, crown: P.crown, total: worthOf(group, G, key, P).total }))
    .sort((a, b) => b.total - a.total)
    .slice(0, limit);
}

// ---- the hooks the coin module uses (shop prices, job pay, debt)
economy.setHooks({
  shop: (group) => {
    const G = groupState(group);
    return G && G.on ? shopMult(G) : 1;
  },
  pay: (group) => {
    const G = groupState(group);
    return G && G.on ? payMult(G) : 1;
  },
  debt: (group, key) => groupState(group)?.players[key]?.loan?.debt || 0,
});

// ---- one pass for all groups: called every few seconds by the scheduler; it only does something when an update is due.
// post(group, content) sends a message. Returns the number of groups updated.
async function tick(post, now = Date.now()) {
  let n = 0;
  for (const group of Object.keys(js.data.groups)) {
    const G = js.data.groups[group];
    if (!G.on) continue;
    G.news = false; // Economy news broadcasts are retired; personal price alerts remain available.
    G.pending = null;
    let ev = { news: null, notes: [] };
    if (now - G.ticked >= R.tickMs) {
      try {
        ev = advance(group, now, 16); // spread recovery work across scheduler passes instead of blocking the event loop
      } catch (err) {
        console.error(`Market update failed for ${group}: ${err.message}`);
        continue;
      }
      n += 1;
      // news that could not be sent (the connection was down) waits and is tried again at the next pass
      G.pending = null;
      for (const note of ev.notes) {
        if (!G.news && note.type !== 'alert') continue; // price alerts are personal: they are sent even when the news is muted
        (G.outbox || (G.outbox = [])).push(note);
      }
      if (G.outbox && G.outbox.length > 30) G.outbox = G.outbox.slice(-30);
      js.touch();
    }
    try {
      G.pending = null;
      while (G.outbox && G.outbox.length) {
        const msg = noteMessage(group, G.outbox[0]);
        if (msg) await post(group, msg);
        G.outbox.shift();
        js.touch();
      }
    } catch (err) {
      console.log(`Market alert could not be sent to ${group} (will retry): ${err.message}`);
    }
  }
  return n;
}

// ---- texts that are sent without a command (news and notices). Same style as the command replies.
const sign = (n, d = 1) => `${n >= 0 ? '+' : '−'}${Math.abs(n).toFixed(d)}%`;
const arrow = (n) => (n >= 0.05 ? '▲' : n <= -0.05 ? '▼' : '▬');
const prefixNow = () => {
  try {
    return require('../whatsapp/store').effectivePrefix();
  } catch (err) {
    return '.';
  }
};

// ---- who owns what (for the news: the owners are tagged)
function holdersOf(G, id) {
  const out = [];
  for (const P of Object.values(G.players)) {
    if (!P.j) continue;
    if (id === 'PROP' ? Object.keys(P.props).length : id === 'BIZ' ? Object.keys(P.biz).length : (P.hold[id] || 0) * (G.prices[id] || 0) >= 1) out.push(P.j);
  }
  return out;
}
const tagOf = (jid) => `@${String(jid).split('@')[0].split(':')[0]}`;
// "👥 @a @b @c +2 more" (everybody listed is tagged, but a line never tags more than max people)
function ownersLine(list, max = 8) {
  if (!list.length) return '';
  const shown = list.slice(0, max);
  return ` 👥 ${shown.map(tagOf).join(' ')}${list.length > max ? ` +${list.length - max} more` : ''}`;
}
// how the prices moved since the last news that was sent
function movesSince(G) {
  const base = G.snap || G.shift || G.prices;
  return [...D.ASSETS.filter((a) => a.kind !== 'stock'), D.PROPERTY_INDEX].map((a) => ({ id: a.id, name: a.name, kind: a.kind, pct: (G.prices[a.id] / (base[a.id] || G.prices[a.id]) - 1) * 100 }));
}

function newsMessage(group, prefix = prefixNow()) {
  const G = groupState(group);
  const s = status(group);
  const n = G.lastNews;
  const mood = MOODS[G.mood];
  const lines = [`📰 *Market News*`, ``, `${mood.icon} *Mood: ${mood.name}*`, `_"${G.headline.t}"_`, ``];
  const mentions = new Set();
  const own = (m) => {
    const who = holdersOf(G, m.id);
    who.slice(0, 8).forEach((j) => mentions.add(j));
    return `${m.pct >= 0 ? '▲' : '▼'} *${m.id}* ${sign(m.pct)}${ownersLine(who)}`;
  };
  if (n && (n.moves.up.length || n.moves.down.length)) {
    lines.push(`*Since the last news*`);
    for (const m of [...n.moves.up, ...n.moves.down]) lines.push(own(m));
    lines.push('');
  }
  // who is hit by this headline: the owners of the stocks of the pushed sectors (and of property, when the mood moves rent)
  const hit = Object.entries(G.tilt || {}).filter(([, v]) => v).map(([sec, v]) => ({ sec, v, ids: D.ASSETS.filter((a) => a.kind !== 'stock' && a.sector === sec).map((a) => a.id) })).filter((h) => h.ids.length);
  const hitLines = hit.map((h) => ({ ...h, who: [...new Set(h.ids.flatMap((id) => holdersOf(G, id)))] })).filter((h) => h.who.length);
  if (hitLines.length) {
    lines.push(`*This news pushes*`);
    for (const h of hitLines) {
      h.who.slice(0, 8).forEach((j) => mentions.add(j));
      lines.push(`${h.v > 0 ? '⬆️' : '⬇️'} *${h.sec}* (${h.ids.join(', ')})${ownersLine(h.who)}`);
    }
    lines.push('');
  }
  const propWho = holdersOf(G, 'PROP');
  const bizWho = holdersOf(G, 'BIZ');
  if (propWho.length) {
    propWho.slice(0, 8).forEach((j) => mentions.add(j));
    lines.push(`🏘️ *Rent ×${mood.rent}* for property owners${ownersLine(propWho)}`);
  }
  if (bizWho.length) {
    bizWho.slice(0, 8).forEach((j) => mentions.add(j));
    lines.push(`🏭 *Business profit ×${mood.biz}* for owners${ownersLine(bizWho)}`);
  }
  if (propWho.length || bizWho.length) lines.push('');
  lines.push(`💡 _${mood.tip}_`, '');
  lines.push(`*Inflation:* ${s.inflation}% a year`);
  lines.push(`*Bonds pay:* ${s.bondRate}% a day • *Loans cost:* ${s.loanRate.toFixed(1)}% a day`);
  lines.push(`*Shop prices:* ${sign((s.shopMult - 1) * 100, 0)} • *Job pay:* ${sign((s.payMult - 1) * 100, 0)}`);
  lines.push('', `_Prices update every 30 minutes._`, `▸ \`${prefix}market\` – prices`, `▸ \`${prefix}portfolio\` – what you own`);
  return { text: lines.join('\n'), mentions: [...mentions] };
}


// the update that is sent every 30 minutes (when the mood changes, newsMessage is sent instead): what moved, who owns it, what to do
function digestMessage(group, prefix = prefixNow()) {
  const G = groupState(group);
  const mood = MOODS[G.mood];
  const rows = movesSince(G);
  const stocks = rows.filter((r) => r.id !== 'PROP');
  const up = stocks.filter((r) => r.pct >= 0.3).sort((a, b) => b.pct - a.pct).slice(0, 4);
  const down = stocks.filter((r) => r.pct <= -0.3).sort((a, b) => a.pct - b.pct).slice(0, 4);
  const prop = rows.find((r) => r.id === 'PROP');
  const mentions = new Set();
  const lineOf = (m) => {
    const who = holdersOf(G, m.id);
    who.slice(0, 8).forEach((j) => mentions.add(j));
    return `${m.pct >= 0 ? '▲' : '▼'} *${m.id}* ${sign(m.pct)}${ownersLine(who)}`;
  };
  const best = picks(group).filter((p) => p.o.net >= 0.8).slice(0, 3);
  const worst = picks(group).filter((p) => p.o.net <= -0.8).slice(-2).reverse();
  const lines = [`📊 *Market Update* _(every 30 minutes)_`, '', `${mood.icon} *Mood: ${mood.name}* • _\"${G.headline.t}\"_`, ''];
  if (up.length || down.length) {
    lines.push(`*Since the last update*`);
    for (const m of up) lines.push(lineOf(m));
    for (const m of down) lines.push(lineOf(m));
  } else lines.push('_A quiet half hour: no big moves._');
  if (prop && Math.abs(prop.pct) >= 0.05) {
    const who = holdersOf(G, 'PROP');
    who.slice(0, 8).forEach((j) => mentions.add(j));
    lines.push('', `🏘️ *Property* ${sign(prop.pct, 2)} ${prop.pct >= 0 ? '(rent and value up)' : '(value down)'}${ownersLine(who)}`);
  }
  lines.push('');
  if (best.length) lines.push(`🟢 *Looks good now:* ${best.map((p) => p.asset.id).join(', ')}`);
  if (worst.length) lines.push(`🔴 *Avoid for now:* ${worst.map((p) => p.asset.id).join(', ')}`);
  if (!best.length && !worst.length) lines.push(`⚪ _Nothing stands out. Bonds are the calm choice._`);
  lines.push('', `▸ \`${prefix}picks\` • \`${prefix}market\` • \`${prefix}portfolio\``);
  return { text: lines.join('\n'), mentions: [...mentions] };
}

function noteMessage(group, note, prefix = prefixNow()) {
  const tag = (jid) => `@${String(jid).split('@')[0].split(':')[0]}`;
  if (note.type === 'alert') {
    return { text: `🔔 *Price alert*\n${tag(note.jid)} ${note.asset} is now *${note.price.toFixed(2)}* (${note.dir} your alert of ${note.target.toFixed(2)}).`, mentions: [note.jid] };
  }
  if (note.type === 'margin') {
    return { text: `⚠️ *Margin call*\n${tag(note.jid)}'s debt grew too big for what they own. Investments were sold and *${fmt(note.paid)} coins* went to the loan.${note.left ? ` Still owed: ${fmt(note.left)}.` : ''}`, mentions: [note.jid] };
  }
  if (note.type === 'collected') {
    return { text: `🏦 *Loan collected*\n${tag(note.jid)}'s loan was due. *${fmt(note.paid)} coins* were taken from their coins and investments.`, mentions: [note.jid] };
  }
  if (note.type === 'overdue') {
    return { text: `🚨 *Loan overdue*\n${tag(note.jid)} could not pay the loan on time. *${fmt(note.left)} coins* are still owed, and every coin they earn now goes to the bank until it is paid.`, mentions: [note.jid] };
  }
  if (note.type === 'week') {
    const medals = ['🥇', '🥈', '🥉'];
    const lines = note.winners.map((w, i) => `${medals[i]} ${tag(w.jid)} ${sign(w.pct)} (${w.profit >= 0 ? '+' : '−'}${fmt(Math.abs(w.profit))} coins) – prize *${fmt(w.prize)} coins*${i === 0 ? ' + the 👑 title' : ''}`);
    return { text: `🏆 *Investor of the Week*\n\n${lines.join('\n')}\n\n_A new week starts now. Best profit in % wins._\n▸ \`${prefix}economy top\` – the ranking`, mentions: note.winners.map((w) => w.jid) };
  }
  return null;
}

module.exports = {
  RULES: R, MOODS, STOCKS: D.STOCKS, COINS: D.COINS, PROPERTIES: D.PROPERTIES, BUSINESSES: D.BUSINESSES,
  setRandom, parseAmount, findAsset, findProperty, findBusiness, weekId,
  isOn, allGroups, enable, disable, transferPlayers, setNews, wipe, forceMood, advance, tick, state: groupState,
  invest, sell, bondBuy, bondSell, propertyBuy, propertySell, businessBuy, businessUpgrade, businessSell, collect,
  alertSet, alertList, alertClear, loanInfo, borrow, repay, quotes, status, portfolio, weeklyBoard, wealthBoard, worthOf,
  profit, newsMessage, digestMessage, noteMessage, outlook, picks, bizUpgradeCost, sign, arrow, change24,
  propValue: (group, id) => propValue(groupState(group), id),
  bizProfitDay: (group, id, lv) => bizProfitDay(groupState(group), id, lv),
};
