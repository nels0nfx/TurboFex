// Persistent Owner/God configuration. Group overrides are intentionally separate from global defaults.
const jsonstore = require('./jsonstore');
const db = jsonstore.open('godsettings', {
  defaults: { presidentSalary: 1000000, presidentSalaryInterval: 10 * 60000, presidentTerm: 2 * 3600000, robChance: 40, robCap: 5000, arrestMultiplier: 1 },
  groups: {}, ownerWallet: 0, audit: [], selectedGroup: null, electionsPaused: {}
});
function ensure() {
  if (!db.data.defaults) db.data.defaults = {};
  db.data.defaults = Object.assign({ presidentSalary: 1000000, presidentSalaryInterval: 10 * 60000, presidentTerm: 2 * 3600000, robChance: 40, robCap: 5000, arrestMultiplier: 1 }, db.data.defaults);
  if (!db.data.groups) db.data.groups = {};
  if (!Array.isArray(db.data.audit)) db.data.audit = [];
  if (!Number.isSafeInteger(db.data.ownerWallet) || db.data.ownerWallet < 0) db.data.ownerWallet = 0;
  if (!db.data.electionsPaused) db.data.electionsPaused = {};
  return db.data;
}
function defaults() { return { ...ensure().defaults }; }
function setDefault(key, value) { const d = ensure().defaults; if (!['presidentSalary','presidentSalaryInterval','presidentTerm','robChance','robCap','arrestMultiplier'].includes(key)) return false; d[key] = value; db.touch(); return true; }
function groupConfig(group) { const d=ensure(); return d.groups[String(group)] || (d.groups[String(group)] = { overrides: {} }); }
function hasOverride(group, key) { return !!groupConfig(group).overrides?.[key]; }
function setOverride(group, key, enabled=true) { const c=groupConfig(group); if (!c.overrides) c.overrides={}; if(enabled) c.overrides[key]=true; else delete c.overrides[key]; db.touch(); }
function selectedGroup() { return ensure().selectedGroup || null; }
function selectGroup(group) { ensure().selectedGroup = group || null; db.touch(); }
function wallet() { return ensure().ownerWallet; }
function walletAdd(amount) { const n=Number(amount); if(!Number.isSafeInteger(n)||n<1||n>Number.MAX_SAFE_INTEGER- wallet()) return false; ensure().ownerWallet += n; db.touch(); return wallet(); }
function walletTake(amount) { const n=Number(amount); if(!Number.isSafeInteger(n)||n<1||n>wallet()) return false; ensure().ownerWallet -= n; db.touch(); return wallet(); }
function audit(action, details, group=null, actor='owner') { const d=ensure(); d.audit.push({at:Date.now(),actor,action:String(action).slice(0,80),details:String(details).slice(0,240),group:group||null}); if(d.audit.length>500)d.audit.splice(0,d.audit.length-500); db.touch(); }
function recentAudit(limit=20) { return ensure().audit.slice(-Math.max(1,Math.min(100,Number(limit)||20))).reverse(); }
function setElectionPaused(group, paused) { const d=ensure(); if(paused)d.electionsPaused[group]=true; else delete d.electionsPaused[group]; db.touch(); }
function electionsPaused(group) { return !!ensure().electionsPaused[group]; }
module.exports = { defaults, setDefault, hasOverride, setOverride, selectedGroup, selectGroup, wallet, walletAdd, walletTake, audit, recentAudit, setElectionPaused, electionsPaused };
