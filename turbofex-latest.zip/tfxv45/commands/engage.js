// Things to do every day besides gambling: quests, the throne and predictions. All of it is per group, with the group's coins.
const economy = require('../core/economy');
const quests = require('../core/quests');
const throne = require('../core/throne');
const predict = require('../core/predict');
const { num, resolveTarget } = require('../whatsapp/utils');

const { fmt } = economy;
const base = { category: 'economy', everyone: true, groupOnly: true, needs: [], weight: 'light' };
const dur = (ms) => {
  const m = Math.max(1, Math.ceil(ms / 60000));
  if (m < 60) return `${m}m`;
  const h = Math.floor(m / 60);
  if (h < 48) return `${h}h ${m % 60}m`;
  return `${Math.floor(h / 24)}d ${h % 24}h`;
};
const bar = (n, of) => '▰'.repeat(Math.round((n / of) * 5)) + '▱'.repeat(5 - Math.round((n / of) * 5));
// 30m, 2h, 1d, 1w -> milliseconds (or null)
const span = (t) => {
  const m = /^(\d+)(m|h|d|w)$/i.exec(String(t || ''));
  return m ? Number(m[1]) * { m: 60000, h: 3600000, d: 86400000, w: 604800000 }[m[2].toLowerCase()] : null;
};
const amountOf = (t) => {
  const m = /^(\d[\d,_]*)(k)?$/i.exec(String(t || ''));
  return m ? Math.round(parseInt(m[1].replace(/[,_]/g, ''), 10) * (m[2] ? 1000 : 1)) : NaN;
};
const tag = (jid) => `@${num(jid)}`;

module.exports = [
  {
    ...base,
    name: 'quests',
    aliases: ['quest', 'missions'],
    description: 'Your 3 quests of the day: finish them for coins (all 3 pay a bonus)',
    async run({ jid, reply, myJid, prefix }) {
      const s = quests.status(jid, myJid);
      const lines = s.quests.map((q) => `${q.done ? '✅' : q.icon} *${q.text}*\n   ${bar(q.progress, q.n)} ${q.progress}/${q.n} • *+${q.reward} coins*${q.done ? ' ✔' : ''}`);
      const w = s.week;
      await reply(
        `🎯 *Quests of today*\n_The same for everybody in this group. New ones every day._\n\n${lines.join('\n\n')}\n\n` +
          `🏆 *All 3:* bonus *+${s.sweepReward} coins* ${s.sweep ? '✅ got it' : ''}\n` +
          `🌟 *This week:* ${w.count}/${w.need} quests done → *+${w.reward} coins* ${w.paid ? '✅ got it' : ''}\n\n` +
          `_Coins are paid by themselves when you finish. Try_ \`${prefix}daily\` • \`${prefix}work\` • \`${prefix}throne\` • \`${prefix}predict\``
      );
    },
  },

  {
    ...base,
    name: 'throne',
    aliases: ['king', 'crownme'],
    description: 'Be the king of the group: throne / take / collect / decree / tax / feast / jail / unjail / peace / holiday (see gov)',
    async run(ctx) {
      const { jid, args, reply, myJid, prefix, msg } = ctx;
      const sub = (args[0] || '').toLowerCase();
      const i = throne.info(jid);
      if (sub === 'take' || sub === 'buy' || sub === 'claim') {
        const r = throne.take(jid, myJid);
        if (!r.ok) {
          if (r.why === 'already') return reply('👑 *You are already the king.* Keep it as long as you can!');
          if (r.why === 'gang') return reply('⚠️ *Gang members cannot take the throne.* Leave your gang first.');
          if (r.why === 'president') return reply('⚠️ *The President cannot also be King.* Your offices must remain separate.');
          if (r.why === 'debt') return reply(`🔒 *You have a loan.* Repay it first (\`${prefix}repay\`).`);
          return reply(`⚠️ *The throne costs ${fmt(r.price)} coins.* You have ${fmt(r.wallet)}.`);
        }
        const p = r.prev;
        await reply(
          `👑 *${tag(myJid)} is the new king!*\n*Paid:* ${fmt(r.price)} coins\n` +
            (p ? `*${tag(p.jid)}* was dethroned and got *${fmt(r.prevGot + r.prevIncome)}* coins back.\n` : '') +
            `*Next price:* ${fmt(r.next)} coins _(it slides down by itself every hour)_\n*King income:* ${throne.info(jid).income} coins every hour → \`${prefix}throne collect\`\n_Powers:_ \`${prefix}throne tax 3\` • \`${prefix}throne feast 1000\` • \`${prefix}throne jail @user\` • \`${prefix}throne decree <text>\``,
          { mentions: [myJid, p?.jid].filter(Boolean) }
        );
        return;
      }
      if (sub === 'collect') {
        const r = throne.collect(jid, myJid);
        if (!r.ok) return reply(r.why === 'nothing' ? '⏳ *Nothing to collect yet.* The king earns every hour.' : `⚠️ *Only the king can collect.* Take the throne with \`${prefix}throne take\``);
        return reply(`👑 *King's income collected*\n*Gross income:* ${fmt(r.gross ?? r.amount)} coins${r.tax ? `\n*President's royal income tax (${r.taxRate}%):* −${fmt(r.tax)} coins` : ''}\n*King received:* +${fmt(r.amount)} coins\n*Wallet:* ${fmt(r.wallet)} coins`);
      }
      if (sub === 'unjail' || sub === 'pardon' || sub === 'free') {
        const target = resolveTarget(msg, args);
        if (!target) return reply(`🔓 *Pardon*\nThe king frees somebody from jail (free).\n*Usage:* \`${prefix}throne unjail @user\` • free everybody: \`${prefix}throne amnesty\``);
        const r = throne.unjail(jid, myJid, target);
        if (!r.ok) return reply(r.why === 'notking' ? '⚠️ *Only the king can free people.*' : `ℹ️ *${tag(target)} is not in jail.*`, { mentions: [target] });
        return reply(`🔓 *${tag(target)} was pardoned by the king!* They can gamble and rob again.`, { mentions: [target] });
      }
      if (sub === 'amnesty') {
        const r = throne.amnesty(jid, myJid);
        if (!r.ok) return reply(r.why === 'notking' ? '⚠️ *Only the king can give an amnesty.*' : 'ℹ️ *Nobody is in jail.*');
        return reply(`🕊️ *Amnesty!* The king freed everybody from jail:\n${r.freed.map(tag).join(' ')}`, { mentions: r.freed });
      }
      if (sub === 'peace' || sub === 'holiday') {
        const R2 = throne.RULES;
        const cost = sub === 'peace' ? R2.peaceCost : R2.holidayCost;
        const ms = sub === 'peace' ? R2.peaceMs : R2.holidayMs;
        const r = throne.law(jid, myJid, sub);
        if (!r.ok) {
          const m = { notking: `⚠️ *Only the king can declare a ${sub === 'peace' ? 'peace law' : 'bank holiday'}.*`, active: `ℹ️ *It is already in force* for another ${dur(r.left || 0)}.`, wait: `⏳ *Too soon.* Again in ${dur(r.waitMs || 0)}.`, poor: `⚠️ *It costs ${fmt(cost)} coins.* You have ${fmt(r.wallet || 0)}.` }[r.why];
          return reply(m || '⚠️ *That did not work.*');
        }
        return reply(sub === 'peace' ? `🕊️ *PEACE LAW!* For ${dur(ms)} nobody can rob anybody in this group. _(cost: ${fmt(cost)} coins)_` : `🎉 *BANK HOLIDAY!* For ${dur(ms)} everybody earns *+${Math.round((R2.holidayBoost - 1) * 100)}%* from work, fish, hunt, mine, crime and daily. _(cost: ${fmt(cost)} coins)_`);
      }
      if (sub === 'gov' || sub === 'government' || sub === 'panel') {
        const R2 = throne.RULES;
        const jailed = throne.jailedList(jid);
        const head = i.king ? `👑 *King:* ${tag(i.king.jid)}` : '👑 *No king.* Take the throne with `' + prefix + 'throne take`';
        return reply(
          `🏛️ *Government*\n${head}\n*Tax:* ${i.tax}% (most ${i.maxTax}%) • *Income:* ${i.income}/hour\n*Peace law:* ${i.peace ? `✅ ${dur(i.peace)} left` : 'off'} • *Bank holiday:* ${i.holiday ? `✅ ${dur(i.holiday)} left` : 'off'}\n*In jail:* ${jailed.length ? jailed.map((j) => `${tag(j.jid)} (${dur(j.until - Date.now())})`).join(' ') : 'nobody'}\n\n` +
            `*What the king can do*\n▸ \`${prefix}gov tax 3\` – a share of jobs and daily goes to the king\n▸ \`${prefix}gov feast 1000\` – feed the people who chatted lately\n▸ \`${prefix}gov grant @user 500\` – direct royal grant\n▸ \`${prefix}gov bounty 100\` – pay every active chatter\n▸ \`${prefix}gov jail @user\` – ${fmt(R2.jailCost)} coins, ${dur(R2.jailMs)}\n▸ \`${prefix}gov unjail @user\` / \`${prefix}gov amnesty\` – free one / free all (free)\n▸ \`${prefix}gov peace\` – nobody can rob for ${dur(R2.peaceMs)} (${fmt(R2.peaceCost)} coins)\n▸ \`${prefix}gov holiday\` – +${Math.round((R2.holidayBoost - 1) * 100)}% pay for everybody for ${dur(R2.holidayMs)} (${fmt(R2.holidayCost)} coins)\n▸ \`${prefix}gov decree <text>\` – a message to the group\n_The king cannot rob and cannot be robbed._`,
          { mentions: [i.king?.jid, ...jailed.map((j) => j.jid)].filter(Boolean) }
        );
      }
      if (sub === 'salarylimit' || sub === 'paycap') {
        if (!throne.isKing(jid, myJid)) return reply('⚠️ Only the current King can set the career salary cap.');
        const amount=Number(args[1]); if(!Number.isSafeInteger(amount)||amount<1||amount>1000000000) return reply(`Usage: \`${prefix}throne salarylimit <amount>\` (1–1,000,000,000).`);
        const rp=require('../core/roleplay'); if(!rp.setCareerSalaryLimit(jid,amount)) return reply('Could not update the salary cap.');
        return reply(`💼 *ROYAL PAY CAP*\nMaximum career salary is now ${fmt(amount)} coins per 20-minute interval, including rank bonuses. The President can raise or lower it.`);
      }
      if (sub === 'tax') {
        const v = args[1];
        if (v === undefined) return reply(`💰 *King's tax*\n*Now:* ${i.tax}% of what people earn from jobs and the daily bonus goes to the king.\n*Most allowed:* ${i.maxTax}%\n\n▸ \`${prefix}throne tax 3\` – set it (0 = no tax)`);
        const r = throne.setTax(jid, myJid, String(v).replace('%', ''));
        if (!r.ok) return reply(r.why === 'notking' ? '⚠️ *Only the king can set the tax.*' : `⚠️ *Choose a tax between 0 and ${r.max}%.*`);
        return reply(r.tax ? `👑 *The king's tax is now ${r.tax}%.*\n_Every time somebody works, fishes, hunts, mines or collects the daily bonus, ${r.tax}% goes to the king. A high tax is not popular..._` : '👑 *The king removed the tax.* Long live the king!');
      }
      if (sub === 'grant') {
        const target = resolveTarget(msg, args.slice(1, -1)); const amount = amountOf(args[args.length - 1]);
        if (!target || !(amount > 0)) return reply(`👑 *Royal grant*\nThe king pays a member directly from their own wallet.\nUsage: \`${prefix}throne grant @user 500\`.`);
        const r = throne.grant(jid, myJid, target, amount);
        if (!r.ok) return reply(({notking:'Only the king can issue royal grants.',self:'You cannot grant coins to yourself.',amount:'Grant must be 1–1,000,000 coins.',poor:`You need ${fmt(r.amount || amount)} coins in your wallet.`})[r.why] || 'Could not issue grant.');
        return reply(`🎁 *ROYAL GRANT*\n${tag(myJid)} awarded ${fmt(r.amount)} coins to ${tag(target)}.`, {mentions:[myJid,target]});
      }
      if (sub === 'bounty') {
        const amount = amountOf(args[1]);
        if (!(amount > 0)) return reply(`👑 *Royal bounty*\nPay every member who chatted in the last hour.\nUsage: \`${prefix}throne bounty 100\` (amount per person).`);
        const r = throne.bounty(jid, myJid, amount);
        if (!r.ok) return reply(({notking:'Only the king can declare a royal bounty.',amount:'Bounty must be 1–1,000,000 coins per person.',quiet:'Nobody else has chatted in the last hour.',poor:`You need ${fmt(r.total || amount)} coins for ${r.count || 'the'} bounty recipients.`})[r.why] || 'Could not pay bounty.');
        return reply(`💰 *ROYAL BOUNTY PAID*\n${r.guests.length} active member(s) received ${fmt(r.amount)} coins each.\nTotal paid by the king: ${fmt(r.total)}.`, {mentions:[myJid,...r.guests]});
      }
      if (sub === 'feast') {
        const amount = amountOf(args[1]);
        if (!(amount > 0)) return reply(`🍗 *Royal feast*\nThe king pays, and everybody who chatted in the last hour shares it (the crown adds ${Math.round(throne.RULES.feastBonus * 100)}%).\n*Usage:* \`${prefix}throne feast 1000\` _(at least ${fmt(throne.RULES.feastMin)}, needs ${throne.RULES.feastMinPeople}+ people chatting)_`);
        const r = throne.feast(jid, myJid, amount);
        if (!r.ok) {
          const m = { notking: '⚠️ *Only the king can hold a feast.*', min: `⚠️ *A feast costs at least ${fmt(r.min || 0)} coins.*`, wait: `⏳ *The cooks are resting.* Next feast in ${dur(r.waitMs || 0)}.`, quiet: `🤫 *Too quiet.* ${r.have} people chatted in the last hour, a feast needs ${r.need}.`, poor: `⚠️ *You only have ${fmt(r.wallet || 0)} coins.*` }[r.why];
          return reply(m || '⚠️ *That did not work.*');
        }
        return reply(`🍗 *A royal feast!*\n${tag(myJid)} paid *${fmt(r.amount)} coins* and *${r.guests.length} people* got *+${fmt(r.each)} coins* each:\n${r.guests.map(tag).join(' ')}\n_Long live the king!_ 👑`, { mentions: [myJid, ...r.guests] });
      }
      if (sub === 'jail' || sub === 'exile') {
        const target = resolveTarget(msg, args);
        if (!target) return reply(`⛓️ *King's jail*\nSend somebody to jail for ${dur(throne.RULES.jailMs)}: they cannot gamble or rob. Costs ${fmt(throne.RULES.jailCost)} coins, once every ${dur(throne.RULES.jailCooldownMs)}.\n*Usage:* \`${prefix}throne jail @user\``);
        const r = throne.jail(jid, myJid, target);
        if (!r.ok) {
          const m = { notking: '⚠️ *Only the king can use the jail.*', self: '😅 *You cannot jail yourself.*', wait: `⏳ *The guards are busy.* Next arrest in ${dur(r.waitMs || 0)}.`, poor: `⚠️ *The jail costs ${fmt(throne.RULES.jailCost)} coins.* You have ${fmt(r.wallet || 0)}.` }[r.why];
          return reply(m || '⚠️ *That did not work.*');
        }
        return reply(`⛓️ *${tag(target)} was sent to jail by the king!*\nFor ${dur(r.until - Date.now())} they cannot gamble or rob. _(cost: ${fmt(r.cost)} coins)_`, { mentions: [target] });
      }
      if (sub === 'decree' || sub === 'say') {
        const r = throne.decree(jid, myJid, args.slice(1).join(' '));
        if (!r.ok) return reply(r.why === 'empty' ? `*Usage:* \`${prefix}throne decree <your words>\`` : '⚠️ *Only the king can write a decree.*');
        return reply(`📜 *The king has spoken:*\n_"${r.decree}"_`);
      }
      const R = throne.RULES;
      const head = i.king
        ? `👑 *King:* ${tag(i.king.jid)} _(on the throne for ${dur(Date.now() - i.since)})_\n${i.decree ? `📜 _"${i.decree}"_\n` : ''}*Waiting for the king:* ${fmt(i.waiting)} coins`
        : '👑 *The throne is empty!* Be the first king.';
      await reply(
        `🏰 *The Throne*\n\n${head}\n\n*Price to take it:* ${fmt(i.price)} coins\n▸ The old king gets ${Math.round(R.payback * 100)}% of the price back, so being dethroned is not a loss\n▸ The king earns *${i.income} coins an hour*\n▸ The price slides down every hour\n▸ The king can set a *tax* (${i.tax}% now), hold a *feast* for chatters and send people to *jail*\n\n▸ \`${prefix}throne take\` • \`${prefix}throne collect\` • \`${prefix}throne decree <text>\`\n▸ \`${prefix}gov\` – everything the king can do (tax, feast, jail, unjail, peace, holiday)\n_The king cannot rob and cannot be robbed._`,
        { mentions: [i.king?.jid].filter(Boolean) }
      );
    },
  },

  {
    ...base,
    name: 'predict',
    aliases: ['prediction', 'predictions'],
    description: 'Bet coins on a yes/no question: predict / predict yes 1 200 / predict new 2d Will it rain on Saturday?',
    async run(ctx) {
      const { jid, args, reply, myJid, prefix, isAdmin, isOwner } = ctx;
      const sub = (args[0] || '').toLowerCase();
      const R = predict.RULES;
      const view = (it) => {
        const p = it.pool || predict.poolOf(it);
        const left = it.closes - Date.now();
        return `*#${it.id}* ${it.q}\n   ✅ YES ${fmt(p.yes)} • ❌ NO ${fmt(p.no)} • ${left > 0 ? `closes in ${dur(left)}` : '🔒 betting closed, waiting for the answer'}`;
      };

      if (sub === 'new' || sub === 'ask' || sub === 'create') {
        if (!isAdmin && !isOwner) return reply('⚠️ *Only group admins can ask a question.*');
        const d = span(args[1]);
        const text = args.slice(2).join(' ');
        if (!d || !text) return reply(`🔮 *Usage:* \`${prefix}predict new 2d Will Nigeria win on Saturday?\`\n_The time is how long people can bet (30m, 6h, 2d, 1w)._`);
        const r = predict.create(jid, myJid, text, d);
        if (!r.ok) return reply(r.why === 'many' ? `⚠️ *There are already ${r.max} open questions.*` : r.why === 'short' ? '⚠️ *Write a longer question.*' : '⚠️ *The time must be between 1 minute and 30 days.*');
        return reply(`🔮 *New prediction #${r.id}*\n_${text.replace(/\s+/g, ' ').slice(0, R.questionMax)}_\n\n*Betting closes in:* ${dur(d)}\n▸ \`${prefix}predict yes ${r.id} 200\`\n▸ \`${prefix}predict no ${r.id} 200\`\n_Winners share the pool. The person who asked cannot bet._`);
      }
      if (sub === 'yes' || sub === 'no') {
        const id = Number(args[1]);
        const amount = amountOf(args[2]);
        if (!id || !(amount > 0)) return reply(`🔮 *Usage:* \`${prefix}predict ${sub} <number> <coins>\`\n*Example:* \`${prefix}predict ${sub} 1 200\` _(smallest ${R.minStake}, most ${fmt(R.maxStake)})_`);
        const r = predict.stake(jid, myJid, id, sub, amount);
        if (!r.ok) {
          const m = {
            none: `⚠️ *There is no open question #${id}.* See \`${prefix}predict\``,
            closed: '🔒 *Betting is closed* for that one.',
            creator: '⚠️ *You asked the question, so you cannot bet on it.*',
            debt: `🔒 *You have a loan.* Repay it first (\`${prefix}repay\`).`,
            otherside: '⚠️ *You already bet on the other side* of this one.',
            min: `⚠️ *The smallest bet is ${R.minStake} coins.*`,
            max: `⚠️ *The most is ${fmt(R.maxStake)} coins on one question* (you put ${fmt(r.have || 0)}).`,
            poor: `⚠️ *Not enough coins.* You have ${fmt(r.wallet || 0)}.`,
          }[r.why];
          return reply(m || '⚠️ *That did not work.*');
        }
        const x = r.payoutPerCoin;
        return reply(`🔮 *Bet placed on ${sub.toUpperCase()}* (#${id})\n*Your total on ${sub.toUpperCase()}:* ${fmt(r.total)} coins\n*Pool:* ✅ ${fmt(r.pool.yes)} • ❌ ${fmt(r.pool.no)}\n${x ? `_If ${sub.toUpperCase()} wins now you get about ×${x.toFixed(2)} back._` : ''}\n_Win or lose, the admin settles it when the answer is known._`);
      }
      if (sub === 'resolve' || sub === 'settle' || sub === 'end') {
        const id = Number(args[1]);
        const out = (args[2] || '').toLowerCase();
        if (!id || !['yes', 'no'].includes(out)) return reply(`🔮 *Usage:* \`${prefix}predict resolve <number> yes|no\``);
        const r = predict.settle(jid, myJid, id, out, isOwner);
        if (!r.ok) return reply(r.why === 'notyours' ? '⚠️ *Only the person who asked (or the bot owner) can settle it.*' : r.why === 'none' ? `⚠️ *There is no open question #${id}.*` : '⚠️ *Say yes or no.*');
        if (r.refunded) return reply(`🔮 *#${id} settled: ${out.toUpperCase()}*\n_Nobody was on the other side, so every bet was given back._`);
        const top = r.winners.slice(0, 5).map((w) => `▸ ${tag(w.jid)} put ${fmt(w.stake)} → *+${fmt(w.got - w.stake)}* profit`);
        return reply(`🔮 *Prediction #${id} settled: ${out.toUpperCase()}* ${out === 'yes' ? '✅' : '❌'}\n_${r.item.q}_\n\n*Pool:* ${fmt(r.pool.total)} coins • *Winners:* ${r.winners.length}\n${top.join('\n')}`, { mentions: r.winners.slice(0, 5).map((w) => w.jid) });
      }
      if (sub === 'cancel') {
        const id = Number(args[1]);
        const r = predict.cancel(jid, myJid, id, isOwner);
        if (!r.ok) return reply(r.why === 'notyours' ? '⚠️ *Only the person who asked (or the bot owner) can cancel it.*' : `⚠️ *There is no open question #${id || '?'}.*`);
        return reply(`🔮 *#${id} cancelled.* ${r.players} ${r.players === 1 ? 'person' : 'people'} got the coins back.`);
      }
      const open = predict.list(jid);
      if (!open.length) return reply(`🔮 *Predictions*\n_No open questions now._\n\n▸ Admins: \`${prefix}predict new 2d Will it rain on Saturday?\`\n_Everybody bets coins on YES or NO. When the answer is known the admin settles it and the winners share the pool._`);
      await reply(`🔮 *Predictions*\n\n${open.map(view).join('\n\n')}\n\n▸ \`${prefix}predict yes <number> <coins>\` • \`${prefix}predict no <number> <coins>\`\n_Winners share the pool (5% is taken). Admins settle with_ \`${prefix}predict resolve <number> yes|no\``, { mentions: [] });
    },
  },

];

// "gov" is the same as "throne": the government of the group (gov alone shows the panel; gov tax 3, gov jail @user...)
const throneCmd = module.exports.find((c) => c.name === 'throne');
module.exports.push({
  ...throneCmd,
  name: 'gov',
  aliases: ['government', 'kingdom', 'king'].filter((a) => !throneCmd.aliases.includes(a)),
  description: 'The government of the group: the king sets tax, feasts, jail, unjail, peace and holiday (gov shows all)',
  run: (ctx) => throneCmd.run({ ...ctx, args: ctx.args.length ? ctx.args : ['gov'] }),
});
