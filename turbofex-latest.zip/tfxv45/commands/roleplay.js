// Careers provide repeatable income; gangs and territories add cooperative long-term progression.
const economy = require('../core/economy');
const rp = require('../core/roleplay');
const { num, resolveTarget } = require('../whatsapp/utils');
const base = { category: 'economy', everyone: true, groupOnly: true, needs: [], weight: 'light' };
const fmt = economy.fmt;
const left = (ms) => { const m = Math.max(1, Math.ceil(ms / 60000)); return m < 60 ? `${m}m` : `${Math.floor(m / 60)}h ${m % 60}m`; };
const who = (jid) => `@${num(jid)}`;
const SALARY_INTERVAL = 20 * 60000;
function resolve(group, key) { const result = rp.resolveWar(group, key); if (!result) return ''; return result.won ? `\n🏆 *Territory captured!* ${result.attacker} defeated ${result.defender}.` : `\n🛡️ *Territory defended!* ${result.defender} held the district.`; }
module.exports = [
  { ...base, name: 'career', aliases: ['careers', 'jobcareer'], description: 'Apply for a career, do duty, collect salary, or check your career', async run({ args, reply, myJid, jid, prefix, msg }) {
    const g = rp.state(jid), u = rp.refreshCareer(jid, myJid), sub = (args[0] || '').toLowerCase(), role = (args[1] || '').toLowerCase();
    if (!sub || sub === 'list') return reply(`💼 *CAREER BOARD*\nChoose one career with \`${prefix}career apply police\`\n\n${Object.entries(rp.CAREERS).map(([k,c]) => `${c.icon} *${c.name}* · ${fmt(rp.careerSalary(jid, k, 1))} coins / 20m salary · ${fmt(c.duty)} duty pay · one holder for 2h\n   ID: ${k}`).join('\n')}\n\nUse \`${prefix}career status\`, \`${prefix}career duty\` and \`${prefix}career salary\`.`);
    if (sub === 'status') {
      if (!u.career || !rp.CAREERS[u.career]) return reply(`You have no career yet. Apply with \`${prefix}career apply police\`.`);
      const c = rp.CAREERS[u.career], wait = Math.max(0, SALARY_INTERVAL - (Date.now() - u.lastSalary));
      return reply(`${c.icon} *Career Record*\n*Career:* ${c.name}\n*Rank:* ${u.rank}\n*Duties completed:* ${u.duties}\n*Term remaining:* ${left((u.careerUntil || 0)-Date.now())}\n*Next salary:* ${wait ? `in ${left(wait)}` : 'ready to collect'}\n*Next promotion:* ${u.rank >= 5 ? 'Maximum rank' : `${Math.max(0, u.rank * 5 - u.duties)} more duties`}`);
    }
    if (sub === 'apply') {
      if (!rp.CAREERS[role]) return reply(`Choose a career ID from \`${prefix}career list\`.`);
      const claim = rp.claimCareer(jid, myJid, role);
      if (!claim.ok) {
        if (claim.why === 'hascareer') return reply(`You already work as *${rp.CAREERS[claim.career].name}*. Use \`${prefix}career quit\` first.`);
        if (claim.why === 'leader') return reply('Government leaders cannot take a criminal career.');
        if (claim.why === 'leadergang') return reply('Leave your gang before taking a government leadership career.');
        return reply(`⛔ *${rp.CAREERS[role].name} is already occupied* by @${num(claim.holder.jid)}. Each career has one holder per group for 2 hours.`, { mentions: [claim.holder.jid] });
      }
      return reply(`✅ *CAREER APPOINTMENT CONFIRMED*\n${rp.CAREERS[role].icon} @${num(myJid)} is now *${rp.CAREERS[role].name}*, Rank 1.\n*Term:* 2 hours\n*Salary:* ${fmt(rp.CAREERS[role].salary)} every 20 minutes\nUse \`${prefix}career commands\` to see this career's powers.`, { mentions: [myJid] });
    }
    if (sub === 'quit') { const r = rp.releaseCareer(jid, myJid); return reply(r.ok ? `You have resigned from *${rp.CAREERS[r.career].name}*. The position is now available.` : 'You do not have an active career to quit.'); }
    if (sub === 'commands' || sub === 'help') {
      const key = (args[1] || u.career || '').toLowerCase();
      if (key !== 'all' && !rp.CAREERS[key]) return reply(`💼 *CAREER COMMANDS*\nApply: \`${prefix}career apply <career-id>\`\nList positions: \`${prefix}career list\`\nSee all powers: \`${prefix}career commands all\`\nCheck term and salary: \`${prefix}career status\`\nCollect salary: \`${prefix}career salary\`\nComplete duty: \`${prefix}career duty\`\nQuit: \`${prefix}career quit\``);
      const actions = { police: 'fine @user amount (wanted players only; 5-minute fine cooldown) • wanted arrest @user', doctor: 'treat @user (remove haunting, heal and protect)', royalguard: 'protect @user (robbery protection)', soldier: 'patrol (reduce wanted levels in this group)', mechanic: 'repair @user (paid repair; part of fee leaves circulation)', criminal: 'extort @user amount (risky transfer, wanted level on use)' };
      if (key === 'all') return reply(`🏛️ *CAREER POWERS*\n${Object.entries(actions).map(([k,v])=>`${rp.CAREERS[k].icon} *${rp.CAREERS[k].name}:* ${v}`).join('\n')}\n\nEach career has one holder per group for 2 hours. Use \`${prefix}career commands <career-id>\` for one career.`);
      return reply(`${rp.CAREERS[key].icon} *${rp.CAREERS[key].name} COMMANDS*\n${actions[key]}\n\nAll commands require an active appointment. Your appointment lasts 2 hours.`);
    }
    if (sub === 'powers') return reply(`🏛️ *Career powers that affect the group*\n👮 Police: \`${prefix}career fine @user 500\` (transfer a fine, max 10,000).\n🩺 Doctor: \`${prefix}career treat @user\` (pay 500, give them 500 and remove a haunting).\n🛡️ Royal Guard: \`${prefix}career protect @user\` (protects from robbery for 30 minutes).\n🎖️ Soldier: \`${prefix}career patrol\` (reduce wanted level by 1 for every wanted player).\n🔧 Mechanic: \`${prefix}career repair @user\` (charges 2,000, pays the mechanic 1,500 and removes 500 from circulation).\n🕶️ Gang Operative: \`${prefix}career extort @user 500\` (attempt a risky transfer and gain wanted level).\nActions require the matching active career. Use \`${prefix}career commands\` for the full command guide.`);
    if (['fine','treat','protect','patrol','repair','extort'].includes(sub)) {
      if (!u.career || !rp.CAREERS[u.career]) return reply(`Apply for a career first: \`${prefix}career apply police\`.`);
      const allowed = { fine: 'police', treat: 'doctor', protect: 'royalguard', patrol: 'soldier', repair: 'mechanic', extort: 'criminal' };
      if (u.career !== allowed[sub]) return reply(`Only a ${rp.CAREERS[allowed[sub]].name} can use this action. Your career is ${rp.CAREERS[u.career].name}.`);
      const now = Date.now();
      if (economy.jailLeft(myJid)) return reply('⛓️ You cannot use career powers while jailed.');
      if (sub === 'patrol') {
        const cd = now - (u.lastAction || 0); if (cd < 30 * 60000) return reply(`⏳ Patrol is ready in ${left(30*60000-cd)}.`);
        let reduced = 0; for (const member of Object.values(g.users)) if ((member.wanted || 0) > 0) { member.wanted -= 1; reduced++; }
        u.lastAction = now; rp.touch(); return reply(`🎖️ *City patrol complete.* Wanted levels were reduced for ${reduced} player(s) across this group.`);
      }
      const target = resolveTarget(msg, args.slice(1));
      if (!target) return reply(`Usage: \`${prefix}career ${sub} @user${sub==='fine' || sub==='extort' ? ' amount' : ''}\`.`);
      if (rp.memberKey(target) === rp.memberKey(myJid)) return reply('You cannot target yourself.');
      if (rp.isGovernmentLeader(jid, target) && sub !== 'treat' && sub !== 'protect' && sub !== 'repair') return reply('Government leaders are protected from this career action.');
      const victim = rp.user(jid, target);
      const cooldownAt = sub === 'fine' ? (u.lastFine || 0) : (u.lastAction || 0); const cooldownMs = sub === 'fine' ? 5 * 60000 : 30 * 60000; const cd = now - cooldownAt; if (cd < cooldownMs) return reply(`⏳ This power is ready in ${left(cooldownMs-cd)}.`);
      if (sub === 'fine') {
        const amount = Math.floor(Number(args[args.length-1]));
        const wantedCap = Math.max(0, (victim.wanted || 0) * 2000);
        if (!(victim.wanted > 0)) return reply('👮 Police fines can only be issued to players with an active wanted level.');
        if (!Number.isSafeInteger(amount) || amount < 1 || amount > wantedCap) return reply(`Fine must be 1–${wantedCap} coins at this wanted level.`);
        const paid = Math.min(amount, economy.balance(target)); if (paid < 1) return reply('That player has no wallet coins to fine.');
        economy.take(target, paid); economy.add(myJid, paid); u.lastFine=now; rp.touch();
        return reply(`👮 *Fine issued*\nOfficer: ${who(myJid)}\nPlayer: ${who(target)}\nTransferred: ${fmt(paid)} coins`, { mentions: [myJid,target] });
      }
      if (sub === 'treat') {
        if (economy.balance(myJid) < 500) return reply('Treatment costs 500 coins.');
        economy.take(myJid,500); economy.add(target,500); victim.ghostUntil=0; victim.protectedUntil=Math.max(victim.protectedUntil||0,now+10*60000); u.lastAction=now; rp.touch();
        return reply(`🩺 *Treatment complete!*\n${who(target)} received 500 coins, their haunting was removed, and they have 10 minutes of robbery protection. Cost to doctor: 500 coins.`, { mentions: [myJid,target] });
      }
      if (sub === 'protect') {
        const until=rp.protect(jid,myJid,target,30*60000,now); u.lastAction=now; rp.touch();
        return reply(`🛡️ ${who(target)} is protected from robbery for 30 minutes by the Royal Guard.`, { mentions: [myJid,target] });
      }
      if (sub === 'repair') {
        const fee = 2000; if (economy.balance(target) < fee) return reply(`A repair costs ${fmt(fee)} coins. That player cannot afford it.`);
        economy.take(target, fee); economy.add(myJid, 1500); u.lastAction=now; rp.touch();
        return reply(`🔧 *Repair completed!*\n${who(myJid)} repaired ${who(target)}'s vehicle.\nCustomer paid: ${fmt(fee)} coins\nMechanic earned: 1,500 coins\nParts and workshop fee removed: 500 coins.`, {mentions:[myJid,target]});
      }
      if (sub === 'extort') {
        const amount=Math.floor(Number(args[args.length-1]));
        if (!Number.isSafeInteger(amount)||amount<100||amount>50000) return reply('Extortion amount must be 100–50,000 coins.');
        if (economy.balance(target)<amount) return reply('That player does not have enough coins for this extortion attempt.');
        u.lastAction=now; rp.addWanted(jid,myJid,1,now);
        if (Math.random()<0.6) { economy.take(target,amount); economy.add(myJid,amount); rp.touch(); return reply(`🕶️ *Extortion succeeded.* ${who(target)} lost ${fmt(amount)} coins. Your wanted level increased.`,{mentions:[myJid,target]}); }
        const fine=Math.min(5000,economy.balance(myJid)); if(fine){economy.take(myJid,fine);economy.add(target,fine);} rp.touch(); return reply(`🚨 *Extortion failed!* You were exposed and paid ${fmt(fine)} coins to ${who(target)}. Wanted level increased.`,{mentions:[myJid,target]});
      }
    }
    if (sub === 'duty') {
      const jailed = economy.jailLeft(myJid); if (jailed) return reply(`⛓️ You are in jail for another ${left(jailed)}. You cannot complete career duties yet.`);
      if (!u.career || !rp.CAREERS[u.career]) return reply(`Apply for a career first: \`${prefix}career apply police\`.`);
      const wait = rp.HOUR - (Date.now() - u.lastDuty); if (wait > 0) return reply(`⏳ Your next duty is available in ${left(wait)}.`);
      const c = rp.CAREERS[u.career], reward = c.duty + (u.rank - 1) * 25;
      u.lastDuty = Date.now(); u.duties += 1;
      const promoted = u.rank < 5 && u.duties >= u.rank * 5; if (promoted) u.rank += 1;
      economy.add(myJid, reward); economy.addRep(myJid, 1); rp.touch();
      return reply(`✅ *Duty completed*\n${c.icon} ${c.name} · Rank ${u.rank}\n*Earned:* +${fmt(reward)} coins\n*Reputation:* +1 ⭐${promoted ? `\n🎖️ *Promotion!* You reached Rank ${u.rank}.` : ''}\n*Duties:* ${u.duties}`);
    }
    if (sub === 'salary' || sub === 'collect') {
      if (!u.career || !rp.CAREERS[u.career]) return reply(`Apply for a career first: \`${prefix}career apply police\`.`);
      const now = Date.now(), elapsed = Math.min(60 * 60000, Math.max(0, now - (u.lastSalary || now))), units = Math.floor(elapsed / SALARY_INTERVAL);
      if (units < 1) return reply(`⏳ Your next salary is ready in ${left(SALARY_INTERVAL - (now - (u.lastSalary || now)))}. Salary accrues up to 1 hour.`);
      const amount = units * rp.careerSalary(jid, u.career, u.rank); u.lastSalary = (now - (u.lastSalary || now) >= 60 * 60000) ? now : u.lastSalary + units * SALARY_INTERVAL; economy.add(myJid, amount); rp.touch();
      return reply(`💵 *Career salary collected*\n${rp.CAREERS[u.career].icon} ${rp.CAREERS[u.career].name} · Rank ${u.rank}\n*Paid:* +${fmt(amount)} coins\n*Next salary:* in 20 minutes (up to 1 hour accrues).\n*Appointment ends:* ${left((u.careerUntil || 0)-Date.now())}.`);
    }
    if (sub === 'promote') return reply(`Promotions happen automatically after every ${u.rank * 5} completed duties, up to Rank 5. Use \`${prefix}career duty\`.`);
    return reply(`Use \`${prefix}career list\`, \`${prefix}career apply police\`, \`${prefix}career duty\`, \`${prefix}career salary\`, \`${prefix}career status\` or \`${prefix}career quit\`.`);
  }},
  { ...base, name: 'gang', aliases: ['gangs'], description: 'Create or join a gang, view details, and manage gang funds', async run({ args, reply, myJid, jid, prefix }) {
    const g = rp.state(jid), u = rp.user(jid, myJid), sub = (args[0] || '').toLowerCase(), name = args.slice(1).join('').toLowerCase();
    if (!sub || sub === 'info') {
      const gang = rp.getGang(jid, myJid); if (!gang) return reply(`You are not in a gang.\nCreate one: \`${prefix}gang create name\`\nJoin one: \`${prefix}gang join name\``);
      return reply(`⚔️ *Gang: ${gang.name}*\n*Leader:* @${gang.leader}\n*Members:* ${gang.members.length}\n*Treasury:* ${fmt(gang.treasury)} coins\n\nUse \`${prefix}gang deposit 500\`, \`${prefix}gang withdraw 500\` (leader only) and \`${prefix}territory\`.`, { mentions: gang.members.map(x => `${x}@s.whatsapp.net`) });
    }
    if (sub === 'create') {
      const gangName = args.slice(1).join('').replace(/\s/g,''); if (economy.balance(myJid) < 1000) return reply('Creating a gang costs 1,000 coins.');
      const r = rp.makeGang(jid, myJid, gangName); if (!r.ok) return reply(({name:'Use a name with 3–20 letters/numbers.',member:'Leave your current gang first.',taken:'That gang name is already taken.',leader:'The King and President cannot join or lead gangs.',career:'Police, soldiers and royal guards cannot join gangs while serving.'})[r.why] || 'Could not create that gang.');
      economy.take(myJid, 1000); return reply(`✅ *Gang created:* ${r.gang.name}\nCreation cost: 1,000 coins. Invite friends to join with \`${prefix}gang join ${r.gang.name}\`.`);
    }
    if (sub === 'join') { const key = args.slice(1).join('').toLowerCase(); const r = rp.joinGang(jid, myJid, key); if (!r.ok) return reply(({member:'You are already in a gang.',missing:'That gang does not exist.',leader:'The King and President cannot join or lead gangs.',career:'Police, soldiers and royal guards cannot join gangs while serving.'})[r.why] || 'Could not join that gang.'); return reply(`⚔️ You joined *${r.gang.name}*. Use \`${prefix}territory\` to see the district map.`); }
    if (sub === 'leave') { const r = rp.leaveGang(jid, myJid); return reply(r.ok ? 'You left your gang.' : r.why === 'leader' ? 'Transfer leadership or ask members to leave before disbanding the gang.' : 'You are not in a gang.'); }
    const gang = rp.getGang(jid, myJid); if (!gang) return reply(`Join or create a gang first. Try \`${prefix}gang create name\`.`);
    if (sub === 'deposit') { const n = Number(args[1]); if (!Number.isSafeInteger(n) || n < 1 || !economy.take(myJid,n)) return reply('Enter a valid amount you can afford, e.g. gang deposit 500.'); gang.treasury += n; rp.touch(); return reply(`🏦 Added ${fmt(n)} coins to *${gang.name}* treasury.`); }
    if (sub === 'withdraw') { const n = Number(args[1]); if (gang.leader !== rp.memberKey(myJid)) return reply('Only the gang leader can withdraw treasury funds.'); if (!Number.isSafeInteger(n) || n < 1 || gang.treasury < n) return reply(`Treasury has ${fmt(gang.treasury)} coins. Use gang withdraw amount.`); gang.treasury -= n; economy.add(myJid,n); rp.touch(); return reply(`💰 Withdrawn ${fmt(n)} coins. Treasury: ${fmt(gang.treasury)}.`); }
    return reply(`Use \`${prefix}gang create name\`, \`${prefix}gang join name\`, \`${prefix}gang info\`, \`${prefix}gang deposit 500\`, \`${prefix}gang withdraw 500\` or \`${prefix}gang leave\`.`);
  }},
  { ...base, name: 'territory', aliases: ['territories', 'turf'], description: 'Claim districts, collect gang income, and fight territory wars', async run({ args, reply, myJid, jid, prefix }) {
    const g = rp.state(jid), sub = (args[0] || '').toLowerCase(), key = (args[1] || '').toLowerCase(), gang = rp.getGang(jid, myJid), now = Date.now();
    const warNotes = Object.keys(rp.DISTRICTS).map(k => resolve(jid,k)).join('');
    if (!sub || sub === 'map' || sub === 'list') return reply(`🗺️ *TERRITORY MAP*${warNotes}\n${Object.entries(rp.DISTRICTS).map(([k,d]) => { const t=g.territories[k]; const owner=t.gang && g.gangs[t.gang] ? g.gangs[t.gang].name : 'Neutral'; const war=t.war ? ` ⚔️ WAR (${left(t.war.endsAt-now)})` : ''; return `• *${d.name}* [${k}]\n  Owner: ${owner}${war}\n  Claim: ${fmt(d.cost)} · Income: ${fmt(d.income)} coins/hour`; }).join('\n')}\n\nClaim: \`${prefix}territory claim oldtown\`\nChallenge: \`${prefix}territory war oldtown\`\nAttack during war: \`${prefix}territory attack oldtown\`\nCollect gang income: \`${prefix}territory collect\``);
    if (!gang) return reply(`You need a gang first: \`${prefix}gang create name\`.`);
    if (sub === 'claim') {
      const d=rp.DISTRICTS[key], t=g.territories[key]; if(!d||!t) return reply(`Choose a district from \`${prefix}territory map\`.`);
      if(gang.leader!==rp.memberKey(myJid)) return reply('Only the gang leader can claim territory.'); if(t.gang) return reply('That district is already controlled. Start a territory war instead.'); if(gang.treasury<d.cost) return reply(`Your gang treasury needs ${fmt(d.cost)} coins. Fund it with \`${prefix}gang deposit 500\`.`);
      gang.treasury-=d.cost; t.gang=gang.key; t.paidAt=now; rp.touch(); return reply(`🏴 *${d.name} claimed!*\n*Gang:* ${gang.name}\n*Cost:* ${fmt(d.cost)} from gang treasury\n*Income:* ${fmt(d.income)} coins/hour, collected into the gang treasury.`);
    }
    if (sub === 'collect') {
      let total=0; for(const [k,d] of Object.entries(rp.DISTRICTS)){ const t=g.territories[k]; if(t.gang!==gang.key) continue; const elapsed=Math.min(12*rp.HOUR,Math.max(0,now-(t.paidAt||now))); const hrs=Math.floor(elapsed/rp.HOUR); if(hrs>0){const amount=hrs*d.income; gang.treasury+=amount; t.paidAt = elapsed >= 12*rp.HOUR ? now : t.paidAt + hrs*rp.HOUR; total+=amount;} }
      rp.touch(); return reply(`💰 *Territory income collected*\nGang: ${gang.name}\nAdded: ${fmt(total)} coins to treasury${total ? '' : '\nNo income ready yet. Territory income accrues hourly, capped at 12 hours.'}\nTreasury: ${fmt(gang.treasury)} coins.`);
    }
    if (sub === 'war') {
      const d=rp.DISTRICTS[key], t=g.territories[key]; if(!d||!t) return reply(`Choose a district from \`${prefix}territory map\`.`); if(!t.gang || !g.gangs[t.gang]) return reply('That district is neutral. Claim it instead.'); if(t.gang===gang.key) return reply('Your gang already controls that district.'); if(t.war) return reply('A war is already active for that district.'); if(gang.leader!==rp.memberKey(myJid)) return reply('Only the gang leader can declare a territory war.');
      t.war={attacker:gang.key, defender:t.gang, attackScore:0, defendScore:0, endsAt:now+10*60000, startedAt:now, fighters:{}}; rp.touch(); return reply(`⚔️ *TERRITORY WAR DECLARED*\n${gang.name} challenges ${g.gangs[t.gang].name} for *${d.name}*.\nWar lasts 10 minutes. Both gangs can use \`${prefix}territory attack ${key}\` to fight. Each member can fight once per war.`);
    }
    if (sub === 'attack') {
      const d=rp.DISTRICTS[key], t=g.territories[key], w=t&&t.war; if(!d||!w) return reply('There is no active war for that district. Check territory map.'); if(now>=w.endsAt){ const r=rp.resolveWar(jid,key,now); return reply(r ? (r.won ? `🏆 ${r.attacker} captured ${d.name}!` : `🛡️ ${r.defender} defended ${d.name}.`) : 'The war has ended.'); }
      const side=gang.key===w.attacker?'attack':gang.key===w.defender?'defend':null; if(!side) return reply('Your gang is not part of this war.'); const member=rp.memberKey(myJid); if(w.fighters[member]) return reply('You have already fought in this war.'); const power=1+Math.floor(Math.random()*3); w.fighters[member]=side; if(side==='attack') w.attackScore+=power; else w.defendScore+=power; rp.touch(); return reply(`⚔️ *Fight recorded!*\n${side==='attack'?'Attacking':'Defending'} ${d.name}\nPower: ${power}\nScore: ${w.attacker} ${w.attackScore} · ${w.defender} ${w.defendScore}\nTime left: ${left(w.endsAt-now)}.`);
    }
    return reply(`Use \`${prefix}territory map\`, \`${prefix}territory claim oldtown\`, \`${prefix}territory war oldtown\`, \`${prefix}territory attack oldtown\` or \`${prefix}territory collect\`.`);
  }}
  ,
  { ...base, name: 'wanted', aliases: ['wantedlevel', 'policecheck'], description: 'Check wanted level, arrest criminals as police/royal guard, or pay bail', async run({ args, reply, myJid, jid, msg, prefix, sock }) {
    const sub = (args[0] || 'status').toLowerCase();
    const me = rp.user(jid, myJid), now = Date.now();
    if (sub === 'bail') {
      if (!(me.jailedUntil > now)) { me.jailedUntil = 0; me.bail = 0; rp.touch(); return reply('✅ You are not in crime-system jail.'); }
      const amount = Math.max(0, me.bail || 0);
      if (economy.balance(myJid) < amount) return reply(`⛓️ You are jailed for ${left(me.jailedUntil-now)}. Bail costs ${fmt(amount)} coins; your wallet has ${fmt(economy.balance(myJid))}.`);
      economy.take(myJid, amount); rp.payBail(jid, myJid, now);
      return reply(`🔓 *Bail paid!* You are free.
Paid: ${fmt(amount)} coins
Wanted level reset. Keep out of trouble.`);
    }
    if (sub === 'info' || sub === 'profile') {
      if (!['police','royalguard'].includes(me.career)) return reply('🚔 Only Police Officers and Royal Guards can inspect detailed roleplay records.');
      const target = resolveTarget(msg, args.slice(1)); if (!target) return reply(`Usage: \`${prefix}wanted info @user\`.`);
      const v=rp.user(jid,target), gang=rp.getGang(jid,target), balance=economy.balance(target), bank=typeof economy.bankBalance==='function'?economy.bankBalance(target):null;
      const lux=(v.luxuries||[]).map(x=>typeof x==='string'?x:(x.name||x.id||'asset')).join(', ')||'None';
      return reply(`🗂️ *POLICE INTELLIGENCE FILE*\nSubject: @${num(target)}\nWallet: ${fmt(balance)} coins${bank===null?'':`\nBank: ${fmt(bank)} coins`}\nCareer: ${v.career?`${rp.CAREERS[v.career]?.name||v.career} (Rank ${v.rank||1})`:'Unemployed'}\nCareer term: ${v.careerUntil>Date.now()?left(v.careerUntil-Date.now())+' remaining':'Inactive'}\nDuties: ${v.duties||0}\nWanted: ${v.wanted||0}/5\nJail: ${v.jailedUntil>Date.now()?left(v.jailedUntil-Date.now())+' remaining':'Not jailed'}\nBail: ${fmt(v.bail||0)}\nGang: ${gang?.name||'None'}\nLast crime: ${v.lastCrime?new Date(v.lastCrime).toISOString():'No recorded crime'}\nProtection: ${v.protectedUntil>Date.now()?left(v.protectedUntil-Date.now())+' remaining':'None'}\nHaunting: ${v.ghostUntil>Date.now()?left(v.ghostUntil-Date.now())+' remaining':'None'}\nLuxury assets: ${lux}`,{mentions:[target]});
    }
    if (sub === 'roster' || sub === 'intel') {
      if (!['police','royalguard'].includes(me.career)) return reply('🚔 Only Police Officers and Royal Guards can access the group intelligence roster.');
      try { const metadata = await sock.groupMetadata(jid); for (const member of (metadata.participants || [])) if (member.id) rp.user(jid, member.id); } catch {}
      const rows=rp.careerRoster(jid).sort((a,b)=>(b.wanted||0)-(a.wanted||0)).slice(0,60);
      if(!rows.length)return reply('No roleplay records have been created for this group yet. Members appear as they use the economy and roleplay commands.');
      return reply(`🗂️ *GROUP POLICE ROSTER*\nRecords: ${rows.length}\n\n${rows.map(v=>`${v.wanted?'🚨':'•'} @${num(v.jid)} | ${v.career?rp.CAREERS[v.career]?.name||v.career:'Unemployed'} | Wanted ${v.wanted}/5 | ${v.jailedUntil>Date.now()?'JAILED':'Free'} | Gang: ${rp.getGang(jid,v.jid)?.name||'None'}`).join('\n')}\n\nUse \`${prefix}wanted info @user\` for a full profile.`,{mentions:rows.map(v=>v.jid)});
    }
    if (sub === 'arrest') {
      const target = resolveTarget(msg, args.slice(1));
      if (!target) return reply(`Usage: \`${prefix}wanted arrest @user\``);
      if (!['police','royalguard'].includes(me.career)) return reply('🚔 Only Police Officers and Royal Guards can arrest wanted players. Apply with `.career apply police`.');
      if (rp.memberKey(target) === rp.memberKey(myJid)) return reply('You cannot arrest yourself.');
      const result = rp.arrest(jid, target, now);
      if (!result.ok) return reply(result.why === 'clean' ? `@${num(target)} has no active wanted level.` : `@${num(target)} is already in jail.`, { mentions: [target] });
      return reply(`🚔 *ARREST MADE*
👮 Officer: @${num(myJid)}
🚨 Suspect: @${num(target)}
⛓️ Jail time: ${left(result.duration)}
💵 Bail: ${fmt(result.bail)} coins
Use \`${prefix}wanted bail\` to get released early.`, { mentions: [myJid, target] });
    }
    const remaining = Math.max(0, (me.jailedUntil || 0) - now);
    return reply(`🚨 *WANTED STATUS*
Wanted level: *${me.wanted || 0}/5*${remaining ? `
⛓️ Jail: ${left(remaining)}
💵 Bail: ${fmt(me.bail || 0)} coins` : ''}

Crime raises your wanted level. Police Officers and Royal Guards can arrest wanted players.
• \`${prefix}wanted arrest @user\`
• \`${prefix}wanted bail\`
• Crime: \`${prefix}crime\``);
  }},
  { ...base, name: 'haunt', aliases: ['ghost'], description: 'Pay to send a ghost after a player for 30 minutes', async run({ args, reply, myJid, jid, msg }) {
    if ((args[0] || '').toLowerCase() === 'status') { const until = rp.user(jid, myJid).ghostUntil || 0; return reply(until > Date.now() ? `👻 A ghost is following you for ${left(until-Date.now())}.` : '👻 No ghost is following you right now.'); }
    const target = resolveTarget(msg, args);
    if (!target) return reply('👻 Tag a player to haunt: `.haunt @user` (cost: 250 coins, lasts 30 minutes).');
    if (rp.memberKey(target) === rp.memberKey(myJid)) return reply('You cannot haunt yourself. Tag another player.');
    if (economy.balance(myJid) < 250) return reply('👻 A haunting costs 250 coins. You do not have enough.');
    const victim = rp.user(jid, target), now = Date.now();
    if ((victim.ghostUntil || 0) > now) return reply(`👻 @${num(target)} already has a ghost following them for ${left(victim.ghostUntil-now)}.`, { mentions: [target] });
    economy.take(myJid, 250); victim.ghostUntil = now + 30 * 60000; rp.touch();
    return reply(`👻 *A ghost has chosen its victim!*
@${num(target)}, a ghost is following you for *30 minutes*.
The haunting ends automatically. Cost: 250 coins.`, { mentions: [target] });
  }},
  { ...base, name: 'nickname', aliases: ['nicktitle', 'paidnick'], description: 'Buy a roleplay nickname for one hour (500 coins)', async run({ args, reply, myJid, jid, prefix }) {
    const sub = (args[0] || '').toLowerCase(), u = rp.user(jid, myJid), now = Date.now();
    if (sub === 'status') {
      const active = rp.activeNickname(jid, myJid, now);
      return reply(active ? `🏷️ Your nickname is *${active}* for another ${left(u.nicknameUntil-now)}.` : `You have no active paid nickname. Set one for 500 coins with \`${prefix}nickname Professional Beggar\`.`);
    }
    const name = args.join(' ').trim();
    if (!name) return reply(`🏷️ *Paid nickname* costs 500 coins and lasts 1 hour.
Example: \`${prefix}nickname Professional Beggar 🥲\`
Check it: \`${prefix}nickname status\``);
    if (name.length > 32) return reply('Nickname must be 32 characters or fewer.');
    if (economy.balance(myJid) < 500) return reply('A paid nickname costs 500 coins. You do not have enough.');
    economy.take(myJid, 500); const result = rp.applyNickname(jid, myJid, name, now);
    return reply(`🏷️ *Nickname activated!*
Nickname: *${result.nickname}*
Duration: 1 hour
Paid: 500 coins
Use \`${prefix}nickname status\` to check the time left. This is an in-game nickname and does not change your WhatsApp profile name.`);
  }},
  { ...base, name: 'headline', aliases: ['breakingnews', 'newsflash'], description: 'Generate a funny breaking-news announcement for roleplay', async run({ args, reply, myJid, jid, msg }) {
    const target = resolveTarget(msg, args) || myJid;
    const stories = [
      (a) => `🚨 *BREAKING NEWS!*\n@${a} was caught arguing with their landlord over 50 coins. Their imaginary mansion has been seized.`,
      (a) => `🚨 *BREAKING NEWS!*\n@${a} has declared bankruptcy after buying suya for the entire neighbourhood. Treasury officials are confused.`,
      (a) => `🚨 *BREAKING NEWS!*\n@${a} was arrested for looking suspicious near a plate of jollof rice. The case is still under investigation.`,
      (a) => `🚨 *BREAKING NEWS!*\n@${a} has been promoted to Professional Beggar after asking three people for 10 coins each.`,
      (a) => `🚨 *BREAKING NEWS!*\n@${a} claims to own five mansions, but was seen negotiating a 2-coin discount.`,
    ];
    const text = stories[Math.floor(Math.random() * stories.length)](num(target));
    return reply(text, { mentions: [target] });
  }}
  ,
  { ...base, name: 'luxury', aliases: ['luxuries', 'flex'], description: 'Buy ultra-expensive collectibles and show your luxury collection', async run({ args, reply, myJid, jid, prefix }) {
    const sub=(args[0]||'list').toLowerCase(), u=rp.user(jid,myJid), owned=new Set(u.luxuries||[]);
    const total=[...owned].reduce((sum,id)=>sum+(rp.LUXURIES[id]?.cost||0),0);
    if(sub==='list' || sub==='shop') return reply(`💎 *LUXURY SHOP*\nMoney is getting serious. These purchases are permanent, group-specific, and cannot be resold.\n\n${Object.entries(rp.LUXURIES).map(([id,x])=>`${x.icon} *${x.name}* · ${fmt(x.cost)} coins · ${x.prestige} prestige${owned.has(id)?' · OWNED':''}\n   ID: ${id}`).join('\n')}\n\nBuy: \`${prefix}luxury buy supercar\`\nCollection: \`${prefix}luxury status\` • Group leaderboard: \`${prefix}luxury leaderboard\``);
    if(sub==='status' || sub==='collection') return reply(`💎 *YOUR LUXURY COLLECTION*\nOwned: ${owned.size}/${Object.keys(rp.LUXURIES).length}\nTotal spent: ${fmt(total)} coins\nPrestige: ${[...owned].reduce((sum,id)=>sum+(rp.LUXURIES[id]?.prestige||0),0)}\n${owned.size?[...owned].map(id=>`${rp.LUXURIES[id].icon} ${rp.LUXURIES[id].name}`).join('\n'):'No luxury assets yet.'}`);
    if(sub==='leaderboard' || sub==='top') {
      const rows=Object.values(rp.state(jid).users).map(x=>({jid:x.jid,items:x.luxuries||[],value:(x.luxuries||[]).reduce((sum,id)=>sum+(rp.LUXURIES[id]?.cost||0),0)})).filter(x=>x.jid&&x.value>0).sort((a,b)=>b.value-a.value).slice(0,10);
      return reply(`🏆 *LUXURY LEADERBOARD*\n${rows.length?rows.map((x,i)=>`${i+1}. @${num(x.jid)} · ${fmt(x.value)} coins spent · ${x.items.length} asset(s)`).join('\n'):'Nobody has purchased a luxury asset yet.'}`,{mentions:rows.map(x=>x.jid)});
    }
    if(sub==='buy') {
      const id=(args[1]||'').toLowerCase(), item=rp.LUXURIES[id];
      if(!item) return reply(`Choose an item from \`${prefix}luxury list\`.`);
      if(owned.has(id)) return reply(`You already own the ${item.name}. Each luxury asset can only be purchased once per group.`);
      if(economy.balance(myJid)<item.cost) return reply(`💸 The ${item.name} costs ${fmt(item.cost)} coins. Your wallet has ${fmt(economy.balance(myJid))}.`);
      if(!economy.take(myJid,item.cost)) return reply('Purchase failed. Check your available wallet balance.');
      u.luxuries.push(id); rp.touch();
      return reply(`${item.icon} *LUXURY PURCHASE CONFIRMED!*\n@${num(myJid)} has purchased a *${item.name}* for ${fmt(item.cost)} coins.\nPrestige earned: +${item.prestige}\nThis purchase is permanent and has been announced to the group.`,{mentions:[myJid]});
    }
    return reply(`Use \`${prefix}luxury list\`, \`${prefix}luxury buy <id>\`, \`${prefix}luxury status\` or \`${prefix}luxury leaderboard\`.`);
  }}
  ,
  { ...base, name: 'president', aliases: ['pres', 'presidency'], description: 'Group president: unlimited policy actions and salary', async run({ args, reply, myJid, jid, prefix, msg }) {
    const sub=(args[0]||'status').toLowerCase(), info=rp.presidentInfo(jid), p=info.president, tag=(x)=>`@${num(x)}`;
    const g=rp.state(jid), settings=rp.economySettings(jid), mention=(ids)=>({mentions:ids.filter(Boolean)});
    if (sub==='status' || sub==='') return reply(`🇳🇬 *GROUP PRESIDENCY*\nPresident: ${p ? `${tag(p.jid)} (term ${left(p.until-Date.now())} left)` : 'Vacant'}\nPresidential tax: ${info.tax}%\nCurfew: ${info.curfew>0?`${left(info.curfew)} remaining`:'inactive'}\nSalary: ${fmt(settings.presidentSalary)} every ${left(settings.presidentSalaryInterval)}\n\nTake office: \`${prefix}president take\` (cost ${fmt(info.cost)}, term 2 hours)\nPowers: \`${prefix}president king\` (inspect King settings), \`${prefix}president revoke tax|decree|peace|holiday|income|jail @user\` (remove one King setting), \`${prefix}president careersalary all 1000\`, \`${prefix}president salarylimit 5000\`, \`${prefix}president tax 10\`, \`${prefix}president salary\`, \`${prefix}president stimulus 100\`, \`${prefix}president grant @user 500\`, \`${prefix}president fine @user 500\`, \`${prefix}president curfew 60\`, \`${prefix}president pardon @user\`, \`${prefix}president bonus 100\`, \`${prefix}president decree message\`, \`${prefix}president law peace on\``, mention(p?[p.jid]:[]));
    if (sub==='take' || sub==='run') {
      const r=rp.takePresident(jid,myJid);
      if(!r.ok) { if (r.why==='occupied') return reply(`🇳🇬 The presidency is occupied by ${tag(r.president.jid)} for ${left(r.president.until-Date.now())}.`, {mentions:[r.president.jid]}); if (r.why==='gang') return reply('⚠️ A gang member cannot become President. Leave your gang first.'); if (r.why==='king') return reply('⚠️ The King cannot also become President. The offices must remain separate.'); return reply(`You need ${fmt(r.cost||rp.PRESIDENT_COST)} coins to take office.`); }
      return reply(`🇳🇬 *${tag(myJid)} IS NOW PRESIDENT OF THIS GROUP!*\nTerm: 2 hours\nSalary: ${fmt(settings.presidentSalary)} every ${left(settings.presidentSalaryInterval)}\nYou can set policy, fund grants and stimulus, fine or pardon players, set curfew and issue decrees.`,{mentions:[myJid]});
    }
    if(sub==='commands' || sub==='help') return reply(`🇳🇬 *PRESIDENTIAL POWERS*\n\`${prefix}president tax <0-100>\` – set the group earnings tax\n\`${prefix}president salary\` – check payroll\n\`${prefix}president stimulus <amount>\` – pay every registered player\n\`${prefix}president bonus <amount>\` – distribute a group bonus\n\`${prefix}president grant @user <amount>\` – fund one player\n\`${prefix}president fine @user <amount>\` – transfer a fine to the President\n\`${prefix}president pardon @user\` – clear wanted level and roleplay jail\n\`${prefix}president curfew <minutes>\` – suspend robbery; use 0 to lift\n\`${prefix}president law robbery|peace|payboost on|off\` – enact group-wide policy\n\`${prefix}president decree <message>\` – publish a decree\n\`${prefix}president king\` – inspect the King's current settings and active royal orders\n\`${prefix}president revoke tax|decree|peace|holiday|income\` – remove one specific King setting\n\`${prefix}president revoke jail @user\` – cancel one royal jail order\n\`${prefix}president careersalary <career|all> <amount>\` – raise career salaries\n\`${prefix}president salarylimit <amount>\` – set the maximum career salary, including rank bonuses. The King can also set the salary limit.`);
    if (!rp.isPresident(jid,myJid)) return reply('⚠️ *Only the current President of this group can use presidential powers.*');

    if(sub==='king' || sub==='kingstatus') { const t=require('../core/throne'), k=t.kingSettings(jid), i=t.info(jid); return reply(`👑 *KING'S SETTINGS / GOVERNMENT AUDIT*\nKing: ${i.king?tag(i.king.jid):'No King'}\nKing tax: ${k.tax}% (maximum ${i.maxTax}%)\nKing decree: ${k.decree||'None'}\nKing income: ${k.income} coins/hour\nPeace law: ${k.peace?left(k.peace)+' remaining':'Inactive'}\nBank holiday: ${k.holiday?left(k.holiday)+' remaining':'Inactive'}\nRoyal jail orders: ${k.jailCount}${k.jailed.length?'\n'+k.jailed.map(x=>`${tag(x.jid)} (${left(x.until-Date.now())})`).join('\n'):''}\nCareer salary cap: ${fmt(g.careerSalaryLimit)}\n\nRemove one item with \`${prefix}president revoke tax|decree|peace|holiday|income\` or \`${prefix}president revoke jail @user\`.`,{mentions:[i.king?.jid,...k.jailed.map(x=>x.jid)].filter(Boolean)}); }
    if(sub==='revoke' || sub==='remove') { const setting=(args[1]||'').toLowerCase(), target=setting==='jail'?resolveTarget(msg,args.slice(2)):null, r=require('../core/throne').removeKingSetting(jid,myJid,setting,target); if(!r.ok) return reply(({target:`Tag the player to remove their royal jail order: \`${prefix}president revoke jail @user\`.`,notjailed:'That player has no active royal jail order.',setting:`Choose one setting: tax, decree, peace, holiday, income, or jail @user.`})[r.why]||'Could not remove that King setting.'); return reply(`🏛️ *PRESIDENTIAL REVIEW*\nRemoved only the King's *${r.setting}* setting. Other royal settings remain unchanged.`); }
    if(sub==='careersalary' || sub==='careerpay') { const career=(args[1]||'').toLowerCase(), amount=Number(args[2]); if(!rp.setCareerSalary(jid,career,amount)) return reply(`Usage: \`${prefix}president careersalary <${Object.keys(rp.CAREERS).join('|')}|all> <amount>\` (1–1,000,000,000).`); return reply(`💼 *CAREER PAY REFORM*\n${career==='all'?'Every career':rp.CAREERS[career].name} base salary is now ${fmt(amount)} coins per 20 minutes. Rank bonuses still apply, subject to the group salary cap of ${fmt(g.careerSalaryLimit)}.`); }
    if(sub==='salarylimit' || sub==='paycap') { const amount=Number(args[1]); if(!rp.setCareerSalaryLimit(jid,amount)) return reply(`Usage: \`${prefix}president salarylimit <amount>\` (1–1,000,000,000).`); return reply(`💼 *CAREER SALARY CAP UPDATED*\nMaximum career salary per 20-minute interval is now ${fmt(amount)} coins, including rank bonuses. The King can also adjust this cap.`); }
    if(sub==='salary') { const amount=rp.collectPresidentSalary(jid) || (p && p.lastSalaryPaidAt > Date.now()-3000 ? p.lastSalaryPaid : 0); return reply(`💵 *PRESIDENTIAL PAYROLL*\nCollected this check: ${fmt(amount)} coins${amount?'':' (no new pay interval completed)'}\nRate: ${fmt(settings.presidentSalary)} every ${left(settings.presidentSalaryInterval)}.`); }
    if(sub==='tax') { const r=rp.setPresidentTax(jid,myJid,args[1]); return reply(r.ok?`🇳🇬 *POLICY UPDATED*\nPresidential tax is now ${r.tax}%. It applies to eligible group earnings and transfers the tax to the President.`:'Tax must be between 0 and 100%. Usage: president tax 10.'); }
    if(sub==='stimulus') { const amount=Math.floor(Number(args[1])); const r=rp.stimulus(jid,myJid,amount); if(!r.ok) return reply(r.why==='poor'?`Stimulus costs ${fmt(r.total)} coins for ${r.count} registered players.`:'Enter a positive whole-number amount per player.'); return reply(`💸 *PRESIDENTIAL STIMULUS*\n${r.count} registered players received ${fmt(r.perPerson)} coins each.\nTotal paid from your wallet: ${fmt(r.total)}.`); }
    if(sub==='grant') { const target=resolveTarget(msg,args.slice(1,-1)); const amount=Math.floor(Number(args[args.length-1])); if(!target||!Number.isSafeInteger(amount)||amount<1) return reply(`Usage: \`${prefix}president grant @user 500\`.`); if(!economy.take(myJid,amount)) return reply(`You need ${fmt(amount)} coins for this grant.`); economy.add(target,amount); return reply(`🇳🇬 *PRESIDENTIAL GRANT*\n${tag(target)} received ${fmt(amount)} coins from President ${tag(myJid)}.`,{mentions:[myJid,target]}); }
    if(sub==='fine') { const target=resolveTarget(msg,args.slice(1,-1)), amount=Math.floor(Number(args[args.length-1])); if(!target||!Number.isSafeInteger(amount)||amount<1) return reply(`Usage: \`${prefix}president fine @user 500\`.`); const paid=Math.min(amount,economy.balance(target)); if(!paid) return reply('That player has no wallet coins to fine.'); economy.take(target,paid); economy.add(myJid,paid); return reply(`⚖️ *PRESIDENTIAL FINE*\n${tag(target)} paid ${fmt(paid)} coins to the President.`,{mentions:[target,myJid]}); }
    if(sub==='pardon') { const target=resolveTarget(msg,args.slice(1)); if(!target) return reply(`Usage: \`${prefix}president pardon @user\`.`); const v=rp.user(jid,target); v.wanted=0; v.jailedUntil=0; v.bail=0; rp.touch(); return reply(`🕊️ *PRESIDENTIAL PARDON*\n${tag(target)} has been pardoned. Wanted level and roleplay jail have been cleared.`,{mentions:[target]}); }
    if(sub==='bonus') { const amount=Math.floor(Number(args[1])); if(!Number.isSafeInteger(amount)||amount<1) return reply(`Usage: \`${prefix}president bonus <amount-per-player>\`.`); const people=Object.values(g.users).map(u=>u.jid).filter(id=>id&&rp.memberKey(id)!==rp.memberKey(myJid)); const total=amount*people.length; if(!Number.isSafeInteger(total)||!economy.take(myJid,total)) return reply(`You need ${fmt(total)} coins to pay ${people.length} eligible players.`); for(const id of people)economy.add(id,amount); return reply(`🎁 *PRESIDENTIAL BONUS*\n${people.length} players received ${fmt(amount)} coins each.\nTotal paid: ${fmt(total)}.`,{mentions:people}); }
    if(sub==='curfew') { const minutes=args[1]===undefined?15:Number(args[1]); if(!Number.isFinite(minutes)||minutes<0||!Number.isSafeInteger(minutes)) return reply(`Usage: \`${prefix}president curfew <minutes>\` (use 0 to lift it).`); g.curfewUntil=minutes===0?0:Date.now()+minutes*60000; rp.touch(); return reply(minutes===0?'🌙 *CURFEW LIFTED.* Robbery and heists are permitted again.':`🌙 *PRESIDENTIAL CURFEW DECLARED!* Robbery and heists are suspended for ${minutes} minutes across this group.`); }
    if(sub==='law') { const law=(args[1]||'').toLowerCase(), value=(args[2]||'on').toLowerCase(); if(!['robbery','peace','payboost'].includes(law)||!['on','off'].includes(value)) return reply(`Usage: \`${prefix}president law robbery on|off\` (also peace or payboost).`); g.presidentialLaws||(g.presidentialLaws={}); g.presidentialLaws[law]=value==='on'; rp.touch(); return reply(`📜 *PRESIDENTIAL LAW*\n${law} is now ${value.toUpperCase()} in this group.`); }
    if(sub==='decree') { const text=args.slice(1).join(' ').trim().slice(0,1000); if(!text) return reply(`Usage: \`${prefix}president decree <message>\`.`); g.presidentialDecree=text; rp.touch(); return reply(`📜 *PRESIDENTIAL DECREE*\n${text}`); }
    return reply(`Use \`${prefix}president status\` or \`${prefix}president commands\` to see presidential powers.`);
  }}

];
