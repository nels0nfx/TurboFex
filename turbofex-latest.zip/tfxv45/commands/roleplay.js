// Careers provide repeatable income; gangs and territories add cooperative long-term progression.
const economy = require('../core/economy');
const rp = require('../core/roleplay');
const { num, resolveTarget } = require('../whatsapp/utils');
const base = { category: 'economy', everyone: true, groupOnly: true, needs: [], weight: 'light' };
const fmt = economy.fmt;
const left = (ms) => { const m = Math.max(1, Math.ceil(ms / 60000)); return m < 60 ? `${m}m` : `${Math.floor(m / 60)}h ${m % 60}m`; };
const who = (jid) => `@${num(jid)}`;
const SALARY_INTERVAL = 20 * 60000;
function resolve(group, key) { const result = rp.resolveWar(group, key); if (!result) return ''; return result.won ? `\n🏆 *Territory captured!* ${result.attacker} defeated ${result.defender}.` : `\n🛡️ *Territory defended!* ${result.defender} held the district.`; }
module.exports = [
  { ...base, name: 'career', aliases: ['careers', 'jobcareer'], description: 'Apply for a career, do duty, collect salary, or check your career', async run({ args, reply, myJid, jid, prefix, msg }) {
    const g = rp.state(jid), u = rp.user(jid, myJid), sub = (args[0] || '').toLowerCase(), role = (args[1] || '').toLowerCase();
    if (!sub || sub === 'list') return reply(`💼 *CAREER BOARD*\nChoose one career with \`${prefix}career apply police\`\n\n${Object.entries(rp.CAREERS).map(([k,c]) => `${c.icon} *${c.name}* · ${fmt(c.salary)} coins / 20m salary · ${fmt(c.duty)} duty pay\n   ID: ${k}`).join('\n')}\n\nUse \`${prefix}career status\`, \`${prefix}career duty\` and \`${prefix}career salary\`.`);
    if (sub === 'status') {
      if (!u.career || !rp.CAREERS[u.career]) return reply(`You have no career yet. Apply with \`${prefix}career apply police\`.`);
      const c = rp.CAREERS[u.career], wait = Math.max(0, SALARY_INTERVAL - (Date.now() - u.lastSalary));
      return reply(`${c.icon} *Career Record*\n*Career:* ${c.name}\n*Rank:* ${u.rank}\n*Duties completed:* ${u.duties}\n*Next salary:* ${wait ? `in ${left(wait)}` : 'ready to collect'}\n*Next promotion:* ${u.rank >= 5 ? 'Maximum rank' : `${Math.max(0, u.rank * 5 - u.duties)} more duties`}`);
    }
    if (sub === 'apply') {
      if (!rp.CAREERS[role]) return reply(`Choose a career ID from \`${prefix}career list\`.`);
      if (u.career) return reply(`You already work as *${rp.CAREERS[u.career].name}*. Use \`${prefix}career quit\` before changing careers.`);
      u.career = role; u.rank = 1; u.duties = 0; u.lastSalary = Date.now(); rp.touch();
      return reply(`✅ *Career accepted*\n${rp.CAREERS[role].icon} You are now a *${rp.CAREERS[role].name}*, Rank 1.\nComplete duties with \`${prefix}career duty\` and collect pay with \`${prefix}career salary\`. Salary accrues for up to 1 hour.`);
    }
    if (sub === 'quit') { if (!u.career) return reply('You do not have a career to quit.'); const old = rp.CAREERS[u.career].name; u.career = null; u.rank = 1; u.duties = 0; rp.touch(); return reply(`You have resigned from *${old}*. Your coins and other progress are unchanged.`); }
    if (sub === 'powers') return reply(`🏛️ *Career powers that affect the group*\n👮 Police: \`${prefix}career fine @user 500\` (transfer a fine, max 10,000).\n🩺 Doctor: \`${prefix}career treat @user\` (pay 500, give them 500 and remove a haunting).\n🛡️ Royal Guard: \`${prefix}career protect @user\` (protects from robbery for 30 minutes).\n🎖️ Soldier: \`${prefix}career patrol\` (reduce wanted level by 1 for every wanted player).\n🔧 Mechanic: \`${prefix}career repair @user\` (charges 2,000, pays the mechanic 1,500 and removes 500 from circulation).\n🕶️ Gang Operative: \`${prefix}career extort @user 500\` (attempt a risky transfer and gain wanted level).\nActions have cooldowns and require the matching career.`);
    if (['fine','treat','protect','patrol','repair','extort'].includes(sub)) {
      if (!u.career || !rp.CAREERS[u.career]) return reply(`Apply for a career first: \`${prefix}career apply police\`.`);
      const allowed = { fine: 'police', treat: 'doctor', protect: 'royalguard', patrol: 'soldier', repair: 'mechanic', extort: 'criminal' };
      if (u.career !== allowed[sub]) return reply(`Only a ${rp.CAREERS[allowed[sub]].name} can use this action. Your career is ${rp.CAREERS[u.career].name}.`);
      const now = Date.now();
      if (economy.jailLeft(myJid)) return reply('⛓️ You cannot use career powers while jailed.');
      if (sub === 'patrol') {
        const cd = now - (u.lastAction || 0); if (cd < 30 * 60000) return reply(`⏳ Patrol is ready in ${left(30*60000-cd)}.`);
        let reduced = 0; for (const member of Object.values(g.users)) if ((member.wanted || 0) > 0) { member.wanted -= 1; reduced++; }
        u.lastAction = now; rp.touch(); return reply(`🎖️ *City patrol complete.* Wanted levels were reduced for ${reduced} player(s) across this group.`);
      }
      const target = resolveTarget(msg, args.slice(1));
      if (!target) return reply(`Usage: \`${prefix}career ${sub} @user${sub==='fine' || sub==='extort' ? ' amount' : ''}\`.`);
      if (rp.memberKey(target) === rp.memberKey(myJid)) return reply('You cannot target yourself.');
      const victim = rp.user(jid, target);
      const cd = now - (u.lastAction || 0); if (cd < 30 * 60000) return reply(`⏳ This power is ready in ${left(30*60000-cd)}.`);
      if (sub === 'fine') {
        const amount = Math.floor(Number(args[args.length-1]));
        const wantedCap = Math.max(0, (victim.wanted || 0) * 2000);
        if (!(victim.wanted > 0)) return reply('👮 Police fines can only be issued to players with an active wanted level.');
        if (!Number.isSafeInteger(amount) || amount < 1 || amount > Math.min(10000, wantedCap)) return reply(`Fine must be 1–${Math.min(10000, wantedCap)} coins at this wanted level.`);
        const paid = Math.min(amount, economy.balance(target)); if (paid < 1) return reply('That player has no wallet coins to fine.');
        economy.take(target, paid); economy.add(myJid, paid); u.lastAction=now; rp.touch();
        return reply(`👮 *Fine issued*\nOfficer: ${who(myJid)}\nPlayer: ${who(target)}\nTransferred: ${fmt(paid)} coins`, { mentions: [myJid,target] });
      }
      if (sub === 'treat') {
        if (economy.balance(myJid) < 500) return reply('Treatment costs 500 coins.');
        economy.take(myJid,500); economy.add(target,500); victim.ghostUntil=0; victim.protectedUntil=Math.max(victim.protectedUntil||0,now+10*60000); u.lastAction=now; rp.touch();
        return reply(`🩺 *Treatment complete!*\n${who(target)} received 500 coins, their haunting was removed, and they have 10 minutes of robbery protection. Cost to doctor: 500 coins.`, { mentions: [myJid,target] });
      }
      if (sub === 'protect') {
        const until=rp.protect(jid,myJid,target,30*60000,now); u.lastAction=now; rp.touch();
        return reply(`🛡️ ${who(target)} is protected from robbery for 30 minutes by the Royal Guard.`, { mentions: [myJid,target] });
      }
      if (sub === 'repair') {
        const fee = 2000; if (economy.balance(target) < fee) return reply(`A repair costs ${fmt(fee)} coins. That player cannot afford it.`);
        economy.take(target, fee); economy.add(myJid, 1500); u.lastAction=now; rp.touch();
        return reply(`🔧 *Repair completed!*\n${who(myJid)} repaired ${who(target)}'s vehicle.\nCustomer paid: ${fmt(fee)} coins\nMechanic earned: 1,500 coins\nParts and workshop fee removed: 500 coins.`, {mentions:[myJid,target]});
      }
      if (sub === 'extort') {
        const amount=Math.floor(Number(args[args.length-1]));
        if (!Number.isSafeInteger(amount)||amount<100||amount>50000) return reply('Extortion amount must be 100–50,000 coins.');
        if (economy.balance(target)<amount) return reply('That player does not have enough coins for this extortion attempt.');
        u.lastAction=now; rp.addWanted(jid,myJid,1,now);
        if (Math.random()<0.6) { economy.take(target,amount); economy.add(myJid,amount); rp.touch(); return reply(`🕶️ *Extortion succeeded.* ${who(target)} lost ${fmt(amount)} coins. Your wanted level increased.`,{mentions:[myJid,target]}); }
        const fine=Math.min(5000,economy.balance(myJid)); if(fine){economy.take(myJid,fine);economy.add(target,fine);} rp.touch(); return reply(`🚨 *Extortion failed!* You were exposed and paid ${fmt(fine)} coins to ${who(target)}. Wanted level increased.`,{mentions:[myJid,target]});
      }
    }
    if (sub === 'duty') {
      const jailed = economy.jailLeft(myJid); if (jailed) return reply(`⛓️ You are in jail for another ${left(jailed)}. You cannot complete career duties yet.`);
      if (!u.career || !rp.CAREERS[u.career]) return reply(`Apply for a career first: \`${prefix}career apply police\`.`);
      const wait = rp.HOUR - (Date.now() - u.lastDuty); if (wait > 0) return reply(`⏳ Your next duty is available in ${left(wait)}.`);
      const c = rp.CAREERS[u.career], reward = c.duty + (u.rank - 1) * 25;
      u.lastDuty = Date.now(); u.duties += 1;
      const promoted = u.rank < 5 && u.duties >= u.rank * 5; if (promoted) u.rank += 1;
      economy.add(myJid, reward); economy.addRep(myJid, 1); rp.touch();
      return reply(`✅ *Duty completed*\n${c.icon} ${c.name} · Rank ${u.rank}\n*Earned:* +${fmt(reward)} coins\n*Reputation:* +1 ⭐${promoted ? `\n🎖️ *Promotion!* You reached Rank ${u.rank}.` : ''}\n*Duties:* ${u.duties}`);
    }
    if (sub === 'salary' || sub === 'collect') {
      if (!u.career || !rp.CAREERS[u.career]) return reply(`Apply for a career first: \`${prefix}career apply police\`.`);
      const now = Date.now(), elapsed = Math.min(60 * 60000, Math.max(0, now - (u.lastSalary || now))), units = Math.floor(elapsed / SALARY_INTERVAL);
      if (units < 1) return reply(`⏳ Your next salary is ready in ${left(SALARY_INTERVAL - (now - (u.lastSalary || now)))}. Salary accrues up to 1 hour.`);
      const amount = units * (rp.CAREERS[u.career].salary + (u.rank - 1) * 50); u.lastSalary = (now - (u.lastSalary || now) >= 60 * 60000) ? now : u.lastSalary + units * SALARY_INTERVAL; economy.add(myJid, amount); rp.touch();
      return reply(`💵 *Career salary collected*\n${rp.CAREERS[u.career].icon} ${rp.CAREERS[u.career].name} · Rank ${u.rank}\n*Paid:* +${fmt(amount)} coins\n*Next salary:* in 20 minutes (maximum 1 hour can accrue).`);
    }
    if (sub === 'promote') return reply(`Promotions happen automatically after every ${u.rank * 5} completed duties, up to Rank 5. Use \`${prefix}career duty\`.`);
    return reply(`Use \`${prefix}career list\`, \`${prefix}career apply police\`, \`${prefix}career duty\`, \`${prefix}career salary\`, \`${prefix}career status\` or \`${prefix}career quit\`.`);
  }},
  { ...base, name: 'gang', aliases: ['gangs'], description: 'Create or join a gang, view details, and manage gang funds', async run({ args, reply, myJid, jid, prefix }) {
    const g = rp.state(jid), u = rp.user(jid, myJid), sub = (args[0] || '').toLowerCase(), name = args.slice(1).join('').toLowerCase();
    if (!sub || sub === 'info') {
      const gang = rp.getGang(jid, myJid); if (!gang) return reply(`You are not in a gang.\nCreate one: \`${prefix}gang create name\`\nJoin one: \`${prefix}gang join name\``);
      return reply(`⚔️ *Gang: ${gang.name}*\n*Leader:* @${gang.leader}\n*Members:* ${gang.members.length}\n*Treasury:* ${fmt(gang.treasury)} coins\n\nUse \`${prefix}gang deposit 500\`, \`${prefix}gang withdraw 500\` (leader only) and \`${prefix}territory\`.`, { mentions: gang.members.map(x => `${x}@s.whatsapp.net`) });
    }
    if (sub === 'create') {
      const gangName = args.slice(1).join('').replace(/\s/g,''); if (economy.balance(myJid) < 1000) return reply('Creating a gang costs 1,000 coins.');
      const r = rp.makeGang(jid, myJid, gangName); if (!r.ok) return reply(({name:'Use a name with 3–20 letters/numbers.',member:'Leave your current gang first.',taken:'That gang name is already taken.'})[r.why] || 'Could not create that gang.');
      economy.take(myJid, 1000); return reply(`✅ *Gang created:* ${r.gang.name}\nCreation cost: 1,000 coins. Invite friends to join with \`${prefix}gang join ${r.gang.name}\`.`);
    }
    if (sub === 'join') { const key = args.slice(1).join('').toLowerCase(); const r = rp.joinGang(jid, myJid, key); if (!r.ok) return reply(({member:'You are already in a gang.',missing:'That gang does not exist.'})[r.why] || 'Could not join that gang.'); return reply(`⚔️ You joined *${r.gang.name}*. Use \`${prefix}territory\` to see the district map.`); }
    if (sub === 'leave') { const r = rp.leaveGang(jid, myJid); return reply(r.ok ? 'You left your gang.' : r.why === 'leader' ? 'Transfer leadership or ask members to leave before disbanding the gang.' : 'You are not in a gang.'); }
    const gang = rp.getGang(jid, myJid); if (!gang) return reply(`Join or create a gang first. Try \`${prefix}gang create name\`.`);
    if (sub === 'deposit') { const n = Number(args[1]); if (!Number.isSafeInteger(n) || n < 1 || !economy.take(myJid,n)) return reply('Enter a valid amount you can afford, e.g. gang deposit 500.'); gang.treasury += n; rp.touch(); return reply(`🏦 Added ${fmt(n)} coins to *${gang.name}* treasury.`); }
    if (sub === 'withdraw') { const n = Number(args[1]); if (gang.leader !== rp.memberKey(myJid)) return reply('Only the gang leader can withdraw treasury funds.'); if (!Number.isSafeInteger(n) || n < 1 || gang.treasury < n) return reply(`Treasury has ${fmt(gang.treasury)} coins. Use gang withdraw amount.`); gang.treasury -= n; economy.add(myJid,n); rp.touch(); return reply(`💰 Withdrawn ${fmt(n)} coins. Treasury: ${fmt(gang.treasury)}.`); }
    return reply(`Use \`${prefix}gang create name\`, \`${prefix}gang join name\`, \`${prefix}gang info\`, \`${prefix}gang deposit 500\`, \`${prefix}gang withdraw 500\` or \`${prefix}gang leave\`.`);
  }},
  { ...base, name: 'territory', aliases: ['territories', 'turf'], description: 'Claim districts, collect gang income, and fight territory wars', async run({ args, reply, myJid, jid, prefix }) {
    const g = rp.state(jid), sub = (args[0] || '').toLowerCase(), key = (args[1] || '').toLowerCase(), gang = rp.getGang(jid, myJid), now = Date.now();
    const warNotes = Object.keys(rp.DISTRICTS).map(k => resolve(jid,k)).join('');
    if (!sub || sub === 'map' || sub === 'list') return reply(`🗺️ *TERRITORY MAP*${warNotes}\n${Object.entries(rp.DISTRICTS).map(([k,d]) => { const t=g.territories[k]; const owner=t.gang && g.gangs[t.gang] ? g.gangs[t.gang].name : 'Neutral'; const war=t.war ? ` ⚔️ WAR (${left(t.war.endsAt-now)})` : ''; return `• *${d.name}* [${k}]\n  Owner: ${owner}${war}\n  Claim: ${fmt(d.cost)} · Income: ${fmt(d.income)} coins/hour`; }).join('\n')}\n\nClaim: \`${prefix}territory claim market\`\nChallenge: \`${prefix}territory war market\`\nAttack during war: \`${prefix}territory attack market\`\nCollect gang income: \`${prefix}territory collect\``);
    if (!gang) return reply(`You need a gang first: \`${prefix}gang create name\`.`);
    if (sub === 'claim') {
      const d=rp.DISTRICTS[key], t=g.territories[key]; if(!d||!t) return reply(`Choose a district from \`${prefix}territory map\`.`);
      if(gang.leader!==rp.memberKey(myJid)) return reply('Only the gang leader can claim territory.'); if(t.gang) return reply('That district is already controlled. Start a territory war instead.'); if(gang.treasury<d.cost) return reply(`Your gang treasury needs ${fmt(d.cost)} coins. Fund it with \`${prefix}gang deposit 500\`.`);
      gang.treasury-=d.cost; t.gang=gang.key; t.paidAt=now; rp.touch(); return reply(`🏴 *${d.name} claimed!*\n*Gang:* ${gang.name}\n*Cost:* ${fmt(d.cost)} from gang treasury\n*Income:* ${fmt(d.income)} coins/hour, collected into the gang treasury.`);
    }
    if (sub === 'collect') {
      let total=0; for(const [k,d] of Object.entries(rp.DISTRICTS)){ const t=g.territories[k]; if(t.gang!==gang.key) continue; const elapsed=Math.min(12*rp.HOUR,Math.max(0,now-(t.paidAt||now))); const hrs=Math.floor(elapsed/rp.HOUR); if(hrs>0){const amount=hrs*d.income; gang.treasury+=amount; t.paidAt = elapsed >= 12*rp.HOUR ? now : t.paidAt + hrs*rp.HOUR; total+=amount;} }
      rp.touch(); return reply(`💰 *Territory income collected*\nGang: ${gang.name}\nAdded: ${fmt(total)} coins to treasury${total ? '' : '\nNo income ready yet. Territory income accrues hourly, capped at 12 hours.'}\nTreasury: ${fmt(gang.treasury)} coins.`);
    }
    if (sub === 'war') {
      const d=rp.DISTRICTS[key], t=g.territories[key]; if(!d||!t) return reply(`Choose a district from \`${prefix}territory map\`.`); if(!t.gang || !g.gangs[t.gang]) return reply('That district is neutral. Claim it instead.'); if(t.gang===gang.key) return reply('Your gang already controls that district.'); if(t.war) return reply('A war is already active for that district.'); if(gang.leader!==rp.memberKey(myJid)) return reply('Only the gang leader can declare a territory war.');
      t.war={attacker:gang.key, defender:t.gang, attackScore:0, defendScore:0, endsAt:now+10*60000, startedAt:now, fighters:{}}; rp.touch(); return reply(`⚔️ *TERRITORY WAR DECLARED*\n${gang.name} challenges ${g.gangs[t.gang].name} for *${d.name}*.\nWar lasts 10 minutes. Both gangs can use \`${prefix}territory attack ${key}\` to fight. Each member can fight once per war.`);
    }
    if (sub === 'attack') {
      const d=rp.DISTRICTS[key], t=g.territories[key], w=t&&t.war; if(!d||!w) return reply('There is no active war for that district. Check territory map.'); if(now>=w.endsAt){ const r=rp.resolveWar(jid,key,now); return reply(r ? (r.won ? `🏆 ${r.attacker} captured ${d.name}!` : `🛡️ ${r.defender} defended ${d.name}.`) : 'The war has ended.'); }
      const side=gang.key===w.attacker?'attack':gang.key===w.defender?'defend':null; if(!side) return reply('Your gang is not part of this war.'); const member=rp.memberKey(myJid); if(w.fighters[member]) return reply('You have already fought in this war.'); const power=1+Math.floor(Math.random()*3); w.fighters[member]=side; if(side==='attack') w.attackScore+=power; else w.defendScore+=power; rp.touch(); return reply(`⚔️ *Fight recorded!*\n${side==='attack'?'Attacking':'Defending'} ${d.name}\nPower: ${power}\nScore: ${w.attacker} ${w.attackScore} · ${w.defender} ${w.defendScore}\nTime left: ${left(w.endsAt-now)}.`);
    }
    return reply(`Use \`${prefix}territory map\`, \`${prefix}territory claim market\`, \`${prefix}territory war market\`, \`${prefix}territory attack market\` or \`${prefix}territory collect\`.`);
  }}
  ,
  { ...base, name: 'wanted', aliases: ['wantedlevel', 'policecheck'], description: 'Check wanted level, arrest criminals as police/royal guard, or pay bail', async run({ args, reply, myJid, jid, msg, prefix }) {
    const sub = (args[0] || 'status').toLowerCase();
    const me = rp.user(jid, myJid), now = Date.now();
    if (sub === 'bail') {
      if (!(me.jailedUntil > now)) { me.jailedUntil = 0; me.bail = 0; rp.touch(); return reply('✅ You are not in crime-system jail.'); }
      const amount = Math.max(0, me.bail || 0);
      if (economy.balance(myJid) < amount) return reply(`⛓️ You are jailed for ${left(me.jailedUntil-now)}. Bail costs ${fmt(amount)} coins; your wallet has ${fmt(economy.balance(myJid))}.`);
      economy.take(myJid, amount); rp.payBail(jid, myJid, now);
      return reply(`🔓 *Bail paid!* You are free.
Paid: ${fmt(amount)} coins
Wanted level reset. Keep out of trouble.`);
    }
    if (sub === 'arrest') {
      const target = resolveTarget(msg, args.slice(1));
      if (!target) return reply(`Usage: \`${prefix}wanted arrest @user\``);
      if (!['police','royalguard'].includes(me.career)) return reply('🚔 Only Police Officers and Royal Guards can arrest wanted players. Apply with `.career apply police`.');
      if (rp.memberKey(target) === rp.memberKey(myJid)) return reply('You cannot arrest yourself.');
      const result = rp.arrest(jid, target, now);
      if (!result.ok) return reply(result.why === 'clean' ? `@${num(target)} has no active wanted level.` : `@${num(target)} is already in jail.`, { mentions: [target] });
      return reply(`🚔 *ARREST MADE*
👮 Officer: @${num(myJid)}
🚨 Suspect: @${num(target)}
⛓️ Jail time: ${left(result.duration)}
💵 Bail: ${fmt(result.bail)} coins
Use \`${prefix}wanted bail\` to get released early.`, { mentions: [myJid, target] });
    }
    const remaining = Math.max(0, (me.jailedUntil || 0) - now);
    return reply(`🚨 *WANTED STATUS*
Wanted level: *${me.wanted || 0}/5*${remaining ? `
⛓️ Jail: ${left(remaining)}
💵 Bail: ${fmt(me.bail || 0)} coins` : ''}

Crime raises your wanted level. Police Officers and Royal Guards can arrest wanted players.
• \`${prefix}wanted arrest @user\`
• \`${prefix}wanted bail\`
• Crime: \`${prefix}crime\``);
  }},
  { ...base, name: 'haunt', aliases: ['ghost'], description: 'Pay to send a ghost after a player for 30 minutes', async run({ args, reply, myJid, jid, msg }) {
    if ((args[0] || '').toLowerCase() === 'status') { const until = rp.user(jid, myJid).ghostUntil || 0; return reply(until > Date.now() ? `👻 A ghost is following you for ${left(until-Date.now())}.` : '👻 No ghost is following you right now.'); }
    const target = resolveTarget(msg, args);
    if (!target) return reply('👻 Tag a player to haunt: `.haunt @user` (cost: 250 coins, lasts 30 minutes).');
    if (rp.memberKey(target) === rp.memberKey(myJid)) return reply('You cannot haunt yourself. Tag another player.');
    if (economy.balance(myJid) < 250) return reply('👻 A haunting costs 250 coins. You do not have enough.');
    const victim = rp.user(jid, target), now = Date.now();
    if ((victim.ghostUntil || 0) > now) return reply(`👻 @${num(target)} already has a ghost following them for ${left(victim.ghostUntil-now)}.`, { mentions: [target] });
    economy.take(myJid, 250); victim.ghostUntil = now + 30 * 60000; rp.touch();
    return reply(`👻 *A ghost has chosen its victim!*
@${num(target)}, a ghost is following you for *30 minutes*.
The haunting ends automatically. Cost: 250 coins.`, { mentions: [target] });
  }},
  { ...base, name: 'nickname', aliases: ['nicktitle', 'paidnick'], description: 'Buy a roleplay nickname for one hour (500 coins)', async run({ args, reply, myJid, jid, prefix }) {
    const sub = (args[0] || '').toLowerCase(), u = rp.user(jid, myJid), now = Date.now();
    if (sub === 'status') {
      const active = rp.activeNickname(jid, myJid, now);
      return reply(active ? `🏷️ Your nickname is *${active}* for another ${left(u.nicknameUntil-now)}.` : `You have no active paid nickname. Set one for 500 coins with \`${prefix}nickname Professional Beggar\`.`);
    }
    const name = args.join(' ').trim();
    if (!name) return reply(`🏷️ *Paid nickname* costs 500 coins and lasts 1 hour.
Example: \`${prefix}nickname Professional Beggar 🥲\`
Check it: \`${prefix}nickname status\``);
    if (name.length > 32) return reply('Nickname must be 32 characters or fewer.');
    if (economy.balance(myJid) < 500) return reply('A paid nickname costs 500 coins. You do not have enough.');
    economy.take(myJid, 500); const result = rp.applyNickname(jid, myJid, name, now);
    return reply(`🏷️ *Nickname activated!*
Nickname: *${result.nickname}*
Duration: 1 hour
Paid: 500 coins
Use \`${prefix}nickname status\` to check the time left. This is an in-game nickname and does not change your WhatsApp profile name.`);
  }},
  { ...base, name: 'headline', aliases: ['breakingnews', 'newsflash'], description: 'Generate a funny breaking-news announcement for roleplay', async run({ args, reply, myJid, jid, msg }) {
    const target = resolveTarget(msg, args) || myJid;
    const stories = [
      (a) => `🚨 *BREAKING NEWS!*\n@${a} was caught arguing with their landlord over 50 coins. Their imaginary mansion has been seized.`,
      (a) => `🚨 *BREAKING NEWS!*\n@${a} has declared bankruptcy after buying suya for the entire neighbourhood. Treasury officials are confused.`,
      (a) => `🚨 *BREAKING NEWS!*\n@${a} was arrested for looking suspicious near a plate of jollof rice. The case is still under investigation.`,
      (a) => `🚨 *BREAKING NEWS!*\n@${a} has been promoted to Professional Beggar after asking three people for 10 coins each.`,
      (a) => `🚨 *BREAKING NEWS!*\n@${a} claims to own five mansions, but was seen negotiating a 2-coin discount.`,
    ];
    const text = stories[Math.floor(Math.random() * stories.length)](num(target));
    return reply(text, { mentions: [target] });
  }}
  ,
  { ...base, name: 'luxury', aliases: ['luxuries', 'flex'], description: 'Buy ultra-expensive collectibles and show your luxury collection', async run({ args, reply, myJid, jid, prefix }) {
    const sub=(args[0]||'list').toLowerCase(), u=rp.user(jid,myJid), owned=new Set(u.luxuries||[]);
    const total=[...owned].reduce((sum,id)=>sum+(rp.LUXURIES[id]?.cost||0),0);
    if(sub==='list' || sub==='shop') return reply(`💎 *LUXURY MARKET*\nMoney is getting serious. These purchases are permanent, group-specific, and cannot be resold.\n\n${Object.entries(rp.LUXURIES).map(([id,x])=>`${x.icon} *${x.name}* · ${fmt(x.cost)} coins · ${x.prestige} prestige${owned.has(id)?' · OWNED':''}\n   ID: ${id}`).join('\n')}\n\nBuy: \`${prefix}luxury buy supercar\`\nCollection: \`${prefix}luxury status\` • Group leaderboard: \`${prefix}luxury leaderboard\``);
    if(sub==='status' || sub==='collection') return reply(`💎 *YOUR LUXURY COLLECTION*\nOwned: ${owned.size}/${Object.keys(rp.LUXURIES).length}\nTotal spent: ${fmt(total)} coins\nPrestige: ${[...owned].reduce((sum,id)=>sum+(rp.LUXURIES[id]?.prestige||0),0)}\n${owned.size?[...owned].map(id=>`${rp.LUXURIES[id].icon} ${rp.LUXURIES[id].name}`).join('\n'):'No luxury assets yet.'}`);
    if(sub==='leaderboard' || sub==='top') {
      const rows=Object.values(rp.state(jid).users).map(x=>({jid:x.jid,items:x.luxuries||[],value:(x.luxuries||[]).reduce((sum,id)=>sum+(rp.LUXURIES[id]?.cost||0),0)})).filter(x=>x.jid&&x.value>0).sort((a,b)=>b.value-a.value).slice(0,10);
      return reply(`🏆 *LUXURY LEADERBOARD*\n${rows.length?rows.map((x,i)=>`${i+1}. @${num(x.jid)} · ${fmt(x.value)} coins spent · ${x.items.length} asset(s)`).join('\n'):'Nobody has purchased a luxury asset yet.'}`,{mentions:rows.map(x=>x.jid)});
    }
    if(sub==='buy') {
      const id=(args[1]||'').toLowerCase(), item=rp.LUXURIES[id];
      if(!item) return reply(`Choose an item from \`${prefix}luxury list\`.`);
      if(owned.has(id)) return reply(`You already own the ${item.name}. Each luxury asset can only be purchased once per group.`);
      if(economy.balance(myJid)<item.cost) return reply(`💸 The ${item.name} costs ${fmt(item.cost)} coins. Your wallet has ${fmt(economy.balance(myJid))}.`);
      if(!economy.take(myJid,item.cost)) return reply('Purchase failed. Check your available wallet balance.');
      u.luxuries.push(id); rp.touch();
      return reply(`${item.icon} *LUXURY PURCHASE CONFIRMED!*\n@${num(myJid)} has purchased a *${item.name}* for ${fmt(item.cost)} coins.\nPrestige earned: +${item.prestige}\nThis purchase is permanent and has been announced to the group.`,{mentions:[myJid]});
    }
    return reply(`Use \`${prefix}luxury list\`, \`${prefix}luxury buy <id>\`, \`${prefix}luxury status\` or \`${prefix}luxury leaderboard\`.`);
  }}
  ,
  { ...base, name: 'president', aliases: ['pres', 'presidency'], description: 'Group president: policies, stimulus, curfew and grants', async run({ args, reply, myJid, jid, prefix, msg }) {
    const sub=(args[0]||'status').toLowerCase(), info=rp.presidentInfo(jid), p=info.president, me=rp.memberKey(myJid), tag=(x)=>`@${num(x)}`;
    if (sub==='status' || sub==='') return reply(`🇳🇬 *GROUP PRESIDENCY*\nPresident: ${p ? `${tag(p.jid)} (term ${left(p.until-Date.now())} left)` : 'Vacant'}\nPresidential tax: ${info.tax}%\nCurfew: ${info.curfew>0?`${left(info.curfew)} remaining`:'inactive'}\n\nTake office: \`${prefix}president take\` (cost ${fmt(info.cost)}, term 2 hours)\nPowers: \`${prefix}president tax 3\`, \`${prefix}president stimulus 100\`, \`${prefix}president grant @user 500\`, \`${prefix}president curfew\`, \`${prefix}president decree message\``, {mentions:p?[p.jid]:[]});
    if (sub==='take' || sub==='run') { const r=rp.takePresident(jid,myJid); if(!r.ok) return reply(r.why==='occupied'?`🇳🇬 The presidency is occupied by ${tag(r.president.jid)} for ${left(r.president.until-Date.now())}.`:`You need ${fmt(r.cost||rp.PRESIDENT_COST)} coins to take office.`); return reply(`🇳🇬 *${tag(myJid)} is now President of this group!*\nTerm: 2 hours\nYou can set policy, distribute stimulus, issue grants and declare a curfew.`,{mentions:[myJid]}); }
    if (!rp.isPresident(jid,myJid)) return reply('Only the current group President can use presidential powers.');
    const g=rp.state(jid);
    if(sub==='tax') { const r=rp.setPresidentTax(jid,myJid,args[1]); return reply(r.ok?`🇳🇬 Presidential tax is now ${r.tax}%. It applies to eligible group earnings and is paid to the President.`:'Tax must be between 0 and 5%. Usage: president tax 3.'); }
    if(sub==='stimulus') { const amount=Math.floor(Number(args[1])); const r=rp.stimulus(jid,myJid,amount); if(!r.ok) return reply(r.why==='poor'?`Stimulus costs ${fmt(r.total)} coins for ${r.count} registered players.`:'Enter a per-player amount from 1 to 1,000,000.'); return reply(`💸 *PRESIDENTIAL STIMULUS*\n${r.count} registered players received ${fmt(r.perPerson)} coins each.\nTotal paid from your wallet: ${fmt(r.total)}.`); }
    if(sub==='grant') { const target=resolveTarget(msg,args.slice(1,-1)); const amount=Math.floor(Number(args[args.length-1])); if(!target||!Number.isSafeInteger(amount)||amount<1||amount>1000000) return reply(`Usage: \`${prefix}president grant @user 500\`.`); if(!economy.take(myJid,amount)) return reply(`You need ${fmt(amount)} coins for this grant.`); economy.add(target,amount); return reply(`🇳🇬 Presidential grant: ${tag(target)} received ${fmt(amount)} coins from the President.`,{mentions:[myJid,target]}); }
    if(sub==='curfew') { const active=g.curfewUntil>Date.now(); if(active) { g.curfewUntil=0; rp.touch(); return reply('🌙 Presidential curfew lifted. Robbery and heists are permitted again.'); } g.curfewUntil=Date.now()+15*60000; rp.touch(); return reply('🌙 *PRESIDENTIAL CURFEW DECLARED!* Robbery and heists are suspended for 15 minutes across this group.'); }
    if(sub==='decree') { const text=args.slice(1).join(' ').trim().slice(0,250); if(!text) return reply(`Usage: \`${prefix}president decree <message>\`.`); g.presidentialDecree=text; rp.touch(); return reply(`📜 *PRESIDENTIAL DECREE*\n${text}`); }
    return reply(`Use \`${prefix}president status\`, take, tax 3, stimulus 100, grant @user 500, curfew or decree message.`);
  }}
];
