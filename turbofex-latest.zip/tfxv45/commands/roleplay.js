// Careers provide repeatable income; gangs and territories add cooperative long-term progression.
const economy = require('../core/economy');
const rp = require('../core/roleplay');
const { num, resolveTarget } = require('../whatsapp/utils');
const base = { category: 'economy', everyone: true, groupOnly: true, needs: [], weight: 'light' };
const fmt = economy.fmt;
const left = (ms) => { const m = Math.max(1, Math.ceil(ms / 60000)); return m < 60 ? `${m}m` : `${Math.floor(m / 60)}h ${m % 60}m`; };
const who = (jid) => `@${num(jid)}`;
function resolve(group, key) { const result = rp.resolveWar(group, key); if (!result) return ''; return result.won ? `\n🏆 *Territory captured!* ${result.attacker} defeated ${result.defender}.` : `\n🛡️ *Territory defended!* ${result.defender} held the district.`; }
module.exports = [
  { ...base, name: 'career', aliases: ['careers', 'jobcareer'], description: 'Apply for a career, do duty, collect salary, or check your career', async run({ args, reply, myJid, jid, prefix }) {
    const g = rp.state(jid), u = rp.user(jid, myJid), sub = (args[0] || '').toLowerCase(), role = (args[1] || '').toLowerCase();
    if (!sub || sub === 'list') return reply(`💼 *CAREER BOARD*\nChoose one career with \`${prefix}career apply police\`\n\n${Object.entries(rp.CAREERS).map(([k,c]) => `${c.icon} *${c.name}* · ${fmt(c.salary)} coins / 6h salary · ${fmt(c.duty)} duty pay\n   ID: ${k}`).join('\n')}\n\nUse \`${prefix}career status\`, \`${prefix}career duty\` and \`${prefix}career salary\`.`);
    if (sub === 'status') {
      if (!u.career || !rp.CAREERS[u.career]) return reply(`You have no career yet. Apply with \`${prefix}career apply police\`.`);
      const c = rp.CAREERS[u.career], wait = Math.max(0, 6 * rp.HOUR - (Date.now() - u.lastSalary));
      return reply(`${c.icon} *Career Record*\n*Career:* ${c.name}\n*Rank:* ${u.rank}\n*Duties completed:* ${u.duties}\n*Next salary:* ${wait ? `in ${left(wait)}` : 'ready to collect'}\n*Next promotion:* ${u.rank >= 5 ? 'Maximum rank' : `${Math.max(0, u.rank * 5 - u.duties)} more duties`}`);
    }
    if (sub === 'apply') {
      if (!rp.CAREERS[role]) return reply(`Choose a career ID from \`${prefix}career list\`.`);
      if (u.career) return reply(`You already work as *${rp.CAREERS[u.career].name}*. Use \`${prefix}career quit\` before changing careers.`);
      u.career = role; u.rank = 1; u.duties = 0; u.lastSalary = Date.now(); rp.touch();
      return reply(`✅ *Career accepted*\n${rp.CAREERS[role].icon} You are now a *${rp.CAREERS[role].name}*, Rank 1.\nComplete duties with \`${prefix}career duty\` and collect pay with \`${prefix}career salary\`. Salary accrues for up to 12 hours.`);
    }
    if (sub === 'quit') { if (!u.career) return reply('You do not have a career to quit.'); const old = rp.CAREERS[u.career].name; u.career = null; u.rank = 1; u.duties = 0; rp.touch(); return reply(`You have resigned from *${old}*. Your coins and other progress are unchanged.`); }
    if (sub === 'duty') {
      const jailed = economy.jailLeft(myJid); if (jailed) return reply(`⛓️ You are in jail for another ${left(jailed)}. You cannot complete career duties yet.`);
      if (!u.career || !rp.CAREERS[u.career]) return reply(`Apply for a career first: \`${prefix}career apply police\`.`);
      const wait = rp.HOUR - (Date.now() - u.lastDuty); if (wait > 0) return reply(`⏳ Your next duty is available in ${left(wait)}.`);
      const c = rp.CAREERS[u.career], reward = c.duty + (u.rank - 1) * 25;
      u.lastDuty = Date.now(); u.duties += 1;
      const promoted = u.rank < 5 && u.duties >= u.rank * 5; if (promoted) u.rank += 1;
      economy.add(myJid, reward); economy.addRep(myJid, 1); rp.touch();
      return reply(`✅ *Duty completed*\n${c.icon} ${c.name} · Rank ${u.rank}\n*Earned:* +${fmt(reward)} coins\n*Reputation:* +1 ⭐${promoted ? `\n🎖️ *Promotion!* You reached Rank ${u.rank}.` : ''}\n*Duties:* ${u.duties}`);
    }
    if (sub === 'salary' || sub === 'collect') {
      if (!u.career || !rp.CAREERS[u.career]) return reply(`Apply for a career first: \`${prefix}career apply police\`.`);
      const now = Date.now(), elapsed = Math.min(12 * rp.HOUR, Math.max(0, now - (u.lastSalary || now))), units = Math.floor(elapsed / (6 * rp.HOUR));
      if (units < 1) return reply(`⏳ Your next salary is ready in ${left(6 * rp.HOUR - (now - (u.lastSalary || now)))}. Salary accrues up to 12 hours.`);
      const amount = units * (rp.CAREERS[u.career].salary + (u.rank - 1) * 50); u.lastSalary = (now - (u.lastSalary || now) >= 12 * rp.HOUR) ? now : u.lastSalary + units * 6 * rp.HOUR; economy.add(myJid, amount); rp.touch();
      return reply(`💵 *Career salary collected*\n${rp.CAREERS[u.career].icon} ${rp.CAREERS[u.career].name} · Rank ${u.rank}\n*Paid:* +${fmt(amount)} coins\n*Next salary:* in 6 hours (maximum 12 hours can accrue).`);
    }
    if (sub === 'promote') return reply(`Promotions happen automatically after every ${u.rank * 5} completed duties, up to Rank 5. Use \`${prefix}career duty\`.`);
    return reply(`Use \`${prefix}career list\`, \`${prefix}career apply police\`, \`${prefix}career duty\`, \`${prefix}career salary\`, \`${prefix}career status\` or \`${prefix}career quit\`.`);
  }},
  { ...base, name: 'gang', aliases: ['gangs'], description: 'Create or join a gang, view details, and manage gang funds', async run({ args, reply, myJid, jid, prefix }) {
    const g = rp.state(jid), u = rp.user(jid, myJid), sub = (args[0] || '').toLowerCase(), name = args.slice(1).join('').toLowerCase();
    if (!sub || sub === 'info') {
      const gang = rp.getGang(jid, myJid); if (!gang) return reply(`You are not in a gang.\nCreate one: \`${prefix}gang create name\`\nJoin one: \`${prefix}gang join name\``);
      return reply(`⚔️ *Gang: ${gang.name}*\n*Leader:* @${gang.leader}\n*Members:* ${gang.members.length}\n*Treasury:* ${fmt(gang.treasury)} coins\n\nUse \`${prefix}gang deposit 500\`, \`${prefix}gang withdraw 500\` (leader only) and \`${prefix}territory\`.`, { mentions: gang.members.map(x => `${x}@s.whatsapp.net`) });
    }
    if (sub === 'create') {
      const gangName = args.slice(1).join('').replace(/\s/g,''); if (economy.balance(myJid) < 1000) return reply('Creating a gang costs 1,000 coins.');
      const r = rp.makeGang(jid, myJid, gangName); if (!r.ok) return reply(({name:'Use a name with 3–20 letters/numbers.',member:'Leave your current gang first.',taken:'That gang name is already taken.'})[r.why] || 'Could not create that gang.');
      economy.take(myJid, 1000); return reply(`✅ *Gang created:* ${r.gang.name}\nCreation cost: 1,000 coins. Invite friends to join with \`${prefix}gang join ${r.gang.name}\`.`);
    }
    if (sub === 'join') { const key = args.slice(1).join('').toLowerCase(); const r = rp.joinGang(jid, myJid, key); if (!r.ok) return reply(({member:'You are already in a gang.',missing:'That gang does not exist.'})[r.why] || 'Could not join that gang.'); return reply(`⚔️ You joined *${r.gang.name}*. Use \`${prefix}territory\` to see the district map.`); }
    if (sub === 'leave') { const r = rp.leaveGang(jid, myJid); return reply(r.ok ? 'You left your gang.' : r.why === 'leader' ? 'Transfer leadership or ask members to leave before disbanding the gang.' : 'You are not in a gang.'); }
    const gang = rp.getGang(jid, myJid); if (!gang) return reply(`Join or create a gang first. Try \`${prefix}gang create name\`.`);
    if (sub === 'deposit') { const n = Number(args[1]); if (!Number.isSafeInteger(n) || n < 1 || !economy.take(myJid,n)) return reply('Enter a valid amount you can afford, e.g. gang deposit 500.'); gang.treasury += n; rp.touch(); return reply(`🏦 Added ${fmt(n)} coins to *${gang.name}* treasury.`); }
    if (sub === 'withdraw') { const n = Number(args[1]); if (gang.leader !== rp.memberKey(myJid)) return reply('Only the gang leader can withdraw treasury funds.'); if (!Number.isSafeInteger(n) || n < 1 || gang.treasury < n) return reply(`Treasury has ${fmt(gang.treasury)} coins. Use gang withdraw amount.`); gang.treasury -= n; economy.add(myJid,n); rp.touch(); return reply(`💰 Withdrawn ${fmt(n)} coins. Treasury: ${fmt(gang.treasury)}.`); }
    return reply(`Use \`${prefix}gang create name\`, \`${prefix}gang join name\`, \`${prefix}gang info\`, \`${prefix}gang deposit 500\`, \`${prefix}gang withdraw 500\` or \`${prefix}gang leave\`.`);
  }},
  { ...base, name: 'territory', aliases: ['territories', 'turf'], description: 'Claim districts, collect gang income, and fight territory wars', async run({ args, reply, myJid, jid, prefix }) {
    const g = rp.state(jid), sub = (args[0] || '').toLowerCase(), key = (args[1] || '').toLowerCase(), gang = rp.getGang(jid, myJid), now = Date.now();
    const warNotes = Object.keys(rp.DISTRICTS).map(k => resolve(jid,k)).join('');
    if (!sub || sub === 'map' || sub === 'list') return reply(`🗺️ *TERRITORY MAP*${warNotes}\n${Object.entries(rp.DISTRICTS).map(([k,d]) => { const t=g.territories[k]; const owner=t.gang && g.gangs[t.gang] ? g.gangs[t.gang].name : 'Neutral'; const war=t.war ? ` ⚔️ WAR (${left(t.war.endsAt-now)})` : ''; return `• *${d.name}* [${k}]\n  Owner: ${owner}${war}\n  Claim: ${fmt(d.cost)} · Income: ${fmt(d.income)} coins/hour`; }).join('\n')}\n\nClaim: \`${prefix}territory claim market\`\nChallenge: \`${prefix}territory war market\`\nAttack during war: \`${prefix}territory attack market\`\nCollect gang income: \`${prefix}territory collect\``);
    if (!gang) return reply(`You need a gang first: \`${prefix}gang create name\`.`);
    if (sub === 'claim') {
      const d=rp.DISTRICTS[key], t=g.territories[key]; if(!d||!t) return reply(`Choose a district from \`${prefix}territory map\`.`);
      if(gang.leader!==rp.memberKey(myJid)) return reply('Only the gang leader can claim territory.'); if(t.gang) return reply('That district is already controlled. Start a territory war instead.'); if(gang.treasury<d.cost) return reply(`Your gang treasury needs ${fmt(d.cost)} coins. Fund it with \`${prefix}gang deposit 500\`.`);
      gang.treasury-=d.cost; t.gang=gang.key; t.paidAt=now; rp.touch(); return reply(`🏴 *${d.name} claimed!*\n*Gang:* ${gang.name}\n*Cost:* ${fmt(d.cost)} from gang treasury\n*Income:* ${fmt(d.income)} coins/hour, collected into the gang treasury.`);
    }
    if (sub === 'collect') {
      let total=0; for(const [k,d] of Object.entries(rp.DISTRICTS)){ const t=g.territories[k]; if(t.gang!==gang.key) continue; const elapsed=Math.min(12*rp.HOUR,Math.max(0,now-(t.paidAt||now))); const hrs=Math.floor(elapsed/rp.HOUR); if(hrs>0){const amount=hrs*d.income; gang.treasury+=amount; t.paidAt = elapsed >= 12*rp.HOUR ? now : t.paidAt + hrs*rp.HOUR; total+=amount;} }
      rp.touch(); return reply(`💰 *Territory income collected*\nGang: ${gang.name}\nAdded: ${fmt(total)} coins to treasury${total ? '' : '\nNo income ready yet. Territory income accrues hourly, capped at 12 hours.'}\nTreasury: ${fmt(gang.treasury)} coins.`);
    }
    if (sub === 'war') {
      const d=rp.DISTRICTS[key], t=g.territories[key]; if(!d||!t) return reply(`Choose a district from \`${prefix}territory map\`.`); if(!t.gang || !g.gangs[t.gang]) return reply('That district is neutral. Claim it instead.'); if(t.gang===gang.key) return reply('Your gang already controls that district.'); if(t.war) return reply('A war is already active for that district.'); if(gang.leader!==rp.memberKey(myJid)) return reply('Only the gang leader can declare a territory war.');
      t.war={attacker:gang.key, defender:t.gang, attackScore:0, defendScore:0, endsAt:now+10*60000, startedAt:now, fighters:{}}; rp.touch(); return reply(`⚔️ *TERRITORY WAR DECLARED*\n${gang.name} challenges ${g.gangs[t.gang].name} for *${d.name}*.\nWar lasts 10 minutes. Both gangs can use \`${prefix}territory attack ${key}\` to fight. Each member can fight once per war.`);
    }
    if (sub === 'attack') {
      const d=rp.DISTRICTS[key], t=g.territories[key], w=t&&t.war; if(!d||!w) return reply('There is no active war for that district. Check territory map.'); if(now>=w.endsAt){ const r=rp.resolveWar(jid,key,now); return reply(r ? (r.won ? `🏆 ${r.attacker} captured ${d.name}!` : `🛡️ ${r.defender} defended ${d.name}.`) : 'The war has ended.'); }
      const side=gang.key===w.attacker?'attack':gang.key===w.defender?'defend':null; if(!side) return reply('Your gang is not part of this war.'); const member=rp.memberKey(myJid); if(w.fighters[member]) return reply('You have already fought in this war.'); const power=1+Math.floor(Math.random()*3); w.fighters[member]=side; if(side==='attack') w.attackScore+=power; else w.defendScore+=power; rp.touch(); return reply(`⚔️ *Fight recorded!*\n${side==='attack'?'Attacking':'Defending'} ${d.name}\nPower: ${power}\nScore: ${w.attacker} ${w.attackScore} · ${w.defender} ${w.defendScore}\nTime left: ${left(w.endsAt-now)}.`);
    }
    return reply(`Use \`${prefix}territory map\`, \`${prefix}territory claim market\`, \`${prefix}territory war market\`, \`${prefix}territory attack market\` or \`${prefix}territory collect\`.`);
  }}
  ,
  { ...base, name: 'wanted', aliases: ['wantedlevel', 'policecheck'], description: 'Check wanted level, arrest criminals as police/royal guard, or pay bail', async run({ args, reply, myJid, jid, msg, prefix }) {
    const sub = (args[0] || 'status').toLowerCase();
    const me = rp.user(jid, myJid), now = Date.now();
    if (sub === 'bail') {
      if (!(me.jailedUntil > now)) { me.jailedUntil = 0; me.bail = 0; rp.touch(); return reply('✅ You are not in crime-system jail.'); }
      const amount = Math.max(0, me.bail || 0);
      if (economy.balance(myJid) < amount) return reply(`⛓️ You are jailed for ${left(me.jailedUntil-now)}. Bail costs ${fmt(amount)} coins; your wallet has ${fmt(economy.balance(myJid))}.`);
      economy.take(myJid, amount); rp.payBail(jid, myJid, now);
      return reply(`🔓 *Bail paid!* You are free.
Paid: ${fmt(amount)} coins
Wanted level reset. Keep out of trouble.`);
    }
    if (sub === 'arrest') {
      const target = resolveTarget(msg, args.slice(1));
      if (!target) return reply(`Usage: \`${prefix}wanted arrest @user\``);
      if (!['police','royalguard'].includes(me.career)) return reply('🚔 Only Police Officers and Royal Guards can arrest wanted players. Apply with `.career apply police`.');
      if (rp.memberKey(target) === rp.memberKey(myJid)) return reply('You cannot arrest yourself.');
      const result = rp.arrest(jid, target, now);
      if (!result.ok) return reply(result.why === 'clean' ? `@${num(target)} has no active wanted level.` : `@${num(target)} is already in jail.`, { mentions: [target] });
      return reply(`🚔 *ARREST MADE*
👮 Officer: @${num(myJid)}
🚨 Suspect: @${num(target)}
⛓️ Jail time: ${left(result.duration)}
💵 Bail: ${fmt(result.bail)} coins
Use \`${prefix}wanted bail\` to get released early.`, { mentions: [myJid, target] });
    }
    const remaining = Math.max(0, (me.jailedUntil || 0) - now);
    return reply(`🚨 *WANTED STATUS*
Wanted level: *${me.wanted || 0}/5*${remaining ? `
⛓️ Jail: ${left(remaining)}
💵 Bail: ${fmt(me.bail || 0)} coins` : ''}

Crime raises your wanted level. Police Officers and Royal Guards can arrest wanted players.
• \`${prefix}wanted arrest @user\`
• \`${prefix}wanted bail\`
• Crime: \`${prefix}crime\``);
  }},
  { ...base, name: 'haunt', aliases: ['ghost'], description: 'Pay to send a ghost after a player for 30 minutes', async run({ args, reply, myJid, jid, msg }) {
    if ((args[0] || '').toLowerCase() === 'status') { const until = rp.user(jid, myJid).ghostUntil || 0; return reply(until > Date.now() ? `👻 A ghost is following you for ${left(until-Date.now())}.` : '👻 No ghost is following you right now.'); }
    const target = resolveTarget(msg, args);
    if (!target) return reply('👻 Tag a player to haunt: `.haunt @user` (cost: 250 coins, lasts 30 minutes).');
    if (rp.memberKey(target) === rp.memberKey(myJid)) return reply('You cannot haunt yourself. Tag another player.');
    if (economy.balance(myJid) < 250) return reply('👻 A haunting costs 250 coins. You do not have enough.');
    const victim = rp.user(jid, target), now = Date.now();
    if ((victim.ghostUntil || 0) > now) return reply(`👻 @${num(target)} already has a ghost following them for ${left(victim.ghostUntil-now)}.`, { mentions: [target] });
    economy.take(myJid, 250); victim.ghostUntil = now + 30 * 60000; rp.touch();
    return reply(`👻 *A ghost has chosen its victim!*
@${num(target)}, a ghost is following you for *30 minutes*.
The haunting ends automatically. Cost: 250 coins.`, { mentions: [target] });
  }},
  { ...base, name: 'nickname', aliases: ['nicktitle', 'paidnick'], description: 'Buy a roleplay nickname for one hour (500 coins)', async run({ args, reply, myJid, jid, prefix }) {
    const sub = (args[0] || '').toLowerCase(), u = rp.user(jid, myJid), now = Date.now();
    if (sub === 'status') {
      const active = rp.activeNickname(jid, myJid, now);
      return reply(active ? `🏷️ Your nickname is *${active}* for another ${left(u.nicknameUntil-now)}.` : `You have no active paid nickname. Set one for 500 coins with \`${prefix}nickname Professional Beggar\`.`);
    }
    const name = args.join(' ').trim();
    if (!name) return reply(`🏷️ *Paid nickname* costs 500 coins and lasts 1 hour.
Example: \`${prefix}nickname Professional Beggar 🥲\`
Check it: \`${prefix}nickname status\``);
    if (name.length > 32) return reply('Nickname must be 32 characters or fewer.');
    if (economy.balance(myJid) < 500) return reply('A paid nickname costs 500 coins. You do not have enough.');
    economy.take(myJid, 500); const result = rp.applyNickname(jid, myJid, name, now);
    return reply(`🏷️ *Nickname activated!*
Nickname: *${result.nickname}*
Duration: 1 hour
Paid: 500 coins
Use \`${prefix}nickname status\` to check the time left. This is an in-game nickname and does not change your WhatsApp profile name.`);
  }},
  { ...base, name: 'headline', aliases: ['breakingnews', 'newsflash'], description: 'Generate a funny breaking-news announcement for roleplay', async run({ args, reply, myJid, jid, msg }) {
    const target = resolveTarget(msg, args) || myJid;
    const stories = [
      (a) => `🚨 *BREAKING NEWS!*\n@${a} was caught arguing with their landlord over 50 coins. Their imaginary mansion has been seized.`,
      (a) => `🚨 *BREAKING NEWS!*\n@${a} has declared bankruptcy after buying suya for the entire neighbourhood. Treasury officials are confused.`,
      (a) => `🚨 *BREAKING NEWS!*\n@${a} was arrested for looking suspicious near a plate of jollof rice. The case is still under investigation.`,
      (a) => `🚨 *BREAKING NEWS!*\n@${a} has been promoted to Professional Beggar after asking three people for 10 coins each.`,
      (a) => `🚨 *BREAKING NEWS!*\n@${a} claims to own five mansions, but was seen negotiating a 2-coin discount.`,
    ];
    const text = stories[Math.floor(Math.random() * stories.length)](num(target));
    return reply(text, { mentions: [target] });
  }}
];
