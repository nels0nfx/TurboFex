// Owner-only controls for group economy balancing. Group-specific roleplay settings stay isolated by group.
const economy = require('../core/economy');
const rp = require('../core/roleplay');
const base = { category: 'economy', everyone: true, groupOnly: true, needs: [], weight: 'light' };
const fmt = economy.fmt;
module.exports = [{ ...base, name: 'economyadmin', aliases: ['ecoadmin', 'economysettings'], description: 'Owner economy administration panel', async run({ args, reply, jid, isOwner, prefix }) {
  if (!isOwner) return reply('🔒 *Owner only.* This panel changes the economy configuration.');
  const sub = (args[0] || 'status').toLowerCase(), cfg = rp.economySettings(jid), mult = economy.getCfg();
  if (sub === 'status' || sub === 'panel') return reply(`🛠️ *TURBOFEX ECONOMY ADMIN*\n*This group*\nPresident salary: ${fmt(cfg.presidentSalary)} every ${Math.round(cfg.presidentSalaryInterval/60000)} minutes\nStandard wallet robbery success chance: ${cfg.robChance}%\nStandard robbery maximum: ${fmt(cfg.robCap)} coins\n\n*Bot-wide economy multipliers*\nPay: ${mult.pay}x • Shop prices: ${mult.shop}x • Chat earnings: ${mult.chat}x\n\n*Group settings*\n\`${prefix}economyadmin salary 1000000 10\`\n\`${prefix}economyadmin robchance 45\`\n\`${prefix}economyadmin robcap 10000\`\n\`${prefix}economyadmin reset\`\n\n*Global settings*\n\`${prefix}economyadmin pay 1.5\` • \`${prefix}economyadmin shop 1.2\` • \`${prefix}economyadmin chat 2\`\n\nEconomy settings are saved persistently. Salary and robbery settings apply only to this group; multipliers apply bot-wide.`);
  if (sub === 'salary') {
    const amount = Number(args[1]), minutes = Number(args[2]);
    if (!Number.isSafeInteger(amount) || amount < 1 || !Number.isSafeInteger(minutes) || minutes < 1 || minutes > 1440) return reply(`Usage: \`${prefix}economyadmin salary <coins-per-pay> <minutes>\`\nExample: \`${prefix}economyadmin salary 1000000 10\``);
    rp.setEconomySetting(jid, 'presidentSalary', amount); rp.setEconomySetting(jid, 'presidentSalaryInterval', minutes);
    return reply(`✅ *PRESIDENTIAL PAYROLL UPDATED*\nSalary: ${fmt(amount)} coins every ${minutes} minutes in this group.`);
  }
  if (sub === 'robchance' || sub === 'robcap') {
    const val = Number(args[1]), key = sub === 'robchance' ? 'robChance' : 'robCap';
    if (!rp.setEconomySetting(jid, key, val)) return reply(sub === 'robchance' ? 'Robbery chance must be a whole number from 1 to 90.' : 'Robbery cap must be a whole number of at least 100 coins.');
    const fresh = rp.economySettings(jid);
    return reply(`✅ *ROBBERY SETTINGS UPDATED*\nSuccess chance: ${fresh.robChance}%\nStandard maximum per robbery: ${fmt(fresh.robCap)} coins.`);
  }
  if (['pay','shop','chat'].includes(sub)) {
    if (!economy.setCfg(sub, args[1])) return reply(`Usage: \`${prefix}economyadmin ${sub} <multiplier>\`\nAllowed range: 0.1x to 20x.`);
    return reply(`✅ *GLOBAL ECONOMY SETTING UPDATED*\n${sub.toUpperCase()} multiplier: ${economy.getCfg()[sub]}x. This applies bot-wide.`);
  }
  if (sub === 'reset') {
    rp.setEconomySetting(jid, 'presidentSalary', 1000000); rp.setEconomySetting(jid, 'presidentSalaryInterval', 10); rp.setEconomySetting(jid, 'robChance', 40); rp.setEconomySetting(jid, 'robCap', 5000);
    return reply('♻️ *GROUP ECONOMY SETTINGS RESET*\nPresident salary: 1,000,000 every 10 minutes. Robbery chance: 40%. Standard robbery cap: 5,000 coins. Global multipliers were not changed.');
  }
  return reply(`Use \`${prefix}economyadmin status\` to open the panel.`);
}}];
