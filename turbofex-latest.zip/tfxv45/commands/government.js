// Public democratic accountability tools for the existing group government.
const rp = require('../core/roleplay');
const economy = require('../core/economy');
const { num, resolveTarget } = require('../whatsapp/utils');
const base = { category: 'economy', everyone: true, groupOnly: true, needs: [], weight: 'light' };
const fmt = economy.fmt;
const who = jid => `@${num(jid)}`;
const remaining = ms => { const m = Math.max(0, Math.ceil(ms / 60000)); return `${m}m`; };
const runPortal = async ({ args, reply, myJid, jid, prefix, msg }) => {
  const send = (s, options) => reply(String(s).split('\n').map((line, i) => !line.trim() || i === 0 || /^\s*[▸•]/.test(line) ? line : `▸ ${line}`).join('\n'), options);
  const area = (args[0] || 'status').toLowerCase();
  const sub = (args[1] || 'status').toLowerCase();
  const target = resolveTarget(msg, args.slice(2, 3));
  const g = rp.state(jid);

  if (area === 'help' || area === 'commands') return send(`🏛️ *PUBLIC GOVERNMENT PORTAL*\n▸ \`${prefix}gov status\` — current leadership and public finances\n▸ \`${prefix}gov election start\` — open a 10-minute election when the presidency is vacant\n▸ \`${prefix}gov election register\` — register as a candidate (must meet presidential eligibility and have the office fee)\n▸ \`${prefix}gov election vote @candidate\` — cast one vote\n▸ \`${prefix}gov election results\` — check candidates and results\n▸ \`${prefix}gov impeachment start <reason>\` — propose removal of the sitting President\n▸ \`${prefix}gov impeachment vote yes|no\` — vote once during the 10-minute ballot\n▸ \`${prefix}gov petition create <request>\`, \`${prefix}gov petition sign <id>\`, \`${prefix}gov petition list\`\n\nVotes are one per member per ballot. Impeachment requires at least 3 votes and a two-thirds majority. Petitions with 5 unique signatures are formally submitted.`, { mentions: [] });

  if (area === 'status') {
    const p = rp.presidentInfo(jid).president;
    const election = rp.governmentElectionStatus(jid);
    const impeachment = rp.governmentImpeachmentStatus(jid);
    return send(`🏛️ *GOVERNMENT STATUS*\nPresident: ${p ? `${who(p.jid)} · ${remaining(p.until - Date.now())} left` : 'Vacant'}\nPublic treasury: ${fmt(rp.governmentTreasury(jid))} coins\nElection: ${election ? `${election.status}${election.status === 'open' ? ` · closes in ${remaining(election.remaining)}` : ''}` : 'Not open'}\nImpeachment: ${impeachment ? `${impeachment.status}${impeachment.status === 'open' ? ` · closes in ${remaining(impeachment.remaining)}` : ''}` : 'None open'}\n\nUse \`${prefix}gov help\` for elections, petitions and accountability commands.`, { mentions: p ? [p.jid] : [] });
  }

  if (area === 'election') {
    if (sub === 'start' || sub === 'open') {
      const r = rp.startGovernmentElection(jid, myJid);
      if (!r.ok) return send(r.why === 'paused' ? 'The Owner has paused elections in this group.' : r.why === 'occupied' ? `The presidency is still occupied by ${who(r.president.jid)}. An election can open when the office is vacant.` : `An election is already open; it closes in ${remaining(r.election.endsAt - Date.now())}.`, { mentions: r.president ? [r.president.jid] : [] });
      return send(`🗳️ *PRESIDENTIAL ELECTION OPENED*\nCandidate registration and voting are open for 10 minutes.\nCandidates: \`${prefix}gov election register\`\nVote: \`${prefix}gov election vote @candidate\`\nThe winner must still pass eligibility checks and pay the normal office fee.`);
    }
    if (sub === 'register' || sub === 'candidate' || sub === 'run') {
      const r = rp.registerElectionCandidate(jid, myJid);
      if (!r.ok) {
        const messages = { paused: 'The Owner has paused elections in this group.', closed: 'There is no open election accepting candidates.', gang: 'Leave your gang before running for President.', king: 'The King cannot also run for President.', jailed: 'You must be released from detention first.', wanted: 'Clear your wanted level before running.', criminal_record: 'Complete the relevant crime-system sentence before running.', previous: 'Another eligible member must serve before you can run again.', poor: `You need ${fmt(r.cost || rp.PRESIDENT_COST)} coins available to qualify.`, occupied: 'The presidency is still occupied.' };
        return send(messages[r.why] || `You cannot register: ${r.why}.`);
      }
      return send(`🗳️ ${who(myJid)} is registered as a presidential candidate. Members may vote with \`${prefix}gov election vote @candidate\`.`, { mentions: [myJid] });
    }
    if (sub === 'vote') {
      const candidate = resolveTarget(msg, args.slice(2));
      if (!candidate) return send(`Usage: \`${prefix}gov election vote @candidate\`.`);
      const r = rp.castElectionVote(jid, myJid, candidate);
      const messages = { paused: 'The Owner has paused elections in this group.', closed: 'Voting is closed or no election is open.', candidate: 'That person is not a registered candidate.', self: 'You cannot vote for yourself.', voted: 'Your vote has already been recorded for this election.' };
      if (!r.ok) return send(messages[r.why] || `Vote not recorded: ${r.why}.`);
      return send(`✅ Your vote for ${who(candidate)} has been recorded. You may vote only once in this election.`, { mentions: [candidate] });
    }
    if (sub === 'results' || sub === 'status') {
      const e = rp.governmentElectionStatus(jid);
      if (!e) return send('No election has been opened yet.');
      const candidates = Object.values(e.candidates || {}).map(c => `${who(c.jid)} — ${e.candidateCounts?.[c.key] || 0} vote(s)`).join('\n') || 'No registered candidates.';
      const outcome = e.result?.winner ? `Winner: ${who(e.result.winner)} (${e.result.votes} vote(s)).` : e.result ? `No winner: ${e.result.reason || e.status}.` : `Voting closes in ${remaining(e.remaining)}.`;
      return send(`🗳️ *PRESIDENTIAL ELECTION*\nStatus: ${e.status}\n${candidates}\nVotes cast: ${e.votesCast}\n${outcome}`, { mentions: Object.values(e.candidates || {}).map(c => c.jid).concat(e.result?.winner ? [e.result.winner] : []) });
    }
    return send(`Use \`${prefix}gov election start|register|vote @candidate|results\`.`);
  }

  if (area === 'impeachment' || area === 'recall') {
    if (sub === 'start' || sub === 'open') {
      const reason = args.slice(2).join(' ').trim();
      const r = rp.startImpeachment(jid, myJid, reason);
      const messages = { vacant: 'There is no sitting President to impeach.', self: 'The President cannot initiate their own impeachment.', active: 'An impeachment vote is already open.', reason: `Provide a reason: \`${prefix}gov impeachment start <reason>\`.` };
      if (!r.ok) return send(messages[r.why] || `Could not open impeachment: ${r.why}.`);
      return send(`⚖️ *IMPEACHMENT VOTE OPENED*\nTarget: ${who(r.impeachment.president)}\nReason: ${r.impeachment.reason}\nVoting closes in 10 minutes. Members vote with \`${prefix}gov impeachment vote yes\` or \`${prefix}gov impeachment vote no\`.\nAt least 3 votes and a two-thirds YES majority are required.`, { mentions: [r.impeachment.president] });
    }
    if (sub === 'vote') {
      const r = rp.voteImpeachment(jid, myJid, args[2]);
      const messages = { closed: 'No impeachment ballot is open, or its voting period has ended.', president: 'The President cannot vote in their own impeachment.', vote: 'Choose yes or no.', voted: 'You have already voted in this impeachment.' };
      if (!r.ok) return send(messages[r.why] || `Vote not recorded: ${r.why}.`);
      return send(`Your impeachment vote is recorded. Current tally: YES ${r.yes} · NO ${r.no}. Final decision is made when the 10-minute ballot closes.`);
    }
    if (sub === 'status' || sub === 'results') {
      const imp = rp.governmentImpeachmentStatus(jid);
      if (!imp) return send('No impeachment has been proposed.');
      return send(`⚖️ *IMPEACHMENT BALLOT*\nTarget: ${who(imp.president)}\nReason: ${imp.reason}\nStatus: ${imp.status}\nYES: ${imp.yes} · NO: ${imp.no} · Total: ${imp.total}\n${imp.status === 'open' ? `Closes in ${remaining(imp.remaining)}.` : `Result: ${imp.result?.passed ? 'President removed by vote.' : 'Motion failed.'}`}`, { mentions: [imp.president] });
    }
    return send(`Use \`${prefix}gov impeachment start <reason>\`, \`${prefix}gov impeachment vote yes|no\`, or \`${prefix}gov impeachment status\`.`);
  }

  if (area === 'petition' || area === 'petitions') {
    if (sub === 'create' || sub === 'new') {
      const r = rp.createGovernmentPetition(jid, myJid, args.slice(2).join(' '));
      if (!r.ok) return send(`Write a clear request: \`${prefix}gov petition create <request>\`.`);
      return send(`📜 *CITIZEN PETITION #${r.petition.id}*\n${r.petition.text}\nSignatures: 1/5\nOthers can sign with \`${prefix}gov petition sign ${r.petition.id}\`.`);
    }
    if (sub === 'sign') {
      const r = rp.signGovernmentPetition(jid, myJid, args[2]);
      const messages = { missing: 'Petition not found.', closed: 'This petition is no longer accepting signatures.', signed: 'You have already signed this petition.' };
      if (!r.ok) return send(messages[r.why] || `Could not sign: ${r.why}.`);
      return send(`📜 *PETITION #${r.petition.id}*\n${r.petition.text}\nSignatures: ${r.count}/5\nStatus: ${r.petition.status === 'submitted' ? 'FORMALLY SUBMITTED — the government must address it publicly.' : 'Collecting signatures.'}`);
    }
    if (sub === 'list' || sub === 'status') {
      const list = rp.governmentPetitions(jid, 10);
      return send(`📜 *CITIZEN PETITIONS*\n${list.length ? list.map(p => `#${p.id} · ${p.status.toUpperCase()} · ${p.signatureCount}/5\n${p.text}`).join('\n\n') : 'No petitions yet.'}\n\nCreate: \`${prefix}gov petition create <request>\` · Sign: \`${prefix}gov petition sign <id>\``);
    }
    return send(`Use \`${prefix}gov petition create <request>\`, \`${prefix}gov petition sign <id>\`, or \`${prefix}gov petition list\`.`);
  }

  if (area === 'treasury' || area === 'finance') {
    const ledger = rp.governmentLedger(jid, 5);
    return send(`🏦 *PUBLIC TREASURY REPORT*\nBalance: ${fmt(rp.governmentTreasury(jid))} coins\nRecent transactions:\n${ledger.length ? ledger.map(x => `${x.type}: ${x.amount >= 0 ? '+' : ''}${fmt(x.amount)} · balance ${fmt(x.balance)}`).join('\n') : 'No recorded transactions.'}`);
  }
  return send(`Unknown section. Use \`${prefix}gov help\`.`);
};
module.exports = [{ ...base, name: 'civic', aliases: ['civicgov'], description: 'Elections, impeachment, citizen petitions and public accountability', run: runPortal }];
module.exports.runPortal = runPortal;
