// Economy 2: work, fish, hunt, mine, bank, deposit, withdraw, rob, lottery, inventory, marry, divorce
const economy = require('../core/economy');
const lottery = require('../core/lottery');
const quests = require('../core/quests');
const { resolveTarget, num } = require('../whatsapp/utils');
const roleplay = require('../core/roleplay');

const { fmt } = economy;
const base = { category: 'economy', everyone: true, needs: [], weight: 'light' };
const pick = (list) => list[Math.floor(Math.random() * list.length)];
const between = (a, b) => a + Math.floor(Math.random() * (b - a + 1));
const left = (ms) => {
  const h = Math.floor(ms / 3600000);
  const m = Math.ceil((ms % 3600000) / 60000);
  return h ? `${h}h ${m}m` : `${m}m`;
};
const amountOf = (arg, max) => (/^all$/i.test(arg || '') ? max : /^\d[\d,_]*$/.test(arg || '') ? parseInt(arg.replace(/[,_]/g, ''), 10) : NaN);

// a job that pays now and then needs a rest: [name, cooldown, min, max, fail chance, pay lines, fail lines]
function job(name, cdMs, min, max, failChance, pays, fails, icon) {
  return {
    ...base,
    name,
    description: `${name[0].toUpperCase()}${name.slice(1)} to earn coins (every ${left(cdMs)})`,
    async run({ reply, myJid, jid }) {
      const cd = economy.cooldown(myJid, name, cdMs);
      if (!cd.ok) return reply(`⏳ *You are tired.* Try again in *${left(cd.waitMs)}*.`);
      if (Math.random() < failChance) return reply(`${icon} *${pick(fails)}*\n_Nothing earned this time._`);
      const pay = economy.payout(myJid, between(min, max)); // pay multipliers and partner bonuses apply; the President's configured tax is deducted where active
      const earned = pay.net;
      const qn = quests.note(quests.track(jid, myJid, 'job'));
      await reply(`${icon} *${pick(pays)}*\n*Earned:* +${fmt(earned)} coins${pay.tools ? ' _(🧰 Toolbox +25%)_' : ''}${pay.love ? ` _(💞 +${Math.round(pay.love * 100)}%)_` : ''}${pay.tax ? ` _(🇳🇬 presidential tax −${fmt(pay.tax)})_` : ''}\n*Wallet:* ${fmt(economy.balance(myJid))}${qn ? `\n\n${qn}` : ''}`);
    },
  };
}

module.exports = [
  job('work', 3600000, 150, 400, 0, ['You fixed phones all morning', 'You delivered packages across town', 'You tutored students after school', 'You cooked for a busy canteen', 'You designed a logo for a client', 'You drove a taxi through rush hour'], [''], '💼'),
  job('fish', 1800000, 40, 250, 0.2, ['You caught a big tilapia', 'You pulled up a net full of fish', 'You landed a huge catfish', 'You hooked a rare golden fish'], ['The fish were not biting', 'Your line snapped', 'You only caught an old shoe'], '🎣'),
  job('hunt', 2700000, 60, 350, 0.15, ['You tracked down a wild boar', 'You trapped a few rabbits', 'You brought home a fine antelope'], ['The animals heard you coming', 'You got lost in the bush', 'You came back empty-handed'], '🏹'),
  job('mine', 3600000, 100, 500, 0.1, ['You dug up some shiny gold', 'You found a pocket of gems', 'You struck a rich copper vein'], ['The tunnel collapsed, you ran out', 'You only found plain rocks'], '⛏️'),
  {
    ...base,
    name: 'bank',
    aliases: ['vault'],
    description: 'Your wallet and your bank (coins in the bank cannot be robbed)',
    async run({ reply, myJid, prefix }) {
      const u = economy.peek(myJid);
      await reply(`🏦 *Bank*\n*Wallet:* ${fmt(u.coins)} coins\n*In the bank:* ${fmt(u.bank || 0)} coins\n_The bank pays 0.3% a day interest on up to ${fmt(economy.BANK.cap)} coins._\n\n▸ \`${prefix}deposit 500\` or \`${prefix}deposit all\`\n▸ \`${prefix}withdraw 500\` or \`${prefix}withdraw all\`\n_Only the wallet can be robbed._`);
    },
  },
  {
    ...base,
    name: 'deposit',
    aliases: ['dep'],
    description: 'Put coins in the bank where nobody can rob them: deposit 500 / deposit all',
    async run({ args, reply, myJid, prefix }) {
      const n = amountOf(args[0], economy.balance(myJid));
      if (!Number.isInteger(n)) return reply(`*Usage:* \`${prefix}deposit 500\` or \`${prefix}deposit all\``);
      if (economy.inDebt(myJid)) return reply(`🔒 *You have a loan.* You cannot use the bank until you \`${prefix}repay\` it.`);
      if (!economy.deposit(myJid, n)) return reply(`⚠️ *You cannot deposit ${Number.isInteger(n) ? fmt(n) : 'that'}.* Your wallet has ${fmt(economy.balance(myJid))} coins.`);
      await reply(`✅ *Deposited ${fmt(n)} coins* 🏦\n*Wallet:* ${fmt(economy.balance(myJid))}\n*Bank:* ${fmt(economy.bankOf(myJid))}`);
    },
  },
  {
    ...base,
    name: 'withdraw',
    aliases: ['with'],
    description: 'Take coins out of the bank: withdraw 500 / withdraw all',
    async run({ args, reply, myJid, prefix }) {
      const n = amountOf(args[0], economy.bankOf(myJid));
      if (!Number.isInteger(n)) return reply(`*Usage:* \`${prefix}withdraw 500\` or \`${prefix}withdraw all\``);
      if (!economy.withdraw(myJid, n)) return reply(`⚠️ *You cannot withdraw that.* Your bank has ${fmt(economy.bankOf(myJid))} coins.`);
      await reply(`✅ *Withdrew ${fmt(n)} coins*\n*Wallet:* ${fmt(economy.balance(myJid))}\n*Bank:* ${fmt(economy.bankOf(myJid))}`);
    },
  },
  {
    ...base,
    name: 'rob',
    groupOnly: true,
    description: 'Try to steal from someone\'s wallet (a failure costs you a fine): rob @user',
    async run({ msg, args, reply, myJid, jid, botIds, prefix }) {
      const mode = /^(wallet|cash|luxury|bank)$/i.test(args[0] || '') ? args[0].toLowerCase() : 'wallet';
      const target = resolveTarget(msg, mode === 'wallet' ? args : args.slice(1));
      if (!target) return reply(`🦹 *ROBBERY OPTIONS*\n\`${prefix}rob @user\` – steal wallet coins (standard risk)\n\`${prefix}rob bank @user\` – raid their bank (rare success, severe penalty)\n\`${prefix}rob luxury @user\` – attempt to steal one luxury asset\n_(reply to a player's message or tag them)_`);
      if (botIds.includes(num(target))) return reply('🤖 *I have nothing to steal.*');
      if (roleplay.memberKey(target) === roleplay.memberKey(myJid)) return reply('😅 *You cannot rob yourself.*');
      const activeCareer = roleplay.refreshCareer(jid, myJid).career;
      if (['police','royalguard','soldier'].includes(activeCareer)) return reply('🛡️ *Serving law enforcement cannot commit robberies.* Resign from your career before returning to crime.');
      if (mode !== 'wallet') {
        if (economy.isKing(myJid)) return reply('🏛️ *The King and President cannot rob.* Government office carries legal immunity.');
        if (economy.isKing(target)) return reply('🏛️ *You cannot rob the King or President.* Government office carries legal immunity.');
        if (economy.peaceLeft() > 0) return reply('🕊️ *A peace law or presidential curfew is active.* All robbery types are suspended in this group.');
        const cd = economy.cooldown(myJid, `rob_${mode}`, 3 * 3600000);
        if (!cd.ok) return reply(`⏳ *The police are watching you.* Try again in *${left(cd.waitMs)}*.`);
        if (economy.inDebt(myJid)) return reply('🔒 *You have a loan.* Repay it before attempting a serious robbery.');
        if (economy.jailLeft(myJid)) return reply(`⛓️ *You are jailed* for another ${left(economy.jailLeft(myJid))}.`);
        const victim = roleplay.user(jid, target), thief = roleplay.user(jid, myJid);
        if (roleplay.protectionLeft(jid, target) > 0 || economy.itemLeft(target, 'shield') > 0) return reply(`🛡️ *${'@'+num(target)} is protected.*`, {mentions:[target]});
        if (mode === 'luxury') {
          const assets = victim.luxuries || [];
          if (!assets.length) return reply(`🏚️ @${num(target)} has no luxury assets to steal.`, {mentions:[target]});
          const thiefOwns = new Set(thief.luxuries || []);
          const stealable = assets.filter(id => !thiefOwns.has(id));
          if (!stealable.length) return reply('💎 You already own every luxury type this player has. There is nothing new to steal.');
          const success = Math.random() < 0.25;
          if (success) {
            const id = stealable[Math.floor(Math.random() * stealable.length)];
            assets.splice(assets.indexOf(id),1);
            if (!Array.isArray(thief.luxuries)) thief.luxuries=[]; thief.luxuries.push(id);
            roleplay.addWanted(jid,myJid,3); roleplay.touch();
            return reply(`💎 *LUXURY HEIST SUCCESSFUL*\n@${num(myJid)} stole the ${roleplay.LUXURIES[id]?.name || id} from @${num(target)}.\n🚨 Wanted level increased by 3. If arrested, jail time can reach 30 minutes.`,{mentions:[myJid,target]});
          }
          const fine = Math.min(economy.balance(myJid), Math.max(1000, Math.floor(economy.balance(myJid)*0.25)));
          if (fine) { economy.take(myJid,fine); economy.add(target,fine); }
          roleplay.addWanted(jid,myJid,2); thief.jailedUntil=Math.max(thief.jailedUntil||0,Date.now()+10*60000); roleplay.touch();
          return reply(`🚨 *LUXURY HEIST FAILED*\nSecurity caught @${num(myJid)}. Fine paid to @${num(target)}: ${fmt(fine)} coins.\n⛓️ Jail: 10 minutes • Wanted level increased by 2.`,{mentions:[myJid,target]});
        }
        const bank = economy.bankOf(target);
        if (bank < 1000) return reply(`🏦 @${num(target)} does not have enough bank savings to make a raid worthwhile.`,{mentions:[target]});
        if (Math.random() < 0.15) {
          const amount = Math.min(bank, Math.max(100, Math.floor(bank * (0.05 + Math.random()*0.1))));
          if (!economy.withdraw(target,amount)) return reply('🏦 The vault resisted the raid. No money moved.');
          economy.add(myJid,amount); roleplay.addWanted(jid,myJid,3); roleplay.touch();
          return reply(`🏦 *BANK RAID SUCCESSFUL*\n@${num(myJid)} stole ${fmt(amount)} coins from @${num(target)}'s bank savings.\n🚨 Wanted level +3. The next arrest can mean up to 30 minutes in jail.`,{mentions:[myJid,target]});
        }
        const fine = Math.min(economy.balance(myJid), Math.max(1000,Math.floor(economy.balance(myJid)*0.3)));
        if (fine) { economy.take(myJid,fine); economy.add(target,fine); }
        roleplay.addWanted(jid,myJid,3); thief.jailedUntil=Math.max(thief.jailedUntil||0,Date.now()+15*60000); roleplay.touch();
        return reply(`🚔 *BANK RAID BUSTED*\n@${num(myJid)} was caught. Fine paid to @${num(target)}: ${fmt(fine)} coins.\n⛓️ Jail: 15 minutes • Wanted level +3.`,{mentions:[myJid,target]});
      }
      const cd = economy.cooldown(myJid, 'rob', 2 * 3600000);
      if (!cd.ok) return reply(`⏳ *The police are watching you.* Try again in *${left(cd.waitMs)}*.`);
      const r = economy.rob(myJid, target);
      if (!r.ok) {
        // nothing happened, so the waiting time is given back
        economy.resetCooldown(myJid, 'rob');
        return reply({ king: '🏛️ *The King and President cannot rob.* Government office carries legal immunity.', kingsafe: '🏛️ *You cannot rob the King or President.* Government office carries legal immunity.', peace: `🕊️ *A peace law is in force.* Nobody can rob for another ${left(r.left || 0)}.`, jail: `⛓️ *You are in roleplay detention* for another ${left(r.left || 0)}.`, shield: '🛡️ *Their wallet has a Shield.* Nobody can rob it now.', debt: '🔒 *You have a loan.* Repay it before you try anything shady.', self: '😅 *You cannot rob yourself.*', poor: '⚠️ *You need at least 100 coins in your wallet to try.* A failed robbery costs a fine.', empty: '😕 *Their wallet has less than 200 coins.* Not worth the risk (the bank is safe).' }[r.why]);
      }
      await reply(r.success ? `🦹 *Robbery worked!*\nYou stole *${fmt(r.amount)} coins* from @${num(target)}.` : `🚔 *You were caught!*\nYou paid a fine of *${fmt(r.amount)} coins* to @${num(target)}.`, { mentions: [target] });
    },
  },
  {
    ...base,
    name: 'lottery',
    aliases: ['lotto'],
    groupOnly: true,
    description: 'Group lottery: lottery buy 3 (100 coins a ticket), an admin draws with lottery draw',
    async run({ args, jid, myJid, isAdmin, isOwner, reply, prefix }) {
      const w = (args[0] || '').toLowerCase();
      if (w === 'buy') {
        const n = parseInt(args[1] || '1', 10);
        if (!Number.isInteger(n) || n < 1) return reply(`*Usage:* \`${prefix}lottery buy 3\``);
        const r = lottery.buy(jid, myJid, n);
        if (!r.ok) return reply(r.why === 'max' ? `⚠️ *You already have ${lottery.MAX_TICKETS} tickets,* the most you can hold.` : `⚠️ *Not enough coins.* A ticket costs ${lottery.PRICE}; you have ${fmt(economy.balance(myJid))}.`);
        const i = lottery.info(jid, myJid);
        return reply(`🎟️ *Bought ${r.bought} ticket${r.bought > 1 ? 's' : ''}* for ${fmt(r.cost)} coins\n*Your tickets:* ${i.mine}\n*Pool:* ${fmt(i.pool)} coins`);
      }
      if (w === 'draw') {
        if (!isAdmin && !isOwner) return reply('⚠️ *Only group admins can draw the lottery.*');
        const r = lottery.draw(jid);
        if (!r) return reply('🎟️ *Nobody has bought a ticket yet.*');
        return reply(`🎉 *Lottery winner!*\n@${num(r.jid)} wins *${fmt(r.prize)} coins* (${r.tickets} tickets were sold).`, { mentions: [r.jid] });
      }
      const i = lottery.info(jid, myJid);
      await reply(`🎟️ *Lottery*\n*Pool:* ${fmt(i.pool)} coins\n*Players:* ${i.players} (${i.total} tickets)\n*Your tickets:* ${i.mine}\n\n▸ \`${prefix}lottery buy 3\` – ${lottery.PRICE} coins a ticket, up to ${lottery.MAX_TICKETS}\n▸ \`${prefix}lottery draw\` – an admin picks the winner`);
    },
  },
  {
    ...base,
    name: 'inventory',
    aliases: ['inv', 'profile'],
    description: 'Your coins, bank, title, charm and partner',
    async run({ reply, myJid }) {
      const u = economy.peek(myJid);
      const sp = economy.spouseOf(myJid);
      const charm = economy.hasCharm(myJid);
      await reply(
        `🎒 *Inventory*\n*Wallet:* ${fmt(u.coins)} coins\n*Bank:* ${fmt(u.bank || 0)} coins\n*Title:* ${u.title || 'none'}\n*Lucky Charm:* ${charm ? 'active 🍀' : 'none'}\n*Shield:* ${economy.itemLeft(myJid, 'shield') ? `active 🛡️ (${left(economy.itemLeft(myJid, 'shield'))})` : 'none'} • *Toolbox:* ${economy.itemLeft(myJid, 'tools') ? 'active 🧰' : 'none'} • *Lockpick:* ${economy.itemLeft(myJid, 'lockpick') ? 'active 🗝️' : 'none'}\n*Reputation:* ${u.rep || 0} ⭐\n*Daily streak:* ${u.streak || 0} days\n*Partner:* ${sp ? `@${num(sp.jid || `${sp.key}@s.whatsapp.net`)} 💍 (${economy.loveTier(u.love).name}, ${u.love || 0} love)` : 'single'}`,
        sp ? { mentions: [sp.jid || `${sp.key}@s.whatsapp.net`] } : {}
      );
    },
  },
  {
    ...base,
    name: 'marry',
    groupOnly: true,
    description: 'Propose to someone: marry @user (they answer with marry accept or marry decline)',
    async run({ msg, args, reply, myJid, botIds, prefix }) {
      const w = (args[0] || '').toLowerCase();
      if (w === 'accept' || w === 'yes') {
        const r = economy.accept(myJid);
        if (!r.ok) return reply(r.why === 'taken' ? '💔 *One of you is already married.*' : '⏳ *Nobody has proposed to you* (or the proposal ran out after 2 minutes).');
        return reply(`💍 *Congratulations!*\n@${num(r.fromJid)} and @${num(myJid)} are now married! 🎉\n_Do things together with_ \`${prefix}couple\` _(date, daily gift, cuddle). Love gives you both bonus pay._`, { mentions: [r.fromJid, myJid] });
      }
      if (w === 'decline' || w === 'no') return reply(economy.decline(myJid) ? '💔 *You said no.*' : 'ℹ️ *Nobody has proposed to you.*');
      const target = resolveTarget(msg, args);
      if (!target) return reply(`*Usage:* \`${prefix}marry @user\`\n_They answer with_ \`${prefix}marry accept\``);
      if (botIds.includes(num(target))) return reply('🤖 *I am married to my work.* 😄');
      const r = economy.propose(myJid, target);
      if (!r.ok) return reply({ self: '😅 *You cannot marry yourself.*', married: `💔 *You are already married.* Use \`${prefix}divorce\` first.`, taken: '💔 *They are already married.*' }[r.why]);
      await reply(`💍 *Proposal!*\n@${num(myJid)} asks @${num(target)} to marry them.\n@${num(target)}, answer with \`${prefix}marry accept\` or \`${prefix}marry decline\` _(2 minutes)_.`, { mentions: [myJid, target] });
    },
  },
  {
    ...base,
    name: 'divorce',
    description: 'End your marriage',
    async run({ reply, myJid }) {
      const sp = economy.divorce(myJid);
      if (!sp) return reply('ℹ️ *You are not married.*');
      await reply(`💔 *Divorced.* You and @${num(sp.jid || `${sp.key}@s.whatsapp.net`)} are no longer married.`, { mentions: [sp.jid || `${sp.key}@s.whatsapp.net`] });
    },
  },
];
