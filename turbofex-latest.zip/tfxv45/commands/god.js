// Owner/God console: secure, persistent group-scoped and global administration.
const rp = require('../core/roleplay');
const economy = require('../core/economy');
const god = require('../core/godsettings');
const groups = require('../whatsapp/groups');
const { num, resolveTarget } = require('../whatsapp/utils');
const base = { category: 'owner', ownerOnly: true, needs: [], weight: 'medium' };
const fmt = economy.fmt;
const validGroup = (s) => typeof s === 'string' && s.endsWith('@g.us');
function duration(text) {
  const m = /^(\d+)(m|min|mins|minutes?|h|hr|hrs|hours?|d|days?)$/i.exec(String(text||'').trim());
  if (!m) return null;
  const n=Number(m[1]), unit=m[2].toLowerCase();
  const mult = unit.startsWith('m') ? 60000 : unit.startsWith('h') ? 3600000 : 86400000;
  const ms=n*mult;
  return Number.isSafeInteger(ms) && ms>=60000 && ms<=30*86400000 ? ms : null;
}
function shortDuration(ms) { if(ms%86400000===0)return `${ms/86400000}d`; if(ms%3600000===0)return `${ms/3600000}h`; return `${Math.round(ms/60000)}m`; }
function targetJid(ctx, token) {
  if (!token) return null;
  const fromMention = resolveTarget(ctx.msg, [token]);
  if (fromMention) return fromMention;
  const digits = String(token).replace(/\D/g,'');
  return digits.length >= 7 && digits.length <= 15 ? `${digits}@s.whatsapp.net` : null;
}
async function groupList(ctx) { try { return await groups.list(ctx.sock, true); } catch { return []; } }
async function resolveGroup(ctx, selector) {
  if (validGroup(selector)) {
    const all = await groupList(ctx);
    return { jid: selector, name: all.find(g=>g.jid===selector)?.name || selector };
  }
  return groups.resolve(ctx.sock, selector);
}
async function currentTarget(ctx, args) {
  if ((args[0]||'').toLowerCase()==='group') {
    const found=await resolveGroup(ctx,args[1]);
    return found ? { group:found.jid, name:found.name, args:args.slice(2) } : { error:`I could not resolve group "${args[1]||''}". Use \`${ctx.prefix}god groups\` to list groups, or provide a full group ID.` };
  }
  if (validGroup(ctx.jid)) {
    const all = await groupList(ctx);
    return { group:ctx.jid, name:all.find(g=>g.jid===ctx.jid)?.name || ctx.jid, args };
  }
  const selected=god.selectedGroup();
  if (!selected) return { error:`Select a group first in DM: \`${ctx.prefix}god groups\` then \`${ctx.prefix}god select <number, name or group ID>\`.` };
  const all=await groupList(ctx);
  return { group:selected, name:all.find(g=>g.jid===selected)?.name || selected, args };
}
async function announce(ctx, group, text, mentions=[]) {
  try { await ctx.sock.sendMessage(group,{text, ...(mentions.length?{mentions}: {})}); return true; }
  catch (err) { return false; }
}
function applyGlobalToKnown(key, value) {
  for (const group of rp.governmentGroupsForScheduler()) {
    if (god.hasOverride(group,key)) continue;
    const g=rp.state(group);
    if (key==='presidentSalary') g.economySettings.presidentSalary=value;
    else if (key==='presidentSalaryInterval') g.economySettings.presidentSalaryInterval=value;
    else if (key==='presidentTerm') {
      g.economySettings.presidentTerm=value;
      if(g.president) g.president.until=(g.president.since||Date.now())+value;
    } else g.economySettings[key]=value;
    rp.touch();
  }
}
function setGroupSetting(group,key,value) {
  const g=rp.state(group);
  if(key==='presidentSalary') g.economySettings.presidentSalary=value;
  else if(key==='presidentSalaryInterval') g.economySettings.presidentSalaryInterval=value;
  else if(key==='presidentTerm') { g.economySettings.presidentTerm=value; if(g.president)g.president.until=(g.president.since||Date.now())+value; }
  else g.economySettings[key]=value;
  god.setOverride(group,key,true); rp.touch();
}
module.exports = [{ ...base, name:'god', aliases:['owneradmin','godmode'], description:'Owner control console for global and per-group administration', async run(ctx) {
  const { args, reply, prefix, isOwner }=ctx;
  if(!isOwner) return reply('🔒 Owner only.');
  let argv=[...args];
  const sub=(argv[0]||'panel').toLowerCase();
  const usage=`👑 *TURBOFEX GOD CONSOLE*\n\n*Group selection (works from DM)*\n\`${prefix}god groups\`\n\`${prefix}god select <number, name or group ID>\`\n\`${prefix}god panel\`\n\`${prefix}god group <group number or ID> <command>\`\n\n*Selected/current group controls*\n\`${prefix}god salary president <coins> [interval]\`\n\`${prefix}god salarytime president <20m|2h>\`\n\`${prefix}god term <2h|7d>\`\n\`${prefix}god appoint @user president\`\n\`${prefix}god dismiss president\` · \`${prefix}god dismiss @user\`\n\`${prefix}god staffpay @user <coins>\`\n\`${prefix}god grant @user <coins>\`\n\`${prefix}god treasury <add|take> <coins>\`\n\`${prefix}god pardon @user\` · \`${prefix}god wanted @user <0-5>\`\n\`${prefix}god event <announcement>\`\n\`${prefix}god election <cancel|pause|resume>\`\n\`${prefix}god court <case-id> <uphold|dismiss> <reason>\`\n\`${prefix}god release @user\` · \`${prefix}god tax <president|king> <0-25>\`\n\`${prefix}god law <robchance|robcap|arrestmultiplier> <value>\`\n\n*Global controls*\n\`${prefix}god global salary president <coins> [interval]\`\n\`${prefix}god global salarytime president <20m|2h>\`\n\`${prefix}god global term <2h|7d>\`\n\`${prefix}god global event <announcement>\`\n\`${prefix}god global law <robchance|robcap|arrestmultiplier> <value>\`\n\`${prefix}god global multiplier <pay|shop|chat> <0.1-20>\`\n\n*Owner wallet & audit*\n\`${prefix}god wallet\` · \`${prefix}god wallet add <coins>\` · \`${prefix}god wallet take <coins>\`\n\`${prefix}god audit [count]\`\n\nGlobal values are defaults. Explicit group overrides remain independent. Every Owner action is privately audited; major interventions are announced in affected groups.`;
  if(['panel','help','status'].includes(sub)) {
    const selected=validGroup(ctx.jid)?ctx.jid:god.selectedGroup();
    let name=selected;
    if(selected){const all=await groupList(ctx);name=all.find(g=>g.jid===selected)?.name||selected;}
    return reply(`👑 *GOD / OWNER CONTROL*\nAuthority: absolute administrative override\nSelected group: ${name||'None (use from a group or select in DM)'}\nSeparate Owner wallet: ${fmt(god.wallet())} coins\nGlobal defaults: President ${fmt(god.defaults().presidentSalary)} coins / ${shortDuration(god.defaults().presidentSalaryInterval)} · term ${shortDuration(god.defaults().presidentTerm)}\nGlobal laws: robbery ${god.defaults().robChance}% · cap ${fmt(god.defaults().robCap)} · arrest duration ${god.defaults().arrestMultiplier}x\n\n${usage}`);
  }
  if(sub==='groups') {
    const all=await groupList(ctx); if(!all.length)return reply('No participating groups were returned. You can still select a known group by full ID using `.god select <group-id>` if the bot has access to it.');
    const page=Math.max(1,Math.min(Math.ceil(all.length/30),Number(argv[1])||1));
    return reply(`👥 *GROUPS (${all.length})* · page ${page}/${Math.ceil(all.length/30)}\n\n${all.slice((page-1)*30,page*30).map((g,i)=>`${(page-1)*30+i+1}. ${g.name}\n${g.jid}${god.selectedGroup()===g.jid?'  ✓ SELECTED':''}`).join('\n\n')}\n\nSelect: \`${prefix}god select <number, name or full ID>\`${page<Math.ceil(all.length/30)?`\nNext page: ${prefix}god groups ${page+1}`:''}`);
  }
  if(sub==='select') {
    const selected=await resolveGroup(ctx,argv.slice(1).join(' '));
    if(!selected)return reply(`I couldn't find that group. Use \`${prefix}god groups\` or provide the full group ID.`);
    god.selectGroup(selected.jid); god.audit('Selected group',selected.name,selected.jid);
    return reply(`✅ Selected *${selected.name}*\nID: ${selected.jid}\nYour next \`${prefix}god\` commands in DM will target this group. Use \`${prefix}god group <another group> <command>\` to target another without changing selection.`);
  }
  if(sub==='wallet') {
    const action=(argv[1]||'status').toLowerCase();
    if(action==='add'||action==='take') {
      const n=Number(argv[2]); if(!Number.isSafeInteger(n)||n<1||n>Number.MAX_SAFE_INTEGER)return reply(`Usage: \`${prefix}god wallet ${action} <positive integer>\``);
      const result=action==='add'?god.walletAdd(n):god.walletTake(n); if(result===false)return reply(action==='take'?'Insufficient Owner wallet balance.':'Amount is too large.');
      god.audit(`Owner wallet ${action}`,`${fmt(n)} coins; balance ${fmt(result)}`);
      return reply(`👑 Owner wallet ${action==='add'?'credited':'debited'}: ${fmt(n)} coins\nBalance: ${fmt(result)} coins. This separate ledger does not alter player wallets.`);
    }
    return reply(`👑 *OWNER WALLET*\nBalance: ${fmt(god.wallet())} coins\n\`${prefix}god wallet add <coins>\`\n\`${prefix}god wallet take <coins>\`\nThe Owner wallet is an administrative ledger separate from group/player economies.`);
  }
  if(sub==='audit') {
    const n=Math.max(1,Math.min(30,Number(argv[1])||15)), rows=god.recentAudit(n);
    return reply(`🧾 *PRIVATE OWNER AUDIT* · latest ${rows.length}\n${rows.length?rows.map(x=>`• ${new Date(x.at).toLocaleString()}\n${x.action}${x.group?` · ${x.group}`:''}\n${x.details}`).join('\n\n'):'No Owner actions recorded yet.'}`);
  }
  let global=false;
  if(sub==='global') { global=true; argv=argv.slice(1); }
  let target;
  if(!global) {
    target=await currentTarget(ctx,argv);
    if(target.error)return reply(target.error.replaceAll('\`',''));
    argv=target.args;
  }
  const action=(argv[0]||'').toLowerCase();
  if(global && !['salary','salarytime','term','event','law','multiplier'].includes(action))return reply('Global controls supported here: salary, salarytime, term, event, law, multiplier.') ;
  const group=target?.group, groupName=target?.name||'all groups';
  if(action==='salary') {
    const role=(argv[1]||'president').toLowerCase(), amount=Number(argv[2]);
    if(role!=='president'||!Number.isSafeInteger(amount)||amount<1||amount>1000000000)return reply(`Usage: \`${prefix}god ${global?'global ':''}salary president <1-1,000,000,000 coins> [interval e.g. 30m]\``);
    let interval=null; if(argv[3]) { interval=duration(argv[3]); if(!interval)return reply('Interval must look like 20m, 2h or 1d (maximum 30 days).'); }
    if(global) {
      god.setDefault('presidentSalary',amount); applyGlobalToKnown('presidentSalary',amount);
      if(interval){god.setDefault('presidentSalaryInterval',interval);applyGlobalToKnown('presidentSalaryInterval',interval);}
      god.audit('Global presidential payroll updated',`${fmt(amount)} coins${interval?` every ${shortDuration(interval)}`:''}`);
      const all=await groupList(ctx); for(const g of all) await announce(ctx,g.jid,`📢 *OWNER ADMINISTRATION NOTICE*\nGlobal presidential salary default changed to ${fmt(amount)} coins${interval?` every ${shortDuration(interval)}`:''}. Group-specific overrides remain in force for the settings they override.`);
      return reply(`✅ Global presidential salary default updated to ${fmt(amount)} coins${interval?` every ${shortDuration(interval)}`:''}. Existing groups without an Owner override were updated; future groups inherit the new default.`);
    }
    setGroupSetting(group,'presidentSalary',amount);
    if(interval)setGroupSetting(group,'presidentSalaryInterval',interval);
    god.audit('Group presidential payroll updated',`${fmt(amount)} coins${interval?` every ${shortDuration(interval)}`:''}`,group);
    await announce(ctx,group,`📢 *OWNER ADMINISTRATION NOTICE*\nPresidential salary for this group is now ${fmt(amount)} coins${interval?` every ${shortDuration(interval)}`:''}.`);
    return reply(`✅ *${groupName}* presidential salary set to ${fmt(amount)} coins${interval?` every ${shortDuration(interval)}`:''}.`);
  }
  if(action==='salarytime') {
    if((argv[1]||'president').toLowerCase()!=='president')return reply('Only `president` is supported for this salary interval.');
    const ms=duration(argv[2]); if(!ms)return reply(`Usage: \`${prefix}god ${global?'global ':''}salarytime president <20m|2h|1d>\``);
    if(global){god.setDefault('presidentSalaryInterval',ms);applyGlobalToKnown('presidentSalaryInterval',ms);god.audit('Global presidential salary interval updated',shortDuration(ms));const all=await groupList(ctx);for(const g of all)await announce(ctx,g.jid,`📢 *OWNER ADMINISTRATION NOTICE*\nGlobal presidential salary interval default is now ${shortDuration(ms)}. Group-specific interval overrides remain in force.`);return reply(`✅ Global presidential salary interval is now ${shortDuration(ms)} for groups without an explicit interval override.`);}
    setGroupSetting(group,'presidentSalaryInterval',ms);god.audit('Group presidential salary interval updated',shortDuration(ms),group);await announce(ctx,group,`📢 *OWNER ADMINISTRATION NOTICE*\nPresidential salary interval changed to ${shortDuration(ms)}.`);return reply(`✅ ${groupName}: President salary interval is now ${shortDuration(ms)}.`);
  }
  if(action==='term') {
    const ms=duration(argv[1]); if(!ms)return reply(`Usage: \`${prefix}god ${global?'global ':''}term <2h|7d> (1 minute to 30 days)\``);
    if(global){god.setDefault('presidentTerm',ms);applyGlobalToKnown('presidentTerm',ms);god.audit('Global presidential term updated',shortDuration(ms));const all=await groupList(ctx);for(const g of all)await announce(ctx,g.jid,`📢 *OWNER ADMINISTRATION NOTICE*\nPresidential term default changed to ${shortDuration(ms)}. Group-specific term overrides remain in force.`);return reply(`✅ Global presidential term set to ${shortDuration(ms)}. Active Presidents in groups without a term override have been adjusted from their original start time.`);}
    setGroupSetting(group,'presidentTerm',ms);god.audit('Group presidential term updated',shortDuration(ms),group);await announce(ctx,group,`📢 *OWNER ADMINISTRATION NOTICE*\nPresidential term for this group is now ${shortDuration(ms)}.`);return reply(`✅ ${groupName}: Presidential term set to ${shortDuration(ms)}. The current President's expiry is recalculated from their start time.`);
  }
  if(action==='law') {
    const keyInput=(argv[1]||'').toLowerCase(), raw=argv[2];
    const key=({robchance:'robChance',robcap:'robCap',arrestmultiplier:'arrestMultiplier'})[keyInput];
    let value;
    if(keyInput==='robchance') { value=Number(raw); if(!Number.isInteger(value)||value<1||value>90)return reply(`Usage: \`${prefix}god ${global?'global ':''}law robchance <1-90>\``); }
    else if(keyInput==='robcap') { value=Number(raw); if(!Number.isSafeInteger(value)||value<100||value>1000000000000)return reply(`Usage: \`${prefix}god ${global?'global ':''}law robcap <100-1,000,000,000,000>\``); }
    else if(keyInput==='arrestmultiplier') { value=Number(raw); if(!Number.isFinite(value)||value<0.1||value>5)return reply(`Usage: \`${prefix}god ${global?'global ':''}law arrestmultiplier <0.1-5>\``); value=Math.round(value*100)/100; }
    else return reply('Law settings: robchance (1–90%), robcap (100–1,000,000,000,000 coins), arrestmultiplier (0.1–5x).');
    if(global) { god.setDefault(key,value);applyGlobalToKnown(key,value);god.audit('Global law changed',`${keyInput} = ${value}`);const all=await groupList(ctx);for(const g of all)await announce(ctx,g.jid,`📜 *OWNER LAW DECREE*\nGlobal default ${keyInput} is now ${value}. Explicit group overrides remain in force.`);return reply(`✅ Global law default updated: ${keyInput} = ${value}. Groups with explicit overrides remain unchanged; future groups inherit this default.`); }
    setGroupSetting(group,key,value);god.audit('Group law changed',`${keyInput} = ${value}`,group);await announce(ctx,group,`📜 *OWNER LAW DECREE*\n${keyInput} for this group is now ${value}.`);return reply(`✅ ${groupName}: ${keyInput} set to ${value}.`);
  }
  if(action==='multiplier') {
    if(!global)return reply(`Use \`${prefix}god global multiplier <pay|shop|chat> <0.1-20>\` for bot-wide economy multipliers.`);
    const key=(argv[1]||'').toLowerCase(), value=argv[2];if(!['pay','shop','chat'].includes(key)||!economy.setCfg(key,value))return reply(`Usage: \`${prefix}god global multiplier <pay|shop|chat> <0.1-20>\``);
    const fresh=economy.getCfg();god.audit('Global economy multiplier changed',`${key} = ${fresh[key]}x`);const all=await groupList(ctx);for(const g of all)await announce(ctx,g.jid,`🌍 *OWNER ECONOMY DECREE*\nGlobal ${key} multiplier is now ${fresh[key]}x.`);return reply(`✅ Global ${key} multiplier set to ${fresh[key]}x across the bot.`);
  }
  if(action==='tax') {
    const kind=(argv[1]||'president').toLowerCase(), pct=Number(argv[2]);if(!['president','king'].includes(kind)||!Number.isFinite(pct)||pct<0||pct>25)return reply(`Usage: \`${prefix}god tax <president|king> <0-25 percent>\``);
    const g=rp.state(group), key=kind==='king'?'presidentKingTax':'presidentTax';g[key]=Math.round(pct*10)/10;rp.touch();god.audit('Owner changed government tax',`${kind} tax = ${g[key]}%`,group);await announce(ctx,group,`📜 *OWNER TAX DECREE*\n${kind==='king'?'Royal':'Presidential'} income tax is now ${g[key]}% in this group. Tax proceeds go to the public treasury.`);return reply(`✅ ${groupName}: ${kind} tax set to ${g[key]}%.`);
  }
  if(action==='court') {
    const id=Number(argv[1]), decision=(argv[2]||'').toLowerCase(), reason=argv.slice(3).join(' ').trim().slice(0,240);if(!Number.isSafeInteger(id)||id<1||!['uphold','dismiss'].includes(decision)||!reason)return reply(`Usage: \`${prefix}god court <case-id> <uphold|dismiss> <reason>\``);
    const g=rp.state(group), c=g.courtCases.find(x=>x&&x.id===id);if(!c)return reply(`Court case #${id} was not found in ${groupName}.`);if(c.status!=='pending')return reply(`Court case #${id} is already ${c.status}.`);
    const now=Date.now(), appellant=rp.user(group,c.appellant);c.status=decision==='dismiss'?'dismissed':'upheld';c.reviewedBy='owner';c.reviewedAt=now;c.decision=decision;c.decisionReason=reason;
    if(decision==='dismiss'){appellant.jailedUntil=0;appellant.bail=0;appellant.wanted=0;appellant.jailReason='';appellant.jailedBy='';appellant.jailType='';}
    else if(appellant.jailedUntil>now)appellant.jailedUntil=Math.min(now+120*60000,appellant.jailedUntil+5*60000);
    rp.recordGovernmentAction(group,'owner',`Owner court ${decision}`,`Case #${id}: ${rp.memberKey(c.appellant)} · ${reason}`);rp.touch();god.audit('Owner overrode court case',`#${id} ${decision}: ${reason}`,group);await announce(ctx,group,`⚖️ *OWNER COURT OVERRIDE*\nCase #${id} was ${decision} by the Owner.\nReason: ${reason}\nAppellant: @${num(c.appellant)}.`,[c.appellant]);return reply(`✅ Court case #${id} ${decision}. Reason recorded: ${reason}`,{mentions:[c.appellant]});
  }
  if(action==='release') {
    const who=targetJid(ctx,argv[1]);if(!who)return reply(`Usage: \`${prefix}god release @user\``);const u=rp.user(group,who);if(!(u.jailedUntil>Date.now()))return reply(`@${num(who)} is not currently detained in ${groupName}.`,{mentions:[who]});u.jailedUntil=0;u.bail=0;u.jailReason='';u.jailedBy='';u.jailType='';rp.touch();god.audit('Owner released detainee',num(who),group);await announce(ctx,group,`👑 *OWNER RELEASE DECREE*\n@${num(who)} has been released from detention by the Owner. Wanted status and criminal record are unchanged.`,[who]);return reply(`✅ @${num(who)} released. Their wanted level and criminal record remain unchanged.`,{mentions:[who]});
  }
  if(action==='appoint') {
    const token=argv[1], role=(argv[2]||'president').toLowerCase(), who=targetJid(ctx,token);
    if(!who)return reply(`Usage: \`${prefix}god appoint @user <president|position-id|police|doctor|soldier|royalguard>\` (or use a phone number with country code).`);
    const g=rp.state(group), now=Date.now();
    if(role==='president') {
      if(g.president&&rp.memberKey(g.president.jid)===rp.memberKey(who))return reply(`@${num(who)} is already the serving President of ${groupName}.`,{mentions:[who]});
      const candidate=rp.user(group,who), recordAt=Math.max(candidate.crimeRecordAt||0,candidate.lastCrime||0), unrehabilitated=recordAt>0&&!((candidate.servedSentenceAt||0)>=recordAt&&(candidate.servedSentenceAt||0)>0);
      if((candidate.wanted||0)>0)return reply('🚨 A wanted member cannot accept the presidency. Issue a full pardon or let them complete the required sentence first.');
      if((candidate.jailedUntil||0)>now)return reply('A detained member cannot accept the presidency.');
      if(candidate.gang)return reply('A gang-affiliated member cannot accept the presidency.');
      if(unrehabilitated)return reply('This member has an outstanding criminal record and must complete a qualifying crime-system sentence before accepting the presidency.');
      const term=g.economySettings.presidentTerm||god.defaults().presidentTerm;
      g.ownerPresidentOffer={jid:who,key:rp.memberKey(who),offeredAt:now,expiresAt:now+30*60000,term,appointedByOwner:true};rp.touch();
      god.audit('Owner offered Presidency',`${num(who)}; expires in 30 minutes; term ${shortDuration(term)}`,group);
      await announce(ctx,group,`👑 *OWNER DECREE — PRESIDENTIAL OFFER*\n@${num(who)} has been offered the presidency by the Owner. The offer is not active until accepted.\nAccept within 30 minutes using \`${prefix}president accept\`.\nProposed term: ${shortDuration(term)}.`,[who]);
      return reply(`✅ Offered @${num(who)} the presidency of *${groupName}*. They must accept within 30 minutes by sending \`${prefix}president accept\` in that group. The current President remains in office until acceptance.`,{mentions:[who]});
    }
    if(Object.hasOwn(rp.GOVERNMENT_POSITIONS,role)) {
      const u=rp.user(group,who), spec=rp.GOVERNMENT_POSITIONS[role], key=rp.memberKey(who);
      if((u.wanted||0)>0)return reply('🚨 Wanted members cannot be appointed to government staff. Issue a pardon first if the wanted status is incorrect.');
      if((u.jailedUntil||0)>now)return reply('A detained member cannot accept government office.');
      if(u.gang)return reply('A gang-affiliated member cannot be appointed to government office.');
      if(g.governmentStaff[key]&&g.governmentStaff[key].until>now)return reply('That member already holds an active government office.');
      if(Object.values(g.governmentStaff).some(x=>x.position===role&&x.until>now&&rp.memberKey(x.jid)!==key)||Object.values(g.governmentAppointmentOffers||{}).some(x=>x.position===role&&x.expiresAt>now&&rp.memberKey(x.jid)!==key))return reply(`The ${spec.title} position is already occupied or has a pending offer.`);
      g.governmentAppointmentOffers[key]={jid:who,title:spec.title,position:role,salary:spec.salary,appointedBy:'owner',offeredAt:now,expiresAt:now+30*60000,powers:[spec.power]};rp.touch();god.audit('Owner offered government appointment',`${num(who)} · ${spec.title}`,group);
      await announce(ctx,group,`👑 *OWNER DECREE — APPOINTMENT OFFER*\n@${num(who)} has been offered *${spec.title}* by the Owner. They must accept within 30 minutes with \`${prefix}govstaff accept\`. Wanted, detained, and gang-affiliated members are not eligible.`,[who]);
      return reply(`✅ Offered @${num(who)} the position of *${spec.title}* in *${groupName}*. They must accept within 30 minutes in that group.`,{mentions:[who]});
    }
    if(Object.hasOwn(rp.CAREERS,role)) {
      const eligible=rp.careerEligibility(group,who,role,now);if(!eligible.ok)return reply(`Cannot offer ${rp.CAREERS[role].name}: ${eligible.why}. Law-enforcement eligibility rules remain enforced even for Owner appointments.`);
      const candidate=rp.user(group,who);if(candidate.career)return reply(`@${num(who)} already has the ${rp.CAREERS[candidate.career]?.name||candidate.career} career. They must leave it before accepting another.`);
      const holder=rp.careerHolder(group,role,now);if(holder&&holder.key!==rp.memberKey(who))return reply(`The ${rp.CAREERS[role].name} position is already occupied.`);
      const key=rp.memberKey(who);g.careerAppointmentOffers[key]={jid:who,career:role,offeredAt:now,expiresAt:now+30*60000,appointedBy:'owner'};rp.touch();god.audit('Owner offered career appointment',`${num(who)} · ${role}`,group);
      await announce(ctx,group,`👑 *OWNER DECREE — CAREER OFFER*\n@${num(who)} has been offered the position of ${rp.CAREERS[role].name}. They must accept within 30 minutes with \`${prefix}career accept\`. Eligibility rules were checked; wanted, jailed, gang-affiliated, or unreformed criminal applicants are not eligible.`,[who]);return reply(`✅ Offered @${num(who)} the ${rp.CAREERS[role].name} position in *${groupName}*. They must accept within 30 minutes in that group.`,{mentions:[who]});
    }
    return reply(`Unknown office/career. Use \`${prefix}president positions\` for government position IDs or \`${prefix}career list\` for careers.`);
  }
  if(action==='dismiss') {
    const kind=(argv[1]||'').toLowerCase(), g=rp.state(group);
    if(kind==='president') {
      const old=g.president;if(!old)return reply(`There is no serving President in ${groupName}.`);
      rp.collectPresidentSalary(group,Date.now());g.lastPresidentKey=old.key||rp.memberKey(old.jid);g.lastPresidentJid=old.jid;g.president=null;g.presidentTax=0;g.presidentKingTax=0;g.curfewUntil=0;g.ownerPresidentOffer=null;rp.touch();god.audit('Owner dismissed President',num(old.jid),group);
      await announce(ctx,group,`👑 *OWNER DECREE — PRESIDENT REMOVED*\n@${num(old.jid)} has been removed from the presidency by the Owner.`,[old.jid]);return reply(`✅ President @${num(old.jid)} dismissed from *${groupName}*. Completed salary intervals were settled.`,{mentions:[old.jid]});
    }
    const token=kind==='staff'||kind==='career'?argv[2]:argv[1], who=targetJid(ctx,token);if(!who)return reply(`Usage: \`${prefix}god dismiss president\`, \`${prefix}god dismiss @user\`, or \`${prefix}god dismiss staff @user\`.`);
    const key=rp.memberKey(who);let removed=[];
    if(kind!=='career'&&g.governmentStaff[key]){delete g.governmentStaff[key];delete g.governmentAppointmentOffers[key];removed.push('government office');}
    const u=rp.user(group,who);if(kind!=='staff'&&u.career){const r=rp.removeCareerHolder(group,who);if(r.ok)removed.push(r.career+' career');}
    if(!removed.length)return reply(`@${num(who)} has no matching active office or career in ${groupName}.`,{mentions:[who]});
    rp.touch();god.audit('Owner dismissed official',`${num(who)} · ${removed.join(', ')}`,group);await announce(ctx,group,`👑 *OWNER DECREE — OFFICIAL REMOVED*\n@${num(who)} has been removed from ${removed.join(' and ')} by the Owner.`,[who]);return reply(`✅ Removed @${num(who)} from ${removed.join(' and ')} in *${groupName}*.`,{mentions:[who]});
  }
  if(action==='staffpay') {
    const who=targetJid(ctx,argv[1]), amount=Number(argv[2]);if(!who||!Number.isSafeInteger(amount)||amount<1||amount>1000000000)return reply(`Usage: \`${prefix}god staffpay @user <1-1,000,000,000 coins per 20m>\``);
    const g=rp.state(group), staff=g.governmentStaff[rp.memberKey(who)];if(!staff||staff.until<=Date.now())return reply('That member does not hold an active government office.');const old=staff.pendingSalary||staff.salary;staff.pendingSalary=amount;staff.salaryEffectiveAt=(staff.lastPaidAt||staff.since||Date.now())+20*60000;rp.touch();god.audit('Owner changed government staff salary',`${num(who)} · ${fmt(old)} -> ${fmt(amount)} / 20m`,group);await announce(ctx,group,`📢 *OWNER PAYROLL DECREE*\n@${num(who)}'s government salary has been set to ${fmt(amount)} coins per 20 minutes, effective at the next pay interval.`,[who]);return reply(`✅ ${num(who)}'s salary changed from ${fmt(old)} to ${fmt(amount)} coins per 20 minutes.`,{mentions:[who]});
  }
  if(action==='grant') {
    const who=targetJid(ctx,argv[1]), amount=Number(argv[2]);if(!who||!Number.isSafeInteger(amount)||amount<1||amount>Number.MAX_SAFE_INTEGER)return reply(`Usage: \`${prefix}god grant @user <positive coins>\``);
    const previous=economy.runIn(group,()=>economy.balance(who));if(amount>Number.MAX_SAFE_INTEGER-previous)return reply('That grant would exceed the safe wallet balance limit. Split it into smaller grants.');const balance=economy.runIn(group,()=>economy.add(who,amount));god.audit('Owner granted coins',`${num(who)} +${fmt(amount)}; ${fmt(previous)} -> ${fmt(balance)}`,group);
    await announce(ctx,group,`🎁 *OWNER GRANT*\n@${num(who)} received ${fmt(amount)} coins from the Owner.\nWallet: ${fmt(previous)} → ${fmt(balance)} coins.`,[who]);return reply(`✅ Granted ${fmt(amount)} coins to @${num(who)} in *${groupName}*. New wallet balance: ${fmt(balance)}.`,{mentions:[who]});
  }
  if(action==='treasury') {
    const mode=(argv[1]||'').toLowerCase(), amount=Number(argv[2]);if(!['add','take'].includes(mode)||!Number.isSafeInteger(amount)||amount<1||amount>Number.MAX_SAFE_INTEGER)return reply(`Usage: \`${prefix}god treasury <add|take> <positive coins>\``);
    const g=rp.state(group), before=g.governmentTreasury||0;if(mode==='take'&&amount>before)return reply(`Treasury only holds ${fmt(before)} coins.`);if(mode==='add'&&amount>Number.MAX_SAFE_INTEGER-before)return reply('That deposit would exceed the safe treasury balance limit. Split it into smaller deposits.');g.governmentTreasury=mode==='add'?before+amount:before-amount;rp.recordTreasuryTransaction(group,`Owner ${mode}`,amount,'owner',`Owner ${mode} treasury`);rp.touch();god.audit(`Owner treasury ${mode}`,`${fmt(amount)}; ${fmt(before)} -> ${fmt(g.governmentTreasury)}`,group);
    await announce(ctx,group,`🏦 *OWNER TREASURY DECREE*\n${fmt(amount)} coins ${mode==='add'?'added to':'withdrawn from'} the public treasury.\nTreasury balance: ${fmt(g.governmentTreasury)} coins.`);return reply(`✅ Treasury ${mode}: ${fmt(amount)} coins. New balance: ${fmt(g.governmentTreasury)} in *${groupName}*.`);
  }
  if(action==='pardon') {
    const who=targetJid(ctx,argv[1]);if(!who)return reply(`Usage: \`${prefix}god pardon @user\``);
    const u=rp.user(group,who);u.wanted=0;u.jailedUntil=0;u.bail=0;u.jailReason='';u.jailedBy='';u.jailType='';u.crimeRecordAt=0;u.lastCrime=0;u.servedSentenceAt=0;rp.touch();god.audit('Owner issued full pardon',num(who),group);
    await announce(ctx,group,`⚖️ *OWNER PARDON*\n@${num(who)} has received a full pardon. Wanted status and active detention have been cleared, and their criminal record has been reset.`,[who]);return reply(`✅ Full pardon issued to @${num(who)} in *${groupName}*.`,{mentions:[who]});
  }
  if(action==='wanted') {
    const who=targetJid(ctx,argv[1]), level=Number(argv[2]);if(!who||!Number.isInteger(level)||level<0||level>5)return reply(`Usage: \`${prefix}god wanted @user <0-5>\``);
    const r=rp.setWantedLevel(group,who,level);if(!r.ok)return reply('Wanted level must be between 0 and 5.');god.audit('Owner changed wanted level',`${num(who)} -> ${level}/5`,group);await announce(ctx,group,`🚨 *OWNER SECURITY OVERRIDE*\n@${num(who)}'s wanted level is now ${level}/5.`,[who]);return reply(`✅ Wanted level for @${num(who)} set to ${level}/5 in *${groupName}*.`,{mentions:[who]});
  }
  if(action==='event') {
    const message=argv.slice(1).join(' ').trim().slice(0,1000);if(!message)return reply(`Usage: \`${prefix}god ${global?'global ':''}event <announcement>\``);
    if(global){const all=await groupList(ctx);let sent=0;for(const g of all)if(await announce(ctx,g.jid,`🌍 *OWNER WORLD DECREE*\n${message}`))sent++;god.audit('Global world event',`${message}; sent to ${sent}/${all.length} groups`);return reply(`🌍 Global announcement sent to ${sent}/${all.length} participating groups.`);}
    const ok=await announce(ctx,group,`🌍 *OWNER WORLD DECREE*\n${message}`);god.audit('Group world event',message,group);return reply(ok?`🌍 Announcement sent to *${groupName}*.`:`The event was recorded, but WhatsApp did not accept the message to ${groupName}.`);
  }
  if(action==='election') {
    const mode=(argv[1]||'').toLowerCase(), g=rp.state(group);
    if(mode==='cancel') { if(g.governmentElection){g.governmentElection.status='cancelled';g.governmentElection.cancelledAt=Date.now();}if(g.governmentImpeachment){g.governmentImpeachment.status='cancelled';g.governmentImpeachment.cancelledAt=Date.now();}rp.touch();god.audit('Owner cancelled active ballots','Election/impeachment ballots cancelled',group);await announce(ctx,group,'👑 *OWNER DECREE*\nAny active presidential election or impeachment ballot has been cancelled.');return reply(`✅ Active election/impeachment ballots cancelled in *${groupName}*.`); }
    if(mode==='pause'||mode==='resume'){god.setElectionPaused(group,mode==='pause');god.audit(`Owner ${mode}d elections`,'Election setting changed',group);await announce(ctx,group,`👑 *OWNER DECREE*\nPresidential elections are now ${mode==='pause'?'paused':'resumed'} in this group.`);return reply(`✅ Elections ${mode==='pause'?'paused':'resumed'} for *${groupName}*. While paused, new elections, registrations and votes are blocked; use \`${prefix}god election cancel\` to cancel an active ballot.`);}
    return reply(`Usage: \`${prefix}god election <cancel|pause|resume>\``);
  }
  return reply(`Unknown God command. Use \`${prefix}god panel\` for the control list.`);
}}];
