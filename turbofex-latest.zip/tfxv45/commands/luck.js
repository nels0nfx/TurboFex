// Owner tools for the coin economy: luck (the gamble chance of one person) and ecoboost (pay, chat coins and shop prices).
const economy = require('../core/economy');
const throne = require('../core/throne');
const market = require('../core/market');
const groups = require('../whatsapp/groups');
const { resolveTarget, num } = require('../whatsapp/utils');

const base = { category: 'owner', realOwnerOnly: true, needs: [], weight: 'light' };

const DURATION = /^(\d+)\s*(m|min|h|hr|hrs|d|day|days|w)$/i;
const UNIT = { m: 60000, min: 60000, h: 3600000, hr: 3600000, hrs: 3600000, d: 86400000, day: 86400000, days: 86400000, w: 604800000 };
const span = (ms) => {
  const m = Math.round(ms / 60000);
  if (m < 60) return `${m} minute${m === 1 ? '' : 's'}`;
  if (m < 2880) return `${Math.round(m / 60)} hour${Math.round(m / 60) === 1 ? '' : 's'}`;
  return `${Math.round(m / 1440)} days`;
};
const isNumberToken = (t) => /^@?\+?\d{7,15}$/.test(t);

// where to apply: the group named, the current group, or every group (null)
async function whereOf(sock, words, isGroup, jid) {
  const text = words.join(' ').trim();
  if (/^(all|everywhere|any)$/i.test(text)) return { group: null, name: 'all groups' };
  if (text) {
    const g = await groups.resolve(sock, text);
    return g ? { group: g.jid, name: g.name } : { error: `⚠️ *I could not find a group called "${text.slice(0, 30)}".* Use the number from the groups list, or part of the group name.` };
  }
  if (isGroup) return { group: jid, name: 'this group' };
  return { group: null, name: 'all groups' };
}

module.exports = [
  {
    ...base,
    name: 'luck',
    aliases: ['setluck'],
    description: 'Owner: set the gamble chance of someone: luck 2348012345678 80 (also 1d, and a group) / luck off / luck list',
    async run({ sock, msg, args, reply, jid, isGroup, prefix }) {
      const first = (args[0] || '').toLowerCase();

      if (first === 'list') {
        const rows = economy.luckList();
        if (!rows.length) return reply('🍀 *Nobody has special luck.*');
        const names = {};
        try {
          for (const g of await groups.list(sock)) names[g.jid] = g.name;
        } catch (err) {
          // the group names are only a nicety
        }
        return reply(`🍀 *Special luck*\n\n${rows.map((r) => `▸ *${r.key}* – ${Math.round(r.chance * 100)}% • ${r.group ? names[r.group] || r.group : 'all groups'} • ${r.until ? `${span(r.until - Date.now())} left` : 'until removed'}`).join('\n')}\n\n_Remove with_ \`${prefix}luck off <number>\``);
      }

      const target = resolveTarget(msg, args);
      const off = first === 'off' || first === 'remove' || first === 'clear';
      if (!target) {
        return reply(
          `🍀 *Luck*\n_Change the gamble chance of one person. They are not told. Normal chance is 45%._\n\n*Usage:*\n▸ \`${prefix}luck 2348012345678 80\` – 80% in every group\n▸ \`${prefix}luck 2348012345678 70 1d\` – for one day (also 30m, 2h, 1w)\n▸ \`${prefix}luck 2348012345678 90 1\` – only in group number 1 of \`${prefix}gjids\`\n▸ \`${prefix}luck @user 80\` – in a group: this group only\n▸ \`${prefix}luck off 2348012345678\` – back to normal\n▸ \`${prefix}luck list\``
        );
      }
      const rest = args.filter((a) => !isNumberToken(a) && !/^@/.test(a) && !['off', 'remove', 'clear'].includes(a.toLowerCase()));

      if (off) {
        const where = await whereOf(sock, rest, isGroup, jid);
        if (where.error) return reply(where.error);
        const had = economy.clearLuck(target, args.some((a) => /^(all|everywhere)$/i.test(a)) ? null : where.group);
        return reply(had ? `✅ *Luck removed* for @${num(target)}.` : `ℹ️ *@${num(target)} had no special luck.*`, { mentions: [target] });
      }

      const chanceWord = rest.find((a) => /^\d{1,3}(\.\d+)?%?$/.test(a));
      if (!chanceWord) return reply(`⚠️ *Write the chance (1 to 100).* Example: \`${prefix}luck 2348012345678 80\``);
      const chance = parseFloat(chanceWord) / 100;
      if (!(chance > 0 && chance <= 1)) return reply('⚠️ *The chance must be between 1 and 100.*');
      let until = null;
      const words = rest.filter((a) => a !== chanceWord);
      const dWord = words.find((a) => DURATION.test(a));
      if (dWord) {
        const m = DURATION.exec(dWord);
        until = Date.now() + Number(m[1]) * UNIT[m[2].toLowerCase()];
      }
      const left = words.filter((a) => a !== dWord && !/^(forever|always|permanent)$/i.test(a));
      const where = await whereOf(sock, left, isGroup, jid);
      if (where.error) return reply(where.error);
      economy.setLuck(target, where.group, chance, until);
      await reply(
        `🍀 *Luck set*\n*Person:* @${num(target)}\n*Gamble chance:* ${Math.round(chance * 100)}% _(normal 45%)_\n*Where:* ${where.name}\n*For:* ${until ? span(until - Date.now()) : 'until you remove it'}\n\n_They are not told. Only the gamble command uses it._`,
        { mentions: [target] }
      );
    },
  },
  {
    ...base,
    name: 'ecoboost',
    aliases: ['ecoset', 'economyset'],
    description: 'Owner: make coins easier or harder to earn: ecoboost pay 1.5 / shop 0.5 / chat 2 / reset (king income: kingincome)',
    async run({ args, reply, prefix }) {
      const what = (args[0] || '').toLowerCase();
      const show = () => {
        const c = economy.getCfg();
        return `⚙️ *Economy settings*\n*Pay* (work, fish, hunt, mine, daily): ×${c.pay}\n*Chat coins:* ×${c.chat}\n*Shop prices:* ×${c.shop}\n\n▸ \`${prefix}ecoboost pay 1.5\` – 50% more pay\n▸ \`${prefix}ecoboost shop 0.5\` – everything in the shop half price\n▸ \`${prefix}ecoboost chat 2\` – double coins for chatting\n▸ \`${prefix}ecoboost reset\` – back to normal\n_Applies to every group. Between 0.1 and 20._`;
      };
      if (!what) return reply(show());
      if (what === 'reset') {
        economy.resetCfg();
        return reply(`✅ *Back to normal.*\n\n${show()}`);
      }
      if (!economy.setCfg(what, args[1])) return reply(`⚠️ *Use:* \`${prefix}ecoboost pay|shop|chat <number between 0.1 and 20>\``);
      await reply(`✅ *Updated.*\n\n${show()}`);
    },
  },

  {
    ...base,
    name: 'kingincome',
    aliases: ['kingpay', 'throneincome'],
    description: 'Owner: how many coins an hour the king earns: kingincome 300 / kingincome 500 <group> / kingincome maxtax 10 / kingincome reset',
    async run({ sock, args, reply, jid, isGroup, prefix }) {
      const first = (args[0] || '').toLowerCase();
      const show = async (where) => {
        const i = throne.incomeInfo(where?.group);
        const rule = throne.RULES;
        return (
          `👑 *King income*\n*Normal:* ${i.base} coins an hour\n*All groups:* ${i.global ?? 'normal'}\n` +
          (where?.group ? `*${where.name}:* ${i.group ?? 'same as all groups'} _(now ${i.now})_\n` : '') +
          `*Most tax a king can set:* ${throne.info(where?.group || jid).maxTax}%\n\n` +
          `▸ \`${prefix}kingincome 300\` – ${isGroup ? 'this group' : 'all groups'}\n▸ \`${prefix}kingincome 300 all\` – every group\n▸ \`${prefix}kingincome 500 2\` – group number 2 of \`${prefix}gjids\`\n▸ \`${prefix}kingincome maxtax 10\` – the highest tax a king may set (0 to 25)\n▸ \`${prefix}kingincome reset\` – back to ${rule.incomePerHour}\n_Coins the king already earned are kept._`
        );
      };
      if (first === 'maxtax') {
        const n = parseFloat(args[1]);
        if (!(n >= 0 && n <= 25)) return reply('⚠️ *Choose a number from 0 to 25.*');
        throne.setMaxTax(n);
        return reply(`✅ *A king can now set a tax up to ${n}%.*`);
      }
      if (first === 'reset') {
        const where = await whereOf(sock, args.slice(1), isGroup, jid);
        if (where.error) return reply(where.error);
        throne.resetIncome(where.group);
        return reply(`✅ *King income is back to normal* (${throne.RULES.incomePerHour} an hour) for *${where.name}*.`);
      }
      const n = parseInt(String(args[0] || '').replace(/[,_]/g, ''), 10);
      if (!args.length || !Number.isInteger(n)) return reply(await show(isGroup ? { group: jid, name: 'this group' } : null));
      if (n < 0 || n > 1000000) return reply('⚠️ *Choose between 0 and 1,000,000 coins an hour.*');
      const where = await whereOf(sock, args.slice(1), isGroup, jid);
      if (where.error) return reply(where.error);
      throne.setIncome(where.group, n);
      await reply(`✅ *The king of ${where.name} now earns ${n} coins an hour.*\n_The king collects with_ \`${prefix}throne collect\`.`);
    },
  },
  {
    ...base,
    name: 'ecotransfer',
    aliases: ['ecomove', 'movedata', 'transfereco'],
    description: 'Owner: move the economy progress of one person or a whole group to another group: ecotransfer 1 to 2 / ecotransfer 1 to 2 2348012345678 / add copy',
    async run({ sock, msg, args, reply, prefix }) {
      const words = args.filter((a) => !/^(copy|move)$/i.test(a));
      const copy = args.some((a) => /^copy$/i.test(a));
      const at = words.findIndex((a) => a.toLowerCase() === 'to');
      if (at < 1) {
        const have = [...economy.groupsWithData().entries()];
        let names = {};
        try {
          for (const g of await groups.list(sock)) names[g.jid] = g.name;
        } catch (err) {
          // the names are only a nicety
        }
        return reply(
          `📦 *Move economy data*\n_Moves coins, bank, titles, items, reputation, love and market investments from one group to another. Quests and the throne stay where they are._\n\n*Usage:*\n▸ \`${prefix}ecotransfer 1 to 2\` – everybody of group 1 → group 2\n▸ \`${prefix}ecotransfer 1 to 2 2348012345678\` – one person only\n▸ add \`copy\` to keep the data in the first group too\n_Numbers are from_ \`${prefix}gjids\` _(or write part of the group name)._\n_If the person already has coins in the new group, they are added together._` +
            (have.length ? `\n\n*Groups with economy data:*\n${have.slice(0, 15).map(([g, n]) => `▸ ${names[g] || g} – ${n} people`).join('\n')}` : '')
        );
      }
      const fromText = words.slice(0, at).join(' ');
      const rest = words.slice(at + 1);
      const personWord = rest.find((a) => isNumberToken(a) || /^@/.test(a));
      const toText = rest.filter((a) => a !== personWord).join(' ');
      const from = await groups.resolve(sock, fromText);
      const to = await groups.resolve(sock, toText);
      if (!from) return reply(`⚠️ *I could not find the first group \"${fromText.slice(0, 30)}\".*`);
      if (!to) return reply(`⚠️ *I could not find the second group \"${toText.slice(0, 30)}\".*`);
      if (from.jid === to.jid) return reply('⚠️ *Choose two different groups.*');
      const person = personWord || msg.message?.extendedTextMessage?.contextInfo?.mentionedJid?.[0] ? resolveTarget(msg, rest) : null;
      const who = person ? economy.keyOf(person) : null;
      const moved = economy.moveGroup(from.jid, to.jid, who, copy ? 'copy' : 'move');
      const invested = market.transferPlayers(from.jid, to.jid, who, copy ? 'copy' : 'move');
      if (!moved.length && !invested) return reply(`ℹ️ *Nothing to ${copy ? 'copy' : 'move'}.* ${who ? 'That person has' : 'Nobody has'} economy data in *${from.name}*.`);
      const coins = moved.reduce((t, m) => t + m.coins, 0);
      await reply(`✅ *Economy data ${copy ? 'copied' : 'moved'}*\n*From:* ${from.name}\n*To:* ${to.name}\n*People:* ${Math.max(moved.length, invested)}${who ? ` (@${num(person)})` : ''}\n*Coins and bank:* ${economy.fmt(coins)}\n*Investments moved:* ${invested} ${invested === 1 ? 'person' : 'people'}${invested ? ' _(kept at their value, the new group\'s prices)_' : ''}\n\n_${copy ? 'The first group keeps its data.' : 'They are gone from the first group.'}_`, person ? { mentions: [person] } : {});
    },
  },
];
