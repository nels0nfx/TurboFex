// Owner-only default gamble odds, configurable globally or for a selected group.
const economy = require('../core/economy');
const groups = require('../whatsapp/groups');
const base = { category: 'owner', realOwnerOnly: true, needs: [], weight: 'light' };

async function resolveWhere(sock, words, isGroup, jid) {
  const text = words.join(' ').trim();
  if (!text) return isGroup ? { group: jid, name: 'this group' } : { group: null, name: 'all groups' };
  if (/^(all|everywhere|global)$/i.test(text)) return { group: null, name: 'all groups' };
  const g = await groups.resolve(sock, text);
  return g ? { group: g.jid, name: g.name } : { error: `⚠️ I could not find group "${text.slice(0, 40)}". Use a number from .gjids or part of its name.` };
}

module.exports = [{
  ...base,
  name: 'gambleodds',
  aliases: ['setgamblechance', 'houseodds'],
  description: 'Owner: set default gamble win chance for this group, a named group, or all groups; reset to normal',
  async run({ sock, args, reply, jid, isGroup, prefix }) {
    const first = (args[0] || '').toLowerCase();
    const settings = economy.gambleChanceSettings();
    if (!args.length || ['status', 'list'].includes(first)) {
      const groupLines = Object.entries(settings.groups).filter(([g]) => g !== '*').map(([g, c]) => `• ${g}: ${Math.round(c * 100)}%`);
      return reply(`🎲 *Default gamble odds*\n*Global:* ${settings.global === null ? 'Normal (45%; 50% with Lucky Charm)' : `${Math.round(settings.global * 100)}%`}\n*Current group:* ${isGroup ? (Number.isFinite(settings.groups[jid]) ? `${Math.round(settings.groups[jid] * 100)}%` : 'uses global/default') : 'not in a group'}\n*Group overrides:* ${groupLines.length ? groupLines.join('\n') : 'none'}\n\n*Set odds* (1–100%):\n• \`${prefix}gambleodds 65\` – this group (or all groups in private chat)\n• \`${prefix}gambleodds 60 all\` – every group\n• \`${prefix}gambleodds 70 2\` – group #2 from \`${prefix}gjids\`\n• \`${prefix}gambleodds reset\` – reset this group/global\n• \`${prefix}gambleodds reset all\` – reset every group and global\n\n*Priority:* personal .luck override → group odds → global odds → normal/Lucky Charm. These are win probabilities, not guaranteed outcomes.`);
    }
    if (first === 'reset' || first === 'off' || first === 'clear') {
      const where = await resolveWhere(sock, args.slice(1), isGroup, jid);
      if (where.error) return reply(where.error);
      if (/^(all|everywhere|global)$/i.test(args.slice(1).join(' ').trim())) {
        economy.setGambleChance(null, null);
        for (const g of Object.keys(economy.gambleChanceSettings().groups)) if (g !== '*') economy.setGambleChance(g, null);
        return reply('✅ Gamble odds reset for all groups. Normal odds are 45% (50% with Lucky Charm), unless a personal .luck override exists.');
      }
      economy.setGambleChance(where.group, null);
      return reply(`✅ Gamble odds reset for *${where.name}*. It now uses ${where.group ? 'the global setting or normal odds' : 'normal odds'} unless a personal .luck override exists.`);
    }
    const raw = String(args[0]).replace(/%$/, '');
    const percent = Number(raw);
    if (!Number.isFinite(percent) || percent < 1 || percent > 100) return reply(`⚠️ Chance must be between 1 and 100. Example: \`${prefix}gambleodds 65\``);
    const where = await resolveWhere(sock, args.slice(1), isGroup, jid);
    if (where.error) return reply(where.error);
    economy.setGambleChance(where.group, percent / 100);
    return reply(`✅ *Gamble odds updated*\n*Scope:* ${where.name}\n*Win chance:* ${percent}%\n\n_This changes the default for everyone in that scope. Personal .luck settings override it. This is a probability, not a promise that a player will win._`);
  },
}];
