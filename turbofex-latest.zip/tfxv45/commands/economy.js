// Coins: balance, daily, give, gamble, shop, buy, richest. Coins are earned by chatting (groups with ranks on), the daily bonus and games.
const economy = require('../core/economy');
const quests = require('../core/quests');
const throne = require('../core/throne');
const mentionsLib = require('../whatsapp/mentions');
const { resolveTarget, num } = require('../whatsapp/utils');

const { fmt } = economy;
const base = { category: 'economy', everyone: true, needs: [], weight: 'light' };

const left = (ms) => {
  const h = Math.floor(ms / 3600000);
  const m = Math.ceil((ms % 3600000) / 60000);
  return h ? `${h}h ${m}m` : `${m}m`;
};
const amountOf = (args, from) => {
  const word = ([...args.slice(from)].reverse().find((a) => /^(all|\d{1,12}[\d,_]*)$/i.test(a) && !/^\d{13,}$/.test(a)) || '').toLowerCase(); // the LAST number: a phone number typed before it is not the amount
  return word;
};

const lastGamble = new Map();

module.exports = [
  {
    ...base,
    name: 'balance',
    aliases: ['bal', 'wallet', 'coins', 'inventory', 'inv'],
    description: 'Your coins (or someone else\'s: balance @user)',
    async run({ msg, args, reply, myJid, prefix, jid }) {
      const target = resolveTarget(msg, args) || myJid;
      const u = economy.peek(target);
      const mine = num(target) === num(myJid);
      const owner = mine ? 'Your balance & inventory' : `Balance of @${num(target)}`;
      const partner = mine ? economy.spouseOf(target) : null;
      const partnerJid = partner ? (partner.jid || `${partner.key}@s.whatsapp.net`) : null;
      await reply(
        `💰 *${owner}*\n` +
          `*Wallet:* ${fmt(u.coins)} coins${u.title ? `  ${u.title}` : ''}${throne.isKing(jid, target) ? '  👑 King' : ''}\n` +
          (u.bank ? `*Bank:* ${fmt(u.bank)} coins 🏦\n` : '') +
          (u.streak > 1 ? `*Daily streak:* ${u.streak} days 🔥\n` : '') +
          (economy.hasCharm(target) ? '🍀 *Lucky Charm* is active\n' : '') +
          (economy.itemLeft(target, 'shield') ? '🛡️ *Shield* is active\n' : '') +
          (u.rep ? `*Reputation:* ${u.rep} ⭐\n` : '') +
          (mine ? `*Title:* ${u.title || 'none'}\n*Toolbox:* ${economy.itemLeft(target, 'tools') ? 'active 🧰' : 'none'}\n*Lockpick:* ${economy.itemLeft(target, 'lockpick') ? 'active 🗝️' : 'none'}\n*Partner:* ${partnerJid ? `@${num(partnerJid)} 💍 (${economy.loveTier(u.love).name}, ${u.love || 0} love)` : 'single'}\n\n_Not sure what to do?_ \`${prefix}earn\` shows everything you can do now.` : ''),
        mine ? (partnerJid ? { mentions: [partnerJid] } : {}) : { mentions: [target] }
      );
    },
  },
  {
    ...base,
    name: 'daily',
    description: 'Collect your daily coins (more every day in a row)',
    async run({ reply, myJid, jid }) {
      const r = economy.daily(myJid);
      if (!r.ok) return reply(`⏳ *You already collected today.* Come back in *${left(r.waitMs)}*.`);
      const dq = quests.note(quests.track(jid, myJid, 'daily'));
      await reply(`🎁 *Daily bonus*\n*Earned:* +${fmt(r.amount)} coins${r.love ? ` _(💞 partner bonus +${Math.round(r.love * 100)}%)_` : ''}${r.tax ? ` _(🇳🇬 government tax −${fmt(r.tax)})_` : ''}\n*Streak:* ${r.streak} day${r.streak > 1 ? 's' : ''} 🔥 _(every day in a row pays more)_\n*Total:* ${fmt(r.coins)} coins${dq ? `\n\n${dq}` : ''}`);
    },
  },
  {
    ...base,
    name: 'give',
    aliases: ['pay', 'send'],
    description: 'Give coins to someone: give @user 100',
    async run({ msg, args, reply, myJid, botIds, prefix }) {
      const target = resolveTarget(msg, args);
      const raw = amountOf(args, 0);
      if (!target || !raw) return reply(`*Usage:* \`${prefix}give @user 100\` _(or reply to their message)_`);
      const amount = raw === 'all' ? economy.balance(myJid) : parseInt(raw.replace(/[,_]/g, ''), 10);
      if (num(target) === num(myJid)) return reply('😅 *You cannot give coins to yourself.*');
      if (botIds.includes(num(target))) return reply('🤖 *I do not need coins, thank you!*');
      if (!Number.isInteger(amount) || amount < 1) return reply('⚠️ *Give at least 1 coin.*');
      if (economy.inDebt(myJid)) return reply(`🔒 *You have a loan.* You cannot give coins away until you \`${prefix}repay\` it.`);
      if (!economy.transfer(myJid, target, amount)) return reply(`⚠️ *You only have ${fmt(economy.balance(myJid))} coins.*`);
      await reply(`✅ *Coins sent*\n*To:* @${num(target)}\n*Amount:* ${fmt(amount)} coins\n*Your balance:* ${fmt(economy.balance(myJid))}`, { mentions: [target] });
    },
  },
  {
    ...base,
    name: 'gamble',
    aliases: ['bet'],
    description: 'Bet coins: win and you double the bet, lose and you lose it (gamble 100 or gamble all)',
    async run({ args, reply, myJid, prefix, jid }) {
      const raw = amountOf(args, 0);
      if (!raw) return reply(`🎲 *Gamble*\n*Usage:* \`${prefix}gamble 100\` or \`${prefix}gamble all\`\n*Win:* double your bet\n*Odds:* 45% _(50% with a 🍀 Lucky Charm)_\n*Smallest bet:* 10 coins`);
      const wait = 6000 - (Date.now() - (lastGamble.get(num(myJid)) || 0));
      if (wait > 0) return reply(`⏳ *Slow down.* Wait ${Math.ceil(wait / 1000)} more seconds between bets.`);
      const bet = raw === 'all' ? Math.min(economy.balance(myJid), 100000) : parseInt(raw.replace(/[,_]/g, ''), 10);
      if (!Number.isInteger(bet)) return reply(`*Usage:* \`${prefix}gamble 100\` or \`${prefix}gamble all\``);
      if (bet > 100000) return reply('⚠️ *The highest bet is 100,000 coins.*');
      const r = economy.gamble(myJid, bet);
      if (r.ok) {
        lastGamble.set(num(myJid), Date.now()); // the pause starts only after a real bet
        if (lastGamble.size > 5000) lastGamble.clear();
      }
      if (!r.ok) return reply(r.why === 'jail' ? `⛓️ *You are in roleplay detention* for another ${left(r.left)}. No gambling until then.` : r.why === 'debt' ? `🔒 *You have a loan.* You cannot gamble until you \`${prefix}repay\` it.` : r.why === 'min' ? '⚠️ *The smallest bet is 10 coins.*' : `⚠️ *You only have ${fmt(economy.balance(myJid))} coins.*`);
      const gq = r.win ? quests.note(quests.track(jid, myJid, 'gamblewin')) : null;
      await reply(r.win ? `🎉 *You won!*\n*Won:* +${fmt(bet)} coins\n*Balance:* ${fmt(r.coins)}${gq ? `\n\n${gq}` : ''}` : `💸 *You lost.*\n*Lost:* ${fmt(bet)} coins\n*Balance:* ${fmt(r.coins)}`);
    },
  },
  {
    ...base,
    name: 'shop',
    description: 'See what you can buy with coins',
    async run({ reply, prefix, myJid }) {
      const lines = Object.entries(economy.ITEMS).map(([id, i]) => `▸ *${i.name}* – ${fmt(economy.priceOf(id))} coins\n   _${i.about}_${economy.itemLeft(myJid, id) ? ` ✅ _active, ${left(economy.itemLeft(myJid, id))} left_` : ''}\n   \`${prefix}buy ${id}\``);
      const m = economy.shopMult();
      const note = m > 1.005 ? `\n\n_📈 Prices are ${Math.round((m - 1) * 100)}% higher because of the economy._` : m < 0.995 ? `\n\n_📉 Prices are ${Math.round((1 - m) * 100)}% lower because of the economy._` : '';
      await reply(`🛒 *Shop*\n\n${lines.join('\n\n')}${note}`);
    },
  },
  {
    ...base,
    name: 'buy',
    description: 'Buy something from the shop: buy vip',
    async run({ args, reply, myJid, prefix }) {
      const id = (args[0] || '').toLowerCase();
      if (!id) return reply(`*Usage:* \`${prefix}buy <item>\`\nSee the items with \`${prefix}shop\``);
      const r = economy.buy(myJid, id);
      if (r.ok) return reply(`▸ ✅ *Bought ${r.item.name}!*${r.item.ms ? `\n_${r.item.about}._` : ''}\n*Balance:* ${fmt(economy.balance(myJid))} coins`);
      if (r.why === 'active') return reply(`⏳ *Your ${r.item.name} is still active* for another ${left(r.left)}.`);
      const why = { unknown: `⚠️ *There is no item "${id.slice(0, 20)}".* See \`${prefix}shop\``, active: '🍀 *Your Lucky Charm is still active.*', owned: '✅ *You already have that title.*', poor: `⚠️ *You need ${fmt(r.need || 0)} more coins.*` };
      await reply(why[r.why]);
    },
  },
  {
    ...base,
    name: 'richest',
    aliases: ['rich', 'wealth'],
    description: 'The people with the most coins',
    async run({ sock, jid, isGroup, reply, prefix }) {
      // in a group: only the people of THIS group (coins are shared by all groups, the list is not)
      const members = isGroup ? await mentionsLib.memberKeys(sock, jid) : null;
      let top = economy.richest(10, members && members.size ? (key, u) => members.has(key) || (u.j && members.has(num(u.j))) : null);
      // when the member list cannot be matched (hidden WhatsApp ids), show everybody of this group instead of an empty list
      if (!top.length && members && members.size) top = economy.richest(10, null);
      if (!top.length) return reply(isGroup ? `💰 *Nobody in this group has coins yet.* Start with \`${prefix}daily\`` : `💰 *Nobody has coins yet.* Start with \`${prefix}daily\``);
      const medals = ['🥇', '🥈', '🥉'];
      // in a group the members are tagged (WhatsApp shows their name); in a private chat the name is written
      const who = isGroup ? await mentionsLib.describe(sock, jid, top.map((r) => r.jid)) : top.map((r) => ({ text: `@${num(r.jid)}`, mention: r.jid }));
      const lines = top.map((r, i) => `${medals[i] || `${i + 1}.`} ${who[i].text}${r.title ? ` ${r.title}` : ''} – *${fmt(r.coins)}* coins`);
      await reply(`💰 *Richest${isGroup ? ' in this group' : ''}*\n\n${lines.join('\n')}`, { mentions: who.map((w) => w.mention).filter(Boolean) });
    },
  },
];
