const economy = require('../core/economy');
const throne = require('../core/throne');
const roleplay = require('../core/roleplay');
const store = require('../whatsapp/store');
const groups = require('../whatsapp/groups');
const base = { category: 'economy', everyone: true, needs: [], weight: 'light' };
module.exports = [{ ...base, name: 'economy', aliases: ['eco'], description: 'Group economy status and on/off controls; market and stocks are removed', groupOnly: true, async run({ reply, myJid, jid, prefix, args, isOwner, sock }) {
  const sub = (args[0] || '').toLowerCase();
  if (['on', 'off'].includes(sub)) {
    const all = (args[1] || '').toLowerCase() === 'all';
    if (all && !isOwner) return reply('⚠️ Only the bot owner can switch the economy in every group.');
    let targets = [jid];
    if (all) {
      try { targets = [...new Set([...(await groups.list(sock)).map(g => g.jid), ...economy.groupsWithData().keys()])]; }
      catch { targets = [...new Set([jid, ...economy.groupsWithData().keys()])]; }
    }
    for (const group of targets) {
      economy.setOff(group, sub === 'off');
      economy.setDrops(group, sub !== 'off');
      if (sub === 'on') store.update(group, g => { g.rank = true; });
    }
    return reply(sub === 'off' ? `🔒 *ECONOMY OFF${all ? ' in all groups' : ' in this group'}*\nCoin earning and economy commands are paused. Nothing was deleted.` : `✅ *ECONOMY ON${all ? ' IN ALL GROUPS' : ' IN THIS GROUP'}*\nEconomy commands are active again. Group ranks are enabled.`);
  }
  const u = economy.peek(myJid), king = throne.info(jid).king, pres = roleplay.presidentInfo(jid).president;
  return reply(`💰 *GROUP ECONOMY*\nWallet: ${economy.fmt(u.coins)} coins\nBank: ${economy.fmt(u.bank || 0)} coins\nKing: ${king ? '@' + String(king.jid).split('@')[0] : 'Vacant'}\nPresident: ${pres ? '@' + String(pres.jid).split('@')[0] : 'Vacant'}\nEconomy: ${economy.isOff(jid) ? 'OFF' : 'ON'}\n\nEarn coins with \`${prefix}daily\`, \`${prefix}work\`, \`${prefix}crime\`, games and careers.\nToggle: \`${prefix}economy on\` / \`${prefix}economy off\`.`, { mentions: [king?.jid, pres?.jid].filter(Boolean) });
}}];
