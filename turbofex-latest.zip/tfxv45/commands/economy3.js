// More to do with coins: couple, crime, beg, weekly, garden (plant / harvest), rep, grab (coin drops), heist and earn (what is ready now).
// Everything is per group and stops when an admin writes "economy off".
const economy = require('../core/economy');
const quests = require('../core/quests');
const drops = require('../core/drops');
const throne = require('../core/throne');
const roleplay = require('../core/roleplay');
const { resolveTarget, num } = require('../whatsapp/utils');

const { fmt } = economy;
const base = { category: 'economy', everyone: true, needs: [], weight: 'light' };
const between = (a, b) => a + Math.floor(Math.random() * (b - a + 1));
const pick = (list) => list[Math.floor(Math.random() * list.length)];
const left = (ms) => {
  const m = Math.max(1, Math.ceil(ms / 60000));
  if (m < 60) return `${m}m`;
  const h = Math.floor(m / 60);
  if (h < 48) return `${h}h ${m % 60}m`;
  return `${Math.floor(h / 24)}d ${h % 24}h`;
};
const HOUR = 3600000;
const tag = (jid) => `@${num(jid)}`;
const qnote = (jid, myJid, event) => quests.note(quests.track(jid, myJid, event));
const tail = (q) => (q ? `\n\n${q}` : '');

const GARDEN = { cost: 60, growMs: HOUR, wiltMs: 8 * HOUR, min: 130, max: 210, wilted: 30 };
const COOLDOWNS = { work: HOUR, fish: 30 * 60000, hunt: 45 * 60000, mine: HOUR, crime: 90 * 60000, beg: 10 * 60000, rob: 2 * HOUR };

// ---------------------------------------------------------------- heist (a group job: needs a crew)
const heists = new Map(); // group -> { crew: Map(key -> jid), timer, starter }
const HEIST = { entry: 100, joinMs: 90000, min: 3, max: 10, baseChance: 0.35, perMember: 0.1, topChance: 0.8, multiplier: 2.2 };

async function resolveHeist(sock, group) {
  const h = heists.get(group);
  if (!h) return;
  heists.delete(group);
  await economy.runIn(group, async () => {
    const crew = [...h.crew.values()].filter((jid) => economy.balance(jid) >= HEIST.entry);
    if (crew.length < HEIST.min) {
      return sock.sendMessage(group, { text: `🕵️ *The heist was called off.* It needs ${HEIST.min} people with ${HEIST.entry} coins each, only ${crew.length} were ready. Nobody paid anything.` });
    }
    for (const jid of crew) economy.take(jid, HEIST.entry);
    const pool = crew.length * HEIST.entry;
    const chance = Math.min(HEIST.topChance, HEIST.baseChance + HEIST.perMember * (crew.length - HEIST.min + 1));
    if (Math.random() < chance) {
      const each = Math.floor((pool * HEIST.multiplier) / crew.length);
      for (const jid of crew) economy.add(jid, each);
      const text = `💎 *The heist worked!*\n${crew.map(tag).join(' ')}\nEach of the ${crew.length} got *+${fmt(each)} coins* (they put in ${HEIST.entry}).`;
      await sock.sendMessage(group, { text, mentions: crew });
    } else {
      await sock.sendMessage(group, { text: `🚔 *The heist failed!*\n${crew.map(tag).join(' ')}\nThe police caught the crew. Each lost the *${HEIST.entry} coins* they put in. _Bigger crews have better odds._`, mentions: crew });
    }
  });
}

module.exports = [
  // ---------------------------------------------------------------- couple
  {
    ...base,
    name: 'couple',
    aliases: ['partner', 'spouse', 'love'],
    groupOnly: true,
    description: 'Things to do with your partner: couple / date / daily / gift 200 / cuddle',
    async run({ args, reply, myJid, jid, prefix }) {
      const sub = (args[0] || '').toLowerCase();
      const info = economy.coupleInfo(myJid);
      if (!info) return reply(`💍 *You have no partner.*\nPropose with \`${prefix}marry @user\`. Couples get bonus pay and can do dates, daily gifts and more together.`);
      const p = info.partner;
      const mention = { mentions: [p.jid, myJid] };
      if (sub === 'date') {
        if (economy.inDebt(myJid)) return reply(`🔒 *You have a loan.* Repay it first (\`${prefix}repay\`).`);
        const wait = economy.coupleWait(myJid, 'date', 3 * HOUR);
        if (wait) return reply(`⏳ *You two already had a date.* Again in *${left(wait)}*.`);
        if (economy.balance(myJid) < 100) return reply('⚠️ *A date costs 100 coins.* You do not have that.');
        economy.coupleCooldown(myJid, 'date', 3 * HOUR);
        economy.take(myJid, 100);
        const spot = pick(['had dinner by the river', 'watched a movie', 'went for a long walk', 'danced all night', 'cooked together at home', 'visited the beach']);
        const a = economy.payout(myJid, between(180, 380), { tax: false, tools: false });
        const b = economy.runIn ? economy.payout(p.jid, between(180, 380), { tax: false, tools: false }) : null;
        const love = economy.addLove(myJid, 8);
        return reply(`💞 *Date night!*\n${tag(myJid)} and ${tag(p.jid)} ${spot}.\n*Each got:* +${fmt(a.net)} / +${fmt(b.net)} coins _(the date cost 100)_\n*Love:* ${love} (+8) • ${economy.loveTier(love).name}${tail(null)}`, mention);
      }
      if (sub === 'daily' || sub === 'gift') {
        if (sub === 'gift') {
          const n = parseInt(String(args[1] || '').replace(/[,_]/g, ''), 10);
          if (!Number.isInteger(n) || n < 1) return reply(`*Usage:* \`${prefix}couple gift 200\` – give your partner coins (more love for bigger gifts).`);
          if (economy.inDebt(myJid)) return reply(`🔒 *You have a loan.* Repay it first (\`${prefix}repay\`).`);
          if (!economy.transfer(myJid, p.jid, n)) return reply(`⚠️ *You only have ${fmt(economy.balance(myJid))} coins.*`);
          const add = Math.min(10, Math.floor(n / 200));
          if (add) economy.addLove(myJid, add);
          return reply(`🎁 *A gift for ${tag(p.jid)}!*\n${tag(myJid)} gave *${fmt(n)} coins*.${add ? `\n💞 Love +${add}` : ''}`, mention);
        }
        const wait = economy.coupleWait(myJid, 'cdaily', 24 * HOUR);
        if (wait) return reply(`⏳ *You two already took today's couple bonus.* Again in *${left(wait)}*.`);
        economy.coupleCooldown(myJid, 'cdaily', 24 * HOUR);
        const each = Math.round((150 + Math.min(350, info.love)) * economy.payMult());
        economy.add(myJid, each);
        economy.add(p.jid, each);
        const love = economy.addLove(myJid, 3);
        return reply(`💑 *Couple bonus*\n${tag(myJid)} and ${tag(p.jid)} each got *+${fmt(each)} coins*.\n*Love:* ${love} (+3) • _the more love, the bigger the bonus_`, mention);
      }
      if (sub === 'cuddle' || sub === 'hug' || sub === 'kiss') {
        const cd = economy.cooldown(myJid, 'cuddle', HOUR);
        if (!cd.ok) return reply(`⏳ *Give your partner a break.* Again in *${left(cd.waitMs)}*.`);
        const love = economy.addLove(myJid, 1);
        return reply(`🥰 ${tag(myJid)} ${pick(['hugged', 'kissed', 'cuddled', 'made tea for'])} ${tag(p.jid)}.\n💞 Love ${love} (+1)`, mention);
      }
      const nextTxt = info.next ? `${info.next.min - info.love} more love → *${info.next.name}* (+${Math.round(info.next.boost * 100)}% pay)` : '_the highest level!_';
      const dateWait = economy.coupleWait(myJid, 'date', 3 * HOUR);
      const dailyWait = economy.coupleWait(myJid, 'cdaily', 24 * HOUR);
      await reply(
        `💞 *Couple*\n${tag(myJid)} 💍 ${tag(p.jid)}\n*Together:* ${info.days} day${info.days === 1 ? '' : 's'}\n*Level:* ${info.tier.name} • *Love:* ${info.love}\n*Bonus:* +${Math.round(info.tier.boost * 100)}% on work, fish, hunt, mine, crime and daily\n*Next:* ${nextTxt}\n\n` +
          `▸ \`${prefix}couple date\` – ${dateWait ? `⏳ ${left(dateWait)}` : '✅ ready'} (costs 100, you both earn)\n▸ \`${prefix}couple daily\` – ${dailyWait ? `⏳ ${left(dailyWait)}` : '✅ ready'} (both get coins)\n▸ \`${prefix}couple gift 200\` – give coins, gain love\n▸ \`${prefix}couple cuddle\` – +1 love, every hour`,
        mention
      );
    },
  },

  // ---------------------------------------------------------------- crime / beg / weekly
  {
    ...base,
    name: 'crime',
    description: 'A risky job: big pay, but you can be fined (every 90 minutes)',
    async run({ reply, myJid, jid, prefix }) {
      if (economy.isKing(myJid)) return reply('🏛️ *Government leaders cannot commit street crime.* Resign from office before returning to criminal activity.');
      if (['police','royalguard','soldier'].includes(roleplay.refreshCareer(jid, myJid).career)) return reply('🛡️ *Serving law enforcement cannot commit street crime.* Resign from your career first.');
      const rpUser = roleplay.user(jid, myJid);
      const rpJail = Math.max(0, (rpUser.jailedUntil || 0) - Date.now());
      if (rpJail) return reply(`⛓️ *You are in roleplay detention for another ${left(rpJail)}. If this is police detention, pay bail with \`${prefix}wanted bail\` to get out early.`);
      const j = economy.jailLeft(myJid);
      if (j) return reply(`⛓️ *You are in roleplay detention* for another ${left(j)}.`);
      if (economy.inDebt(myJid)) return reply(`🔒 *You have a loan.* Repay it first (\`${prefix}repay\`).`);
      const cd = economy.cooldown(myJid, 'crime', COOLDOWNS.crime);
      if (!cd.ok) return reply(`⏳ *Lay low for a while.* Try again in *${left(cd.waitMs)}*.`);
      const q = qnote(jid, myJid, 'crime');
      if (Math.random() < 0.55) {
        const wanted = roleplay.addWanted(jid, myJid, 1); 
        const p = economy.payout(myJid, between(300, 900));
        return reply(`🦹 *${pick(['You hacked a vending machine', 'You sold fake watches', 'You pulled off a quiet pickpocket run', 'You sneaked into a closed market'])}*\n*Earned:* +${fmt(p.net)} coins${p.tax ? ` _(🇳🇬 government tax −${fmt(p.tax)})_` : ''}\n*Wallet:* ${fmt(economy.balance(myJid))}\n🚨 *Wanted level:* ${wanted}/5${tail(q)}`);
      }
      const wanted = roleplay.addWanted(jid, myJid, 2);
      const fine = Math.min(economy.balance(myJid), between(150, 400));
      if (fine) economy.take(myJid, fine);
      return reply(`🚔 *${pick(['The police were waiting', 'A neighbour called the cops', 'You tripped the alarm'])}*\n*Fine:* −${fmt(fine)} coins\n*Wallet:* ${fmt(economy.balance(myJid))}\n🚨 *Wanted level:* ${wanted}/5${tail(q)}`);
    },
  },
  {
    ...base,
    name: 'beg',
    description: 'Ask for a few coins (every 10 minutes)',
    async run({ reply, myJid }) {
      const cd = economy.cooldown(myJid, 'beg', COOLDOWNS.beg);
      if (!cd.ok) return reply(`⏳ *People are tired of you.* Try again in *${left(cd.waitMs)}*.`);
      if (Math.random() < 0.25) return reply(`🙏 *${pick(['Nobody stopped', 'A dog barked at you', 'They pretended not to see you'])}.*\n_Nothing this time._`);
      const n = between(10, 45);
      economy.add(myJid, n);
      await reply(`🙏 *${pick(['A kind stranger helped you', 'An old lady gave you some coins', 'A child shared his pocket money'])}*\n*Got:* +${n} coins\n*Wallet:* ${fmt(economy.balance(myJid))}`);
    },
  },
  {
    ...base,
    name: 'weekly',
    description: 'Your big weekly bonus (every 7 days)',
    async run({ reply, myJid, jid }) {
      const cd = economy.cooldown(myJid, 'weekly', 7 * 24 * HOUR);
      if (!cd.ok) return reply(`⏳ *You already took this week's bonus.* Come back in *${left(cd.waitMs)}*.`);
      const p = economy.payout(myJid, 3000, { tools: false });
      await reply(`🎉 *Weekly bonus*\n*Earned:* +${fmt(p.net)} coins${p.love ? ` _(💞 +${Math.round(p.love * 100)}%)_` : ''}\n*Wallet:* ${fmt(economy.balance(myJid))}${tail(null)}`);
    },
  },

  // ---------------------------------------------------------------- garden
  {
    ...base,
    name: 'garden',
    aliases: ['plant', 'crop', 'farmplot'],
    description: 'Plant a seed (60 coins), wait 1 hour, harvest for more: plant / garden harvest',
    async run({ reply, myJid, jid, cmdName, args, prefix }) {
      const sub = cmdName === 'plant' ? 'plant' : (args[0] || '').toLowerCase();
      const u = economy.peek(myJid);
      const now = Date.now();
      const plot = u.plot;
      if (sub === 'plant') {
        if (plot) return reply(plot && now - plot.at >= GARDEN.growMs ? `🌾 *Your crop is ready!* Send \`${prefix}garden harvest\` first.` : `🌱 *Your seed is still growing.* Ready in *${left(plot.at + GARDEN.growMs - now)}*.`);
        if (economy.inDebt(myJid)) return reply(`🔒 *You have a loan.* Repay it first (\`${prefix}repay\`).`);
        if (!economy.take(myJid, GARDEN.cost)) return reply(`⚠️ *Seeds cost ${GARDEN.cost} coins.* You have ${fmt(economy.balance(myJid))}.`);
        u.plot = { at: now };
        economy.touch();
        return reply(`🌱 *Planted!*\nIt grows for ${left(GARDEN.growMs)}. Then \`${prefix}garden harvest\` it (within ${left(GARDEN.wiltMs)} or it wilts).`);
      }
      if (sub === 'harvest') {
        if (!plot) return reply(`🌱 *You have nothing planted.* Start with \`${prefix}plant\` (${GARDEN.cost} coins).`);
        if (now - plot.at < GARDEN.growMs) return reply(`🌱 *Not ready yet.* Ready in *${left(plot.at + GARDEN.growMs - now)}*.`);
        const wilted = now - plot.at > GARDEN.wiltMs;
        u.plot = null;
        economy.touch();
        const q = qnote(jid, myJid, 'harvest');
        if (wilted) {
          economy.add(myJid, GARDEN.wilted);
          return reply(`🥀 *Your crop wilted* because you waited too long. You saved *${GARDEN.wilted} coins* worth.\n_Harvest within ${left(GARDEN.wiltMs)} next time._${tail(q)}`);
        }
        const p = economy.payout(myJid, between(GARDEN.min, GARDEN.max), { tax: false, tools: false });
        return reply(`🌾 *Harvest!*\n*Earned:* +${fmt(p.net)} coins _(seeds cost ${GARDEN.cost})_\n*Wallet:* ${fmt(economy.balance(myJid))}${tail(q)}`);
      }
      const status = !plot ? `Empty. \`${prefix}plant\` costs ${GARDEN.cost} coins.` : now - plot.at < GARDEN.growMs ? `🌱 Growing – ready in *${left(plot.at + GARDEN.growMs - now)}*.` : now - plot.at > GARDEN.wiltMs ? '🥀 Wilted. Harvest it to clear the plot.' : `🌾 *Ready!* Send \`${prefix}garden harvest\`.`;
      await reply(`🌱 *Your garden*\n${status}\n\n▸ \`${prefix}plant\` • \`${prefix}garden harvest\`\n_Plant (${GARDEN.cost}), wait ${left(GARDEN.growMs)}, harvest ${GARDEN.min}–${GARDEN.max}. Wilts after ${left(GARDEN.wiltMs)}._`);
    },
  },

  // ---------------------------------------------------------------- rep
  {
    ...base,
    name: 'rep',
    aliases: ['reputation', 'thanks'],
    groupOnly: true,
    description: 'Give a member reputation (once every 12 hours, you both get coins): rep @user',
    async run({ msg, args, reply, myJid, jid, botIds, prefix }) {
      const target = resolveTarget(msg, args);
      if (!target) return reply(`⭐ *Reputation*\nThank somebody who helped: \`${prefix}rep @user\`\nThey get +1 ⭐ and 50 coins, you get 20. Once every 12 hours.`);
      if (economy.keyOf(target) === economy.keyOf(myJid)) return reply('😅 *You cannot give reputation to yourself.*');
      if (botIds.includes(num(target))) return reply('🤖 *Thank you, but keep it for the people!*');
      const cd = economy.cooldown(myJid, 'rep', 12 * HOUR);
      if (!cd.ok) return reply(`⏳ *You already gave reputation.* Again in *${left(cd.waitMs)}*.`);
      const t = economy.peek(target);
      t.rep = (t.rep || 0) + 1;
      economy.add(target, 50);
      economy.add(myJid, 20);
      const q = qnote(jid, myJid, 'rep');
      await reply(`⭐ *${tag(myJid)} gave reputation to ${tag(target)}!*\n${tag(target)} now has *${t.rep}* ⭐ and got +50 coins. You got +20.${tail(q)}`, { mentions: [myJid, target] });
    },
  },

  // ---------------------------------------------------------------- grab (coin drops)
  {
    ...base,
    name: 'grab',
    groupOnly: true,
    description: 'Grab the bag of coins that dropped in the chat (the first one wins)',
    async run({ reply, jid, myJid }) {
      const r = drops.grab(jid, myJid);
      if (!r.ok) return reply(r.why === 'gone' ? '💨 *Too late,* the bag is gone.' : '👀 *There is nothing to grab right now.* Bags drop now and then when the chat is active.');
      await reply(`💰 *${tag(myJid)} grabbed the bag!*\n*Won:* +${fmt(r.prize)} coins\n*Wallet:* ${fmt(economy.balance(myJid))}${tail(r.quest)}`, { mentions: [myJid] });
    },
  },

  // ---------------------------------------------------------------- heist
  {
    ...base,
    name: 'heist',
    groupOnly: true,
    description: 'A group robbery: heist to start, heist join to be in the crew (100 coins each, 3+ people)',
    async run({ sock, jid, args, reply, myJid, prefix }) {
      const sub = (args[0] || '').toLowerCase();
      const h = heists.get(jid);
      const need = `${HEIST.entry} coins each`;
      if (economy.isKing(myJid)) return reply('🏛️ *The King and President cannot lead a heist.* Government office carries legal immunity.');
      if (['police','royalguard','soldier'].includes(roleplay.refreshCareer(jid, myJid).career)) return reply('🛡️ Serving law enforcement cannot join criminal heists.')
      if (economy.peaceLeft() > 0) return reply(`🕊️ *A peace law is in force.* No heists for another ${left(economy.peaceLeft())}.`);
      if (sub === 'join' || (h && !sub)) {
        if (!h) return reply(`🕵️ *No heist is being planned.* Start one with \`${prefix}heist\`.`);
        if (economy.balance(myJid) < HEIST.entry) return reply(`⚠️ *You need ${HEIST.entry} coins* to join the crew.`);
        if (economy.inDebt(myJid)) return reply(`🔒 *You have a loan.* Repay it first (\`${prefix}repay\`).`);
        if (economy.jailLeft(myJid)) return reply("⛓️ *You are in roleplay detention.*");
        if (h.crew.size >= HEIST.max && !h.crew.has(economy.keyOf(myJid))) return reply('⚠️ *The crew is full.*');
        if (h.crew.has(economy.keyOf(myJid))) return reply('✅ *You are already in the crew.*');
        h.crew.set(economy.keyOf(myJid), myJid);
        return reply(`🕵️ *${tag(myJid)} joined the crew!* (${h.crew.size}/${HEIST.max})\n_The heist starts in ${left(Math.max(1, h.at + HEIST.joinMs - Date.now()))}._`, { mentions: [myJid] });
      }
      if (h) return reply(`🕵️ *A heist is already being planned.* Join with \`${prefix}heist join\`.`);
      if (economy.balance(myJid) < HEIST.entry) return reply(`⚠️ *You need ${HEIST.entry} coins* to lead a heist.`);
      if (economy.inDebt(myJid)) return reply(`🔒 *You have a loan.* Repay it first (\`${prefix}repay\`).`);
      if (economy.jailLeft(myJid)) return reply("⛓️ *You are in roleplay detention.*");
      const crew = new Map([[economy.keyOf(myJid), myJid]]);
      const state = { crew, at: Date.now() };
      state.timer = setTimeout(() => resolveHeist(sock, jid).catch((e) => console.error('Heist error:', e.message)), HEIST.joinMs);
      if (state.timer.unref) state.timer.unref();
      heists.set(jid, state);
      await reply(`🕵️ *${tag(myJid)} is planning a heist!*\nJoin the crew with \`${prefix}heist join\` in the next *${HEIST.joinMs / 1000} seconds*.\n▸ ${need} (taken when it starts) • at least ${HEIST.min} people, up to ${HEIST.max}\n▸ Success: pays ×${HEIST.multiplier} to every member. Chance: ${Math.round(HEIST.baseChance * 100)}% with ${HEIST.min}, +${Math.round(HEIST.perMember * 100)}% for each extra person (max ${Math.round(HEIST.topChance * 100)}%).\n▸ Failure: everybody loses the ${HEIST.entry}.`, { mentions: [myJid] });
    },
  },

  // ---------------------------------------------------------------- earn: what can I do now?
  {
    ...base,
    name: 'earn',
    aliases: ['activities', 'ways'],
    description: 'Everything you can do to earn coins, and what is ready now',
    async run({ jid, reply, myJid, prefix, isGroup }) {
      const u = economy.peek(myJid);
      const now = Date.now();
      const ready = (ms) => (ms > 0 ? `⏳ ${left(ms)}` : '✅ ready');
      const dailyMs = u.lastDaily && now - u.lastDaily < 24 * HOUR ? 24 * HOUR - (now - u.lastDaily) : 0;
      const row = (name, text, ms) => `${ready(ms)} \`${prefix}${name}\` – ${text}`;
      const plotText = !u.plot ? ['plant', 'plant a seed (60)', 0] : now - u.plot.at >= GARDEN.growMs ? ['garden harvest', 'your crop is ripe', 0] : ['garden harvest', 'your crop is growing', u.plot.at + GARDEN.growMs - now];
      const lines = [
        row('daily', 'the daily bonus (streak pays more)', dailyMs),
        row('weekly', 'the big weekly bonus', economy.cooldownLeft(myJid, 'weekly', 7 * 24 * HOUR)),
        row('work', 'steady pay', economy.cooldownLeft(myJid, 'work', COOLDOWNS.work)),
        row('fish', 'small, can fail', economy.cooldownLeft(myJid, 'fish', COOLDOWNS.fish)),
        row('hunt', 'medium', economy.cooldownLeft(myJid, 'hunt', COOLDOWNS.hunt)),
        row('mine', 'bigger pay', economy.cooldownLeft(myJid, 'mine', COOLDOWNS.mine)),
        row('crime', 'risky, big pay', economy.cooldownLeft(myJid, 'crime', COOLDOWNS.crime)),
        row('beg', 'a few coins', economy.cooldownLeft(myJid, 'beg', COOLDOWNS.beg)),
        row(...plotText),
      ];
      const more = [`🎯 \`${prefix}quests\` – 3 missions a day with bonuses`];
      if (isGroup) {
        const i = throne.info(jid);
        more.push(`💼 \`${prefix}career\` – take a job with special powers`, `👑 \`${prefix}throne\` – ${i.king ? 'the king earns every hour' : 'the throne is empty!'}`, `🕵️ \`${prefix}heist\` – rob with a crew • ⭐ \`${prefix}rep @user\` • 💰 \`${prefix}grab\` when a bag drops`);
        if (economy.spouseOf(myJid)) {
          more.push(`💞 \`${prefix}couple\` – date ${ready(economy.coupleWait(myJid, 'date', 3 * HOUR))} • daily ${ready(economy.coupleWait(myJid, 'cdaily', 24 * HOUR))}`);
        } else more.push(`💍 \`${prefix}marry @user\` – couples earn bonus pay`);
      }
      await reply(`🧭 *What to do now*\n*Wallet:* ${fmt(u.coins)} coins\n\n${lines.join('\n')}\n\n${more.join('\n')}\n\n_Chatting earns coins too._`);
    },
  },
];
