// ============================================================
//  TURBOFEX SETTINGS  -  edit the values between the quotes
//  Numbers: country code + number, digits only, NO plus sign.
//  Example (South Africa): 27821234567
// ============================================================
const fs = require('fs');
const path = require('path');
const { DATA } = require('./core/paths');

const digits = (v) => String(v || '').replace(/\D/g, '');

// the number the owner typed when the bot was first started (see core/setup.js)
let saved = {};
try {
  saved = JSON.parse(fs.readFileSync(path.join(DATA, 'setup.json'), 'utf8'));
} catch (err) {
  saved = {};
}

// ONE number: the WhatsApp number the bot is linked to, and also its owner.
// Leave it empty and the bot asks for it when you start it for the first time.
const number = digits(process.env.NUMBER) || digits(process.env.PAIRING_NUMBER) || digits(saved.number);
// (Older setups that still set OWNER_NUMBER keep working: that number stays the owner.)
const legacyOwner = digits(process.env.OWNER_NUMBER);

module.exports = {
  // Symbol that starts every command, e.g. .ping
  prefix: process.env.PREFIX || '.',

  // The bot's number = the owner's number (set it here, with NUMBER, or let the bot ask)
  number,
  ownerNumber: legacyOwner || number,
  pairingNumber: number,
  legacyOwner: !!legacyOwner && legacyOwner !== number,

  // How to link: 'code' (pairing code) or 'qr'. Empty = the bot asks when you start it.
  pairMethod: /^(code|pairing|pair)$/i.test(process.env.PAIR_METHOD || '') ? 'code' : /^qr$/i.test(process.env.PAIR_METHOD || '') ? 'qr' : '',

  // Time zone used for the menu clock and auto open/close, e.g. 'Africa/Johannesburg' (.region changes it too)
  timezone: process.env.TIMEZONE || 'Africa/Johannesburg',

  // Folder where the WhatsApp login is saved (do not delete it)
  sessionDir: 'session',

  // Optional. How the bot shows up in WhatsApp > Linked devices when you link it. Leave it empty to keep the default.
  // 'android' lets the bot receive view-once pictures and videos (you must link the bot again after changing it).
  browser: process.env.BOT_BROWSER || '',
};
