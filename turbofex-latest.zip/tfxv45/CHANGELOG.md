## v0.7.6 — Stop repeated government salary announcements
- Fixed the payroll scheduler so a successfully delivered group salary notice is acknowledged and removed from the pending queue instead of being resent every 20 seconds.
- Failed group sends remain queued for retry; the salary itself is still credited only once per completed pay interval.
- Added a regression test that runs the scheduler twice and verifies the same salary notice is not announced again and the wallet is not credited twice.

## v0.6.6
- Applied the same shop-style `▸` line formatting to all recently added career, gang, territory, court, wanted, government staff/payroll, presidential and luxury command responses. Preserved the shop response itself and avoided duplicate bullets.

## v0.6.5
- Restored the original shop response layout; `▸` now appears on gang response detail lines, matching the shop item style without changing the shop.

## v0.6.4
- Merged the overlapping balance/inventory views into one detailed `balance` command (`inventory` and `inv` remain aliases); removed the duplicate inventory handler. Audited the registered command names and aliases—no name/alias collisions remain.
- Shop and gang crime responses now use consistent `▸` formatting.
- President help reorganized into a command centre; government offices are predefined with fixed duties, powers and pay.
- Government officials have 2-hour terms and are removed after 20 minutes without a qualifying duty action.

## v0.6.3
- Restricted government, police, court-review, and career-power commands to the active role; unauthorized users are ignored silently, while role application/take-office commands remain available.
- Government appointments and the presidency expire after 2 hours; expired staff lose permissions automatically.
- Added gang banditry and kidnapping operations with wanted levels, cooldowns, and ransom release.

## v0.6.2
- Police can view available wanted suspects with `wanted suspects`. Police can choose the arrest sentence (1–120 minutes) and bail amount (0–1,000,000,000,000 coins) for each arrest. Existing automatic defaults remain available when custom values are omitted.

## v0.6.1
- Added criminal-record eligibility for the presidency: candidates with a recorded crime must complete a crime-system prison sentence before taking office. Bail, escape, presidential detention and pardon do not satisfy the requirement. Denied candidates receive an in-chat step-by-step guide.

## v0.6.0
- Added `president resign` / `president leave` / `president stepdown` to vacate the seat, settle completed salary intervals, reset presidential policies and require another member to serve before the former President can return.


## v0.5.9
- Fixed presidential tax exemption to compare normalized WhatsApp identities, including device-suffixed JIDs, so the President's own earnings are never taxed by their own policy.
- Added presidential rotation: after a President's term ends, they cannot immediately retake office until another member has served a presidential term. The previous President can return after that successor's term ends.
