## v0.6.3
- Restricted government, police, court-review, and career-power commands to the active role; unauthorized users are ignored silently, while role application/take-office commands remain available.
- Government appointments and the presidency expire after 2 hours; expired staff lose permissions automatically.
- Added gang banditry and kidnapping operations with wanted levels, cooldowns, and ransom release.

## v0.6.2
- Police can view available wanted suspects with `wanted suspects`. Police can choose the arrest sentence (1–120 minutes) and bail amount (0–1,000,000,000,000 coins) for each arrest. Existing automatic defaults remain available when custom values are omitted.

## v0.6.1
- Added criminal-record eligibility for the presidency: candidates with a recorded crime must complete a crime-system prison sentence before taking office. Bail, escape, presidential detention and pardon do not satisfy the requirement. Denied candidates receive an in-chat step-by-step guide.

## v0.6.0
- Added `president resign` / `president leave` / `president stepdown` to vacate the seat, settle completed salary intervals, reset presidential policies and require another member to serve before the former President can return.


## v0.5.9
- Fixed presidential tax exemption to compare normalized WhatsApp identities, including device-suffixed JIDs, so the President's own earnings are never taxed by their own policy.
- Added presidential rotation: after a President's term ends, they cannot immediately retake office until another member has served a presidential term. The previous President can return after that successor's term ends.
