## v0.6.0
- Added `president resign` / `president leave` / `president stepdown` to vacate the seat, settle completed salary intervals, reset presidential policies and require another member to serve before the former President can return.


## v0.5.9
- Fixed presidential tax exemption to compare normalized WhatsApp identities, including device-suffixed JIDs, so the President's own earnings are never taxed by their own policy.
- Added presidential rotation: after a President's term ends, they cannot immediately retake office until another member has served a presidential term. The previous President can return after that successor's term ends.
