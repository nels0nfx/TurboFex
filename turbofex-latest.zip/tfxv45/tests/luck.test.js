require('./_setup');
const test = require('node:test');
const assert = require('node:assert');
const baileys = require('../core/baileys');
const store = require('../whatsapp/store');
const handler = require('../whatsapp/handler');
const economy = require('../core/economy');
const market = require('../core/market');

baileys.setForTests({});
const OWNER = '27800000001@s.whatsapp.net';
const GROUP = '120363000000000777@g.us';
const OTHER = '120363000000000778@g.us';
const sent = [];
const sock = {
  user: { id: '27899999999:1@s.whatsapp.net', lid: '999888777:1@lid' },
  sendMessage: async (j, c) => { sent.push({ j, c }); return { key: { id: `K${sent.length}` } }; },
  groupMetadata: async () => ({ subject: 'G', participants: [{ id: OWNER, admin: 'admin' }, { id: '27811111111@s.whatsapp.net' }] }),
  groupFetchAllParticipating: async () => ({ [GROUP]: { id: GROUP, subject: 'Alpha', participants: [] }, [OTHER]: { id: OTHER, subject: 'Beta', participants: [] } }),
  readMessages: async () => {}, sendPresenceUpdate: async () => {}, presenceSubscribe: async () => {},
};
let n = 0;
const texts = () => sent.filter((s) => s.c.text).map((s) => s.c.text);
const dm = async (from, text) => { await handler.handleMessage(sock, { key: { remoteJid: from, id: `L${++n}`, fromMe: false }, message: { conversation: text }, messageTimestamp: Math.floor(Date.now() / 1000) }); await handler.idle(); await new Promise((r) => setTimeout(r, 15)); };
const inGroup = async (g, from, text) => { await handler.handleMessage(sock, { key: { remoteJid: g, participant: from, id: `L${++n}`, fromMe: false }, message: { conversation: text }, messageTimestamp: Math.floor(Date.now() / 1000) }); await handler.idle(); await new Promise((r) => setTimeout(r, 15)); };
let uid = 0;
const person = () => `2784440${String(++uid).padStart(4, '0')}@s.whatsapp.net`;

test('luck: the owner sets the gamble chance, the gamble uses it, everybody else keeps 45%', () => {
  const a = person();
  const b = person();
  for (const w of [a, b]) economy.runIn(GROUP, () => economy.add(w, 100000));
  economy.runIn(GROUP, () => {
    assert.strictEqual(economy.gamble(a, 100, () => 0.7).win, false, 'normal: 45%');
    economy.setLuck(a, null, 0.8);
    assert.strictEqual(economy.gamble(a, 100, () => 0.7).win, true, '80% for the one with luck');
    assert.strictEqual(economy.gamble(b, 100, () => 0.7).win, false, 'the others are not changed');
    economy.setLuck(a, null, 1);
    for (let i = 0; i < 20; i++) assert.ok(economy.gamble(a, 10, () => 0.999).win);
    economy.setLuck(a, null, 0.05);
    assert.strictEqual(economy.gamble(a, 100, () => 0.2).win, false, 'the owner can also lower it');
  });
});

test('luck: one group or all groups, a time limit, and removing it', () => {
  const a = person();
  for (const g of [GROUP, OTHER]) economy.runIn(g, () => economy.add(a, 5000));
  const win = (g) => economy.runIn(g, () => economy.gamble(a, 10, () => 0.9).win);
  economy.setLuck(a, GROUP, 0.95);
  assert.strictEqual(win(GROUP), true);
  assert.strictEqual(win(OTHER), false, 'only the group it was set for');
  economy.setLuck(a, null, 0.95);
  assert.strictEqual(win(OTHER), true, 'all groups');
  economy.setLuck(a, GROUP, 0.1);
  assert.strictEqual(win(GROUP), false, 'a group setting wins over "all groups"');
  economy.clearLuck(a, GROUP);
  assert.strictEqual(win(GROUP), true);
  economy.setLuck(a, null, 0.95, Date.now() - 1000);
  assert.strictEqual(win(OTHER), false, 'expired');
  assert.ok(economy.clearLuck(a));
  assert.strictEqual(economy.luckOf(a), null);
});

test('luck: set from the owner private chat with a number, a time and a group name', async () => {
  store.setMode('public');
  const target = '27811112222@s.whatsapp.net';
  sent.length = 0;
  await dm(OWNER, '.luck 27811112222 85');
  assert.match(texts().at(-1), /Luck set/);
  assert.match(texts().at(-1), /85%/);
  assert.match(texts().at(-1), /all groups/);
  economy.runIn(GROUP, () => assert.strictEqual(economy.luckOf(target), 0.85));
  economy.runIn(OTHER, () => assert.strictEqual(economy.luckOf(target), 0.85));
  await dm(OWNER, '.luck off 27811112222');
  assert.match(texts().at(-1), /Luck removed/);
  economy.runIn(GROUP, () => assert.strictEqual(economy.luckOf(target), null));
  await dm(OWNER, '.luck 27811112222 70 2h alpha');
  assert.match(texts().at(-1), /Alpha/);
  assert.match(texts().at(-1), /2 hours/);
  economy.runIn(GROUP, () => assert.strictEqual(economy.luckOf(target), 0.7));
  economy.runIn(OTHER, () => assert.strictEqual(economy.luckOf(target), null), 'only in Alpha');
  await dm(OWNER, '.luck list');
  assert.match(texts().at(-1), /27811112222/);
  assert.match(texts().at(-1), /Alpha/);
  await dm(OWNER, '.luck 27811112222 70 nowhere-land');
  assert.match(texts().at(-1), /could not find a group/);
  await dm(OWNER, '.luck 27811112222 abc');
  assert.match(texts().at(-1), /Write the chance/);
  await dm(OWNER, '.luck');
  assert.match(texts().at(-1), /Usage/);
});

test('luck: inside a group it is for this group, and nobody but the real owner can use it', async () => {
  store.setMode('public');
  const target = '27811113333@s.whatsapp.net';
  sent.length = 0;
  await inGroup(GROUP, OWNER, '.luck 27811113333 90');
  assert.match(texts().at(-1), /this group/);
  economy.runIn(GROUP, () => assert.strictEqual(economy.luckOf(target), 0.9));
  economy.runIn(OTHER, () => assert.strictEqual(economy.luckOf(target), null));
  const before = sent.length;
  await dm('27833334444@s.whatsapp.net', '.luck 27833334444 100');
  await inGroup(GROUP, '27811111111@s.whatsapp.net', '.luck 27811111111 100');
  assert.ok(!sent.slice(before).some((s) => s.c.text && /Luck set/.test(s.c.text)), 'no reply to others');
  economy.runIn(GROUP, () => assert.strictEqual(economy.luckOf('27811111111@s.whatsapp.net'), null));
});

test('luck is invisible: the gamble reply never shows the chance', async () => {
  store.setMode('public');
  const p = '27811115555@s.whatsapp.net';
  economy.runIn(GROUP, () => economy.add(p, 1000));
  economy.setLuck(p, null, 1);
  sent.length = 0;
  await inGroup(GROUP, p, '.gamble 100');
  assert.match(texts().at(-1), /You won/);
  assert.doesNotMatch(texts().at(-1), /100%|chance|luck/i);
  economy.clearLuck(p);
});

test('ecoboost: pay, chat coins and shop prices can be changed by the owner (and reset)', async () => {
  store.setMode('public');
  const p = person();
  economy.runIn(GROUP, () => {
    assert.strictEqual(economy.daily(p, 1000).amount, 500);
    assert.strictEqual(economy.priceOf('vip'), 2500);
  });
  sent.length = 0;
  await dm(OWNER, '.ecoboost pay 2');
  assert.match(texts().at(-1), /Pay.*×2/);
  await dm(OWNER, '.ecoboost shop 0.5');
  await dm(OWNER, '.ecoboost chat 3');
  const q = person();
  economy.runIn(GROUP, () => {
    assert.strictEqual(economy.daily(q, 1000).amount, 1000, 'daily is doubled');
    assert.strictEqual(economy.priceOf('vip'), 1250, 'half price');
    assert.strictEqual(economy.payMult(), 2);
    assert.strictEqual(economy.chatMult(), 3);
  });
  await dm(OWNER, '.ecoboost pay 99');
  assert.match(texts().at(-1), /Use:/);
  await dm(OWNER, '.ecoboost reset');
  assert.match(texts().at(-1), /Back to normal/);
  economy.runIn(GROUP, () => assert.strictEqual(economy.priceOf('vip'), 2500));
  const m = person();
  await inGroup(GROUP, '27811119999@s.whatsapp.net', '.ecoboost pay 5');
  assert.strictEqual(economy.getCfg().pay, 1, 'only the real owner');
  assert.ok(m);
});

test('balance: things are cheaper and money is easier to make than before', () => {
  assert.deepStrictEqual(['charm', 'vip', 'legend', 'rich'].map((id) => economy.ITEMS[id].price), [800, 2500, 10000, 25000]);
  const jobs = require('../commands/economy2');
  assert.ok(jobs.find((c) => c.name === 'work'));
  assert.ok(market.BUSINESSES.kiosk.cost <= 1500 && market.PROPERTIES.room.value <= 2500);
  // a day of normal play (daily + a few jobs) buys the cheapest title
  const a = person();
  economy.runIn(GROUP, () => {
    economy.add(a, economy.daily(a, 5000).amount);
    assert.ok(economy.balance(a) >= 500);
  });
});

test('the market is cheaper to enter: a first business and a first room are within a few days of play', () => {
  assert.ok(market.BUSINESSES.kiosk.cost < 2000);
  assert.ok(market.PROPERTIES.room.value < 3000);
});

test('gamble odds: owner defaults can target a group or all groups, with personal luck taking priority', () => {
  const a = person();
  for (const g of [GROUP, OTHER]) economy.runIn(g, () => economy.add(a, 10000));
  economy.setGambleChance(GROUP, 0.9);
  assert.strictEqual(economy.runIn(GROUP, () => economy.gamble(a, 10, () => 0.8).win), true, 'group default applies');
  assert.strictEqual(economy.runIn(OTHER, () => economy.gamble(a, 10, () => 0.8).win), false, 'other group stays at normal odds');
  economy.setGambleChance(null, 0.85);
  assert.strictEqual(economy.runIn(OTHER, () => economy.gamble(a, 10, () => 0.8).win), true, 'global default applies');
  economy.setLuck(a, GROUP, 0.2);
  assert.strictEqual(economy.runIn(GROUP, () => economy.gamble(a, 10, () => 0.3).win), false, 'personal luck overrides group odds');
  economy.setGambleChance(GROUP, null);
  economy.setGambleChance(null, null);
  economy.clearLuck(a);
});
