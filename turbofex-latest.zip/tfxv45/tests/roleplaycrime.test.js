require('./_setup');
const test = require('node:test');
const assert = require('node:assert/strict');
const rp = require('../core/roleplay');
const economy = require('../core/economy');
require('../core/throne');
const group = `crime-test-${Date.now()}@g.us`;
const a = '27815550001@s.whatsapp.net';
const b = '27815550002@s.whatsapp.net';

test('wanted levels are capped, scoped per group, and arrests create timed jail plus bail', () => {
  for (let i = 0; i < 8; i++) rp.addWanted(group, a, 1, 1000 + i);
  assert.equal(rp.user(group, a).wanted, 5);
  assert.equal(rp.user(`${group}-other`, a).wanted, 0);
  const now = Date.now();
  const arrest = rp.arrest(group, a, now);
  assert.equal(arrest.ok, true);
  assert.equal(arrest.duration, 30 * 60000);
  assert.equal(rp.user(group, a).wanted, 0);
  assert.equal(rp.user(group, a).jailedUntil, now + 30 * 60000);
  economy.runIn(group, () => assert.equal(economy.gamble(a, 10).why, 'jail'));
  assert.equal(rp.arrest(group, a, now + 1000).why, 'jailed');
  assert.equal(rp.payBail(group, a, now + 2000).amount, 750);
  assert.equal(rp.user(group, a).jailedUntil, 0);
});

test('paid nickname expires after one hour and ghost duration is stored', () => {
  const now = 5000000;
  const n = rp.applyNickname(group, b, 'Professional Beggar 🥲', now);
  assert.equal(n.ok, true);
  assert.equal(rp.activeNickname(group, b, now + 1000), 'Professional Beggar 🥲');
  assert.equal(rp.activeNickname(group, b, now + 3600001), null);
  const u = rp.user(group, b); u.ghostUntil = now + 30 * 60000; rp.touch();
  assert.equal(rp.user(group, b).ghostUntil, now + 30 * 60000);
});

test('new roleplay commands are registered without duplicate names or aliases', () => {
  const fs = require('node:fs');
  const commands = [].concat(...fs.readdirSync('./commands').filter(f => f.endsWith('.js')).map(f => require(`../commands/${f}`)));
  const names = new Set();
  for (const c of commands) for (const n of [c.name, ...(c.aliases || [])]) {
    assert.ok(!names.has(n), `duplicate command/alias: ${n}`); names.add(n);
  }
  for (const name of ['career','gang','territory','wanted','haunt','nickname','headline']) assert.ok(commands.some(c => c.name === name), `${name} command missing`);
});
