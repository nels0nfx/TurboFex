require('./_setup');
const test = require('node:test');
const assert = require('node:assert/strict');
const rp = require('../core/roleplay');
const economy = require('../core/economy');
require('../core/throne');
const group = `crime-test-${Date.now()}@g.us`;
const a = '27815550001@s.whatsapp.net';
const b = '27815550002@s.whatsapp.net';

test('wanted levels are capped, scoped per group, and arrests create timed jail plus bail', () => {
  for (let i = 0; i < 8; i++) rp.addWanted(group, a, 1, 1000 + i);
  assert.equal(rp.user(group, a).wanted, 5);
  assert.equal(rp.user(`${group}-other`, a).wanted, 0);
  const now = Date.now();
  const arrest = rp.arrest(group, a, now);
  assert.equal(arrest.ok, true);
  assert.equal(arrest.duration, 30 * 60000);
  assert.equal(rp.user(group, a).wanted, 5);
  assert.equal(rp.user(group, a).jailedUntil, now + 30 * 60000);
  economy.runIn(group, () => assert.equal(economy.gamble(a, 10).why, 'jail'));
  assert.equal(rp.arrest(group, a, now + 1000).why, 'jailed');
  assert.equal(rp.payBail(group, a, now + 2000).amount, 750);
  assert.equal(rp.user(group, a).jailedUntil, 0);
  assert.equal(rp.user(group, a).wanted, 0);
});

test('police arrest supports a custom sentence and bail amount with validation', () => {
  const g = `custom-arrest-${Date.now()}@g.us`, suspect = '27815550009@s.whatsapp.net';
  rp.addWanted(g, suspect, 3, Date.now());
  const now = Date.now();
  const result = rp.arrest(g, suspect, now, { minutes: 47, bail: 987654 });
  assert.equal(result.ok, true);
  assert.equal(result.duration, 47 * 60000);
  assert.equal(result.bail, 987654);
  const invalid = `custom-arrest-invalid-${Date.now()}@g.us`;
  rp.addWanted(invalid, suspect, 1, now);
  assert.equal(rp.arrest(invalid, suspect, now, { minutes: 121, bail: 500 }).why, 'duration');
  assert.equal(rp.arrest(invalid, suspect, now, { minutes: 10, bail: -1 }).why, 'bail');
});

test('paid nickname expires after one hour and ghost duration is stored', () => {
  const now = 5000000;
  const n = rp.applyNickname(group, b, 'Professional Beggar 🥲', now);
  assert.equal(n.ok, true);
  assert.equal(rp.activeNickname(group, b, now + 1000), 'Professional Beggar 🥲');
  assert.equal(rp.activeNickname(group, b, now + 3600001), null);
  const u = rp.user(group, b); u.ghostUntil = now + 30 * 60000; rp.touch();
  assert.equal(rp.user(group, b).ghostUntil, now + 30 * 60000);
});

test('new roleplay commands are registered without duplicate names or aliases', () => {
  const fs = require('node:fs');
  const commands = [].concat(...fs.readdirSync('./commands').filter(f => f.endsWith('.js')).map(f => require(`../commands/${f}`)));
  const names = new Set();
  for (const c of commands) for (const n of [c.name, ...(c.aliases || [])]) {
    assert.ok(!names.has(n), `duplicate command/alias: ${n}`); names.add(n);
  }
  for (const name of ['career','gang','territory','wanted','court','haunt','nickname','headline']) assert.ok(commands.some(c => c.name === name), `${name} command missing`);
});

test('President can detain a clean player and wanted status clears on sentence completion', () => {
  const g = `pres-jail-${Date.now()}@g.us`, president = '27815551111@s.whatsapp.net', target = '27815551112@s.whatsapp.net';
  economy.runIn(g, () => { economy.add(president, 6000000); assert.equal(rp.takePresident(g, president).ok, true); });
  const now = Date.now(), result = rp.presidentialJail(g, president, target, 2, 'Court order', now);
  assert.equal(result.ok, true); assert.equal(rp.user(g, target).wanted, 0); assert.equal(rp.jailLeft(g, target, now + 60000), 60000);
  assert.equal(rp.jailLeft(g, target, now + 3 * 60000), 0); assert.equal(rp.user(g, target).wanted, 0);
});

test('President cannot be charged their own presidential tax', () => {
  const g = `tax-president-${Date.now()}@g.us`, president = '27815552221@s.whatsapp.net', other = '27815552222@s.whatsapp.net';
  economy.runIn(g, () => { economy.add(president, 6000000); assert.equal(rp.takePresident(g, president).ok, true); rp.setPresidentTax(g, president, 25); const before = economy.balance(president); const own = economy.payout(president, 1000, {tools:false}); assert.equal(own.tax, 0); const otherBefore = economy.balance(other); const payout = economy.payout(other, 1000, {tools:false}); assert.ok(payout.tax > 0); assert.equal(economy.balance(other), otherBefore + payout.net); assert.equal(economy.balance(president), before + own.net + payout.tax); });
});

test('prison work reduces a sentence with a cooldown and preserves wanted status until release', () => {
  const g = `prison-work-${Date.now()}@g.us`, id = '27815553331@s.whatsapp.net';
  const u = rp.user(g,id); u.wanted=3; u.jailedUntil=1000000; u.jailType='police'; u.bail=450;
  const first = rp.prisonWork(g,id,100000); assert.equal(first.ok,true); assert.equal(first.reduction,60000); assert.equal(u.jailedUntil,940000); assert.equal(u.wanted,3);
  assert.equal(rp.prisonWork(g,id,101000).why,'cooldown');
  assert.equal(rp.expireDetentions(950000),1); assert.equal(u.wanted,0); assert.equal(u.jailedUntil,0);
});

test('court appeals can be filed by detainees and dismissed by the President', () => {
  const g = `court-appeal-${Date.now()}@g.us`, president = '27815554441@s.whatsapp.net', target = '27815554442@s.whatsapp.net';
  economy.runIn(g, () => { economy.add(president, 6000000); assert.equal(rp.takePresident(g, president).ok, true); });
  const detention = rp.presidentialJail(g, president, target, 10, 'Administrative review');
  assert.equal(detention.ok, true);
  const appeal = rp.fileCourtAppeal(g, target, 'The detention was issued in error.');
  assert.equal(appeal.ok, true);
  assert.equal(rp.fileCourtAppeal(g, target, 'duplicate').why, 'pending');
  const decision = rp.reviewCourtCase(g, president, appeal.case.id, 'dismiss', 'Evidence did not support detention.');
  assert.equal(decision.ok, true);
  assert.equal(rp.user(g, target).jailedUntil, 0);
  assert.equal(rp.user(g, target).wanted, 0);
  assert.equal(rp.courtCases(g, 'pending').length, 0);
});

test('prison escape has cooldown, chance-based outcomes and sentence extension on failure', () => {
  const g = `escape-test-${Date.now()}@g.us`, id = '27815554451@s.whatsapp.net';
  const u = rp.user(g,id); u.jailedUntil=500000; u.jailType='police'; u.wanted=1;
  const escaped = rp.attemptPrisonEscape(g,id,100000,0.01);
  assert.equal(escaped.ok,true); assert.equal(u.jailedUntil,0); assert.equal(u.wanted,3);
  u.jailedUntil=900000; u.jailType='police'; u.wanted=1; u.lastEscape=0;
  const failed = rp.attemptPrisonEscape(g,id,200000,0.99);
  assert.equal(failed.ok,false); assert.equal(failed.why,'caught'); assert.equal(u.jailedUntil,1200000); assert.equal(u.wanted,2);
  assert.equal(rp.attemptPrisonEscape(g,id,201000,0.99).why,'cooldown');
});

test('successful police arrests progress police-specific rank milestones', () => {
  const g = `police-rank-${Date.now()}@g.us`, officer = '27815554461@s.whatsapp.net';
  const u=rp.user(g,officer); u.career='police'; u.rank=1; u.arrests=0;
  assert.equal(rp.recordPoliceArrest(g,officer).rank,1);
  assert.equal(rp.recordPoliceArrest(g,officer).rank,1);
  const promotion=rp.recordPoliceArrest(g,officer);
  assert.equal(promotion.rank,2); assert.equal(promotion.promoted,true); assert.equal(u.arrests,3);
});

test('President tax exemption survives alternate WhatsApp ID formats', () => {
  const g = `tax-president-format-${Date.now()}@g.us`;
  const president = '27815556661:4@s.whatsapp.net';
  economy.runIn(g, () => {
    economy.add(president, 6000000);
    assert.equal(rp.takePresident(g, president).ok, true);
    rp.setPresidentTax(g, president, 40);
    const before = economy.balance(president);
    const own = economy.payout('27815556661@s.whatsapp.net', 1000, { tools: false });
    assert.equal(own.tax, 0);
    assert.equal(economy.balance('27815556661@s.whatsapp.net'), before + own.net);
  });
});

test('former President cannot immediately retake office until another member serves', () => {
  const g = `president-rotation-${Date.now()}@g.us`;
  const former = '27815557771@s.whatsapp.net';
  const next = '27815557772@s.whatsapp.net';
  const start = Date.now();
  economy.runIn(g, () => {
    economy.add(former, 12000000);
    economy.add(next, 6000000);
    assert.equal(rp.takePresident(g, former, start).ok, true);
    assert.equal(rp.presidentInfo(g, start + rp.PRESIDENT_TERM + 1).president, null);
    assert.equal(rp.takePresident(g, former, start + rp.PRESIDENT_TERM + 2).why, 'previous');
    assert.equal(rp.takePresident(g, next, start + rp.PRESIDENT_TERM + 3).ok, true);
    assert.equal(rp.presidentInfo(g, start + 2 * rp.PRESIDENT_TERM + 4).president, null);
    assert.equal(rp.takePresident(g, former, start + 2 * rp.PRESIDENT_TERM + 5).ok, true);
  });
});

test('President can resign, vacates the seat, resets policy, and must wait for another President', () => {
  const g = `pres-resign-${Date.now()}@g.us`, former = '27815552221@s.whatsapp.net', next = '27815552222@s.whatsapp.net';
  economy.runIn(g, () => {
    economy.add(former, 12000000);
    economy.add(next, 6000000);
    assert.equal(rp.takePresident(g, former).ok, true);
    assert.equal(rp.setPresidentTax(g, former, 10).ok, true);
    const resigned = rp.resignPresident(g, former);
    assert.equal(resigned.ok, true);
    assert.equal(rp.presidentInfo(g).president, null);
    assert.equal(rp.presidentInfo(g).tax, 0);
    assert.equal(rp.takePresident(g, former).why, 'previous');
    assert.equal(rp.takePresident(g, next).ok, true);
    // Once another member has served, the former President is eligible again after that term ends.
    const future = Date.now() + rp.PRESIDENT_TERM + 1;
    rp.presidentInfo(g, future);
    assert.equal(rp.takePresident(g, former, future + 1).ok, true);
  });
});


test('criminal record blocks presidency until a real prison sentence is completed', () => {
  const g = `pres-criminal-record-${Date.now()}@g.us`, id = '27815558881@s.whatsapp.net';
  const now = Date.now();
  economy.runIn(g, () => economy.add(id, 12000000));
  rp.addWanted(g, id, 1, now);
  assert.equal(rp.takePresident(g, id, now + 1).why, 'wanted');
  const arrest = rp.arrest(g, id, now + 2);
  assert.equal(arrest.ok, true);
  assert.equal(rp.takePresident(g, id, now + 3).why, 'jailed');
  // Paying bail is not rehabilitation.
  rp.payBail(g, id, now + 4);
  assert.equal(rp.takePresident(g, id, now + 5).why, 'criminal_record');
  // Re-arrest and complete the sentence.
  const u = rp.user(g, id); u.wanted = 1; u.lastCrime = now; u.crimeRecordAt = now; u.jailedUntil = now + 1000; u.jailType = 'police'; u.bail = 100;
  rp.jailLeft(g, id, now + 2000);
  assert.ok(u.servedSentenceAt >= now + 2000);
  economy.runIn(g, () => assert.equal(rp.takePresident(g, id, now + 2001).ok, true));
});

test('presidential detention and escape do not count as serving a criminal sentence', () => {
  const g = `pres-no-fake-rehab-${Date.now()}@g.us`, id = '27815558882@s.whatsapp.net';
  const now = Date.now(), u = rp.user(g, id);
  rp.addWanted(g, id, 1, now);
  u.jailedUntil = now + 100; u.jailType = 'presidential';
  rp.jailLeft(g, id, now + 200);
  assert.equal(u.servedSentenceAt || 0, 0);
  assert.equal(rp.takePresident(g, id, now + 201).why, 'criminal_record');
});
