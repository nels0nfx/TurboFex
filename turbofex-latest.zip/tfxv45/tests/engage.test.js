require('./_setup');
const test = require('node:test');
const assert = require('node:assert');
const baileys = require('../core/baileys');
const store = require('../whatsapp/store');
const handler = require('../whatsapp/handler');
const economy = require('../core/economy');
const market = require('../core/market');
const quests = require('../core/quests');
const throne = require('../core/throne');
const predict = require('../core/predict');

baileys.setForTests({});
const OWNER = '27800000001@s.whatsapp.net';
const NOW = Date.UTC(2026, 9, 28, 12, 0, 0);
const HOUR = 3600000;
let gid = 0;
const newGroup = () => `1203630000001${String(++gid).padStart(5, '0')}@g.us`;
let uid = 0;
const person = () => `2786660${String(++uid).padStart(4, '0')}@s.whatsapp.net`;
const fund = (g, who, n) => economy.runIn(g, () => economy.add(who, n));
const wallet = (g, who) => economy.runIn(g, () => economy.balance(who));

function fakeSock() {
  const sent = [];
  return {
    user: { id: '27899999999:1@s.whatsapp.net', lid: '999888777:1@lid' },
    sent,
    texts: () => sent.filter((s) => s.c.text).map((s) => s.c.text),
    sendMessage: async (j, c) => { sent.push({ j, c }); return { key: { id: `K${sent.length}` } }; },
    groupMetadata: async () => ({ subject: 'G', participants: [{ id: OWNER, admin: 'admin' }] }),
    readMessages: async () => {}, sendPresenceUpdate: async () => {}, presenceSubscribe: async () => {},
  };
}
let n = 0;
async function say(sock, group, from, text) {
  await handler.handleMessage(sock, { key: { remoteJid: group, participant: from, id: `E${++n}`, fromMe: false }, message: { conversation: text }, messageTimestamp: Math.floor(Date.now() / 1000) });
  await handler.idle();
  await new Promise((r) => setTimeout(r, 15));
}
const last = (s) => s.texts().at(-1);

// ---------------- quests
test('quests: 3 quests a day, the same for the whole group, each pays when finished, all 3 pay a bonus', () => {
  const g = newGroup();
  const a = person();
  const b = person();
  const s1 = quests.status(g, a, NOW);
  assert.strictEqual(s1.quests.length, 3);
  assert.deepStrictEqual(quests.status(g, b, NOW).quests.map((q) => q.id), s1.quests.map((q) => q.id));
  assert.ok(s1.quests.every((q) => !q.market), 'no market quests while the market is closed');
  let paid = 0;
  for (const q of s1.quests) {
    for (let i = 0; i < q.n - 1; i++) assert.strictEqual(quests.track(g, a, q.event, 1, NOW).done.length, 0);
    const r = quests.track(g, a, q.event, 1, NOW);
    assert.strictEqual(r.done.length, 1);
    paid += q.reward;
    if (q.id === s1.quests.at(-1).id) { assert.strictEqual(r.sweep, quests.RULES.sweep); paid += r.sweep; }
  }
  assert.strictEqual(wallet(g, a), paid);
  assert.strictEqual(wallet(g, b), 0);
  // finished quests do not pay twice
  const again = quests.track(g, a, s1.quests[0].event, 50, NOW);
  assert.strictEqual(again.done.length, 0);
  assert.strictEqual(wallet(g, a), paid);
});

test('quests: a new day brings new progress, no market quests remain, private chats ignored', () => {
  const g = newGroup();
  const a = person();
  quests.track(g, a, 'daily', 1, NOW);
  const day2 = quests.status(g, a, NOW + 24 * HOUR);
  assert.ok(day2.quests.every((q) => q.progress === 0 && !q.done));
  assert.strictEqual(day2.day === quests.status(g, a, NOW).day, false);
  const seen = new Set();
  for (let d = 2; d < 40; d++) quests.status(g, a, NOW + d * 24 * HOUR).quests.forEach((q) => seen.add(q.id));
  assert.ok(!['invest', 'profit', 'collect'].some((id) => seen.has(id)));
  assert.ok(!['invest', 'profit', 'collect'].some((id) => quests.POOL.some((q) => q.id === id)));
  assert.deepStrictEqual(quests.track('123@s.whatsapp.net', a, 'chat', 99, NOW).done, []);
});

test('quests: 12 quests in a week pays the weekly prize once', () => {
  const g = newGroup();
  const a = person();
  let weekly = 0;
  for (let d = 0; d < 4; d++) {
    const t = NOW + d * 24 * HOUR; // a Wednesday + 3 days: still the same week (to Sunday)
    for (const q of quests.status(g, a, t).quests) weekly += quests.track(g, a, q.event, q.n, t).weekly;
  }
  assert.strictEqual(weekly, quests.RULES.weekly);
});

// ---------------- throne
test('throne: take, price goes up, old king is paid back, price slides down, income', () => {
  const g = newGroup();
  const a = person();
  const b = person();
  fund(g, a, 2000);
  fund(g, b, 5000);
  assert.strictEqual(throne.info(g, NOW).king, null);
  const t1 = throne.take(g, a, NOW);
  assert.ok(t1.ok && t1.price === 500 && t1.prev === null);
  assert.strictEqual(wallet(g, a), 1500);
  assert.strictEqual(throne.take(g, a, NOW).why, 'already');
  assert.strictEqual(throne.info(g, NOW).price, 625);
  assert.strictEqual(throne.collect(g, b, NOW + HOUR).why, 'notking');
  const c = throne.collect(g, a, NOW + 5 * HOUR);
  assert.strictEqual(c.amount, 500);
  assert.strictEqual(throne.decree(g, a, '  all   hail  ').decree, 'all hail');
  // two hours of waiting: the price slid down a little, and the first king earned 200 meanwhile
  const p = throne.info(g, NOW + 7 * HOUR).price;
  assert.ok(p < 625 && p >= 500);
  const t2 = throne.take(g, b, NOW + 7 * HOUR);
  assert.ok(t2.ok);
  assert.strictEqual(t2.prevGot, Math.floor(t2.price * 0.7));
  assert.strictEqual(wallet(g, a), 1500 + 500 + t2.prevGot + 200);
  assert.strictEqual(wallet(g, b), 5000 - t2.price);
  assert.strictEqual(throne.info(g, NOW + 7 * HOUR).decree, '');
});

test('throne: too poor, in debt, price never under 500, income stops growing after 24 hours', () => {
  const g = newGroup();
  const a = person();
  assert.strictEqual(throne.take(g, a, NOW).why, 'poor');
  fund(g, a, 600);
  assert.ok(throne.take(g, a, NOW).ok);
  assert.strictEqual(throne.info(g, NOW + 500 * HOUR).price, 500);
  assert.strictEqual(throne.info(g, NOW + 500 * HOUR).waiting, 2400);
});

// ---------------- predict
test('predict: bets, settle pays the winners from the pool minus 5%', () => {
  const g = newGroup();
  const admin = person();
  const a = person();
  const b = person();
  const c = person();
  [a, b, c, admin].forEach((x) => fund(g, x, 1000));
  const q = predict.create(g, admin, 'Will it rain on Saturday?', 2 * 24 * HOUR, NOW);
  assert.ok(q.ok);
  assert.strictEqual(predict.stake(g, admin, q.id, 'yes', 100, NOW).why, 'creator');
  assert.strictEqual(predict.stake(g, a, q.id, 'yes', 10, NOW).why, 'min');
  assert.strictEqual(predict.stake(g, a, q.id, 'yes', 9000, NOW).why, 'max');
  assert.ok(predict.stake(g, a, q.id, 'yes', 200, NOW).ok);
  assert.strictEqual(predict.stake(g, a, q.id, 'no', 100, NOW).why, 'otherside');
  assert.ok(predict.stake(g, b, q.id, 'no', 300, NOW).ok);
  assert.ok(predict.stake(g, c, q.id, 'no', 100, NOW).ok);
  assert.strictEqual(predict.stake(g, a, q.id, 'yes', 100, NOW + 3 * 24 * HOUR).why, 'closed');
  assert.strictEqual(predict.settle(g, a, q.id, 'yes', false, NOW).why, 'notyours');
  const r = predict.settle(g, admin, q.id, 'yes', false, NOW + 3 * 24 * HOUR);
  assert.ok(r.ok);
  assert.strictEqual(r.pool.total, 600);
  assert.strictEqual(wallet(g, a), 800 + 570); // the only winner takes the pool minus 5%
  assert.strictEqual(wallet(g, b), 700);
  assert.strictEqual(r.burned, 30);
  assert.strictEqual(predict.settle(g, admin, q.id, 'yes').why, 'none');
});

test('predict: nobody on a side, cancelled, or never settled -> everybody gets the coins back', () => {
  const g = newGroup();
  const admin = person();
  const a = person();
  const b = person();
  [a, b].forEach((x) => fund(g, x, 1000));
  const q1 = predict.create(g, admin, 'Will the bus come on time?', HOUR, NOW);
  predict.stake(g, a, q1.id, 'yes', 400, NOW);
  assert.strictEqual(wallet(g, a), 600);
  assert.ok(predict.settle(g, admin, q1.id, 'no', false, NOW + 2 * HOUR).refunded);
  assert.strictEqual(wallet(g, a), 1000);
  const q2 = predict.create(g, admin, 'Will we pass the exam?', HOUR, NOW);
  predict.stake(g, b, q2.id, 'no', 250, NOW);
  assert.strictEqual(predict.cancel(g, admin, q2.id).players, 1);
  assert.strictEqual(wallet(g, b), 1000);
  const q3 = predict.create(g, admin, 'Will the shop open on Monday?', HOUR, NOW);
  predict.stake(g, b, q3.id, 'yes', 100, NOW);
  assert.strictEqual(predict.list(g, NOW + 9 * 24 * HOUR).length, 0);
  assert.strictEqual(wallet(g, b), 1000);
});

test('predict: limits on questions', () => {
  const g = newGroup();
  const admin = person();
  assert.strictEqual(predict.create(g, admin, 'short', HOUR, NOW).why, 'short');
  assert.strictEqual(predict.create(g, admin, 'A proper question here?', 5, NOW).why, 'duration');
  for (let i = 0; i < 5; i++) assert.ok(predict.create(g, admin, `Question number ${i} here?`, HOUR, NOW).ok);
  assert.strictEqual(predict.create(g, admin, 'One more question please?', HOUR, NOW).why, 'many');
});

// ---------------- commands
test('commands: quests, throne and predict work; market commands are gone', async () => {
  store.setMode('public');
  const sock = fakeSock();
  const g = newGroup();
  fund(g, OWNER, 5000);
  await say(sock, g, OWNER, '.quests');
  assert.match(last(sock), /Quests of today/);
  assert.match(last(sock), /Weekly|This week/);
  await say(sock, g, OWNER, '.throne');
  assert.match(last(sock), /The throne is empty/);
  await say(sock, g, OWNER, '.throne take');
  assert.match(last(sock), /new king/);
  await say(sock, g, OWNER, '.throne decree long live me');
  assert.match(last(sock), /long live me/);
  await say(sock, g, OWNER, '.predict new 2d Will the match end in a draw?');
  assert.match(last(sock), /New prediction #1/);
  await say(sock, g, OWNER, '.predict');
  assert.match(last(sock), /draw/);
  await say(sock, g, OWNER, '.predict yes 1 100');
  assert.match(last(sock), /cannot bet/);
  await say(sock, g, OWNER, '.predict resolve 1 yes');
  assert.match(last(sock), /settled/);
  await say(sock, g, OWNER, '.economy');
  assert.match(last(sock), /GROUP ECONOMY/);
  await say(sock, g, OWNER, '.market FARM');
  assert.doesNotMatch(last(sock), /Dividend|price|invest/);
  await say(sock, g, OWNER, '.career commands');
  assert.match(last(sock), /CAREER COMMANDS/);
});

test('commands: a quest finished by daily shows the quest notice and pays', async () => {
  store.setMode('public');
  const sock = fakeSock();
  const g = newGroup();
  const who = OWNER;
  // force a day where "daily" is a quest: find a group id whose quests today include daily
  let g2 = g;
  for (let i = 0; i < 60 && !quests.status(g2, who).quests.some((q) => q.id === 'daily'); i++) g2 = newGroup();
  assert.ok(quests.status(g2, who).quests.some((q) => q.id === 'daily'));
  const before = wallet(g2, who);
  await say(sock, g2, who, '.daily');
  assert.match(last(sock), /Quest done/);
  assert.ok(wallet(g2, who) > before + 500);
});

test('alerts: the engine posts a ping when the price gets there, even with the news muted', () => {
  const g = newGroup();
  const a = person();
  market.enable(g, NOW);
  market.setNews(g, false);
  const price = market.quotes(g).find((x) => x.asset.id === 'TRB').price;
  assert.ok(market.alertSet(g, a, 'TRB', 'above', String(price * 1.0001)).ok);
  assert.strictEqual(market.alertSet(g, a, 'TRB', 'below', String(price * 2)).why, 'already');
  let ping = null;
  for (let t = NOW + 30 * 60000, i = 0; i < 400 && !ping; t += 30 * 60000, i++) ping = market.advance(g, t).notes.find((x) => x.type === 'alert');
  assert.ok(ping, 'an alert is sent');
  assert.strictEqual(market.alertList(g, a).alerts.length, 0, 'it is sent once');
});

test('dividends: stocks that pay dividends add money to collect', () => {
  const g = newGroup();
  const a = person();
  market.enable(g, NOW);
  fund(g, a, 20000);
  assert.ok(market.invest(g, a, 'NCOM', '5000', NOW).ok);
  for (let i = 1; i <= 96; i++) market.advance(g, NOW + i * 30 * 60000);
  const c = market.collect(g, a);
  assert.ok(c.div && c.div.net > 0, 'dividend paid');
});
