require('./_setup');
const test = require('node:test');
const assert = require('node:assert');
const rp = require('../core/roleplay');
const group = `roleplay-test-${Date.now()}@g.us`;
const a = '27811111111@s.whatsapp.net';
const b = '27822222222@s.whatsapp.net';
test('career, gang, and territory data are scoped and persistent in roleplay store', () => {
  const u = rp.user(group, a); u.career = 'police'; u.rank = 2; rp.touch();
  assert.strictEqual(rp.user(group, a).career, 'police');
  assert.strictEqual(rp.user(`${group}-other`, a).career, null);
  u.career = null; rp.touch();
  const made = rp.makeGang(group, a, 'NightWolves'); assert.strictEqual(made.ok, true);
  assert.strictEqual(rp.joinGang(group, b, 'nightwolves').ok, true);
  assert.strictEqual(rp.getGang(group, b).members.length, 2);
  assert.strictEqual(rp.makeGang(group, b, 'AnotherGang').why, 'member');
});
test('territory war resolves to attacker only when attack score is higher', () => {
  const g = rp.state(group), gang = rp.getGang(group, a);
  g.gangs.defenders = { key: 'defenders', name: 'defenders', leader: rp.memberKey(b), members: [rp.memberKey(b)], treasury: 0 };
  const t = g.territories.oldtown; t.gang = 'defenders'; t.war = { attacker: gang.key, defender: 'defenders', attackScore: 5, defendScore: 2, endsAt: 1, startedAt: 0, fighters: {} };
  const result = rp.resolveWar(group, 'oldtown', 2);
  assert.strictEqual(result.won, true); assert.strictEqual(t.gang, gang.key);
});
