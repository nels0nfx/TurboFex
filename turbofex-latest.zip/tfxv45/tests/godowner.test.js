require('./_setup');
const test = require('node:test');
const assert = require('node:assert/strict');
const godCommand = require('../commands/god')[0];
const roleplayCommands = require('../commands/roleplay');
const careerCommand = roleplayCommands.find(c=>c.name==='career');
const presidentCommand = roleplayCommands.find(c=>c.name==='president');
const god = require('../core/godsettings');
const rp = require('../core/roleplay');
const economy = require('../core/economy');

function ctx(group, args, extras={}) {
  const messages=[];
  const sock={
    async groupFetchAllParticipating(){return {[group]:{id:group,subject:'Owner Test Group',participants:[]}};},
    async sendMessage(jid,content){messages.push({jid,content});return {};}
  };
  return {ctx:{args,jid:'owner-test@s.whatsapp.net',myJid:'owner-test@s.whatsapp.net',isOwner:true,prefix:'.',sock,msg:{key:{remoteJid:'owner-test@s.whatsapp.net'},message:{}},async reply(text,options){messages.push({jid:'owner-test@s.whatsapp.net',content:{text,options}});},...extras},messages};
}

test('Owner can select a group in DM and change presidential salary and interval', async()=>{
  const group=`god-salary-${Date.now()}@g.us`;
  const select=ctx(group,['select','1']);
  await godCommand.run(select.ctx);
  assert.equal(god.selectedGroup(),group);
  const change=ctx(group,['salary','president','500000','30m']);
  await godCommand.run(change.ctx);
  const settings=rp.economySettings(group);
  assert.equal(settings.presidentSalary,500000);
  assert.equal(settings.presidentSalaryInterval,30*60000);
  assert.ok(change.messages.some(m=>m.jid===group),'group receives a public salary-setting notice');
});

test('Owner appointment to police still rejects wanted members', async()=>{
  const group=`god-police-${Date.now()}@g.us`, member='2348012345678@s.whatsapp.net';
  god.selectGroup(group);
  rp.setWantedLevel(group,member,2);
  const run=ctx(group,['appoint','2348012345678','police']);
  await godCommand.run(run.ctx);
  assert.equal(rp.user(group,member).career,null);
  assert.ok(run.messages.some(m=>String(m.content.text||'').includes('wanted')));
});

test('Owner election pause blocks election start, registration, and votes',()=>{
  const group=`god-election-${Date.now()}@g.us`;
  god.setElectionPaused(group,true);
  try {
    assert.equal(rp.startGovernmentElection(group,'owner-test@s.whatsapp.net').why,'paused');
    assert.equal(rp.registerElectionCandidate(group,'candidate@s.whatsapp.net').why,'paused');
    assert.equal(rp.castElectionVote(group,'voter@s.whatsapp.net','candidate@s.whatsapp.net').why,'paused');
  } finally { god.setElectionPaused(group,false); }
});

test('Owner wallet is separate from player/group balances and records grants',()=>{
  const before=god.wallet(), player='wallet-test@s.whatsapp.net';
  assert.equal(god.walletAdd(1234),before+1234);
  const group=`god-wallet-${Date.now()}@g.us`;
  economy.runIn(group,()=>economy.add(player,99));
  assert.equal(economy.runIn(group,()=>economy.balance(player)),99);
  assert.equal(god.wallet(),before+1234);
  assert.equal(god.walletTake(1234),before);
});


test('Owner career appointments are offers and require the member to accept', async()=>{
  const group=`god-career-offer-${Date.now()}@g.us`, member='2348098765432@s.whatsapp.net';
  god.selectGroup(group);
  const offerCtx=ctx(group,['appoint','2348098765432','doctor']);
  await godCommand.run(offerCtx.ctx);
  assert.equal(rp.user(group,member).career,null,'career must not activate before acceptance');
  assert.ok(rp.state(group).careerAppointmentOffers[rp.memberKey(member)]);
  const acceptMessages=[];
  await careerCommand.run({args:['accept'],jid:group,myJid:member,prefix:'.',msg:{key:{remoteJid:group},message:{}},async reply(text,options){acceptMessages.push({text,options});}});
  assert.equal(rp.user(group,member).career,'doctor');
  assert.equal(rp.state(group).careerAppointmentOffers[rp.memberKey(member)],undefined);
  assert.ok(acceptMessages.some(m=>m.text.includes('APPOINTMENT ACCEPTED')));
});

test('Owner court override can dismiss a pending appeal with a recorded reason', async()=>{
  const group=`god-court-${Date.now()}@g.us`, appellant='court-appellant@s.whatsapp.net';
  god.selectGroup(group);
  const u=rp.user(group,appellant);u.jailedUntil=Date.now()+10*60000;u.wanted=2;u.jailReason='wrongful detention';u.jailedBy='officer@s.whatsapp.net';u.jailType='police';rp.touch();
  const filed=rp.fileCourtAppeal(group,appellant,'I was detained by mistake');assert.equal(filed.ok,true);
  const run=ctx(group,['court',String(filed.case.id),'dismiss','Evidence showed the arrest was mistaken']);
  await godCommand.run(run.ctx);
  assert.equal(rp.state(group).courtCases.find(c=>c.id===filed.case.id).status,'dismissed');
  assert.equal(rp.user(group,appellant).jailedUntil,0);
  assert.equal(rp.user(group,appellant).wanted,0);
  assert.ok(god.recentAudit(10).some(a=>a.action==='Owner overrode court case'));
});

test('Global law defaults persist and affect new groups', async()=>{
  const group=`god-global-law-${Date.now()}@g.us`;
  const run=ctx(group,['global','law','arrestmultiplier','1.5']);
  await godCommand.run(run.ctx);
  assert.equal(god.defaults().arrestMultiplier,1.5);
  assert.equal(rp.economySettings(group).arrestMultiplier,1.5);
});


test('global salary changes preserve explicit per-group salary overrides', async()=>{
  const group=`god-salary-override-${Date.now()}@g.us`;
  god.selectGroup(group);
  await godCommand.run(ctx(group,['salary','president','123456','45m']).ctx);
  const before=rp.economySettings(group);
  const global=ctx(group,['global','salary','president','999999','15m']);
  await godCommand.run(global.ctx);
  const after=rp.economySettings(group);
  assert.equal(after.presidentSalary,before.presidentSalary);
  assert.equal(after.presidentSalaryInterval,before.presidentSalaryInterval);
  assert.equal(god.defaults().presidentSalary,999999);
  assert.equal(god.defaults().presidentSalaryInterval,15*60000);
});


test('Owner presidential appointments remain offers until the appointee accepts', async()=>{
  const group=`god-president-offer-${Date.now()}@g.us`, member='2348076543210@s.whatsapp.net';
  god.selectGroup(group);
  const offer=ctx(group,['appoint','2348076543210','president']);
  await godCommand.run(offer.ctx);
  assert.equal(rp.state(group).president,null,'Owner offer must not activate the presidency yet');
  assert.equal(rp.state(group).ownerPresidentOffer.key,rp.memberKey(member));
  const messages=[];
  await presidentCommand.run({args:['accept'],jid:group,myJid:member,prefix:'.',msg:{key:{remoteJid:group},message:{}},async reply(text,options){messages.push({text,options});}});
  assert.equal(rp.state(group).president.key,rp.memberKey(member));
  assert.equal(rp.state(group).ownerPresidentOffer,null);
  assert.ok(messages.some(m=>m.text.includes('PRESIDENTIAL APPOINTMENT ACCEPTED')));
});
