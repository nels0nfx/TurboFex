require('./_setup');
const test = require('node:test');
const assert = require('node:assert/strict');
const rp = require('../core/roleplay');
const economy = require('../core/economy');

function withClock(fn) {
  const original = Date.now; let now = original(); Date.now = () => now;
  try { fn({ get now() { return now; }, advance(ms) { now += ms; } }); }
  finally { Date.now = original; }
}

test('presidential election blocks instant takeover, permits one vote per member, and installs a clear winner', () => {
  withClock(clock => {
    const group = `gov-election-${Date.now()}@g.us`;
    const candidate = 'election-candidate@s.whatsapp.net';
    const voter1 = 'election-voter1@s.whatsapp.net';
    const voter2 = 'election-voter2@s.whatsapp.net';
    economy.runIn(group, () => {
      economy.add(candidate, rp.PRESIDENT_COST + 1000);
      assert.equal(rp.startGovernmentElection(group, voter1).ok, true);
      assert.equal(rp.takePresident(group, voter1).why, 'election');
      assert.equal(rp.registerElectionCandidate(group, candidate).ok, true);
      assert.equal(rp.castElectionVote(group, voter1, candidate).ok, true);
      assert.equal(rp.castElectionVote(group, voter1, candidate).why, 'voted');
      assert.equal(rp.castElectionVote(group, voter2, candidate).ok, true);
      clock.advance(10 * 60000 + 1);
      const result = rp.governmentElectionStatus(group);
      assert.equal(result.status, 'completed');
      assert.equal(result.result.winner, candidate);
      assert.equal(rp.isPresident(group, candidate), true);
    });
  });
});

test('impeachment requires a reason, unique votes, and at least three votes with a two-thirds majority', () => {
  withClock(clock => {
    const group = `gov-impeachment-${Date.now()}@g.us`;
    const president = 'impeach-president@s.whatsapp.net';
    const voters = ['impeach-v1@s.whatsapp.net','impeach-v2@s.whatsapp.net','impeach-v3@s.whatsapp.net'];
    economy.runIn(group, () => {
      economy.add(president, rp.PRESIDENT_COST + 1000);
      assert.equal(rp.takePresident(group, president).ok, true);
      assert.equal(rp.startImpeachment(group, voters[0], '').why, 'reason');
      assert.equal(rp.startImpeachment(group, voters[0], 'Abuse of office').ok, true);
      assert.equal(rp.voteImpeachment(group, president, 'yes').why, 'president');
      assert.equal(rp.voteImpeachment(group, voters[0], 'yes').ok, true);
      assert.equal(rp.voteImpeachment(group, voters[0], 'no').why, 'voted');
      assert.equal(rp.voteImpeachment(group, voters[1], 'yes').ok, true);
      assert.equal(rp.voteImpeachment(group, voters[2], 'no').ok, true);
      clock.advance(10 * 60000 + 1);
      const result = rp.governmentImpeachmentStatus(group);
      assert.equal(result.status, 'passed');
      assert.equal(result.result.passed, true);
      assert.equal(rp.presidentInfo(group).president, null);
    });
  });
});

test('petitions accept unique signatures and submit at five supporters', () => {
  const group = `gov-petition-${Date.now()}@g.us`;
  const author = 'petition-author@s.whatsapp.net';
  const petition = rp.createGovernmentPetition(group, author, 'Publish the public budget');
  assert.equal(petition.ok, true);
  assert.equal(rp.signGovernmentPetition(group, author, petition.petition.id).why, 'signed');
  for (let i = 1; i <= 4; i++) assert.equal(rp.signGovernmentPetition(group, `petition-${i}@s.whatsapp.net`, petition.petition.id).ok, true);
  const saved = rp.governmentPetitions(group, 5)[0];
  assert.equal(saved.signatureCount, 5);
  assert.equal(saved.status, 'submitted');
  assert.equal(rp.signGovernmentPetition(group, 'petition-5@s.whatsapp.net', petition.petition.id).why, 'closed');
});

test('government command module loads and exposes the public portal', () => {
  const commands = require('../commands/government');
  assert.ok(commands.some(c => c.name === 'civic' && c.aliases.includes('civicgov')));
  assert.equal(typeof commands.runPortal, 'function');
  const all = [].concat(...require('fs').readdirSync('./commands').filter(f => f.endsWith('.js')).map(f => require(`../commands/${f}`)));
  const gov = all.find(c => c.name === 'gov');
  assert.ok(gov);
});

test('the legacy .gov command routes election actions to the new public portal', async () => {
  const all = [].concat(...require('fs').readdirSync('./commands').filter(f => f.endsWith('.js')).map(f => require(`../commands/${f}`)));
  const gov = all.find(c => c.name === 'gov');
  const group = `gov-command-route-${Date.now()}@g.us`;
  let output = '';
  await gov.run({ args: ['election', 'start'], reply: async value => { output = value; }, myJid: 'gov-route-user@s.whatsapp.net', jid: group, prefix: '.', msg: {} });
  assert.match(output, /PRESIDENTIAL ELECTION OPENED/);
});

test('presidential fines share fairness controls, require reasons, and enforce a per-target cooldown', () => {
  withClock(clock => {
    const group = `gov-president-fine-${Date.now()}@g.us`;
    const president = 'fine-president@s.whatsapp.net', target = 'fine-target@s.whatsapp.net';
    economy.runIn(group, () => {
      economy.add(president, rp.PRESIDENT_COST + 1000);
      economy.add(target, 10000);
      assert.equal(rp.takePresident(group, president).ok, true);
      assert.equal(rp.presidentialFine(group, president, target, 100, '').why, 'reason');
      const fine = rp.presidentialFine(group, president, target, 100, 'Repeated robbery');
      assert.equal(fine.ok, true);
      assert.equal(fine.previousWallet, 10000);
      assert.equal(fine.newWallet, 9900);
      assert.equal(rp.presidentialFine(group, president, target, 100, 'Again').why, 'cooldown');
      clock.advance(5 * 60000 + 1);
      assert.equal(rp.presidentialFine(group, president, target, 100, 'Later fine').ok, true);
    });
  });
});

test('President cannot review an appeal against presidential detention', () => {
  withClock(clock => {
    const group = `gov-court-conflict-${Date.now()}@g.us`;
    const president = 'court-conflict-president@s.whatsapp.net', detainee = 'court-conflict-detainee@s.whatsapp.net';
    economy.runIn(group, () => {
      economy.add(president, rp.PRESIDENT_COST + 1000);
      assert.equal(rp.takePresident(group, president).ok, true);
      assert.equal(rp.presidentialJail(group, president, detainee, 20, 'Abuse allegation').ok, true);
      const appeal = rp.fileCourtAppeal(group, detainee, 'I challenge this detention');
      assert.equal(appeal.ok, true);
      assert.equal(rp.reviewCourtCase(group, president, appeal.case.id, 'dismiss', 'I think it is fair').why, 'conflict');
    });
  });
});
