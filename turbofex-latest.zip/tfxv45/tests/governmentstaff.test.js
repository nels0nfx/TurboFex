require('./_setup');
const test = require('node:test');
const assert = require('node:assert/strict');
const rp = require('../core/roleplay');
const economy = require('../core/economy');

test('President assigns staff powers, changes titles and audits staff actions', () => {
  const group = `government-powers-${Date.now()}@g.us`;
  const president = 'gov-p-president@s.whatsapp.net', worker = 'gov-p-worker@s.whatsapp.net';
  economy.runIn(group, () => {
    economy.add(president, rp.PRESIDENT_COST + 5000);
    assert.equal(rp.takePresident(group, president).ok, true);
    assert.equal(rp.appointGovernmentStaff(group, president, worker, 'Minister', 1000).ok, true);
    assert.equal(rp.setGovernmentStaffPowers(group, president, worker, ['finance', 'justice']).ok, true);
    assert.equal(rp.governmentStaffCan(group, worker, 'finance'), true);
    assert.equal(rp.governmentStaffCan(group, worker, 'security'), false);
    assert.equal(rp.setGovernmentStaffTitle(group, president, worker, 'Finance Minister').staff.title, 'Finance Minister');
    assert.equal(rp.depositGovernmentTreasury(group, president, 3000).ok, true);
    const citizen = 'gov-p-citizen@s.whatsapp.net';
    assert.equal(rp.governmentGrant(group, worker, citizen, 1200).ok, true);
    assert.equal(rp.governmentTreasury(group), 1800);
    assert.equal(rp.recordGovernmentStaffAction(group, worker, 'Treasury grant', 'citizen received 1200'), true);
    assert.equal(rp.governmentStaffAudit(group, worker, 10)[0].action, 'Treasury grant');
    assert.equal(rp.setGovernmentStaffPowers(group, president, worker, []).ok, true);
    assert.equal(rp.governmentStaffCan(group, worker, 'finance'), false);
  });
});

test('predefined government positions have fixed powers and expire after 20 minutes without duty', () => {
  const group = `government-position-${Date.now()}@g.us`;
  const president = 'gov-pos-president@s.whatsapp.net', worker = 'gov-pos-worker@s.whatsapp.net';
  const originalNow = Date.now;
  let now = originalNow();
  Date.now = () => now;
  try {
    economy.runIn(group, () => {
      economy.add(president, rp.PRESIDENT_COST + 5000);
      assert.equal(rp.takePresident(group, president).ok, true);
      const appointed = rp.appointGovernmentPosition(group, president, worker, 'finance');
      assert.equal(appointed.ok, true);
      assert.equal(appointed.staff.title, 'Minister of Finance');
      assert.deepEqual(appointed.staff.powers, ['finance']);
      assert.equal(appointed.staff.until - now, 2 * 60 * 60 * 1000);
      assert.equal(rp.appointGovernmentPosition(group, president, 'another@s.whatsapp.net', 'finance').why, 'occupied');
      now += 19 * 60 * 1000;
      assert.equal(rp.recordGovernmentStaffAction(group, worker, 'Treasury review'), true);
      now += 19 * 60 * 1000;
      assert.ok(rp.governmentStaffInfo(group, worker));
      now += 21 * 60 * 1000;
      assert.equal(rp.governmentStaffInfo(group, worker), null);
      assert.equal(rp.governmentStaffCan(group, worker, 'finance'), false);
    });
  } finally { Date.now = originalNow; }
});
