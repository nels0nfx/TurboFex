require('./_setup');
const test = require('node:test');
const assert = require('node:assert/strict');
const rp = require('../core/roleplay');
const economy = require('../core/economy');

test('President assigns staff powers, changes titles and audits staff actions', () => {
  const group = `government-powers-${Date.now()}@g.us`;
  const president = 'gov-p-president@s.whatsapp.net', worker = 'gov-p-worker@s.whatsapp.net';
  economy.runIn(group, () => {
    economy.add(president, rp.PRESIDENT_COST + 5000);
    assert.equal(rp.takePresident(group, president).ok, true);
    assert.equal(rp.appointGovernmentStaff(group, president, worker, 'Minister', 1000).ok, true);
    assert.equal(rp.setGovernmentStaffPowers(group, president, worker, ['finance', 'justice']).ok, true);
    assert.equal(rp.governmentStaffCan(group, worker, 'finance'), true);
    assert.equal(rp.governmentStaffCan(group, worker, 'security'), false);
    assert.equal(rp.setGovernmentStaffTitle(group, president, worker, 'Finance Minister').staff.title, 'Finance Minister');
    assert.equal(rp.depositGovernmentTreasury(group, president, 3000).ok, true);
    const citizen = 'gov-p-citizen@s.whatsapp.net';
    assert.equal(rp.governmentGrant(group, worker, citizen, 1200).ok, true);
    assert.equal(rp.governmentTreasury(group), 1800);
    assert.equal(rp.recordGovernmentStaffAction(group, worker, 'Treasury grant', 'citizen received 1200'), true);
    assert.equal(rp.governmentStaffAudit(group, worker, 10)[0].action, 'Treasury grant');
    assert.equal(rp.setGovernmentStaffPowers(group, president, worker, []).ok, true);
    assert.equal(rp.governmentStaffCan(group, worker, 'finance'), false);
  });
});

test('predefined government positions have fixed powers and expire after 20 minutes without duty', () => {
  const group = `government-position-${Date.now()}@g.us`;
  const president = 'gov-pos-president@s.whatsapp.net', worker = 'gov-pos-worker@s.whatsapp.net';
  const originalNow = Date.now;
  let now = originalNow();
  Date.now = () => now;
  try {
    economy.runIn(group, () => {
      economy.add(president, rp.PRESIDENT_COST + 5000);
      assert.equal(rp.takePresident(group, president).ok, true);
      const appointed = rp.appointGovernmentPosition(group, president, worker, 'finance');
      assert.equal(appointed.ok, true);
      assert.equal(appointed.staff.title, 'Minister of Finance');
      assert.deepEqual(appointed.staff.powers, ['finance']);
      assert.equal(appointed.staff.until - now, 2 * 60 * 60 * 1000);
      assert.equal(rp.appointGovernmentPosition(group, president, 'another@s.whatsapp.net', 'finance').why, 'occupied');
      now += 19 * 60 * 1000;
      assert.equal(rp.recordGovernmentStaffAction(group, worker, 'Treasury review'), true);
      now += 2 * 60 * 1000;
      assert.equal(rp.governmentStaffInfo(group, worker), null, 'read-only treasury reviews must not reset the duty deadline');
      const notices = rp.takeGovernmentSalaryNotices(group);
      assert.equal(notices.length, 1);
      assert.equal(notices[0].amount, 1200);
      now += 21 * 60 * 1000;
      assert.equal(rp.governmentStaffInfo(group, worker), null);
      assert.equal(rp.governmentStaffCan(group, worker, 'finance'), false);
    });
  } finally { Date.now = originalNow; }
});

test('President can change a minister salary and the new rate starts on the next pay interval', () => {
  const group = `government-salary-change-${Date.now()}@g.us`;
  const president = 'gov-salary-president@s.whatsapp.net', worker = 'gov-salary-worker@s.whatsapp.net';
  const originalNow = Date.now; let now = originalNow(); Date.now = () => now;
  try {
    economy.runIn(group, () => {
      economy.add(president, rp.PRESIDENT_COST + 1000);
      assert.equal(rp.takePresident(group, president, now).ok, true);
      const appointment = rp.appointGovernmentPosition(group, president, worker, 'finance');
      assert.equal(appointment.ok, true);
      now += 19 * 60 * 1000;
      rp.recordGovernmentStaffAction(group, worker, 'Treasury grant', 'qualifying action');
      const changed = rp.setGovernmentStaffSalary(group, president, worker, 5000);
      assert.equal(changed.ok, true);
      assert.equal(changed.previousSalary, 1200);
      now += 60 * 1000;
      const first = rp.distributeGovernmentPayroll(now);
      assert.equal(first.payments.find(x => x.jid === worker && x.group === group).amount, 1200);
      now += 20 * 60 * 1000;
      rp.recordGovernmentStaffAction(group, worker, 'Treasury grant', 'qualifying action');
      const second = rp.distributeGovernmentPayroll(now);
      assert.equal(second.payments.find(x => x.jid === worker && x.group === group && x.amount === 5000).amount, 5000);
    });
  } finally { Date.now = originalNow; }
});

test('government fines are limited to 10% of wallet and are recorded in the public treasury ledger', () => {
  const group = `government-fine-cap-${Date.now()}@g.us`;
  const president = 'gov-fine-president@s.whatsapp.net', justice = 'gov-fine-justice@s.whatsapp.net', target = 'gov-fine-target@s.whatsapp.net';
  economy.runIn(group, () => {
    economy.add(president, rp.PRESIDENT_COST + 1000);
    assert.equal(rp.takePresident(group, president).ok, true);
    assert.equal(rp.appointGovernmentPosition(group, president, justice, 'justice').ok, true);
    rp.state(group).governmentStaff[rp.memberKey(justice)].lastDutyAt = Date.now();
    economy.add(target, 10000);
    assert.equal(rp.governmentFine(group, justice, target, 1500, 'Proportionate fine').why, 'limit');
    const fine = rp.governmentFine(group, justice, target, 1000, 'Proportionate fine');
    assert.equal(fine.ok, true);
    assert.equal(fine.balance, 1000);
    assert.equal(rp.governmentLedger(group)[0].type, 'Justice fine');
  });
});
