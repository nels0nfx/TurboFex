require('./_setup');
const test = require('node:test');
const assert = require('node:assert/strict');
const rp = require('../core/roleplay');
const economy = require('../core/economy');

test('full pardon clears wanted, detention, bail, and criminal-record eligibility block', () => {
  const group = `pardon-full-${Date.now()}@g.us`;
  const suspect = 'pardon-suspect@s.whatsapp.net';
  const now = Date.now();
  const u = rp.user(group, suspect);
  Object.assign(u, {
    wanted: 4, jailedUntil: now + 60000, bail: 2500,
    jailReason: 'Wanted level 4/5', jailedBy: 'police', jailType: 'police',
    crimeRecordAt: now - 5000, lastCrime: now - 5000, servedSentenceAt: 0,
  });
  const result = rp.pardon(group, suspect, now);
  assert.equal(result.ok, true);
  assert.equal(u.wanted, 0);
  assert.equal(u.jailedUntil, 0);
  assert.equal(u.bail, 0);
  assert.equal(u.jailReason, '');
  assert.equal(u.jailedBy, '');
  assert.equal(u.jailType, '');
  assert.equal(u.crimeRecordAt, 0);
  assert.equal(u.lastCrime, 0);
  assert.equal(u.servedSentenceAt, 0);
  assert.equal(u.pardonedAt, now);
  assert.equal(rp.careerEligibility(group, suspect, 'police', now).ok, true);
});

test('court dismissal also clears the active criminal record', () => {
  const group = `pardon-court-${Date.now()}@g.us`;
  const president = 'pardon-court-president@s.whatsapp.net';
  const suspect = 'pardon-court-suspect@s.whatsapp.net';
  economy.runIn(group, () => {
    economy.add(president, rp.PRESIDENT_COST + 1000);
    assert.equal(rp.takePresident(group, president).ok, true);
    const now = Date.now();
    const u = rp.user(group, suspect);
    Object.assign(u, { wanted: 2, jailedUntil: now + 60000, bail: 300, jailReason: 'test', jailedBy: 'police', jailType: 'police', crimeRecordAt: now - 1000, lastCrime: now - 1000 });
    const g = rp.state(group);
    const c = { id: 1, type: 'detention-appeal', appellant: suspect, jailedBy: 'police', jailType: 'police', status: 'pending', filedAt: now, filedReason: 'Wrong person', decisionReason: '' };
    g.courtCases.push(c);
    const result = rp.reviewCourtCase(group, president, 1, 'dismiss', 'Evidence did not support the detention', now);
    assert.equal(result.ok, true);
    assert.equal(u.wanted, 0);
    assert.equal(u.jailedUntil, 0);
    assert.equal(u.bail, 0);
    assert.equal(u.crimeRecordAt, 0);
    assert.equal(u.lastCrime, 0);
    assert.equal(rp.careerEligibility(group, suspect, 'police', now).ok, true);
  });
});

test('presidential and Justice Ministry pardon commands use the shared full-pardon path', async () => {
  const commands = require('../commands/roleplay');
  const presidentCommand = commands.find(c => c.name === 'president');
  const staffCommand = commands.find(c => c.name === 'govstaff');
  const group = `pardon-command-${Date.now()}@g.us`;
  const president = 'pardon-command-president@s.whatsapp.net';
  const justice = 'pardon-command-justice@s.whatsapp.net';
  const suspect = 'pardon-command-suspect@s.whatsapp.net';
  const now = Date.now();
  const targetMsg = { message: { extendedTextMessage: { text: 'pardon @target', contextInfo: { mentionedJid: [suspect] } } } };
  const responses = [];
  const reply = async (message, options) => { responses.push({ message, options }); };
  economy.runIn(group, () => {
    economy.add(president, rp.PRESIDENT_COST + 1000);
    assert.equal(rp.takePresident(group, president).ok, true);
    assert.equal(rp.appointGovernmentPosition(group, president, justice, 'justice').ok, true);
    assert.equal(rp.acceptGovernmentAppointment(group, justice).ok, true);
  });
  Object.assign(rp.user(group, suspect), { wanted: 3, jailedUntil: now + 60000, bail: 900, jailReason: 'test', jailedBy: 'police', jailType: 'police', crimeRecordAt: now - 1000, lastCrime: now - 1000 });
  await presidentCommand.run({ args: ['pardon', '@target', 'wrongful accusation'], reply, myJid: president, jid: group, prefix: '.', msg: targetMsg });
  assert.equal(rp.user(group, suspect).wanted, 0);
  assert.equal(rp.user(group, suspect).crimeRecordAt, 0);
  Object.assign(rp.user(group, suspect), { wanted: 2, jailedUntil: now + 60000, bail: 600, jailReason: 'test', jailedBy: 'police', jailType: 'police', crimeRecordAt: now - 500, lastCrime: now - 500 });
  await staffCommand.run({ args: ['pardon', '@target'], reply, myJid: justice, jid: group, prefix: '.', msg: targetMsg });
  assert.equal(rp.user(group, suspect).wanted, 0);
  assert.equal(rp.user(group, suspect).jailedUntil, 0);
  assert.equal(rp.user(group, suspect).crimeRecordAt, 0);
  assert.match(responses.at(-1).message, /full pardon/i);
});


test('Owner pardon command applies the full pardon to the selected/current group', async () => {
  const godCommand = require('../commands/god').find(c => c.name === 'god');
  const group = `pardon-owner-command-${Date.now()}@g.us`;
  const owner = '27800000001@s.whatsapp.net';
  const suspect = 'pardon-owner-suspect@s.whatsapp.net';
  const now = Date.now();
  Object.assign(rp.user(group, suspect), { wanted: 5, jailedUntil: now + 60000, bail: 5000, jailReason: 'test', jailedBy: 'police', jailType: 'police', crimeRecordAt: now - 1000, lastCrime: now - 1000 });
  const sent = [];
  const sock = {
    groupFetchAllParticipating: async () => ({ [group]: { id: group, subject: 'Pardon Test Group', participants: [] } }),
    sendMessage: async (to, payload) => { sent.push({ to, payload }); return {}; },
  };
  const msg = { message: { extendedTextMessage: { text: 'pardon @target', contextInfo: { mentionedJid: [suspect] } } } };
  const replies = [];
  await godCommand.run({ args: ['pardon', '@target'], reply: async (message) => replies.push(message), prefix: '.', isOwner: true, jid: group, msg, sock });
  const u = rp.user(group, suspect);
  assert.equal(u.wanted, 0);
  assert.equal(u.jailedUntil, 0);
  assert.equal(u.bail, 0);
  assert.equal(u.crimeRecordAt, 0);
  assert.equal(u.lastCrime, 0);
  assert.ok(sent.some(x => x.to === group && /OWNER PARDON/.test(x.payload.text)));
  assert.match(replies[0], /Full pardon issued/i);
});

test('pardon by phone number clears the existing LID-based detention record', () => {
  const idmap = require('../whatsapp/idmap');
  const group = `pardon-lid-alias-${Date.now()}@g.us`;
  const lid = `990000${Date.now() % 1000000}@lid`;
  const phone = `23480${String(Date.now()).slice(-8)}@s.whatsapp.net`;
  const now = Date.now();
  idmap.learn(lid, phone);
  const stored = rp.user(group, lid);
  Object.assign(stored, {
    wanted: 3, jailedUntil: now + 45 * 60000, bail: 900,
    jailReason: 'Wanted level 3/5', jailedBy: 'police', jailType: 'police',
    crimeRecordAt: now - 1000, lastCrime: now - 1000,
  });
  const result = rp.pardon(group, phone, now);
  assert.equal(result.ok, true);
  assert.equal(result.user, stored, 'pardon must resolve the existing member record, not create a duplicate');
  assert.equal(stored.jailedUntil, 0);
  assert.equal(stored.wanted, 0);
  assert.equal(rp.jailLeft(group, lid, now), 0, 'the handler detention check must see the same released record');
  assert.equal(rp.user(group, phone), stored, 'phone and LID forms must resolve to one user record');
});
