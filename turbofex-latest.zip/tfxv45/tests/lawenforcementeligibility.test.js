require('./_setup');
const test = require('node:test');
const assert = require('node:assert/strict');
const rp = require('../core/roleplay');
const economy = require('../core/economy');
const scheduler = require('../core/scheduler');

function groupId(label) { return `law-enforcement-${label}-${Date.now()}-${Math.random().toString(36).slice(2)}@g.us`; }

test('wanted members cannot self-apply or be appointed to police, royal guard, or soldier', () => {
  const group = groupId('eligibility'), president = 'eligibility-president@s.whatsapp.net', suspect = 'eligibility-suspect@s.whatsapp.net';
  economy.runIn(group, () => {
    economy.add(president, rp.PRESIDENT_COST + 1000);
    assert.equal(rp.takePresident(group, president).ok, true);
    rp.addWanted(group, suspect, 2);
    for (const career of ['police', 'royalguard', 'soldier']) {
      assert.equal(rp.claimCareer(group, suspect, career).why, 'wanted');
      assert.equal(rp.appointCareer(group, president, suspect, career).why, 'wanted');
    }
  });
});

test('wanted status immediately removes a serving police officer and queues a public notice', () => {
  const group = groupId('revoke'), officer = 'revoke-officer@s.whatsapp.net';
  assert.equal(rp.claimCareer(group, officer, 'police').ok, true);
  assert.equal(rp.addWanted(group, officer, 1), 1);
  assert.equal(rp.user(group, officer).career, null);
  assert.equal(rp.careerHolder(group, 'police'), null);
  const notices = rp.takeCareerRemovalNotices(group);
  assert.equal(notices.length, 1);
  assert.equal(notices[0].jid, officer);
  assert.equal(notices[0].reason, 'wanted');
});

test('law enforcement rejects unreformed criminal records even when wanted level is zero', () => {
  const group = groupId('record'), member = 'record-member@s.whatsapp.net';
  const u = rp.user(group, member);
  u.wanted = 0; u.crimeRecordAt = Date.now() - 1000; u.lastCrime = u.crimeRecordAt; u.servedSentenceAt = 0;
  assert.equal(rp.claimCareer(group, member, 'police').why, 'criminal_record');
  assert.equal(rp.claimCareer(group, member, 'royalguard').why, 'criminal_record');
});

test('failed prison escape increases wanted level through shared enforcement and removes police status', () => {
  const group = groupId('escape'), officer = 'escape-officer@s.whatsapp.net';
  assert.equal(rp.claimCareer(group, officer, 'police').ok, true);
  const u = rp.user(group, officer); u.jailedUntil = Date.now() + 5 * 60000; u.jailType = 'crime'; u.bail = 500;
  const result = rp.attemptPrisonEscape(group, officer, Date.now(), 0.99);
  assert.equal(result.why, 'caught');
  assert.ok(rp.user(group, officer).wanted > 0);
  assert.equal(rp.user(group, officer).career, null);
});

test('scheduler announces wanted-career revocation in the group', async () => {
  const group = groupId('notice'), officer = 'notice-officer@s.whatsapp.net';
  rp.claimCareer(group, officer, 'police'); rp.addWanted(group, officer, 1);
  const messages = [];
  await scheduler.tick({ sendMessage: async (jid, payload) => { messages.push({ jid, payload }); return {}; }, groupSettingUpdate: async () => ({}) });
  assert.ok(messages.some(m => m.jid === group && /LAW-ENFORCEMENT DISMISSAL/.test(m.payload.text)));
});
