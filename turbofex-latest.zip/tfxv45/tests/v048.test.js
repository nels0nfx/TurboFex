require('./_setup');
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const rp = require('../core/roleplay');
const economy = require('../core/economy');
require('../core/throne');

const group = `v048-${Date.now()}@g.us`;
const president = '2348011111111@s.whatsapp.net';
const citizen = '2348022222222@s.whatsapp.net';

test('presidency is group-scoped, costs money, and has a timed term', () => {
  const now = Date.now();
  economy.runIn(group, () => {
    economy.add(president, rp.PRESIDENT_COST + 10000);
    assert.equal(rp.takePresident(group, president, now).ok, true);
    assert.equal(rp.isPresident(group, president, now + 1), true);
    assert.equal(rp.isPresident(`${group}-other`, president, now + 1), false);
    assert.equal(rp.setPresidentTax(group, president, 3, now).tax, 3);
    assert.equal(rp.presidentInfo(group, now + 1).tax, 3);
    assert.equal(rp.presidentInfo(group, now + rp.PRESIDENT_TERM + 1).president, null);
  });
});

test('presidential stimulus distributes a funded amount to registered group users', () => {
  economy.runIn(group, () => {
    economy.add(president, rp.PRESIDENT_COST + 5000);
    economy.add(citizen, 100);
    rp.user(group, president); rp.user(group, citizen);
    assert.equal(rp.takePresident(group, president).ok, true);
    const before = economy.balance(citizen);
    const result = rp.stimulus(group, president, 100);
    assert.equal(result.ok, true);
    assert.equal(result.count, 1);
    assert.equal(economy.balance(citizen), before + 100);
  });
});

test('Royal Guard protection blocks robbery for the protected group member', () => {
  economy.runIn(group, () => {
    const guard = '2348033333333@s.whatsapp.net';
    economy.add(guard, 10000);
    economy.add(citizen, 10000);
    rp.protect(group, guard, citizen, 30 * 60000);
    const result = economy.rob(guard, citizen, () => 0);
    assert.equal(result.ok, false);
    assert.equal(result.why, 'shield');
  });
});

test('career salary interval is 20 minutes and market commands are removed', () => {
  const roleplaySource = fs.readFileSync(path.join(__dirname, '..', 'commands', 'roleplay.js'), 'utf8');
  assert.match(roleplaySource, /SALARY_INTERVAL\s*=\s*20\s*\*\s*60000/);
  assert.equal(fs.existsSync(path.join(__dirname, '..', 'commands', 'market.js')), false);
  assert.ok(require('../commands/economyinfo').some((c) => c.name === 'economy'));
  const commands = require('../commands/roleplay');
  assert.ok(commands.some((c) => c.name === 'president'));
  assert.ok(commands.some((c) => c.name === 'career'));
});

test('king can issue a direct grant and pay active chatters a bounty', () => {
  const throne = require('../core/throne');
  const group2 = `${group}-king`;
  economy.runIn(group2, () => {
    economy.add(president, 100000);
    economy.add(citizen, 1000);
    assert.equal(throne.take(group2, president).ok, true);
    assert.equal(throne.grant(group2, president, citizen, 500).ok, true);
    throne.seen(group2, citizen);
    const r = throne.bounty(group2, president, 100);
    assert.equal(r.ok, true);
    assert.equal(r.guests.length, 1);
    assert.equal(r.total, 100);
  });
});


test('luxury purchases are expensive, persistent and group-specific', async () => {
  const command = require('../commands/roleplay').find((c) => c.name === 'luxury');
  const group3 = `${group}-luxury`;
  const messages = [];
  economy.runIn(group3, async () => {
    economy.add(president, rp.LUXURIES.supercar.cost + 1000);
    await command.run({ args: ['buy', 'supercar'], reply: async (m) => messages.push(m), myJid: president, jid: group3, prefix: '.' });
    assert.ok(rp.user(group3, president).luxuries.includes('supercar'));
    assert.match(messages.at(-1), /LUXURY PURCHASE CONFIRMED/);
    await command.run({ args: ['buy', 'supercar'], reply: async (m) => messages.push(m), myJid: president, jid: group3, prefix: '.' });
    assert.match(messages.at(-1), /already own/);
  });
  assert.equal(rp.user(`${group3}-other`, president).luxuries.length, 0);
});
