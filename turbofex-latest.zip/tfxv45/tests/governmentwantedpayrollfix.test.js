require('./_setup');
const test = require('node:test');
const assert = require('node:assert/strict');
const rp = require('../core/roleplay');
const economy = require('../core/economy');
const scheduler = require('../core/scheduler');

test('wanted members cannot be appointed to government offices', () => {
  const group = `wanted-appoint-${Date.now()}@g.us`;
  const president = 'wanted-president@s.whatsapp.net';
  const suspect = 'wanted-suspect@s.whatsapp.net';
  economy.runIn(group, () => {
    economy.add(president, rp.PRESIDENT_COST + 5000);
    assert.equal(rp.takePresident(group, president).ok, true);
    rp.addWanted(group, suspect, 2);
    assert.equal(rp.appointGovernmentPosition(group, president, suspect, 'finance').why, 'wanted');
    assert.equal(rp.appointGovernmentStaff(group, president, suspect, 'Custom Minister', 1000).why, 'wanted');
  });
});

test('a government official who becomes wanted is removed and queued for group notice', () => {
  const group = `wanted-remove-${Date.now()}@g.us`;
  const president = 'wanted-remove-president@s.whatsapp.net';
  const worker = 'wanted-remove-worker@s.whatsapp.net';
  economy.runIn(group, () => {
    economy.add(president, rp.PRESIDENT_COST + 5000);
    assert.equal(rp.takePresident(group, president).ok, true);
    assert.equal(rp.appointGovernmentPosition(group, president, worker, 'security').ok, true);
    assert.equal(rp.acceptGovernmentAppointment(group, worker).ok, true);
    assert.equal(rp.setWantedLevel(group, worker, 1).ok, true);
    assert.equal(rp.governmentStaffInfo(group, worker), null);
    const notices = rp.takeGovernmentStaffRemovalNotices(group);
    assert.equal(notices.length, 1);
    assert.equal(notices[0].jid, worker);
    assert.equal(notices[0].wanted, 1);
  });
});

test('automatic salary is credited and announced in the group only', async () => {
  const group = `payroll-dm-${Date.now()}@g.us`;
  const president = 'payroll-dm-president@s.whatsapp.net';
  const worker = 'payroll-dm-worker@s.whatsapp.net';
  economy.runIn(group, () => {
    economy.add(president, rp.PRESIDENT_COST + 5000);
    assert.equal(rp.takePresident(group, president).ok, true);
    assert.equal(rp.appointGovernmentPosition(group, president, worker, 'finance').ok, true);
    assert.equal(rp.acceptGovernmentAppointment(group, worker).ok, true);
    rp.state(group).governmentStaff[rp.memberKey(worker)].lastPaidAt = Date.now() - 20 * 60 * 1000 - 1000;
    rp.state(group).governmentStaff[rp.memberKey(worker)].lastDutyAt = Date.now();
  });
  const before = economy.runIn(group, () => economy.balance(worker));
  const messages = [];
  await scheduler.tick({
    sendMessage: async (jid, payload) => { messages.push({jid,payload}); return {}; },
    groupSettingUpdate: async () => ({}),
  });
  const groupNotice = messages.find(x => x.jid === group && /GOVERNMENT SALARY PAID/.test(x.payload.text));
  const dm = messages.find(x => x.jid === worker && /YOUR GOVERNMENT SALARY WAS CREDITED/.test(x.payload.text));
  assert.ok(groupNotice, 'salary is publicly announced in the group');
  assert.equal(dm, undefined, 'salary must not be sent privately');
  assert.equal(economy.runIn(group, () => economy.balance(worker)), before + 1200);
  assert.match(groupNotice.payload.text, /Previous wallet:/);
  assert.match(groupNotice.payload.text, /New wallet:/);
});
