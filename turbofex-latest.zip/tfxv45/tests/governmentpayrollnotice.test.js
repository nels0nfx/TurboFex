require('./_setup');
const test = require('node:test');
const assert = require('node:assert/strict');
const rp = require('../core/roleplay');
const economy = require('../core/economy');
const scheduler = require('../core/scheduler');

test('automatic government payroll posts a tagged group notice with previous and new wallet balances', async () => {
  const group = `government-payroll-notice-${Date.now()}@g.us`;
  const president = 'gov-notice-president@s.whatsapp.net';
  const worker = 'gov-notice-worker@s.whatsapp.net';
  economy.runIn(group, () => {
    economy.add(president, rp.PRESIDENT_COST + 5000);
    assert.equal(rp.takePresident(group, president).ok, true);
    const appointment = rp.appointGovernmentPosition(group, president, worker, 'finance');
    assert.equal(appointment.ok, true);
    rp.state(group).governmentStaff[rp.memberKey(worker)].lastPaidAt = Date.now() - 20 * 60 * 1000;
  });
  const messages = [];
  await scheduler.tick({
    sendMessage: async (jid, payload) => { messages.push({ jid, payload }); return {}; },
    groupSettingUpdate: async () => ({}),
  });
  const notice = messages.find(x => x.jid === group && /GOVERNMENT SALARY PAID/.test(x.payload.text));
  assert.ok(notice, 'scheduler should announce the payroll in the group');
  assert.deepEqual(notice.payload.mentions, [worker]);
  assert.match(notice.payload.text, /@gov-notice-worker received \*\+1,200 coins\*/);
  assert.match(notice.payload.text, /Previous wallet: 0 coins/);
  assert.match(notice.payload.text, /New wallet: 1,200 coins/);
});
