require('./_setup');
const test = require('node:test');
const assert = require('node:assert/strict');
const rp = require('../core/roleplay');
const economy = require('../core/economy');
const group = `roleplay-admin-${Date.now()}@g.us`;
const other = `${group}-other`;
const a = '27840000001@s.whatsapp.net';
const b = '27840000002@s.whatsapp.net';

test('career appointments are exclusive per group and expire after two hours', () => {
  const now = Date.now();
  assert.equal(rp.claimCareer(group, a, 'police', now).ok, true);
  const occupied = rp.claimCareer(group, b, 'police', now + 1000);
  assert.equal(occupied.ok, false);
  assert.equal(occupied.why, 'occupied');
  assert.equal(rp.claimCareer(other, b, 'police', now + 1000).ok, true);
  const after = rp.claimCareer(group, b, 'police', now + rp.CAREER_TERM + 1);
  assert.equal(after.ok, true);
  assert.equal(rp.refreshCareer(group, a, now + rp.CAREER_TERM + 2).career, null);
});

test('owner economy settings are group scoped and accept adjustable presidential payroll', () => {
  assert.equal(rp.setEconomySetting(group, 'presidentSalary', 2500000), true);
  assert.equal(rp.setEconomySetting(group, 'presidentSalaryInterval', 5), true);
  assert.equal(rp.economySettings(group).presidentSalary, 2500000);
  assert.equal(rp.economySettings(group).presidentSalaryInterval, 5 * 60000);
  assert.equal(rp.economySettings(other).presidentSalary, 1000000);
  assert.equal(rp.setEconomySetting(group, 'robChance', 91), false);
});

test('presidency is per group and payroll accrues at configured intervals', () => {
  const now = Date.now();
  rp.setEconomySetting(group, 'presidentSalary', 1000000);
  rp.setEconomySetting(group, 'presidentSalaryInterval', 10);
  economy.runIn(group, () => {
    economy.add(a, 6000000);
    assert.equal(rp.takePresident(group, a, now).ok, true);
    const info = rp.presidentInfo(group, now + 10 * 60000);
    assert.equal(info.president.key, rp.memberKey(a));
    assert.equal(economy.balance(a), 6000000 + 1000000 - 5000000);
    assert.equal(rp.presidentInfo(other, now).president, null);
  });
});
