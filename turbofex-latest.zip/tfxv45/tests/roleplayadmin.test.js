require('./_setup');
const test = require('node:test');
const assert = require('node:assert/strict');
const rp = require('../core/roleplay');
const economy = require('../core/economy');
const group = `roleplay-admin-${Date.now()}@g.us`;
const other = `${group}-other`;
const a = '27840000001@s.whatsapp.net';
const b = '27840000002@s.whatsapp.net';

test('career appointments are exclusive per group and expire after two hours', () => {
  const now = Date.now();
  assert.equal(rp.claimCareer(group, a, 'police', now).ok, true);
  const occupied = rp.claimCareer(group, b, 'police', now + 1000);
  assert.equal(occupied.ok, false);
  assert.equal(occupied.why, 'occupied');
  assert.equal(rp.claimCareer(other, b, 'police', now + 1000).ok, true);
  const after = rp.claimCareer(group, b, 'police', now + rp.CAREER_TERM + 1);
  assert.equal(after.ok, true);
  assert.equal(rp.refreshCareer(group, a, now + rp.CAREER_TERM + 2).career, null);
});

test('owner economy settings are group scoped and accept adjustable presidential payroll', () => {
  assert.equal(rp.setEconomySetting(group, 'presidentSalary', 2500000), true);
  assert.equal(rp.setEconomySetting(group, 'presidentSalaryInterval', 5), true);
  assert.equal(rp.economySettings(group).presidentSalary, 2500000);
  assert.equal(rp.economySettings(group).presidentSalaryInterval, 5 * 60000);
  assert.equal(rp.economySettings(other).presidentSalary, 1000000);
  assert.equal(rp.setEconomySetting(group, 'robChance', 91), false);
});

test('presidency is per group and payroll accrues at configured intervals', () => {
  const now = Date.now();
  rp.setEconomySetting(group, 'presidentSalary', 1000000);
  rp.setEconomySetting(group, 'presidentSalaryInterval', 10);
  economy.runIn(group, () => {
    economy.add(a, 6000000);
    assert.equal(rp.takePresident(group, a, now).ok, true);
    const info = rp.presidentInfo(group, now + 10 * 60000);
    assert.equal(info.president.key, rp.memberKey(a));
    assert.equal(rp.presidentSalaryAccrued(group, now + 10 * 60000), 1000000);
    assert.equal(rp.collectPresidentSalary(group, now + 10 * 60000), 1000000);
    assert.equal(economy.balance(a), 6000000 + 1000000 - 5000000);
    assert.equal(rp.presidentInfo(other, now).president, null);
  });
});

test('King and President cannot join gangs, and government leaders cannot hold careers', () => {
  const throne = require('../core/throne');
  const govGroup = `roleplay-admin-government-${Date.now()}@g.us`;
  const king = '27840000003@s.whatsapp.net';
  const president = '27840000004@s.whatsapp.net';
  const citizen = '27840000005@s.whatsapp.net';
  economy.runIn(govGroup, () => {
    economy.add(king, 10000);
    assert.equal(throne.take(govGroup, king).ok, true);
    assert.equal(rp.makeGang(govGroup, king, 'royalcrew').why, 'leader');
    assert.equal(rp.claimCareer(govGroup, king, 'police').why, 'leader');
    assert.equal(rp.makeGang(govGroup, citizen, 'citycrew').ok, true);
    assert.equal(rp.joinGang(govGroup, king, 'citycrew').why, 'leader');
  });
  const pGroup = `roleplay-admin-president-${Date.now()}@g.us`;
  economy.runIn(pGroup, () => {
    economy.add(president, rp.PRESIDENT_COST + 1000);
    assert.equal(rp.takePresident(pGroup, president).ok, true);
    assert.equal(rp.makeGang(pGroup, president, 'prescrew').why, 'leader');
    assert.equal(rp.claimCareer(pGroup, president, 'doctor').why, 'leader');
  });
});

test('President can inspect and revoke one King setting without clearing the others', () => {
  const throne = require('../core/throne');
  const govGroup = `roleplay-admin-override-${Date.now()}@g.us`;
  const king = '27840000006@s.whatsapp.net';
  const president = '27840000007@s.whatsapp.net';
  economy.runIn(govGroup, () => {
    economy.add(king, 10000);
    economy.add(president, rp.PRESIDENT_COST + 1000);
    assert.equal(throne.take(govGroup, king).ok, true);
    assert.equal(throne.setTax(govGroup, king, 3).ok, false, 'King taxation is now disabled');
    assert.equal(throne.decree(govGroup, king, 'King decree').ok, true);
    assert.equal(throne.jail(govGroup, king, '27840000008@s.whatsapp.net').ok, false, 'detention belongs to government staff');
    assert.equal(rp.takePresident(govGroup, president).ok, true);
    assert.equal(throne.kingSettings(govGroup).tax, 0);
    assert.equal(throne.removeKingSetting(govGroup, president, 'decree').ok, true);
    assert.equal(throne.info(govGroup).tax, 0);
    assert.equal(throne.info(govGroup).decree, '');
    throne.setIncome(govGroup, 321);
    assert.equal(throne.removeKingSetting(govGroup, president, 'income').ok, true);
    assert.equal(throne.info(govGroup).income, throne.RULES.incomePerHour);
  });
});

test('President can appoint a career holder and King; appointed King cannot be bought off the throne', () => {
  const throne = require('../core/throne');
  const group = `roleplay-president-appointments-${Date.now()}@g.us`;
  const president = '27840000031@s.whatsapp.net';
  const officer = '27840000032@s.whatsapp.net';
  const king = '27840000033@s.whatsapp.net';
  economy.runIn(group, () => {
    economy.add(president, rp.PRESIDENT_COST + 5000);
    assert.equal(rp.takePresident(group, president).ok, true);
    const career = rp.appointCareer(group, president, officer, 'police');
    assert.equal(career.ok, true);
    assert.equal(rp.user(group, officer).career, 'police');
    const appointed = throne.appointKing(group, president, king);
    assert.equal(appointed.ok, true);
    assert.equal(throne.isKing(group, king), true);
    assert.equal(throne.take(group, officer).why, 'appointed');
    assert.equal(rp.claimCareer(group, king, 'doctor').why, 'leader');
  });
});

test('career salary reforms are group scoped and respect the government-set cap', () => {
  const group = `career-salary-reform-${Date.now()}@g.us`;
  assert.equal(rp.setCareerSalary(group, 'all', 5000), true);
  assert.equal(rp.careerSalary(group, 'police', 1), 5000);
  assert.equal(rp.setCareerSalaryLimit(group, 1200), true);
  assert.equal(rp.careerSalary(group, 'doctor', 5), 1200);
  assert.equal(rp.careerSalary(group, 'doctor', 1), 1200);
});

test('president is protected from both committing and being targeted by wallet robbery', () => {
  const govGroup = `roleplay-admin-robbery-${Date.now()}@g.us`;
  const president = '27840000009@s.whatsapp.net';
  const thief = '27840000010@s.whatsapp.net';
  economy.runIn(govGroup, () => {
    economy.add(president, rp.PRESIDENT_COST + 10000);
    economy.add(thief, 10000);
    assert.equal(rp.takePresident(govGroup, president).ok, true);
    assert.equal(economy.rob(president, thief).why, 'king');
    assert.equal(economy.rob(thief, president).why, 'kingsafe');
  });
});

test('President can appoint staff, set salary, and staff can collect accrued pay', () => {
  const groupId = `roleplay-staff-${Date.now()}@g.us`, president = 'staff-president@s.whatsapp.net', worker = 'staff-worker@s.whatsapp.net';
  economy.runIn(groupId, () => {
    economy.add(president, 6000000);
    assert.equal(rp.takePresident(groupId, president).ok, true);
    const appointed = rp.appointGovernmentStaff(groupId, president, worker, 'Finance Minister', 7500);
    assert.equal(appointed.ok, true);
    assert.equal(rp.governmentStaff(groupId)[0].salary, 7500);
    const paid = rp.collectGovernmentSalary(groupId, worker, appointed.staff.lastClaimAt + 20 * 60000);
    assert.equal(paid.amount, 7500);
    assert.equal(economy.balance(worker), 7500);
    assert.equal(rp.removeGovernmentStaff(groupId, president, worker).ok, true);
  });
});

test('President can dismiss a career holder and group-specific royal tax limit is enforced', () => {
  const groupId = `roleplay-dismiss-${Date.now()}@g.us`, president = 'dismiss-president@s.whatsapp.net', worker = 'dismiss-worker@s.whatsapp.net';
  const throne = require('../core/throne');
  economy.runIn(groupId, () => {
    economy.add(president, 6000000);
    assert.equal(rp.takePresident(groupId, president).ok, true);
    assert.equal(rp.claimCareer(groupId, worker, 'doctor').ok, true);
    assert.equal(rp.removeCareerHolder(groupId, worker).ok, true);
    assert.equal(rp.user(groupId, worker).career, null);
    assert.equal(throne.setGroupMaxTax(groupId, president, 12).maxTax, 12);
  });
});
