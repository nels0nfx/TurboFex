require('./_setup');
const test = require('node:test');
const assert = require('node:assert/strict');
const rp = require('../core/roleplay');
const economy = require('../core/economy');
const group = `roleplay-admin-${Date.now()}@g.us`;
const other = `${group}-other`;
const a = '27840000001@s.whatsapp.net';
const b = '27840000002@s.whatsapp.net';

test('career appointments are exclusive per group and expire after two hours', () => {
  const now = Date.now();
  assert.equal(rp.claimCareer(group, a, 'police', now).ok, true);
  const occupied = rp.claimCareer(group, b, 'police', now + 1000);
  assert.equal(occupied.ok, false);
  assert.equal(occupied.why, 'occupied');
  assert.equal(rp.claimCareer(other, b, 'police', now + 1000).ok, true);
  const after = rp.claimCareer(group, b, 'police', now + rp.CAREER_TERM + 1);
  assert.equal(after.ok, true);
  assert.equal(rp.refreshCareer(group, a, now + rp.CAREER_TERM + 2).career, null);
});

test('owner economy settings are group scoped and accept adjustable presidential payroll', () => {
  assert.equal(rp.setEconomySetting(group, 'presidentSalary', 2500000), true);
  assert.equal(rp.setEconomySetting(group, 'presidentSalaryInterval', 5), true);
  assert.equal(rp.economySettings(group).presidentSalary, 2500000);
  assert.equal(rp.economySettings(group).presidentSalaryInterval, 5 * 60000);
  assert.equal(rp.economySettings(other).presidentSalary, 1000000);
  assert.equal(rp.setEconomySetting(group, 'robChance', 91), false);
});

test('presidency is per group and payroll accrues at configured intervals', () => {
  const now = Date.now();
  rp.setEconomySetting(group, 'presidentSalary', 1000000);
  rp.setEconomySetting(group, 'presidentSalaryInterval', 10);
  economy.runIn(group, () => {
    economy.add(a, 6000000);
    assert.equal(rp.takePresident(group, a, now).ok, true);
    const info = rp.presidentInfo(group, now + 10 * 60000);
    assert.equal(info.president.key, rp.memberKey(a));
    assert.equal(economy.balance(a), 6000000 + 1000000 - 5000000);
    assert.equal(rp.presidentInfo(other, now).president, null);
  });
});

test('King and President cannot join gangs, and government leaders cannot hold careers', () => {
  const throne = require('../core/throne');
  const govGroup = `roleplay-admin-government-${Date.now()}@g.us`;
  const king = '27840000003@s.whatsapp.net';
  const president = '27840000004@s.whatsapp.net';
  const citizen = '27840000005@s.whatsapp.net';
  economy.runIn(govGroup, () => {
    economy.add(king, 10000);
    assert.equal(throne.take(govGroup, king).ok, true);
    assert.equal(rp.makeGang(govGroup, king, 'royalcrew').why, 'leader');
    assert.equal(rp.claimCareer(govGroup, king, 'police').why, 'leader');
    assert.equal(rp.makeGang(govGroup, citizen, 'citycrew').ok, true);
    assert.equal(rp.joinGang(govGroup, king, 'citycrew').why, 'leader');
  });
  const pGroup = `roleplay-admin-president-${Date.now()}@g.us`;
  economy.runIn(pGroup, () => {
    economy.add(president, rp.PRESIDENT_COST + 1000);
    assert.equal(rp.takePresident(pGroup, president).ok, true);
    assert.equal(rp.makeGang(pGroup, president, 'prescrew').why, 'leader');
    assert.equal(rp.claimCareer(pGroup, president, 'doctor').why, 'leader');
  });
});

test('President can remove all King-set settings and release royal jail', () => {
  const throne = require('../core/throne');
  const govGroup = `roleplay-admin-override-${Date.now()}@g.us`;
  const king = '27840000006@s.whatsapp.net';
  const president = '27840000007@s.whatsapp.net';
  const citizen = '27840000008@s.whatsapp.net';
  economy.runIn(govGroup, () => {
    economy.add(king, 10000);
    economy.add(president, rp.PRESIDENT_COST + 1000);
    assert.equal(throne.take(govGroup, king).ok, true);
    assert.equal(throne.setTax(govGroup, king, 3).ok, true);
    assert.equal(throne.decree(govGroup, king, 'King decree').ok, true);
    assert.equal(throne.jail(govGroup, king, citizen).ok, true);
    assert.equal(rp.takePresident(govGroup, president).ok, true);
    const cleared = throne.removeKingSettings(govGroup, president);
    assert.equal(cleared.ok, true);
    assert.equal(cleared.cleared, 1);
    assert.equal(throne.info(govGroup).tax, 0);
    assert.equal(throne.info(govGroup).decree, '');
    assert.equal(throne.jailedList(govGroup).length, 0);
  });
});

test('president is protected from both committing and being targeted by wallet robbery', () => {
  const govGroup = `roleplay-admin-robbery-${Date.now()}@g.us`;
  const president = '27840000009@s.whatsapp.net';
  const thief = '27840000010@s.whatsapp.net';
  economy.runIn(govGroup, () => {
    economy.add(president, rp.PRESIDENT_COST + 10000);
    economy.add(thief, 10000);
    assert.equal(rp.takePresident(govGroup, president).ok, true);
    assert.equal(economy.rob(president, thief).why, 'king');
    assert.equal(economy.rob(thief, president).why, 'kingsafe');
  });
});
