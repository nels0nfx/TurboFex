# ⚡ TurboFex v0.6.2

[![CI](https://github.com/nels0nfx/TurboFex/actions/workflows/ci.yml/badge.svg)](https://github.com/nels0nfx/TurboFex/actions/workflows/ci.yml)

WhatsApp group management and assistant bot by **Nelson Fx** (Trinity Flow). It runs on Node.js with the
[Baileys](https://github.com/WhiskeySockets/Baileys) library and is built to run for months without attention:
it reconnects by itself, backs up its login, updates itself safely and protects the server it runs on.

> Unofficial bots can get a number banned. Use a spare number for the bot, never your main one.

## Features
- **300+ commands** in 16 categories (group management incl. ranks and birthdays, security, lookup, status tools, games, media, audio/video/picture editing, budget, tools...). Send `.menu`.
- **Group economy:** per-group coins, bank, jobs, games, careers, gangs, territory, king and president systems. Market and stock trading have been removed.
- **Link previews:** every message with a link shows the preview card (picture, title, description).
- **Private by default.** Only the owner can use commands; everybody else gets no reply at all. `.mode public` opens it up.
- **Formatted replies.** Every command reply uses WhatsApp formatting (bold titles and labels, `▸` bullets, commands in monospace).
- **Safe in production:** server protection for heavy commands, safe self-update with automatic rollback, daily login backup, write-behind key store for fast replies.
- **Watchers:** auto view-once, anti-delete and anti-edit (also for the new sealed edits), auto view / like / save for statuses.
- **Reactions** (⏳ then ✅), **watermark** under results, **sticker credit**, **AFK** that tells each person once.

## Requirements
- Node.js **20 or newer**
- A WhatsApp number for the bot
- Optional tools (only the commands that need them are affected if missing): `sharp` (pictures), `ffmpeg` (audio/video), `qrcode`

## Quick start
1. Upload the files (or the release zip) to your host and unarchive them. On a Pterodactyl panel use the **Files** tab and **Unarchive**.
2. Make sure the host runs `npm install`, then start it with `npm start`.
3. The bot asks **which number to use** (country code, digits only, no `+`). That number is the bot's WhatsApp number **and** its owner. Then it asks **how to link**: `1` pairing code or `2` QR code, and shows only the one you chose. (To skip the questions, set `NUMBER` and `PAIR_METHOD=code` or `qr` as environment variables.)
4. Link the bot (see below), add it to a group, make it admin, and send `.ping`.

### Linking the bot
Since **28 July 2026** WhatsApp links new devices differently and the WhatsApp library does not handle it. TurboFex handles it itself:
1. Start the bot with an **empty** `session/` folder and answer the two questions (number, then pairing code or QR).
2. **Pairing code:** WhatsApp > **Linked devices** > **Link a device** > *Link with phone number instead*, and type the code. **QR code:** scan the QR in the console (you need a second screen to show it). If WhatsApp refuses a pairing code, the bot shows the QR instead.
3. WhatsApp may ask for a refresh: with the QR the bot draws a **new QR**, scan that one as well.
4. The bot restarts once and prints `online as ...`.

If it fails, wait a few minutes (too many attempts are rate limited) and try again. A bot that is already linked is not affected.

## Configuration
| Setting (`config.js`) | Environment variable | Meaning |
|---|---|---|
| `number` | `NUMBER` | The bot's number, which is also its owner. Empty = the bot asks at the first start |
| `pairMethod` | `PAIR_METHOD` | `code` or `qr`. Empty = the bot asks at the first start |
| `prefix` | `PREFIX` | Command prefix (default `.`; `.setprefix` changes it while running) |
| `timezone` | `TIMEZONE` | For the menu clock and auto open/close |
| | `BOT_BROWSER` | Device identity used when linking (`android` can receive view-once files) |
| | `FAST_KEYS=off` | Turns off the write-behind key store |
| | `RESTORE_LOGIN=1` | Start once to restore the login from the last backup |
| | `YTDLP_PATH`, `YTDLP_COOKIES` | Your own yt-dlp binary, a cookies.txt for YouTube |
| | `PLAY_MAX_MB`, `PLAY_MAX_SECONDS` | Limits for `.play` (default 60 MB / 60 min) |
| | `DL_MAX_MB`, `DL_MAX_SECONDS` | Limits for `.dl` videos (default 60 MB / 30 min) |
| | `TURBOFEX_DATA` | Folder for saved data (default `data/`) |

## Economy
Market, stock trading, investment products, bonds, market property, market businesses and related commands are no longer included. Use `.economy`, `.balance`, `.daily`, `.work`, `.shop`, `.career`, `.gang`, `.territory`, `.throne` and `.president` for the remaining economy and roleplay systems.

## Using the bot
- `.menu` shows the categories (alphabetical). `.menu group` shows one category, `.menu kick` shows help for one command, `.list` shows everything with descriptions.
- Anti-link, anti-word, anti-spam, anti-fake, welcome and goodbye are OFF by default and are turned on per group. The bot must be a group admin to delete messages, remove people and change group settings.
- Auto-replies, AFK notices, protections and running games still work in private mode; they are not commands.
- **AFK:** `.afk on lunch` stays on until `.afk off`. Everybody who writes to you or mentions you is told once per AFK session.
- **Reactions:** `.cmdreact on|smart|clean|off` (`smart` = only slow commands).
- **Watermark:** `.watermark on|off|text ...`, added under the result of media, audio, video and editor commands.
- **Sticker credit:** `.stickerpack My Pack | My Name` (default: bot name by Nelson Fx).
- **Status tools:** `.autoviewstatus on`, `.autolikestatus on`, `.statusemoji`, `.statusdelay`, `.statuslimit 200`, `.statusinfo`. WhatsApp only delivers the statuses of people saved as contacts on the bot's phone.
- **Watchers:** `.autoviewonce`, `.antidelete`, `.antiedit` plus `.viewoncejid`, `.deletejid`, `.editjid` for where copies go. `.vv` opens a view-once you reply to. Anti-edit and anti-delete only know messages the bot saw before they changed. Use these only for messages that were sent to you.
- **Security:** `.ratelimit 20` (commands per person per minute), `.anticall reject|block`, `.privacy` (bot account privacy), `.antipromote on` / `.antidemote on` (undo promotions and demotions made by anyone except the group creator and the bot owner, the bot must be admin), `.antimedia sticker on` (block stickers, images, videos, audio or documents), `.slowmode 10` (seconds between messages of a member).
- **Community:** `.rules` / `.setrules`, `.report <why>` (reply to a message: tags the admins), `.rank on` then `.rank` and `.top` (XP and levels for chatting), `.giveaway 2 prize`, `.setbirthday 25 Dec` and `.birthday on` (wishes at 08:00), `.feedback <message>` (to the owner, 3 a day per person).
- **Lookup:** `.weather <city>`, `.define <word>`, `.wiki <topic>`, `.currency 100 usd ngn`, `.translate fr <text>`. They use free public services (Open-Meteo, dictionaryapi.dev, Wikipedia, exchangerate-api.com, MyMemory) which can be slow or limit use.
- **Media and tools:** `.dl <link or name>` (video, up to 720p), `.take My Pack | Me` (new credit on a sticker), `.attp <text>` (text sticker), `.setgpp` (group picture), `.note` and `.todo` (private, in a private chat).
- **Owner:** `.stats` (usage and last errors), `.broadcast <text>` then `.broadcast confirm` (all groups, slowly, 100 at most), `.linkpreview on|off|test <link>`.
- **play:** `.play <name or link>` always sends audio (YouTube, TikTok, SoundCloud, Instagram and most other sites, through yt-dlp, downloaded automatically on first use). If YouTube blocks the server, send a `cookies.txt` with `.ytcookies`. Only download content you have the right to.
- **Server protection:** heavy commands are blocked with a clear message when a tool is missing, memory is low, the server is overloaded or too many run at once. `.server` shows the state, `.server guard off` disables it.

## Operating the bot
### Updates
- `.update` checks, `.update now` installs and restarts, and the bot checks at start (`.autoupdate off` to stop). After an update you get an "update complete" message; after a restart an "I am back" message with a short menu (`.restartmsg off` to silence restarts).
- A downloaded update is **validated before any file is replaced** (every file must compile, required files must exist, `package.json` must be valid). A broken zip is rejected and nothing changes.
- If a valid update still crashes the bot at start, the previous version is put back automatically.
- `config.js`, `session/` and `data/` are never touched by updates.

### Backups and cleanup
- A copy of the login is made a few minutes after connecting and then daily (last 3 kept) in `data/session-backup/`. It is never sent over WhatsApp. `.loginbackup` lists the copies, `.loginbackup now` makes one.
- If `session/` has files but `creds.json` is damaged, the last backup is restored at start. An empty `session/` means "link a fresh device". To restore on purpose start once with `RESTORE_LOGIN=1`. After WhatsApp logs the bot out the copies are deleted.
- Once a month encryption files of chats silent for 90+ days are removed (`.sessionclean` runs it now). The login itself is never touched.
- `.backup` saves the bot's settings.

### Troubleshooting
- Lots of `Bad MAC` lines, "Waiting for this message", or the bot stops answering: send `.repair` (clears chat sessions, you stay logged in). Make sure the number is linked to only ONE running bot.
- `.status` shows version, library version, loaded commands, watcher counters and problems. `.statusinfo` shows status counters and the like route.
- View-once files arrive empty on linked devices. Reply to them with `.vv`.

## Security
- **`session/` and `data/` hold the bot's login and private data. Never commit or share them.** The included `.gitignore` excludes them.
- Owner commands (`.block`, `.update`, `.restart`, `.loginbackup`...) are limited to the owner number; destructive ones to the main owner only.
- Update notes and links come from `update.json` (the repo to update from). Point it to your own repository if you fork this project.
- The bot only fetches PUBLIC web addresses (link previews, downloads, lookups): private, local and cloud-metadata addresses are refused, also after redirects.
- The bot name is part of the code: it cannot be changed from a panel setting, and editing `core/brand.js` stops the bot from starting.

## Development
```
npm test        # unit tests (no network, no WhatsApp, no install needed)
```
- `index.js` supervises `core/boot.js`; `whatsapp/` holds the connection, handler and features; `commands/` has one file per command (or a list of related ones); `core/` holds shared services (updater, backup, capacity guard...); `tests/` has the tests, which also run on every push (GitHub Actions).
- A command is `{ name, aliases?, category, description, run(ctx) }`. Optional: `ownerOnly`, `realOwnerOnly`, `adminOnly`, `groupOnly`, `botAdminRequired`, `slow`, `weight: 'light'|'medium'|'heavy'`, `needs: [...]`, `format: false`, `noReact`, `watermark`. The tests check names, aliases (no duplicates), categories and descriptions.
- Replies are formatted automatically (see `whatsapp/format.js`); write plain text and it comes out formatted, or write your own WhatsApp formatting and it is left alone.
- **Publishing an update:** bump `version` in `package.json`, add notes at the top of `changelog.txt`, run `npm test`, then upload the new `turbofex-latest.zip` to the main page of the GitHub repo. Every bot picks it up on its next check or restart.

## Community and support
- 💬 Support group (Telegram): https://t.me/+7PwU2Vo9czE1NTRk
- 📣 Telegram channel: https://t.me/+e89lCBU2wLpjNWNk
- 🟢 WhatsApp channel: https://whatsapp.com/channel/0029VbDpuKM8qIzkoQscOE2w
- 💻 GitHub: https://github.com/nels0nfx/TurboFex


## Economy and government (v0.6.2)
- `economy on|off` per group (off = every economy command, news, drops and chat coins stop; owner: `economy off all`)
- `.career commands`: career powers and duties
- `gov` (government overview; King: collect, decree, personal grant, bounty, feast), `kingincome`, `ecotransfer` (owner), `couple`, `crime`, `beg`, `weekly`, `plant`/`garden harvest`, `rep`, `grab`, `heist`, `earn`


## Gamble odds and economy controls (v0.4.6)

- `.gambleodds 65` sets the default win probability to 65% for the current group, or globally when used in a private chat.
- `.gambleodds 60 all` sets it for every group; `.gambleodds 70 2` targets group #2 from `.gjids`.
- `.gambleodds status` shows global and group overrides. `.gambleodds reset` resets the current scope; `.gambleodds reset all` resets all scopes.
- Personal `.luck` settings take priority over group odds, which take priority over global odds, which take priority over normal odds / Lucky Charm.
- Odds are probabilities, not guaranteed wins. The command is owner-only.
- Existing economy tools remain available: bank interest, jobs and daily rewards, shop, roleplay careers, gang treasuries, territory income, King and President powers.

## Performance, economy and roleplay (v0.4.8)

Economy, roleplay, throne, lottery and quest JSON stores are saved with debounced asynchronous disk I/O during normal operation. A synchronous fallback is retained for abrupt process exit.

## Roleplay Economy (v0.4.5)
- Careers: `.career list`, `.career apply police`, `.career duty`, `.career salary` (every 20 minutes), `.career powers`. Police fines, doctors treat, guards protect, soldiers patrol and gang operatives can extort.
- Government: `.president` provides a timed group presidency with taxes, grants, stimulus, curfew and decrees. Kings can use `.gov grant @user 500` and `.gov bounty 100`.
- Luxury progression: `.luxury list`, `.luxury buy supercar`, `.luxury status` and `.luxury leaderboard` add permanent high-value collectibles from 10 million to 2 billion coins.
- Gangs and territory wars: `.gang`, `.territory map`, `.territory claim oldtown`, `.territory war oldtown`, `.territory attack oldtown`, `.territory collect`.
- Wanted system: `.crime` increases wanted level; Police Officers and Royal Guards can use `.wanted arrest @user`; Police can list suspects with `.wanted suspects` and choose sentence/bail with `.wanted arrest @user <minutes> <bail>`; arrested players can use `.wanted bail`.
- Ghosts: `.haunt @user` costs 250 coins and follows the target for 30 minutes; `.haunt status` checks your own haunting.
- Paid roleplay nickname: `.nickname Professional Beggar 🥲` costs 500 coins and lasts one hour; `.nickname status` checks it.
- Funny group announcement: `.headline @user` (aliases `.breakingnews` and `.newsflash`). These headlines are fictional roleplay jokes and do not seize real in-game assets.


## Economy and roleplay updates (v0.4.8)
- Career salaries can be collected every 20 minutes, with up to one hour of missed salary accrued.
- Career powers affect group members: police fines, doctor treatment grants and protection, Royal Guard robbery protection, soldier patrols that reduce wanted levels, and risky gang-operative extortion.
- Group presidency: pay to take a two-hour term, set a 0–5% presidential tax, fund a group-wide stimulus, issue personal grants, declare a 15-minute anti-robbery curfew, and publish decrees.
- - Luxury collectibles from 10 million to 2 billion coins provide a permanent high-end money sink and a group leaderboard.

### Economy administration and server roleplay (v0.5.1)
- `.economyadmin status` opens the owner-only panel. Configure group president salary with `.economyadmin salary 1000000 10`, standard robbery chance with `.economyadmin robchance 45`, and standard robbery cap with `.economyadmin robcap 10000`. Pay/shop/chat multipliers are bot-wide.
- Each career has one holder per career per group for a 2-hour term. Use `.career commands` or `.career commands police` to inspect powers. Police fines have a 5-minute cooldown.
- The group President receives 1,000,000 coins every 10 minutes by default, configurable by the owner. Presidential powers have no cooldown or fixed amount cap, but transfers require available funds.
- `.rob bank @user` and `.rob luxury @user` introduce higher-risk robberies with larger penalties and wanted levels.
- 

## Court, prison and police progression (v0.6.2)
- Police can list available wanted suspects with `.wanted suspects` and set each arrest sentence (1–120 minutes) and bail (0–1,000,000,000,000 coins) using `.wanted arrest @user <minutes> <bail>`.
- Detained players can file one pending appeal with `court appeal <reason>`.
- The President or Justice staff can list cases and uphold or dismiss appeals with `court cases` and `court review <id> uphold|dismiss <reason>`. Decisions are logged; dismissals release the appellant and clear wanted status.
- Prisoners can attempt `wanted escape` once every 10 minutes. Police detention has a 25% base escape chance; presidential detention has a 15% chance. Failure extends the sentence and raises wanted level; success releases the prisoner but raises wanted level.
- Successful arrests by a Police Officer count toward police-specific promotion milestones at 3, 6, 10 and 15 arrests. Rank is shown in career status and arrest reports.
- `court` is allowed while detained so appeals can be filed. The King no longer taxes ordinary group earnings; only the President's configured earnings tax applies.


### Presidential tax and rotation (v0.6.2)
- The current President is exempt from their own presidential earnings tax, including when WhatsApp supplies a device-suffixed JID.
- Once a presidential term expires, that former President must wait until another member serves a term before taking office again.
