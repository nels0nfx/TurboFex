// ============================================================
//  TURBOFEX SETTINGS  -  edit the values between the quotes
//  Numbers: country code + number, digits only, NO plus sign.
//  Example (South Africa): 27821234567
// ============================================================
module.exports = {
  // Symbol that starts every command, e.g. !ping
  prefix: process.env.PREFIX || '!',

  // YOUR personal number (the boss of the bot)
  ownerNumber: (process.env.OWNER_NUMBER || '').replace(/\D/g, ''),

  // The number the BOT will run on (the one you link to WhatsApp).
  // If you fill this in, you get an 8-letter pairing code in the console.
  // If you leave it empty, a QR code is shown instead.
  pairingNumber: (process.env.PAIRING_NUMBER || '').replace(/\D/g, ''),

  // Time zone used for the menu clock and auto open/close, e.g. 'Africa/Johannesburg'
  timezone: process.env.TIMEZONE || 'Africa/Johannesburg',

  // Folder where the WhatsApp login is saved (do not delete it)
  sessionDir: 'session',
};
