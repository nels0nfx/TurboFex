// ============================================================
//  TURBOFEX SETTINGS  -  edit the values between the quotes
//  Numbers: country code + number, digits only, NO plus sign.
//  Example (South Africa): 27821234567
// ============================================================
module.exports = {
  // Symbol that starts every command, e.g. .ping
  prefix: process.env.PREFIX || '.',

  // YOUR personal number (the boss of the bot)
  ownerNumber: (process.env.OWNER_NUMBER || '').replace(/\D/g, ''),

  // The number the BOT will run on (the one you link to WhatsApp).
  // A QR code is always shown in the console. If you fill this in, an 8-letter pairing code is shown as well
  // (WhatsApp refuses pairing codes at the moment: the bot tells you when it does, then use the QR).
  pairingNumber: (process.env.PAIRING_NUMBER || '').replace(/\D/g, ''),

  // Time zone used for the menu clock and auto open/close, e.g. 'Africa/Johannesburg'
  timezone: process.env.TIMEZONE || 'Africa/Johannesburg',

  // Folder where the WhatsApp login is saved (do not delete it)
  sessionDir: 'session',

  // Optional. How the bot shows up in WhatsApp > Linked devices when you link it. Leave it empty to keep the default.
  // 'android' lets the bot receive view-once pictures and videos (you must link the bot again after changing it).
  browser: process.env.BOT_BROWSER || '',
};
