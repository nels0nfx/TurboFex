// index.js has two jobs:
//  1) Normal start: it launches the bot as a "child" process and watches it.
//  2) If the bot asks for a restart (after an update or !restart), it starts it again.
const { spawn } = require('child_process');
const { RESTART_CODE } = require('./core/restart');

if (process.env.FLASH_CHILD === '1') {
  require('./core/boot')
    .start()
    .catch((err) => {
      console.error('Could not start:', err);
      process.exit(1);
    });
} else {
  let child = null;
  let stopping = false;
  const restarts = [];

  const run = () => {
    child = spawn(process.execPath, [__filename], {
      stdio: 'inherit',
      env: { ...process.env, FLASH_CHILD: '1' },
    });

    child.on('exit', (code) => {
      child = null;
      if (code === RESTART_CODE && !stopping) {
        const now = Date.now();
        restarts.push(now);
        while (restarts.length && now - restarts[0] > 60000) restarts.shift();
        if (restarts.length > 5) {
          console.error('Too many restarts in a row. Stopping.');
          process.exit(1);
        }
        console.log('\n🔄 Restarting the bot...\n');
        return setTimeout(run, 1000);
      }
      process.exit(stopping ? 0 : code ?? 1);
    });
  };

  for (const sig of ['SIGINT', 'SIGTERM']) {
    process.on(sig, () => {
      stopping = true;
      if (child) child.kill(sig);
      else process.exit(0);
    });
  }

  run();
}
