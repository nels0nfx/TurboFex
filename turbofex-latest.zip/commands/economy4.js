// More economy: pet, quiz, spin (daily wheel), rain, bounty, community (shared fund).
const economy = require('../core/economy');
const quests = require('../core/quests');
const throne = require('../core/throne');
const community = require('../core/community');
const { resolveTarget, num } = require('../whatsapp/utils');

const { fmt } = economy;
const base = { category: 'economy', everyone: true, needs: [], weight: 'light' };
const HOUR = 3600000;
const between = (a, b) => a + Math.floor(Math.random() * (b - a + 1));
const pick = (list) => list[Math.floor(Math.random() * list.length)];
const tag = (jid) => `@${num(jid)}`;
const left = (ms) => {
  const m = Math.max(1, Math.ceil(ms / 60000));
  if (m < 60) return `${m}m`;
  const h = Math.floor(m / 60);
  return h < 48 ? `${h}h ${m % 60}m` : `${Math.floor(h / 24)}d ${h % 24}h`;
};
const qn = (jid, myJid, event) => {
  const n = quests.note(quests.track(jid, myJid, event));
  return n ? `\n\n${n}` : '';
};
const amountOf = (word) => {
  const w = String(word || '').toLowerCase().replace(/[,_]/g, '');
  if (w === 'all') return -1;
  return /^\d{1,9}$/.test(w) ? parseInt(w, 10) : NaN;
};

// ---------------------------------------------------------------- pets
const PETS = { dog: '🐶', cat: '🐱', parrot: '🦜', rabbit: '🐰', turtle: '🐢', fox: '🦊' };
const PET = { adopt: 500, feed: 20, feedCd: 4 * HOUR, playCd: HOUR, hungryAfter: 12 * HOUR, perLevel: 8, maxLevel: 20 };
const petLevel = (p) => Math.min(PET.maxLevel, Math.floor(Math.sqrt((p.xp || 0) / 10)) + 1);
const petFedUntil = (p) => (p.fed || 0) + PET.hungryAfter;
// coins the pet found while it was fed (at most 12 hours of them)
function petWaiting(p, now = Date.now()) {
  const end = Math.min(now, petFedUntil(p));
  const hours = Math.min(12, Math.max(0, (end - (p.collected || 0)) / HOUR));
  return Math.floor(hours * PET.perLevel * petLevel(p));
}

// ---------------------------------------------------------------- quiz
const QUIZ = [
  ['What is the capital of Nigeria?', 'Abuja', ['Lagos', 'Kano', 'Ibadan']],
  ['How many days are in a leap year?', '366', ['365', '364', '367']],
  ['Which planet is closest to the sun?', 'Mercury', ['Venus', 'Mars', 'Earth']],
  ['What is 12 × 12?', '144', ['124', '122', '154']],
  ['Which is the largest ocean?', 'Pacific', ['Atlantic', 'Indian', 'Arctic']],
  ['Which gas do plants take in from the air?', 'Carbon dioxide', ['Oxygen', 'Nitrogen', 'Helium']],
  ['How many continents are there?', '7', ['5', '6', '8']],
  ['What is the capital of Ghana?', 'Accra', ['Kumasi', 'Tamale', 'Takoradi']],
  ['Which is the largest animal on land?', 'African elephant', ['Giraffe', 'Hippo', 'Rhino']],
  ['How many minutes are in 3 hours?', '180', ['120', '160', '200']],
  ['What is the chemical formula of water?', 'H2O', ['CO2', 'O2', 'NaCl']],
  ['Which is the longest river in Africa?', 'Nile', ['Niger', 'Congo', 'Zambezi']],
  ['What is the capital of Kenya?', 'Nairobi', ['Mombasa', 'Kisumu', 'Nakuru']],
  ['How many sides does a hexagon have?', '6', ['5', '7', '8']],
  ['What do bees make?', 'Honey', ['Milk', 'Silk', 'Sugar']],
  ['Which planet is called the Red Planet?', 'Mars', ['Venus', 'Jupiter', 'Saturn']],
  ['What is 15% of 200?', '30', ['15', '25', '35']],
  ['What is the capital of Egypt?', 'Cairo', ['Alexandria', 'Luxor', 'Giza']],
  ['How many players of one team are on the pitch in football?', '11', ['9', '10', '12']],
  ['Which metal is liquid at room temperature?', 'Mercury', ['Iron', 'Copper', 'Tin']],
  ['In which year did Nigeria become independent?', '1960', ['1957', '1963', '1970']],
  ['Which is the largest country in Africa by area?', 'Algeria', ['Nigeria', 'Egypt', 'South Africa']],
  ['How many legs does a spider have?', '8', ['6', '10', '12']],
  ['Which organ pumps blood around the body?', 'Heart', ['Liver', 'Lungs', 'Kidney']],
  ['What is the square root of 81?', '9', ['8', '7', '11']],
  ['What is the smallest prime number?', '2', ['1', '3', '5']],
  ['What is the capital of Senegal?', 'Dakar', ['Thies', 'Saint-Louis', 'Touba']],
  ['How many strings does a standard guitar have?', '6', ['4', '5', '8']],
  ['At what temperature does water freeze, in °C?', '0', ['10', '-10', '32']],
  ['Who wrote the novel "Things Fall Apart"?', 'Chinua Achebe', ['Wole Soyinka', 'Chimamanda Adichie', 'Ben Okri']],
  ['Which is the tallest animal?', 'Giraffe', ['Elephant', 'Camel', 'Ostrich']],
  ['How many hours are in a week?', '168', ['144', '156', '172']],
  ['Which planet is famous for its rings?', 'Saturn', ['Mars', 'Mercury', 'Venus']],
  ['What is the capital of Ethiopia?', 'Addis Ababa', ['Gondar', 'Dire Dawa', 'Hawassa']],
  ['What is 7 × 8?', '56', ['54', '58', '64']],
  ['Which vitamin do we get from sunlight?', 'Vitamin D', ['Vitamin A', 'Vitamin C', 'Vitamin K']],
  ['How many bones does an adult human have?', '206', ['186', '216', '256']],
  ['Which is the largest mammal?', 'Blue whale', ['Elephant', 'Great white shark', 'Giraffe']],
  ['What is the currency of Ghana?', 'Cedi', ['Naira', 'Rand', 'Shilling']],
];
const QUIZ_RULES = { lifeMs: 60000, gapMs: 90000, min: 120, max: 260 };
const quizRooms = new Map(); // group -> { q, opts, correct, at, locked:Set, last }
const LETTERS = ['A', 'B', 'C', 'D'];

module.exports = [
  // ---------------------------------------------------------------- pet
  {
    ...base,
    name: 'pet',
    aliases: ['pets', 'adopt'],
    description: 'A pet that finds you coins while it is fed: pet / pet adopt dog Rex / pet feed / pet play / pet collect',
    async run({ args, reply, myJid, jid, prefix, cmdName }) {
      const sub = cmdName === 'adopt' ? 'adopt' : (args[0] || '').toLowerCase();
      const u = economy.peek(myJid);
      const now = Date.now();
      const p = u.pet;
      const show = () => {
        const lvl = petLevel(p);
        const hungry = petFedUntil(p) < now;
        const next = lvl >= PET.maxLevel ? null : Math.pow(lvl, 2) * 10 - (p.xp || 0);
        return `${PETS[p.type]} *${p.name}* – level ${lvl}${lvl >= PET.maxLevel ? ' (max)' : ''}\n*Mood:* ${hungry ? '😿 hungry – it finds nothing until you feed it' : `😺 happy for ${left(petFedUntil(p) - now)}`}\n*Finds:* ${PET.perLevel * lvl} coins an hour while fed • *waiting:* ${fmt(petWaiting(p, now))}${next ? `\n*Next level:* ${next} more xp` : ''}\n\n▸ \`${prefix}pet feed\` (${PET.feed} coins) • \`${prefix}pet play\` • \`${prefix}pet collect\``;
      };
      if (sub === 'adopt') {
        if (p) return reply(`🐾 *You already have ${p.name}.* ${PETS[p.type]}`);
        const type = (args[1] || '').toLowerCase();
        if (!PETS[type]) return reply(`🐾 *Adopt a pet* (${PET.adopt} coins)\n${Object.entries(PETS).map(([k, e]) => `${e} ${k}`).join(' • ')}\n\n*Usage:* \`${prefix}pet adopt dog Rex\``);
        if (economy.inDebt(myJid)) return reply(`🔒 *You have a loan.* Repay it first (\`${prefix}repay\`).`);
        if (!economy.take(myJid, PET.adopt)) return reply(`⚠️ *A pet costs ${PET.adopt} coins.* You have ${fmt(economy.balance(myJid))}.`);
        const name = args.slice(2).join(' ').replace(/[^\p{L}\p{N} _-]/gu, '').slice(0, 16) || pick(['Buddy', 'Lucky', 'Coco', 'Max', 'Bella', 'Shadow']);
        u.pet = { type, name, xp: 0, fed: now, collected: now, feedAt: 0, playAt: 0 };
        economy.touch();
        return reply(`🎉 *You adopted ${name}!* ${PETS[type]}\nFeed it every day and it finds coins for you.\n\n▸ \`${prefix}pet\` – see it • \`${prefix}pet feed\` • \`${prefix}pet play\``);
      }
      if (!p) return reply(`🐾 *You have no pet.*\nAdopt one for ${PET.adopt} coins: \`${prefix}pet adopt dog Rex\`\n_Types: ${Object.keys(PETS).join(', ')}. A fed pet finds coins every hour._`);
      if (sub === 'feed') {
        const wait = (p.feedAt || 0) + PET.feedCd - now;
        if (wait > 0) return reply(`🍖 *${p.name} is full.* Feed again in *${left(wait)}*.`);
        if (!economy.take(myJid, PET.feed)) return reply(`⚠️ *Food costs ${PET.feed} coins.*`);
        // what it found until now is kept: it is added to the waiting coins first
        p.stash = (p.stash || 0) + petWaiting(p, now);
        p.collected = now;
        p.fed = now;
        p.feedAt = now;
        p.xp = (p.xp || 0) + 5;
        economy.touch();
        return reply(`🍖 *${p.name} ate and is happy for ${left(PET.hungryAfter)}!* ${PETS[p.type]}\n+5 xp • level ${petLevel(p)}${qn(jid, myJid, 'pet')}`);
      }
      if (sub === 'play') {
        const wait = (p.playAt || 0) + PET.playCd - now;
        if (wait > 0) return reply(`🎾 *${p.name} is tired.* Play again in *${left(wait)}*.`);
        p.playAt = now;
        p.xp = (p.xp || 0) + 3;
        let found = 0;
        if (petFedUntil(p) > now) {
          found = between(10, 30) * petLevel(p);
          economy.add(myJid, found);
        }
        economy.touch();
        return reply(`🎾 *You played with ${p.name}!* ${PETS[p.type]}\n+3 xp • level ${petLevel(p)}${found ? `\n*It found:* +${fmt(found)} coins` : '\n_It is hungry, so it found nothing. Feed it!_'}${qn(jid, myJid, 'pet')}`);
      }
      if (sub === 'collect') {
        const n = (p.stash || 0) + petWaiting(p, now);
        if (n < 1) return reply(petFedUntil(p) < now ? `😿 *${p.name} is hungry* and found nothing. \`${prefix}pet feed\`` : `⏳ *${p.name} has found nothing yet.* Check in an hour.`);
        p.stash = 0;
        p.collected = now;
        economy.add(myJid, n);
        economy.touch();
        return reply(`${PETS[p.type]} *${p.name} brought you ${fmt(n)} coins!*\n*Wallet:* ${fmt(economy.balance(myJid))}`);
      }
      if (sub === 'rename') {
        const name = args.slice(1).join(' ').replace(/[^\p{L}\p{N} _-]/gu, '').slice(0, 16);
        if (!name) return reply(`*Usage:* \`${prefix}pet rename Rex\``);
        p.name = name;
        economy.touch();
        return reply(`✅ *Your pet is now called ${name}.*`);
      }
      return reply(`🐾 *Your pet*\n${show()}`);
    },
  },

  // ---------------------------------------------------------------- quiz
  {
    ...base,
    name: 'brain',
    aliases: ['coinquiz', 'bq'],
    groupOnly: true,
    description: 'A quick question: the first right answer wins coins. brain to ask, brain a / b / c / d to answer',
    async run({ args, reply, jid, myJid, prefix }) {
      const now = Date.now();
      const room = quizRooms.get(jid) || { last: 0 };
      quizRooms.set(jid, room);
      const live = room.q && now - room.at < QUIZ_RULES.lifeMs;
      const word = (args[0] || '').toLowerCase();
      const letter = /^[abcd]$/.test(word) ? word.toUpperCase() : null;
      if (room.q && !live) {
        const text = `⌛ *Time is up!* The answer was *${room.correct}*.`;
        room.q = null;
        if (!letter) await reply(text);
        else return reply(`${text}\n_Start another with_ \`${prefix}brain\``);
      }
      if (letter) {
        if (!room.q) return reply(`🧠 *There is no question now.* Ask one with \`${prefix}brain\``);
        if (room.locked.has(economy.keyOf(myJid))) return reply('🚫 *You already answered this one.* Wait for the next question.');
        const chosen = room.opts[LETTERS.indexOf(letter)];
        if (chosen !== room.correct) {
          room.locked.add(economy.keyOf(myJid));
          return reply(`❌ *${tag(myJid)}: not ${letter}!* Others can still answer.`, { mentions: [myJid] });
        }
        const prize = Math.round(room.prize * economy.payMult());
        economy.add(myJid, prize);
        room.q = null;
        return reply(`✅ *${tag(myJid)} got it!* The answer was *${room.correct}*.\n*Won:* +${fmt(prize)} coins${qn(jid, myJid, 'quiz')}`, { mentions: [myJid] });
      }
      if (live) return reply(`🧠 *Question still open* (${left(QUIZ_RULES.lifeMs - (now - room.at))} left)\n\n${room.q}\n${room.opts.map((o, i) => `${LETTERS[i]}) ${o}`).join('\n')}\n\n_Answer with_ \`${prefix}brain a\``);
      const wait = room.last + QUIZ_RULES.gapMs - now;
      if (wait > 0) return reply(`⏳ *Let the others rest.* Next question in *${left(wait)}*.`);
      const [q, correct, wrong] = pick(QUIZ);
      const opts = [correct, ...wrong].sort(() => Math.random() - 0.5);
      Object.assign(room, { q, correct, opts, at: now, last: now, locked: new Set(), prize: between(QUIZ_RULES.min, QUIZ_RULES.max) });
      await reply(`🧠 *QUIZ TIME!* (first right answer wins *${fmt(room.prize)} coins*)\n\n${q}\n${opts.map((o, i) => `${LETTERS[i]}) ${o}`).join('\n')}\n\n_Answer with_ \`${prefix}brain a\` _(you have ${left(QUIZ_RULES.lifeMs)}, one try each)_`);
    },
  },

  // ---------------------------------------------------------------- spin
  {
    ...base,
    name: 'spin',
    aliases: ['wheel', 'dailyspin'],
    description: 'Spin the free wheel once a day for coins (no bet needed)',
    async run({ reply, myJid, jid }) {
      const cd = economy.cooldown(myJid, 'spin', 24 * HOUR);
      if (!cd.ok) return reply(`🎡 *You already spun today.* Come back in *${left(cd.waitMs)}*.`);
      const table = [[40, 100, 300], [30, 300, 600], [15, 600, 1000], [10, 1000, 1500], [4, 2000, 2000], [1, 5000, 5000]];
      let r = Math.random() * 100;
      let range = table[0];
      for (const t of table) {
        if (r < t[0]) {
          range = t;
          break;
        }
        r -= t[0];
      }
      const p = economy.payout(myJid, between(range[1], range[2]), { tax: false, tools: false });
      const big = p.gross >= 2000;
      await reply(`🎡 *The wheel spins...*\n${big ? '🎉 *JACKPOT!* ' : ''}*You won:* +${fmt(p.net)} coins\n*Wallet:* ${fmt(economy.balance(myJid))}${qn(jid, myJid, 'spin')}`);
    },
  },

  // ---------------------------------------------------------------- rain
  {
    ...base,
    name: 'rain',
    aliases: ['makeitrain', 'shower'],
    groupOnly: true,
    description: 'Share coins with the people who chatted in the last hour: rain 500',
    async run({ args, reply, myJid, jid, prefix }) {
      const n = amountOf(args[0]);
      if (!args.length || Number.isNaN(n)) return reply(`🌧️ *Make it rain*\nYou give coins and everybody who chatted in the last hour (up to 10 people) shares them.\n*Usage:* \`${prefix}rain 500\` _(at least 100, 3+ people)_`);
      const amount = n === -1 ? Math.min(economy.balance(myJid), 100000) : n;
      if (amount < 100) return reply('⚠️ *The least is 100 coins.*');
      if (economy.inDebt(myJid)) return reply(`🔒 *You have a loan.* Repay it first (\`${prefix}repay\`).`);
      const guests = throne.recentChatters(jid, myJid, 10);
      if (guests.length < 3) return reply(`🤫 *Too quiet.* ${guests.length} people chatted in the last hour, rain needs 3.`);
      if (economy.balance(myJid) < amount) return reply(`⚠️ *You only have ${fmt(economy.balance(myJid))} coins.*`);
      const cd = economy.cooldown(myJid, 'rain', 60000);
      if (!cd.ok) return reply(`⏳ *Wait ${left(cd.waitMs)} before the next rain.*`);
      const each = Math.floor(amount / guests.length);
      economy.take(myJid, each * guests.length);
      for (const g of guests) economy.add(g, each);
      await reply(`🌧️ *${tag(myJid)} made it rain!*\n*${guests.length} people* got *+${fmt(each)} coins* each:\n${guests.map(tag).join(' ')}${qn(jid, myJid, 'rain')}`, { mentions: [myJid, ...guests] });
    },
  },

  // ---------------------------------------------------------------- bounty
  {
    ...base,
    name: 'bounty',
    aliases: ['bounties', 'wanted'],
    groupOnly: true,
    description: 'Put coins on somebody\'s head, whoever robs him takes them: bounty @user 500 / bounty list',
    async run({ msg, args, reply, myJid, jid, prefix }) {
      const target = resolveTarget(msg, args);
      const sub = (args[0] || '').toLowerCase();
      if (!target || sub === 'list') {
        const board = economy.bountyBoard(10);
        if (!board.length) return reply(`🎯 *No bounties now.*\nPut coins on somebody's head: \`${prefix}bounty @user 500\` _(${economy.BOUNTY.min}–${fmt(economy.BOUNTY.max)})_\nWhoever *robs* him successfully takes it.`);
        return reply(`🎯 *Wanted*\n${board.map((b, i) => `${i + 1}. ${tag(b.jid)} – *${fmt(b.bounty)}* coins`).join('\n')}\n\n▸ \`${prefix}rob @user\` to collect • \`${prefix}bounty @user 500\` to add`, { mentions: board.map((b) => b.jid) });
      }
      const amount = amountOf([...args].reverse().find((a) => /^\d{1,9}$/.test(a)));
      if (!(amount > 0)) return reply(`*Usage:* \`${prefix}bounty @user 500\``);
      const r = economy.placeBounty(myJid, target, amount);
      if (!r.ok) {
        const m = { self: '😅 *You cannot put a bounty on yourself.*', king: '👑 *Nobody can put a bounty on the king.*', debt: `🔒 *You have a loan.* Repay it first.`, min: `⚠️ *The least is ${fmt(r.min || 0)} coins.*`, max: `⚠️ *A person can carry at most ${fmt(r.max || 0)} coins of bounty.*`, poor: `⚠️ *You only have ${fmt(r.wallet || 0)} coins.*` }[r.why];
        return reply(m || '⚠️ *That did not work.*');
      }
      await reply(`🎯 *BOUNTY!*\n${tag(myJid)} put *${fmt(amount)} coins* on ${tag(target)}'s head.\n*Total bounty:* ${fmt(r.total)} coins\n_Whoever robs ${tag(target)} successfully takes it:_ \`${prefix}rob\``, { mentions: [myJid, target] });
    },
  },

  // ---------------------------------------------------------------- community fund
  {
    ...base,
    name: 'community',
    aliases: ['fund', 'pot', 'donate'],
    groupOnly: true,
    description: 'A shared fund: everybody gives, at the goal all donors get 125% back and the group earns +15% for an hour',
    async run({ args, reply, myJid, jid, prefix, cmdName }) {
      const i = community.info(jid);
      const word = cmdName === 'donate' ? args[0] : args[0] === 'give' || args[0] === 'donate' ? args[1] : args[0];
      const bar = (a, b) => `${'█'.repeat(Math.min(10, Math.round((a / b) * 10)))}${'░'.repeat(10 - Math.min(10, Math.round((a / b) * 10)))}`;
      if (!word) {
        return reply(`🤝 *Community fund*\n${bar(i.total, i.goal)} ${fmt(i.total)} / ${fmt(i.goal)} coins\n*Donors now:* ${i.donors.length} (at least ${community.RULES.minDonors} needed)\n${i.boostLeft ? `🎉 *Community boom is on:* +${Math.round((community.RULES.boost - 1) * 100)}% pay for ${left(i.boostLeft)}\n` : ''}*Times reached:* ${i.done}\n\nWhen the goal is reached *every donor gets ${Math.round(community.RULES.payback * 100)}% back* and the whole group earns *+${Math.round((community.RULES.boost - 1) * 100)}%* for ${left(community.RULES.boostMs)}.\n▸ \`${prefix}community give 200\` (at least ${community.RULES.min})`);
      }
      let n = amountOf(word);
      if (n === -1) n = economy.balance(myJid);
      if (!(n > 0)) return reply(`*Usage:* \`${prefix}community give 200\``);
      const r = community.donate(jid, myJid, n);
      if (!r.ok) {
        const m = { min: `⚠️ *The least is ${r.min} coins.*`, debt: '🔒 *You have a loan.* Repay it first.', poor: `⚠️ *You only have ${fmt(r.wallet || 0)} coins.*` }[r.why];
        return reply(m || '⚠️ *That did not work.*');
      }
      if (r.reached) {
        return reply(`🎉 *THE COMMUNITY FUND REACHED ${fmt(r.goal)} COINS!*\n${r.payouts.map((p) => `${tag(p.jid)} gave ${fmt(p.coins)} → got *${fmt(p.back)}*`).join('\n')}\n\n🚀 *Community boom:* everybody earns *+${Math.round((community.RULES.boost - 1) * 100)}%* for the next ${left(community.RULES.boostMs)}!\n_The next goal is ${fmt(community.info(jid).goal)}._${r.quest}`, { mentions: r.payouts.map((p) => p.jid) });
      }
      await reply(`🤝 *${tag(myJid)} gave ${fmt(r.put)} coins${r.capped ? ' (the pot is nearly full)' : ''}!*\n${bar(r.total, r.goal)} ${fmt(r.total)} / ${fmt(r.goal)}\n${r.donors} donor${r.donors === 1 ? '' : 's'}${r.total >= r.goal ? ` – the goal needs ${community.RULES.minDonors}+ donors, ask a friend!` : ''}${r.quest}`, { mentions: [myJid] });
    },
  },
];
