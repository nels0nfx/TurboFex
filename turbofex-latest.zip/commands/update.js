const { getLatest, applyUpdate, reasonText } = require('../core/updater');
const { restartBot } = require('../core/restart');
const brand = require('../core/brand');

module.exports = {
  name: 'update',
  description: 'Check for a new version, or install it with: update now (owner only)',
  ownerOnly: true,
  async run({ args, reply, prefix }) {
    const install = (args[0] || '').toLowerCase() === 'now';

    let info;
    try {
      info = await getLatest();
    } catch (err) {
      return reply(`⚠️ Could not reach GitHub: ${err.message}`);
    }
    if (!info.ok) return reply(`⚠️ ${reasonText(info.reason)}`);

    if (!info.available) {
      return reply(`✅ You're up to date. ${brand.botName} v${info.current} is the newest version.`);
    }

    if (!install) {
      const notes = info.notes ? `\n\n📝 What's new:\n${info.notes.slice(0, 600)}` : '';
      return reply(
        `🆕 Update available: v${info.current} → v${info.latest}${notes}\n\nTo install it, send: ${prefix}update now`
      );
    }

    await reply(`⬇️ Installing v${info.latest}... please wait.`);
    try {
      const result = await applyUpdate(info);
      await reply(`✅ Updated to v${result.version} (${result.files} files). Restarting now, back in a few seconds...`);
      restartBot();
    } catch (err) {
      await reply(`❌ Update failed: ${err.message}`);
    }
  },
};
