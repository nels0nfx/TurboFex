const { toggleSetting } = require('../whatsapp/actions');

module.exports = {
  name: 'antispam',
  category: 'group',
  description: 'Warn members who flood the chat: on / off (admins only)',
  groupOnly: true,
  adminOnly: true,
  async run(ctx) {
    await toggleSetting(ctx, 'antispam', 'Anti-spam');
    if ((ctx.args[0] || '').toLowerCase() === 'on' && !ctx.isBotAdmin) {
      await ctx.reply('⚠️ Note: I must be a group admin to warn and remove people.');
    }
  },
};
