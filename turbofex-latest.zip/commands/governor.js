// The Governor office (see core/governor.js): governor / governor run / governor vote @user / governor sale ...
const govcmd = require('../core/govcmd');

module.exports = [
  {
    name: 'governor',
    aliases: ['mayor', 'election'],
    category: 'economy',
    everyone: true,
    needs: [],
    weight: 'light',
    groupOnly: true,
    description: 'The elected Governor: governor / run / vote @user / salary / sale / feecut / veto / audit @user',
    async run(ctx) {
      return govcmd.handle(ctx, (ctx.args[0] || '').toLowerCase());
    },
  },
];
