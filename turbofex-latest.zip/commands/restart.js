const { restartBot } = require('../core/restart');
const brand = require('../core/brand');

module.exports = {
  name: 'restart',
  description: 'Restart the bot (owner only)',
  ownerOnly: true,
  async run({ reply }) {
    await reply(`🔄 Restarting ${brand.botName}... back in a few seconds.`);
    restartBot();
  },
};
