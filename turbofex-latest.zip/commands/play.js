// play: always sends AUDIO. A song name or a link from almost any site (YouTube, TikTok, SoundCloud, Instagram,
// Facebook... anything the downloader supports) or a direct link to an audio file.
const { downloadAudio, MAX_MB } = require('../core/ytdlp');
const audius = require('../core/audius');
const { readLimited } = require('../core/download');

const MAX_BYTES = MAX_MB * 1024 * 1024;
const DIRECT_AUDIO = /\.(mp3|m4a|ogg|opus|wav|aac|flac)(\?|#|$)/i;

async function sendAudio(sock, jid, msg, a) {
  const lines = [`🎵 *${a.title || 'Audio'}*`, a.artist && `👤 ${a.artist}`, a.duration && `⏱️ ${a.duration}`, a.url && `🔗 ${a.url}`].filter(Boolean);
  await sock.sendMessage(jid, { text: lines.join('\n') }, { quoted: msg });
  return sock.sendMessage(jid, { audio: a.buffer, mimetype: a.mimetype });
}

module.exports = {
  name: 'play',
  category: 'media',
  slow: true,
  weight: 'medium',
  needs: [],
  aliases: ['song', 'audio'],
  description: 'play <song name or link>: sends the audio (YouTube, TikTok, SoundCloud, Instagram and most other sites)',
  async run({ sock, jid, msg, rest, reply, prefix, isOwner }) {
    if (!rest) return reply(`Type a song name or a link.\n${prefix}play calm down\n${prefix}play https://youtu.be/...`);
    const nice = (err, fallback) => `⚠️ ${fallback}${isOwner ? `\nReason: ${String(err.message).slice(0, 140)}` : ''}`;

    // a direct link to an audio file
    if (/^https?:\/\/\S+$/i.test(rest) && DIRECT_AUDIO.test(rest)) {
      try {
        const res = await fetch(rest, { redirect: 'follow', signal: AbortSignal.timeout(60000), headers: { 'User-Agent': 'TurboFex' } });
        if (res.ok) {
          const type = (res.headers.get('content-type') || '').split(';')[0].trim().toLowerCase();
          if (Number(res.headers.get('content-length')) <= MAX_BYTES) {
            const buffer = await readLimited(res, MAX_BYTES);
            return sock.sendMessage(jid, { audio: buffer, mimetype: type.startsWith('audio/') ? type : 'audio/mpeg' }, { quoted: msg });
          }
        }
      } catch (err) {
        // the downloader below tries as well
      }
    }

    await reply('⏳ Getting your audio, one moment...');
    let problem;
    try {
      const a = await downloadAudio(rest, { onSetup: () => reply('⏳ Setting up the downloader (first time only, about a minute)...') });
      return await sendAudio(sock, jid, msg, a);
    } catch (err) {
      problem = err;
      console.error('Play failed:', err.message);
      if (err.code === 'TOO_LONG' || err.code === 'TOO_BIG') return reply(`⚠️ ${err.message}`);
    }

    // the downloader failed: for a song name, try free music from Audius
    if (!/^https?:\/\//i.test(rest)) {
      try {
        const [track] = await audius.search(rest, 3);
        if (track) {
          const buffer = await audius.download(track);
          return await sendAudio(sock, jid, msg, { buffer, mimetype: 'audio/mpeg', title: track.title, artist: track.artist, duration: track.duration, url: track.url });
        }
      } catch (err) {
        // fall through to the message below
      }
    }
    return reply(nice(problem, 'I could not get that audio. Check the name or link and try again.'));
  },
};
