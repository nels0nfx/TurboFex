const { search } = require('../core/ytsearch');

const MAX_BYTES = 25 * 1024 * 1024;
const STREAMING = /(^|\.)(youtube\.com|youtu\.be|spotify\.com|soundcloud\.com|tiktok\.com|instagram\.com|facebook\.com|fb\.watch|music\.apple\.com|deezer\.com)$/i;

// reads a download but stops when it gets too big
async function readLimited(res, max) {
  const chunks = [];
  let size = 0;
  const reader = res.body.getReader();
  for (;;) {
    const { done, value } = await reader.read();
    if (done) break;
    size += value.length;
    if (size > max) {
      await reader.cancel();
      throw Object.assign(new Error('That file is bigger than 25 MB.'), { code: 'TOO_BIG' });
    }
    chunks.push(Buffer.from(value));
  }
  return Buffer.concat(chunks);
}

module.exports = {
  name: 'play',
  category: 'media',
  slow: true,
  aliases: ['song'],
  description: 'play <song name> finds it on YouTube and gives you the link; play <link to an audio/video file> sends that file',
  async run({ sock, jid, msg, rest, reply, prefix }) {
    if (!rest) return reply(`Type a song name or a link to an audio file.\n${prefix}play calm down rema\n${prefix}play https://example.com/song.mp3`);

    // a link
    if (/^https?:\/\/\S+$/i.test(rest)) {
      let host = '';
      try {
        host = new URL(rest).hostname;
      } catch (err) {
        return reply('⚠️ That link does not look right.');
      }
      if (STREAMING.test(host)) {
        return reply(`🚫 I cannot download from ${host.replace(/^www\./, '')}: that would break the site's rules.\nSend me a direct link to an audio or video FILE (for example ending in .mp3, .m4a or .mp4) and I will send it to you.`);
      }
      try {
        const res = await fetch(rest, { redirect: 'follow', signal: AbortSignal.timeout(60000), headers: { 'User-Agent': 'TurboFex' } });
        if (!res.ok) return reply(`⚠️ That link answered with error ${res.status}.`);
        const type = (res.headers.get('content-type') || '').split(';')[0].trim().toLowerCase();
        const isAudio = type.startsWith('audio/') || /\.(mp3|m4a|ogg|opus|wav|aac|flac)(\?|$)/i.test(rest);
        const isVideo = type.startsWith('video/') || /\.(mp4|mov|webm|mkv)(\?|$)/i.test(rest);
        if (!isAudio && !isVideo) return reply('⚠️ That link is not an audio or video file.');
        if (Number(res.headers.get('content-length')) > MAX_BYTES) return reply('⚠️ That file is bigger than 25 MB.');
        const buffer = await readLimited(res, MAX_BYTES);
        if (isAudio) return sock.sendMessage(jid, { audio: buffer, mimetype: type.startsWith('audio/') ? type : 'audio/mpeg' }, { quoted: msg });
        return sock.sendMessage(jid, { video: buffer, mimetype: type.startsWith('video/') ? type : 'video/mp4', caption: '🎬' }, { quoted: msg });
      } catch (err) {
        return reply(`⚠️ I could not get that file.\nReason: ${String(err.message).slice(0, 100)}`);
      }
    }

    // a song name: show the best matches
    try {
      const results = await search(rest, 3);
      if (!results.length) return reply(`😕 I found nothing for "${rest}".`);
      const lines = results.map((r, i) => `${i + 1}. *${r.title}*\n   ${r.channel}${r.channel ? ' • ' : ''}${r.duration}${r.views ? ` • ${r.views}` : ''}\n   ${r.url}`);
      await reply(`🎵 *Results for "${rest}"*\n\n${lines.join('\n\n')}\n\nOpen a link to listen. I cannot download from YouTube, but if you have a direct link to the audio file, send: ${prefix}play <link>`);
    } catch (err) {
      await reply(`⚠️ I could not search right now.\nReason: ${String(err.message).slice(0, 100)}`);
    }
  },
};
