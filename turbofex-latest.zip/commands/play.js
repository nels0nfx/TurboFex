// play: always sends AUDIO. A song name or a link from almost any site (YouTube, TikTok, SoundCloud, Instagram,
// Facebook... anything the downloader supports) or a direct link to an audio file.
const { downloadAudio, titleOf, MAX_MB } = require('../core/ytdlp');
const audius = require('../core/audius');
const { readLimited } = require('../core/download');

const MAX_BYTES = MAX_MB * 1024 * 1024;
const DIRECT_AUDIO = /\.(mp3|m4a|ogg|opus|wav|aac|flac)(\?|#|$)/i;

async function sendAudio(sock, jid, msg, a) {
  const lines = [`🎵 *${a.title || 'Audio'}*`, a.artist && `👤 ${a.artist}`, a.duration && `⏱️ ${a.duration}`, a.url && `🔗 ${a.url}`].filter(Boolean);
  await sock.sendMessage(jid, { text: lines.join('\n') }, { quoted: msg });
  return sock.sendMessage(jid, { audio: a.buffer, mimetype: a.mimetype });
}

module.exports = {
  name: 'play',
  category: 'media',
  slow: true,
  weight: 'medium',
  needs: [],
  aliases: ['song', 'audio'],
  description: 'play <song name or link>: sends the audio (YouTube, TikTok, SoundCloud, Instagram and most other sites)',
  async run({ sock, jid, msg, rest, reply, prefix, isOwner }) {
    if (!rest) return reply(`Type a song name or a link.\n${prefix}play calm down\n${prefix}play https://youtu.be/...`);
    const nice = (err, fallback) => `⚠️ ${fallback}${isOwner ? `\nReason: ${String(err.message).slice(0, 140)}` : ''}`;

    // a direct link to an audio file
    if (/^https?:\/\/\S+$/i.test(rest) && DIRECT_AUDIO.test(rest)) {
      try {
        const res = await fetch(rest, { redirect: 'follow', signal: AbortSignal.timeout(60000), headers: { 'User-Agent': 'TurboFex' } });
        if (res.ok) {
          const type = (res.headers.get('content-type') || '').split(';')[0].trim().toLowerCase();
          if (Number(res.headers.get('content-length')) <= MAX_BYTES) {
            const buffer = await readLimited(res, MAX_BYTES);
            return sock.sendMessage(jid, { audio: buffer, mimetype: type.startsWith('audio/') ? type : 'audio/mpeg' }, { quoted: msg });
          }
        }
      } catch (err) {
        // the downloader below tries as well
      }
    }

    await reply('⏳ Getting your audio, one moment...');
    const setup = { onSetup: () => reply('⏳ Setting up the downloader (first time only, about a minute)...') };
    const isLink = /^https?:\/\//i.test(rest);
    let problem;
    let query = isLink ? '' : rest;

    // 1) the song or link itself
    try {
      return await sendAudio(sock, jid, msg, await downloadAudio(rest, setup));
    } catch (err) {
      problem = err;
      console.error('Play failed:', err.message);
      if (err.code === 'TOO_LONG' || err.code === 'TOO_BIG') return reply(`⚠️ ${err.message}`);
    }

    // 2) a link that did not work: find out what it is, then look for the same song on other sites
    if (isLink && /youtu\.?be/i.test(rest)) query = await titleOf(rest);

    if (query) {
      try {
        return await sendAudio(sock, jid, msg, await downloadAudio(query, { source: 'soundcloud' }));
      } catch (err) {
        console.error('Play (SoundCloud) failed:', err.message);
      }
      try {
        const [track] = await audius.search(query, 3);
        if (track) {
          const buffer = await audius.download(track);
          return await sendAudio(sock, jid, msg, { buffer, mimetype: 'audio/mpeg', title: track.title, artist: track.artist, duration: track.duration, url: track.url });
        }
      } catch (err) {
        console.error('Play (Audius) failed:', err.message);
      }
    }
    if (problem?.code === 'BOT_BLOCK') {
      return reply(isOwner ? `⚠️ YouTube blocked this server and the song was not found elsewhere.\n🍪 Fix: send a cookies.txt with *${prefix}ytcookies* (see ${prefix}ytcookies).` : '⚠️ I could not get that audio right now. Please try another song or try again later.');
    }
    return reply(nice(problem, 'I could not get that audio. Check the name or link and try again.'));
  },
};
