const games = require('../whatsapp/play');

module.exports = {
  name: 'scramble',
  category: 'games',
  description: 'Unscramble the word: first to type it wins',
  async run({ jid, reply, prefix, myIds }) {
    if (games.get(jid)) return reply(games.busyText(prefix));
    const game = games.begin(jid, games.scramble.create(), myIds);
    await reply(games.scramble.intro(game));
  },
};
