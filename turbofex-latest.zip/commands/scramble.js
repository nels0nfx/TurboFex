const games = require('../whatsapp/play');

module.exports = {
  name: 'scramble',
  category: 'games',
  description: 'Unscramble the word, first to type it wins: scramble or scramble 5 (rounds)',
  async run({ sock, jid, args, reply, prefix, myIds }) {
    if (games.get(jid)) return reply(games.busyText(prefix));
    const rounds = games.parseRounds(args, 5);
    const game = games.start({ sock, jid, game: games.scramble.create(), starterIds: myIds, rounds });
    await reply(games.scramble.intro(game) + games.seriesNote(game, prefix));
  },
};
