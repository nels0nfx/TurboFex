const pkg = require('../package.json');
const clock = require('../core/clock');
const store = require('../whatsapp/store');

module.exports = {
  name: 'status',
  category: 'owner',
  description: 'Health check: version, commands loaded, problems found (owner only)',
  ownerOnly: true,
  async run({ reply, commandList, diag, prefix }) {
    const s = diag.stats;
    const problems = diag.loadErrors.length ? diag.loadErrors.map((e) => `• ${e}`).join('\n') : 'None';
    await reply(
      `🩺 *Status*\n\n` +
        `📦 Version: v${pkg.version}\n` +
        `🟢 Node: ${process.versions.node}\n` +
        `⏱️ Uptime: ${clock.uptime()}\n` +
        `🧩 Commands loaded: ${commandList.length}\n` +
        `🔣 Prefix: ${prefix}\n` +
        `🔐 Mode: ${store.getMode()}\n` +
        `🔄 Auto-update: ${store.getAutoUpdate() ? 'on' : 'off'}\n` +
        `⏰ Scheduled messages: ${store.schedules().length}\n` +
        `📨 Messages handled: ${s.handled}\n` +
        `♻️ Old/duplicate messages skipped: ${s.replaysIgnored + s.duplicatesIgnored}\n\n` +
        `⚠️ Commands that failed to load:\n${problems}`
    );
  },
};
