const store = require('../whatsapp/store');

module.exports = {
  name: 'setprefix',
  category: 'owner',
  description: 'Change the command prefix, or use the bot with no prefix: setprefix . / setprefix none (owner only)',
  ownerOnly: true,
  async run({ args, reply, prefix, config }) {
    const v = args[0] || '';
    if (!v) {
      return reply(
        `Current prefix: *${prefix || 'none (no prefix)'}*\nTo change it: ${prefix}setprefix .\nTo use the bot with no prefix at all: ${prefix}setprefix none\nTo go back to the default: ${prefix}setprefix reset`
      );
    }
    if (v.toLowerCase() === 'reset') {
      store.setPrefix(null);
      const back = store.effectivePrefix();
      return reply(`✅ Prefix is back to *${back}*\nUse ${back}menu from now on.`);
    }
    if (/^(none|off|no|remove|empty)$/i.test(v)) {
      store.setNoPrefix(true);
      return reply('✅ *No prefix mode is ON.* Just write the command: *menu*, *ping*, *play calm down*.\nThe old prefix still works too if you type it.\nTo bring a prefix back: setprefix . (or setprefix reset)');
    }
    if (!/^\S{1,3}$/.test(v)) return reply('⚠️ The prefix must be 1 to 3 characters with no spaces (or write "none" to use no prefix).');
    store.setPrefix(v);
    return reply(`✅ Prefix is now *${v}*\nUse ${v}menu from now on.`);
  },
};
