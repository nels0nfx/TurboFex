const store = require('../whatsapp/store');

module.exports = {
  name: 'setprefix',
  category: 'owner',
  description: 'Change the command prefix, e.g. setprefix . (owner only)',
  ownerOnly: true,
  async run({ args, reply, prefix, config }) {
    const v = args[0] || '';
    if (!v) {
      return reply(`Current prefix: *${prefix}*\nTo change it: ${prefix}setprefix .\nTo go back to the default: ${prefix}setprefix reset`);
    }
    if (v.toLowerCase() === 'reset') {
      store.setPrefix(null);
      const back = store.effectivePrefix();
      return reply(`✅ Prefix is back to *${back}*\nUse ${back}menu from now on.`);
    }
    if (!/^\S{1,3}$/.test(v)) return reply('⚠️ The prefix must be 1 to 3 characters with no spaces.');
    store.setPrefix(v);
    return reply(`✅ Prefix is now *${v}*\nUse ${v}menu from now on.`);
  },
};
