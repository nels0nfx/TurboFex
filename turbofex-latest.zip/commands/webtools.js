// Media and web tools: lyrics, tts, tovn, ocr, removebg, image, ssweb, shorten
const media = require('../whatsapp/media');
const web = require('../core/web');
const { assertPublicUrl } = require('../core/safefetch');
const { getQuoted } = require('../whatsapp/utils');

const base = { needs: [], weight: 'light' };
const OWNER_KEY = (name) => `⚠️ This needs a free API key. The owner can get one and set ${name} in the bot settings (environment variables).`;

const LANGS = new Set(['en', 'es', 'fr', 'de', 'it', 'pt', 'ru', 'ar', 'hi', 'sw', 'yo', 'ig', 'ha', 'zu', 'af', 'tr', 'id', 'ja', 'ko', 'nl', 'pl', 'zh-cn', 'zh-tw']);

// the words of the message that was replied to
function quotedText(msg) {
  const q = getQuoted(msg);
  const m = q?.message;
  return m ? m.conversation || m.extendedTextMessage?.text || m.imageMessage?.caption || m.videoMessage?.caption || '' : '';
}

// cuts a text into pieces of at most 180 characters at sentence or word ends (the speech service takes short pieces)
function pieces(text, size = 180) {
  const out = [];
  let rest = text.replace(/\s+/g, ' ').trim();
  while (rest.length > size) {
    let cut = Math.max(rest.lastIndexOf('. ', size), rest.lastIndexOf('! ', size), rest.lastIndexOf('? ', size), rest.lastIndexOf(', ', size));
    if (cut < size / 3) cut = rest.lastIndexOf(' ', size);
    if (cut < 1) cut = size;
    out.push(rest.slice(0, cut + 1).trim());
    rest = rest.slice(cut + 1).trim();
  }
  if (rest) out.push(rest);
  return out;
}

// a voice note (opus) is what WhatsApp shows as a round "voice message"; without ffmpeg the sound is sent as normal audio
async function sendVoice(ctx, buffer, srcMime = 'mp3') {
  let out = null;
  try {
    out = await media.ffmpeg(buffer, 'ogg', (i, o) => ['-i', i, '-vn', '-t', '300', '-c:a', 'libopus', '-b:a', '48k', '-application', 'voip', o]);
  } catch (err) {
    if (err.code !== 'NEED_FFMPEG') throw err;
  }
  if (out) return ctx.sock.sendMessage(ctx.jid, { audio: out, mimetype: 'audio/ogg; codecs=opus', ptt: true }, { quoted: ctx.msg });
  return ctx.sock.sendMessage(ctx.jid, { audio: buffer, mimetype: srcMime === 'mp3' ? 'audio/mpeg' : 'audio/mp4' }, { quoted: ctx.msg });
}

module.exports = [
  {
    ...base,
    name: 'lyrics',
    aliases: ['lyric'],
    category: 'media',
    description: 'Find a song and get a link to its lyrics: lyrics rema calm down',
    async run({ rest, reply, prefix }) {
      if (!rest) return reply(`*Usage:* \`${prefix}lyrics <artist and song>\`\n*Example:* \`${prefix}lyrics rema calm down\``);
      const q = encodeURIComponent(rest);
      let found = [];
      try {
        const j = await web.getJson(`https://api.lyrics.ovh/suggest/${q}`, { timeout: 8000 });
        found = (j.data || []).slice(0, 3);
      } catch (err) {
        // the links below still work
      }
      const songs = found.map((s) => `🎵 *${s.title}* - ${s.artist?.name || ''}${s.album?.title ? ` (${s.album.title})` : ''}`).join('\n');
      await reply(
        `${songs ? `${songs}\n\n` : '🎵 *Lyrics*\n'}📖 _I only send the link, the words belong to the songwriters:_\n` +
          `https://genius.com/search?q=${q}\nhttps://www.google.com/search?q=${encodeURIComponent(`${rest} lyrics`)}`
      );
    },
  },
  {
    ...base,
    name: 'tts',
    aliases: ['say', 'speak'],
    category: 'media',
    slow: true,
    description: 'Turn text into a voice note: tts hello everyone (or tts fr bonjour; reply to a message to read it out)',
    async run(ctx) {
      const { args, rest, msg, reply, prefix } = ctx;
      let lang = 'en';
      let text = rest;
      if (args[0] && LANGS.has(args[0].toLowerCase())) {
        lang = args[0].toLowerCase();
        text = rest.slice(args[0].length).trim();
      }
      text = (text || quotedText(msg)).trim();
      if (!text) return reply(`*Usage:* \`${prefix}tts hello everyone\`\n*Other languages:* \`${prefix}tts fr bonjour\`\n_${[...LANGS].join(', ')}_`);
      if (text.length > 500) return reply(`⚠️ That is too long for a voice note (${text.length} characters, the limit is 500).`);
      try {
        const parts = [];
        for (const p of pieces(text)) {
          parts.push(await web.getBuffer(`https://translate.google.com/translate_tts?ie=UTF-8&client=tw-ob&tl=${lang}&q=${encodeURIComponent(p)}`, { timeout: 15000, max: 3 * 1024 * 1024 }));
        }
        await sendVoice(ctx, Buffer.concat(parts));
      } catch (err) {
        console.error('tts failed:', err.message);
        await reply('⚠️ I could not make the voice note right now. Please try again later.');
      }
    },
  },
  {
    ...base,
    name: 'tovn',
    aliases: ['voicenote', 'toptt'],
    category: 'media',
    slow: true,
    description: 'Send audio or a video as a voice note: reply to it with tovn',
    async run(ctx) {
      await media.handle(ctx, ['audio', 'video'], `Reply to an audio or video with ${ctx.prefix}tovn`, async (found, buffer) => {
        await sendVoice(ctx, buffer, 'other');
      });
    },
  },
  {
    ...base,
    name: 'ocr',
    aliases: ['readtext', 'totext'],
    category: 'media',
    slow: true,
    description: 'Read the text in a picture: reply to an image with ocr',
    async run(ctx) {
      await media.handle(ctx, ['image'], `Reply to a picture with ${ctx.prefix}ocr`, async (found, buffer) => {
        let jpeg = buffer;
        try {
          jpeg = await media.loadSharp()(buffer, { failOn: 'none' }).rotate().resize({ width: 1800, height: 1800, fit: 'inside', withoutEnlargement: true }).jpeg({ quality: 70 }).toBuffer(); // the free service takes up to 1 MB
        } catch (err) {
          // sent as it is
        }
        const form = new FormData();
        form.append('apikey', process.env.OCR_API_KEY || 'helloworld');
        form.append('language', 'eng');
        form.append('OCREngine', '2');
        form.append('scale', 'true');
        form.append('file', new Blob([jpeg], { type: 'image/jpeg' }), 'image.jpg');
        const res = await fetch('https://api.ocr.space/parse/image', { method: 'POST', body: form, signal: AbortSignal.timeout(30000) });
        const j = await res.json();
        const text = (j.ParsedResults || []).map((r) => r.ParsedText || '').join('\n').trim();
        if (!text) return ctx.reply(j.IsErroredOnProcessing ? '⚠️ *The text reader could not process that picture.* Try a clearer or smaller one.' : '🔎 *I could not find any text in that picture.*');
        await ctx.reply(`📝 *Text found:*\n\n${text.slice(0, 3500)}`);
      });
    },
  },
  {
    ...base,
    name: 'removebg',
    aliases: ['nobg', 'rmbg'],
    category: 'media',
    slow: true,
    description: 'Remove the background of a picture: reply to an image with removebg',
    async run(ctx) {
      if (!process.env.REMOVEBG_API_KEY) return ctx.reply(ctx.isOwner ? OWNER_KEY('REMOVEBG_API_KEY (free at remove.bg/api)') : media.NOT_HERE);
      await media.handle(ctx, ['image'], `Reply to a picture with ${ctx.prefix}removebg`, async (found, buffer) => {
        const form = new FormData();
        form.append('size', 'auto');
        form.append('image_file', new Blob([buffer], { type: 'image/jpeg' }), 'image.jpg');
        const res = await fetch('https://api.remove.bg/v1.0/removebg', { method: 'POST', headers: { 'X-Api-Key': process.env.REMOVEBG_API_KEY }, body: form, signal: AbortSignal.timeout(45000) });
        if (!res.ok) throw new Error(`remove.bg answered ${res.status}`);
        const png = Buffer.from(await res.arrayBuffer());
        // sent as a file so the transparent background is kept
        await ctx.sock.sendMessage(ctx.jid, { document: png, mimetype: 'image/png', fileName: 'no-background.png' }, { quoted: ctx.msg });
      });
    },
  },
  {
    ...base,
    name: 'image',
    aliases: ['img', 'pic'],
    category: 'media',
    slow: true,
    description: 'Search for a picture: image sunset beach',
    async run({ sock, jid, msg, rest, reply, prefix }) {
      if (!rest) return reply(`*Usage:* \`${prefix}image <what to look for>\`\n*Example:* \`${prefix}image sunset beach\``);
      try {
        const j = await web.getJson(`https://api.openverse.org/v1/images/?q=${encodeURIComponent(rest)}&page_size=12&mature=false&category=photograph,illustration`, { timeout: 12000 });
        const list = (j.results || []).filter((r) => r.thumbnail || r.url);
        if (!list.length) return reply(`🔎 I found no pictures for "${rest.slice(0, 40)}".`);
        const order = list.sort(() => Math.random() - 0.5).slice(0, 4);
        for (const r of order) {
          try {
            const url = r.thumbnail || r.url;
            await assertPublicUrl(url);
            const buffer = await web.getBuffer(url, { timeout: 15000, max: 5 * 1024 * 1024 });
            const credit = `${r.title ? `*${String(r.title).slice(0, 80)}*\n` : ''}${r.creator ? `📸 ${String(r.creator).slice(0, 50)}\n` : ''}📄 ${String(r.license || '').toUpperCase()} ${r.license_version || ''}\n🔗 ${r.foreign_landing_url || ''}`;
            return await sock.sendMessage(jid, { image: buffer, caption: credit.trim() }, { quoted: msg });
          } catch (err) {
            // try the next one
          }
        }
        await reply('⚠️ I found pictures but could not download them. Please try again.');
      } catch (err) {
        console.error('image search failed:', err.message);
        await reply('⚠️ The picture search is not answering right now. Please try again later.');
      }
    },
  },
  {
    ...base,
    name: 'ssweb',
    aliases: ['screenshot', 'ss'],
    category: 'media',
    slow: true,
    description: 'A screenshot of a website: ssweb https://example.com',
    async run({ sock, jid, msg, args, reply, prefix }) {
      let url = (args[0] || '').trim();
      if (!url) return reply(`*Usage:* \`${prefix}ssweb https://example.com\``);
      if (!/^https?:\/\//i.test(url)) url = `https://${url}`;
      try {
        await assertPublicUrl(url);
      } catch (err) {
        return reply('⚠️ That address is not a public website.');
      }
      try {
        const buffer = await web.getBuffer(`https://image.thum.io/get/width/1280/crop/900/noanimate/${url}`, { timeout: 40000, max: 6 * 1024 * 1024 });
        await sock.sendMessage(jid, { image: buffer, caption: `🖥️ ${url.slice(0, 200)}` }, { quoted: msg });
      } catch (err) {
        console.error('ssweb failed:', err.message);
        await reply('⚠️ I could not take a screenshot of that site right now.');
      }
    },
  },
  {
    ...base,
    name: 'shorten',
    aliases: ['short', 'tinyurl'],
    category: 'tools',
    description: 'Make a long link short: shorten https://example.com/very/long/link',
    async run({ args, reply, prefix }) {
      let url = (args[0] || '').trim();
      if (!url) return reply(`*Usage:* \`${prefix}shorten https://example.com/very/long/link\``);
      if (!/^https?:\/\//i.test(url)) url = `https://${url}`;
      try {
        await assertPublicUrl(url);
        const j = await web.getJson(`https://is.gd/create.php?format=json&url=${encodeURIComponent(url)}`, { timeout: 10000 });
        if (!j.shorturl) throw new Error(j.errormessage || 'no short link');
        await reply(`🔗 *Short link*\n${j.shorturl}`);
      } catch (err) {
        await reply('⚠️ I could not shorten that link. Check that it is a real web address.');
      }
    },
  },
];
