const store = require('../whatsapp/store');
const clock = require('../core/clock');

module.exports = {
  name: 'schedules',
  category: 'tools',
  description: 'Show the scheduled messages in this chat',
  async run({ jid, reply, prefix }) {
    const list = store.schedules().filter((s) => s.jid === jid);
    if (!list.length) return reply(`⏰ No scheduled messages here.\nAdd one: ${prefix}schedule 18:30 Dinner time!`);
    const lines = list.map((s) => `#${s.id}  ${s.once ? 'once' : 'daily'} ${s.time}  ${s.text.replace(/\s+/g, ' ').slice(0, 50)}`);
    await reply(`⏰ *Scheduled messages* (${clock.zone()} time)\n\n${lines.join('\n')}\n\nRemove one: ${prefix}unschedule <number>`);
  },
};
