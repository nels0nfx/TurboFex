const games = require('../whatsapp/play');

module.exports = {
  name: 'trivia',
  category: 'games',
  aliases: ['quiz'],
  description: 'Trivia for everyone, answer 1-4: trivia or trivia 10 (rounds)',
  async run({ sock, jid, args, reply, prefix, myIds }) {
    if (games.get(jid)) return reply(games.busyText(prefix));
    const rounds = games.parseRounds(args, 5);
    const game = games.start({ sock, jid, game: games.trivia.create(), starterIds: myIds, rounds });
    await reply(games.trivia.intro(game) + games.seriesNote(game, prefix));
  },
};
