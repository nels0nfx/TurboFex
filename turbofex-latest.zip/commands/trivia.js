const games = require('../whatsapp/play');

module.exports = {
  name: 'trivia',
  category: 'games',
  aliases: ['quiz'],
  description: 'A general knowledge question: answer with 1, 2, 3 or 4',
  async run({ jid, reply, prefix, myIds }) {
    if (games.get(jid)) return reply(games.busyText(prefix));
    const game = games.begin(jid, games.trivia.create(), myIds);
    await reply(games.trivia.intro(game));
  },
};
