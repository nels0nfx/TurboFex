// The market: economy, market, invest, sell, portfolio, bonds, property, business, collect, loan, repay.
// Every group has its own market (switched on with "economy on"), its own prices and its own coins.
const market = require('../core/market');
const economy = require('../core/economy');
const quests = require('../core/quests');
const store = require('../whatsapp/store');
const mentionsLib = require('../whatsapp/mentions');
const { resolveTarget, num } = require('../whatsapp/utils');

const { fmt } = economy;
const { RULES: R, MOODS } = market;
const { DIVIDENDS } = require('../core/marketdata');
const base = { category: 'economy', everyone: true, groupOnly: true, needs: [], weight: 'light' };

const coins = (n) => fmt(Math.floor(n));
const money = (n) => Number(n).toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
const units = (n) => Number(n).toLocaleString('en-US', { maximumFractionDigits: 3 });
const pct = (n, d = 1) => `${n >= 0 ? '+' : '−'}${Math.abs(n).toFixed(d)}%`;
const gain = (n) => `${n >= 0 ? '+' : '−'}${coins(Math.abs(n))}`;
const arrow = (n) => (n >= 0.05 ? '▲' : n <= -0.05 ? '▼' : '▬');
const dur = (ms) => {
  const m = Math.max(1, Math.ceil(ms / 60000));
  if (m < 60) return `${m}m`;
  const h = Math.floor(m / 60);
  if (h < 48) return `${h}h ${m % 60}m`;
  return `${Math.floor(h / 24)}d ${h % 24}h`;
};
const SPARK = '▁▂▃▄▅▆▇█';
const spark = (list, width = 24) => {
  const step = Math.max(1, Math.ceil(list.length / width));
  const pts = list.filter((_, i) => i % step === step - 1 || i === list.length - 1);
  const lo = Math.min(...pts);
  const hi = Math.max(...pts);
  return pts.map((v) => SPARK[hi === lo ? 3 : Math.min(7, Math.floor(((v - lo) / (hi - lo)) * 7.999))]).join('');
};
const MOOD_LINE = (def) => `${def.icon} ${def.name}`;

const verdictIcon = (n) => (n > 0.5 ? '🟢' : n < -0.5 ? '🔴' : '⚪');

// ---- the guide: short pages in plain words
function guideText(topic, prefix) {
  const t = String(topic || '').toLowerCase();
  const p = prefix;
  const pages = {
    stocks: `📘 *Guide: stocks, coins and bonds*\nThere are 3 kinds, from safe to risky:\n▸ 🏛️ *Bonds* – pay a little every day. Very safe. \`${p}bonds\`\n▸ 📈 *Stocks* – 10 made-up companies. A price goes up or down a few % a day. Some are safe (medicine, telecom, farm), some risky (tech, oil).\n▸ 🪙 *Coins* – can jump or fall 20% in a day. Big wins, big losses.\n\nEach one reacts differently to the mood. See which ones like or hate the mood now: \`${p}market TECH\`\n_Tip: never put everything in one thing._`,
    profit: `📘 *Guide: profit and loss*\nYou make *profit* 🟢 when you sell for more than you paid. You make a *loss* 🔴 when you sell for less.\n▸ Every buy and sell has a small *fee* (stocks 1.5%, coins 2%, bonds 0.5%). That is why you start a little in the red.\n▸ After you buy, I tell you the *break-even price*. Above it you are in profit.\n▸ \`${p}portfolio\` shows green or red for each thing you own.\n▸ \`${p}profit\` shows your total profit in plain numbers: overall, this week and the last 24 hours.\n▸ Coins from work, fish and daily are *not* profit. Only what investing made counts.\n▸ The *weekly prize* goes to the best profit in %, so small players can win too.`,
    property: `📘 *Guide: property and business*\n▸ 🏘️ *Property* costs a lot and pays *rent* every day. The value changes slowly with the economy. There is a small tax and a fee when you buy or sell. \`${p}property\`\n▸ 🏭 *Business* (kiosk, farm, shop, factory): buy it, upgrade it, and it earns *profit* every day. \`${p}business\`\n▸ Rent and profit wait for you (up to 2–3 days). Take them with \`${p}collect\`.\n_These are slow and steady. Good when the market is crashing._`,
    loans: `📘 *Guide: loans*\n▸ \`${p}loan 2000\` gives you coins now. You pay back more later (interest every day, more when inflation is high).\n▸ You can borrow up to half of what you own. A fee of 2% is taken at the start.\n▸ While you owe, you cannot give coins, gamble or use the bank.\n▸ If the debt becomes too big for what you own, I *sell your investments* to pay it (margin call).\n▸ After 7 days the loan is taken from your coins and investments.\n⚠️ _A loan makes wins bigger and losses bigger. Avoid loans in a crash._`,
    mood: `📘 *Guide: the mood*\nThe whole market has a *mood* that changes every few hours, with a news headline:\n▸ 🚀 *Boom* – prices rise\n▸ ⚖️ *Stable* – quiet\n▸ 📉 *Recession* – prices slide slowly\n▸ 🔥 *Inflation* – goods cost more; farm and oil win, transport loses\n▸ 💥 *Crash* – big drops (but a crash can never take more than 12% of stocks or 25% of coins in one day)\nThe mood also changes the shop prices, job pay, bond yield and loan cost. \`${p}economy\` shows it.`,
    tips: `📘 *Guide: 6 tips for beginners*\n1. Start small: \`${p}invest FARM 200\`. Learn first.\n2. Spread your money: a bit of bonds, a bit of stocks. Coins only with what you can lose.\n3. Read the news. \`${p}news economy\` tells you what is happening.\n4. Do not panic-sell in a crash. Prices come back more often than not.\n5. Trade less. Every trade costs a fee.\n6. Check \`${p}profit\` once a day, not every minute. Prices only change every 30 minutes.`,
  };
  if (pages[t]) return pages[t];
  return `📘 *How the market works – in 1 minute*\n\n1️⃣ *Earn coins* with \`${p}daily\`, \`${p}work\`, \`${p}fish\`, \`${p}mine\`.\n2️⃣ *Buy* something with your coins: \`${p}invest TECH 500\` puts 500 coins into TurboTech.\n3️⃣ *Wait.* Prices change every 30 minutes. The *mood* (boom, crash...) pushes them up or down. \`${p}market\`\n4️⃣ *Sell* when you like the price: \`${p}sell TECH all\`. More than you paid = profit 🟢. Less = loss 🔴.\n5️⃣ *Check* how you are doing: \`${p}profit\` (am I winning?) and \`${p}portfolio\` (what do I own?).\n\n*Safe → risky:* bonds → stocks → coins.\n_Each group has its own market and its own coins._\n\n*Not sure what to buy?* \`${p}picks\` shows what looks profitable and what to avoid (🟢 buy, 🔴 avoid).\n*Also every day:* \`${p}earn\` (what is ready now) • \`${p}quests\` • \`${p}throne\` (be the king) • \`${p}couple\` • \`${p}garden\` • \`${p}heist\` • \`${p}predict\` • \`${p}alert\`\n\nMore: \`${p}guide stocks\` • \`${p}guide profit\` • \`${p}guide mood\` • \`${p}guide property\` • \`${p}guide loans\` • \`${p}guide tips\``;
}

const closed = (prefix) => `📉 *The market is closed in this group.*\nAn admin or the owner can open it with \`${prefix}economy on\`.`;

// the usual reasons a trade does not work
function why(r, prefix) {
  const f = {
    closed: () => closed(prefix),
    unknown: () => `⚠️ *I do not know that one.* See the list with \`${prefix}market\``,
    amount: () => '⚠️ *I did not understand the amount.* Write a number (500, 2k), a share (50%) or all.',
    wait: () => `⏳ *Wait ${Math.ceil(r.waitMs / 1000)} seconds* before your next trade.`,
    poor: () => `⚠️ *Not enough coins.* Your wallet has ${coins(r.wallet || 0)} coins${r.need ? ` and you need ${coins(r.need)}` : ''}.`,
    min: () => `⚠️ *Too small.* The smallest trade is ${r.min} coins.`,
    cap: () => `⚠️ *Too much for one trade.* You can use at most ${Math.round(R.capShare * 100)}% of your wallet (${coins(r.cap)} coins) at a time.`,
    none: () => `⚠️ *You do not own ${r.asset?.name || r.id || 'that'}.*`,
    over: () => `⚠️ *You only have ${coins(r.value)} coins of ${r.asset?.id || 'that'}.* Use \`all\` to sell everything.`,
    bondcap: () => `⚠️ *Bonds are full.* You can keep at most ${coins(R.bondCap)} coins in bonds${r.room != null ? ` (${coins(r.room)} left)` : ''}.`,
    max: () => `⚠️ *You already own the most you can.* ${r.max} of each kind.`,
    owned: () => '⚠️ *You already own that business.* Upgrade it instead.',
    maxlevel: () => `⚠️ *It is already at the highest level (${R.bizMaxLevel}).*`,
    has: () => `⚠️ *You already have a loan* of ${coins(r.debt)} coins. Repay it first.`,
    limit: () => `⚠️ *That is more than you can borrow.* Your limit is ${coins(r.limit)} coins.`,
    noloan: () => '✅ *You have no loan.*',
  }[r.why];
  return f ? f() : '⚠️ *That did not work.*';
}

async function needOpen(ctx) {
  if (market.isOn(ctx.jid)) return true;
  await ctx.reply(closed(ctx.prefix));
  return false;
}

// "@x 12.4%" lines for the people of a ranking
async function names(sock, jid, list) {
  const who = await mentionsLib.describe(sock, jid, list.map((r) => r.jid));
  return { text: who.map((w) => w.text), mentions: who.map((w) => w.mention).filter(Boolean) };
}

const tableRow = (q) => `${q.asset.id.padEnd(5)} ${money(q.price).padStart(9)}  ${arrow(q.change)} ${pct(q.change).padStart(7)}  ${q.outlook ? q.outlook.icon : ''}`;

function priceTable(quotes, title) {
  return `*${title}*\n\`\`\`\n${quotes.map(tableRow).join('\n')}\n\`\`\``;
}

function likes(asset) {
  const rows = Object.entries(asset.fx).map(([m, v]) => ({ m, v }));
  const good = rows.filter((r) => r.v >= 0.15 * (asset.kind === 'coin' ? 5 : 1)).map((r) => MOODS[r.m].icon + ' ' + MOODS[r.m].name);
  const bad = rows.filter((r) => r.v <= -0.15 * (asset.kind === 'coin' ? 5 : 1)).map((r) => MOODS[r.m].icon + ' ' + MOODS[r.m].name);
  return { good, bad };
}

module.exports = [
  // ---------------------------------------------------------------- guide and profit
  {
    ...base,
    name: 'guide',
    aliases: ['learn', 'howto', 'ecoguide'],
    description: 'How the market works in 1 minute (guide profit / stocks / mood / property / loans / tips)',
    async run({ args, reply, prefix }) {
      await reply(guideText(args[0], prefix));
    },
  },
  {
    ...base,
    name: 'profit',
    aliases: ['pnl', 'gains', 'winning'],
    description: 'Are you making profit? Your gain or loss overall, this week and today, in plain numbers',
    async run(ctx) {
      const { jid, reply, myJid, prefix } = ctx;
      if (!(await needOpen(ctx))) return;
      const r = market.profit(jid, myJid);
      if (r.empty || !r.ok) return reply(`📈 *Your profit*\n_You have not invested yet._\n\n▸ \`${prefix}guide\` – how it works (1 minute)\n▸ \`${prefix}invest FARM 200\` – a safe first try`);
      const { overall, week, day, parts } = r;
      const verdict = overall.profit > 0.5 ? '🟢 *You are making profit.*' : overall.profit < -0.5 ? '🔴 *You are at a loss right now.*' : '⚪ *You are about even.*';
      const since = Date.now() - r.since > 3600000 ? ` _(since ${dur(Date.now() - r.since)} ago)_` : '';
      const out = [
        `📈 *Your profit*`,
        verdict,
        '',
        `*Overall:* ${verdictIcon(overall.profit)} ${gain(overall.profit)} coins (${pct(overall.pct)})${since}`,
        `*This week:* ${verdictIcon(week.profit)} ${gain(week.profit)} coins (${pct(week.pct)})`,
        `*Last 24 hours:* ${verdictIcon(day)} ${gain(day)} coins _(price moves on what you hold now)_`,
        '',
        '*How it adds up*',
        `▸ You put in: ${coins(parts.putIn)} coins`,
        `▸ It is worth now: ${coins(parts.worth)} coins`,
        `▸ Rent and business income: ${gain(parts.income)}`,
        `▸ Loan interest and fees: ${gain(-parts.loanCost)}`,
        `_Profit = ${coins(parts.worth)} ${parts.income >= 0 ? '+' : '−'} ${coins(Math.abs(parts.income))} − ${coins(parts.putIn)} − ${coins(parts.loanCost)} = ${gain(overall.profit)}_`,
        `*Costs so far:* trading fees and duty ${coins(parts.fees)} • taxes ${coins(parts.tax)} • loan interest ${coins(parts.interest)} _(already counted above)_`,
      ];
      // one or two plain tips
      const p = market.portfolio(jid, myJid);
      const s = market.status(jid);
      const tips = [];
      const coinValue = (p.positions || []).filter((x) => x.asset.kind === 'coin').reduce((a, x) => a + x.value, 0);
      const stockValue = (p.positions || []).reduce((a, x) => a + x.value, 0);
      if (parts.fees > Math.max(50, Math.abs(overall.profit)) && overall.profit < parts.fees) tips.push('Fees are eating your profit. Trade less often and hold longer.');
      if (stockValue > 0 && coinValue / stockValue > 0.6) tips.push('Most of your money is in coins. They swing a lot. Mix in stocks or bonds.');
      if (p.loan && (s.mood === 'crash' || s.mood === 'recession')) tips.push(`You owe coins in a ${s.def.name.toLowerCase()}. Consider \`${prefix}repay\` to avoid forced sales.`);
      if (p.positions && p.bond < 1 && (s.mood === 'crash' || s.mood === 'recession')) tips.push(`In a ${s.def.name.toLowerCase()}, bonds are the safe choice. \`${prefix}bonds\``);
      if (p.worth && p.worth.wallet > 3 * Math.max(1, p.worth.invested)) tips.push(`Your coins are sitting idle. Bonds pay every day: \`${prefix}bonds buy 1000\``);
      if (tips.length) out.push('', ...tips.slice(0, 2).map((t) => `💡 _${t}_`));
      out.push('', `▸ \`${prefix}portfolio\` – each thing you own • \`${prefix}guide profit\` – how profit works`);
      await reply(out.join('\n'));
    },
  },

  // ---------------------------------------------------------------- market
  {
    ...base,
    name: 'market',
    aliases: ['stocks', 'prices', 'coinmarket'],
    description: 'Prices of the stocks and coins, the mood and the 24 hour change (market TECH for one)',
    async run(ctx) {
      const { jid, args, reply, prefix } = ctx;
      if (!(await needOpen(ctx))) return;
      const s = market.status(jid);
      const q = market.quotes(jid);
      const one = args[0] ? market.findAsset(args[0]) : null;
      if (args[0] && !one && !/^(stocks?|coins?|crypto|shares?)$/i.test(args[0])) return reply(why({ why: 'unknown' }, prefix));
      if (one && one.kind !== 'bond') {
        const row = q.find((x) => x.asset.id === one.id);
        const lo = Math.min(...row.hist);
        const hi = Math.max(...row.hist);
        const l = likes(one);
        const mine = market.portfolio(jid, ctx.myJid).positions?.find((p) => p.asset.id === one.id);
        return reply(
          `${one.icon} *${one.name}* (${one.id})\n` +
            `*Price:* ${money(row.price)} coins  ${arrow(row.change)} ${pct(row.change)} in 24h\n` +
            `*24h range:* ${money(lo)} – ${money(hi)}\n` +
            `*Trend:* ${spark(row.hist)}\n` +
            `*Kind:* ${one.kind === 'coin' ? 'coin' : `stock, ${one.sector}`} • *Risk:* ${one.risk}\n` +
            (DIVIDENDS[one.id] ? `*Dividend:* ${DIVIDENDS[one.id]}% of what you hold, every day (take it with \`${prefix}collect\`)\n` : '') +
            (l.good.length ? `*Likes:* ${l.good.join(' • ')}\n` : '') +
            (l.bad.length ? `*Hates:* ${l.bad.join(' • ')}\n` : '') +
            (row.outlook ? `\n${row.outlook.icon} *Outlook: ${row.outlook.label}* – ${row.outlook.verdict}\n_${row.outlook.reason}. Expected move ${pct(row.outlook.gross)} over the next ~${dur(row.outlook.hours * 3600000)}, fees ${row.outlook.fees.toFixed(1)}%, usual swing ±${row.outlook.swing.toFixed(1)}%. It is an estimate, not a promise._\n\n` : '') +
            (mine ? `*You hold:* ${units(mine.units)} units ≈ ${coins(mine.value)} coins (${pct(mine.plPct)})\n` : '') +
            `\n▸ \`${prefix}invest ${one.id} 500\`\n▸ \`${prefix}sell ${one.id} all\``
        );
      }
      const want = (args[0] || '').toLowerCase();
      const stocks = q.filter((x) => x.asset.kind === 'stock');
      const crypto = q.filter((x) => x.asset.kind === 'coin');
      const parts = [`📊 *Market* – ${MOOD_LINE(s.def)}`, `_"${s.headline}"_`, `💡 _${s.def.tip}_`, ''];
      if (!want || /^(stocks?|shares?)$/.test(want)) parts.push(priceTable(stocks, 'Stocks'), '');
      if (!want || /^(coins?|crypto)$/.test(want)) parts.push(priceTable(crypto, 'Coins (wild swings)'), '');
      if (!want) {
        parts.push(`*Bonds:* pay ${s.bondRate}% a day (the safe choice)`);
        parts.push(`*Property index:* ${s.propertyIndex.toFixed(3)} ${arrow(s.propertyChange)} ${pct(s.propertyChange)}`);
        parts.push('');
      }
      parts.push(`_Next price update in ${dur(s.nextUpdate - Date.now())} • 24h change._`, `_Last column = outlook: 🟢🟢 strong buy • 🟢 buy • ⚪ not worth a quick trade • 🔴 likely loss • 🔴🔴 avoid_`);
      parts.push(`▸ \`${prefix}picks\` – what to buy and what to avoid now`, `▸ \`${prefix}market TECH\` – one in detail`, `▸ \`${prefix}invest TECH 500\` • \`${prefix}portfolio\``);
      await reply(parts.join('\n'));
    },
  },

  {
    ...base,
    name: 'picks',
    aliases: ['signals', 'outlook', 'advice', 'whattobuy'],
    description: 'What looks profitable right now and what to avoid (an estimate from the mood and the news)',
    async run(ctx) {
      const { jid, reply, prefix } = ctx;
      if (!(await needOpen(ctx))) return;
      const s = market.status(jid);
      const all = market.picks(jid);
      const good = all.filter((p) => p.o.net >= 0.8).slice(0, 4);
      const bad = all.filter((p) => p.o.key === 'weak' || p.o.key === 'avoid').slice(-4).reverse();
      const line = (p) => `${p.o.icon} *${p.asset.id}* ${p.asset.icon} ${p.asset.name} – ${p.o.verdict}\n   _${p.o.reason} • expected ${pct(p.o.gross)} • risk ${p.asset.risk}_`;
      const out = [`🎯 *Picks* – ${MOOD_LINE(s.def)}`, `_Outlook for the next ~${dur(all[0].o.hours * 3600000)} (until the mood may change)._`, ''];
      out.push('*Looks profitable*');
      out.push(...(good.length ? good.map(line) : ['_Nothing clearly profitable now. Bonds (safe) or waiting is fine._']));
      out.push('', '*Better to avoid*');
      out.push(...(bad.length ? bad.map(line) : ['_Nothing looks bad right now._']));
      out.push('', `🏛️ *Bonds* pay ${s.bondRate}% a day – the safe choice when nothing looks good.`);
      out.push('', `⚠️ _This is an estimate from the mood, the news and how far a price is from normal. Prices also swing at random, so no pick is guaranteed. Fees are about 2–4% for a buy and sell._`, `▸ \`${prefix}market TECH\` – one in detail • \`${prefix}invest <asset> <coins>\``);
      await reply(out.join('\n'));
    },
  },

  // ---------------------------------------------------------------- invest / sell
  {
    ...base,
    name: 'invest',
    aliases: ['buyshare'],
    description: 'Buy a stock, a coin or bonds with coins: invest TECH 500 (also 2k, 50% or all)',
    async run(ctx) {
      const { jid, args, reply, myJid, prefix } = ctx;
      if (!(await needOpen(ctx))) return;
      if (args.length < 2) {
        return reply(
          `💼 *Invest*\n*Usage:* \`${prefix}invest <asset> <amount>\`\n*Examples:* \`${prefix}invest TECH 500\` • \`${prefix}invest TRB 2k\` • \`${prefix}invest bonds 1000\`\n\n` +
            `▸ The amount is in coins (a number, 2k, 50% or all)\n▸ One trade uses at most ${Math.round(R.capShare * 100)}% of your wallet\n▸ Fee: stocks ${R.fee.stock * 100}% • coins ${R.fee.coin * 100}% • bonds ${R.fee.bond * 100}%\n▸ Wait ${R.cooldownMs / 1000}s between trades\n\nSee the prices with \`${prefix}market\``
        );
      }
      const r = market.invest(jid, myJid, args[0], args[1]);
      if (!r.ok) return reply(why(r, prefix));
      const iq = quests.note(quests.track(jid, myJid, 'invest'));
      const tail = iq ? `\n\n${iq}` : '';
      if (r.bond) {
        return reply(`✅ *Bought bonds*\n*Spent:* ${coins(r.amount)} coins (fee ${coins(r.fee)})\n*Bonds:* ${coins(r.held)} coins • pays ${r.rate}% a day\n*Wallet:* ${coins(r.wallet)} coins${tail}`);
      }
      await reply(
        `✅ *Invested in ${r.asset.id}* ${r.asset.icon}\n*Spent:* ${coins(r.amount)} coins (fee ${coins(r.fee)})\n*Got:* ${units(r.units)} units at ${money(r.price)}\n` +
          `*You hold:* ${units(r.held)} units ≈ ${coins(r.held * r.price)} coins\n*Wallet:* ${coins(r.wallet)} coins\n\n` +
          `${(() => { const o = market.outlook(jid, r.asset.id); return o ? `${o.icon} *Outlook now: ${o.label}* – ${o.verdict}\n_${o.reason}._\n\n` : ''; })()}` +
          `📌 _You are at a small loss because of the fee. You break even when ${r.asset.id} reaches *${money(r.breakEven)}*. Above that is profit 🟢, below is loss 🔴._\n▸ \`${prefix}profit\` – are you winning?${tail}`
      );
    },
  },
  {
    ...base,
    name: 'sell',
    aliases: ['sellshare'],
    description: 'Sell a stock, a coin or bonds for coins: sell TECH 500 (also 50% or all)',
    async run(ctx) {
      const { jid, args, reply, myJid, prefix } = ctx;
      if (!(await needOpen(ctx))) return;
      if (args.length < 2) {
        return reply(`💼 *Sell*\n*Usage:* \`${prefix}sell <asset> <amount>\`\n*Examples:* \`${prefix}sell TECH 500\` • \`${prefix}sell TRB 50%\` • \`${prefix}sell NOVA all\`\n_The amount is the value in coins. See what you own with_ \`${prefix}portfolio\``);
      }
      const r = market.sell(jid, myJid, args[0], args[1]);
      if (!r.ok) return reply(why(r, prefix));
      const cost = r.costPart || 0;
      const pl = r.proceeds - cost;
      const sq = !r.bond && pl > 0 ? quests.note(quests.track(jid, myJid, 'sellprofit')) : null;
      const tail = sq ? `\n\n${sq}` : '';
      if (r.bond) return reply(`✅ *Sold bonds*\n*Got:* ${coins(r.proceeds)} coins (fee ${coins(r.fee)})\n*Bonds left:* ${coins(r.held)} coins\n*Wallet:* ${coins(r.wallet)} coins`);
      await reply(
        `✅ *Sold ${r.asset.id}* ${r.asset.icon}\n*Sold:* ${units(r.units)} units at ${money(r.price)}\n*Got:* ${coins(r.proceeds)} coins (fee ${coins(r.fee)})\n` +
          `*Result:* ${pl >= 0 ? '🟢' : '🔴'} ${gain(pl)} coins${cost > 0 ? ` (${pct((pl / cost) * 100)})` : ''}\n` +
          (r.held ? `*Still holding:* ${units(r.held)} units\n` : '') +
          `*Wallet:* ${coins(r.wallet)} coins${tail}`
      );
    },
  },

  // ---------------------------------------------------------------- portfolio
  {
    ...base,
    name: 'portfolio',
    aliases: ['pf', 'networth', 'investments'],
    description: 'What you own, profit and loss and net worth (portfolio @user shows another member)',
    async run(ctx) {
      const { msg, args, jid, reply, myJid, prefix } = ctx;
      if (!(await needOpen(ctx))) return;
      const target = resolveTarget(msg, args) || myJid;
      const mine = num(target) === num(myJid);
      const p = market.portfolio(jid, target);
      const owner = mine ? 'Your portfolio' : `Portfolio of @${num(target)}`;
      const opts = mine ? {} : { mentions: [target] };
      if (p.empty) {
        return reply(`📊 *${owner}*\n*Wallet:* ${coins(p.wallet)} coins${p.bank ? `\n*Bank:* ${coins(p.bank)} coins` : ''}\n\n_${mine ? 'You own nothing yet.' : 'They own nothing yet.'}_${mine ? `\n▸ \`${prefix}market\` – see the prices\n▸ \`${prefix}invest TECH 500\` – buy your first stock` : ''}`, opts);
      }
      const w = p.worth;
      const out = [`📊 *${owner}*${p.crown ? ' 👑' : ''}`, `*Wallet:* ${coins(w.wallet)} coins`];
      if (w.bank) out.push(`*Bank:* ${coins(w.bank)} coins 🏦`);
      const pr = market.profit(jid, target);
      if (pr.ok && !pr.empty && (p.positions.length || p.bond >= 1 || p.props.length || p.biz.length)) {
        out.push(`*Profit overall:* ${verdictIcon(pr.overall.profit)} ${gain(pr.overall.profit)} coins (${pct(pr.overall.pct)})`);
        if (p.positions.length) out.push(`*Last 24h:* ${verdictIcon(pr.day)} ${gain(pr.day)} coins _(price moves on what you hold)_`);
      }
      if (p.positions.length || p.bond >= 1) {
        out.push('', '*Investments*');
        for (const x of p.positions) out.push(`▸ ${x.asset.icon} *${x.asset.id}* ${units(x.units)} units ≈ *${coins(x.value)}* coins  ${x.pl >= 0 ? '🟢' : '🔴'} ${pct(x.plPct)} (${gain(x.pl)})${x.outlook ? ` ${x.outlook.icon} ${x.outlook.key === 'weak' || x.outlook.key === 'avoid' ? 'consider selling' : x.outlook.key === 'neutral' ? 'hold' : 'hold, looks good'}` : ''}`);
        if (p.bond >= 1) out.push(`▸ 🏛️ *Bonds* *${coins(p.bond)}* coins  🟢 ${gain(p.bondEarned)} earned`);
      }
      if (p.props.length) {
        out.push('', '*Property*');
        for (const x of p.props) out.push(`▸ ${x.def.icon} *${x.def.name}* ×${x.n} ≈ *${coins(x.value)}* coins`);
        out.push(`   _Rent waiting: ${coins(p.rent)} (tax ${coins(p.tax)})_`);
      }
      if (p.div >= 1) out.push('', `💸 *Dividends waiting:* ${coins(p.div)} coins _(\`${prefix}collect\`)_`);
      if (p.biz.length) {
        out.push('', '*Business*');
        for (const x of p.biz) out.push(`▸ ${x.def.icon} *${x.def.name}* level ${x.level} – profit waiting *${coins(x.waiting)}*`);
      }
      if (p.loan) out.push('', `*Loan:* 🔴 −${coins(p.loan.debt)} coins • ${p.loan.overdue ? '*overdue*' : `due in ${dur(p.loan.due - Date.now())}`}`);
      out.push('', `*Net worth:* ${coins(w.total)} coins`);
      if (p.realized) out.push(`*Profit taken so far:* ${gain(p.realized)} coins`);
      const wk = p.week;
      out.push(`*This week (investing only):* ${wk.eligible ? `${pct(wk.pct)} (${gain(wk.profit)} coins)${wk.rank ? ` • #${wk.rank} of ${wk.of}` : ''}` : `_invest ${coins(R.weekMinInvested)}+ coins to join the ranking_`}`);
      if (mine) out.push('', `▸ \`${prefix}profit\` – am I winning? • \`${prefix}guide\` – how it works`, `▸ \`${prefix}economy top\` – the ranking • \`${prefix}collect\` – rent and profit`);
      await reply(out.join('\n'), opts);
    },
  },

  // ---------------------------------------------------------------- bonds
  {
    ...base,
    name: 'bonds',
    aliases: ['bond', 'savings'],
    description: 'Safe savings that pay a little every day: bonds / bonds buy 1000 / bonds sell all',
    async run(ctx) {
      const { jid, args, reply, myJid, prefix } = ctx;
      if (!(await needOpen(ctx))) return;
      const sub = (args[0] || '').toLowerCase();
      if (sub === 'buy' || sub === 'sell') {
        if (!args[1]) return reply(`*Usage:* \`${prefix}bonds ${sub} 1000\` or \`${prefix}bonds ${sub} all\``);
        const r = sub === 'buy' ? market.bondBuy(jid, myJid, args[1]) : market.bondSell(jid, myJid, args[1]);
        if (!r.ok) return reply(why(r, prefix));
        return reply(sub === 'buy'
          ? `✅ *Bought bonds*\n*Spent:* ${coins(r.amount)} coins (fee ${coins(r.fee)})\n*Bonds:* ${coins(r.held)} coins • pays ${r.rate}% a day\n*Wallet:* ${coins(r.wallet)} coins`
          : `✅ *Sold bonds*\n*Got:* ${coins(r.proceeds)} coins (fee ${coins(r.fee)})\n*Bonds left:* ${coins(r.held)} coins\n*Wallet:* ${coins(r.wallet)} coins`);
      }
      const s = market.status(jid);
      const p = market.portfolio(jid, myJid);
      const held = p.empty ? 0 : p.bond;
      await reply(
        `🏛️ *Bonds*\n_Low but steady. The safe choice in a recession._\n\n*Pays now:* ${s.bondRate}% a day (${MOOD_LINE(s.def)})\n*Fee:* ${R.fee.bond * 100}% when you buy and when you sell\n*Most you can keep:* ${coins(R.bondCap)} coins\n*Your bonds:* ${coins(held)} coins${held >= 1 ? ` (${gain(p.bondEarned)} earned)` : ''}\n\n` +
          `▸ \`${prefix}bonds buy 1000\`\n▸ \`${prefix}bonds sell 500\` or \`${prefix}bonds sell all\``
      );
    },
  },

  // ---------------------------------------------------------------- property
  {
    ...base,
    name: 'property',
    aliases: ['properties', 'realestate', 'estate'],
    description: 'Buy property that pays rent every day: property / property buy flat / property sell flat',
    async run(ctx) {
      const { jid, args, reply, myJid, prefix } = ctx;
      if (!(await needOpen(ctx))) return;
      const sub = (args[0] || '').toLowerCase();
      if (sub === 'buy' || sub === 'sell') {
        if (!args[1]) return reply(`*Usage:* \`${prefix}property ${sub} flat\`\n_Kinds:_ ${Object.keys(market.PROPERTIES).join(', ')}`);
        const r = sub === 'buy' ? market.propertyBuy(jid, myJid, args[1]) : market.propertySell(jid, myJid, args[1]);
        if (!r.ok) return reply(why(r, prefix));
        return reply(sub === 'buy'
          ? `🏠 *Bought a ${r.def.name}*\n*Price:* ${coins(r.price)} coins + ${coins(r.stamp)} stamp duty\n*You own:* ${r.owned}\n*Wallet:* ${coins(r.wallet)} coins\n_Collect the rent with_ \`${prefix}collect\``
          : `✅ *Sold a ${r.def.name}*\n*Price:* ${coins(r.price)} coins − ${coins(r.stamp)} costs\n*Got:* ${coins(r.proceeds)} coins\n*Wallet:* ${coins(r.wallet)} coins`);
      }
      const s = market.status(jid);
      const p = market.portfolio(jid, myJid);
      const rows = Object.entries(market.PROPERTIES).map(([id, d]) => {
        const price = market.propValue(jid, id);
        const rent = price * R.rentPerDay * s.def.rent;
        const tax = price * R.taxPerDay;
        const own = p.props?.find((x) => x.id === id)?.n || 0;
        return `▸ ${d.icon} *${d.name}* – ${coins(price)} coins${own ? ` (you own ${own})` : ''}\n   _Rent ≈ ${coins(rent)} a day, tax ${coins(tax)}_ • \`${prefix}property buy ${id}\``;
      });
      await reply(
        `🏘️ *Property*\n_Costs a lot, pays rent every day. The value follows the economy, slowly._\n\n${rows.join('\n')}\n\n` +
          `*Property index:* ${s.propertyIndex.toFixed(3)} ${arrow(s.propertyChange)} ${pct(s.propertyChange)}\n*Stamp duty:* ${R.propertyStamp * 100}% when you buy and when you sell • *Tax:* ${R.taxPerDay * 100}% of the value a day • *Most:* ${R.propertyMax} of each\n\n` +
          `▸ \`${prefix}property sell flat\`\n▸ \`${prefix}collect\` – take the rent`
      );
    },
  },

  // ---------------------------------------------------------------- business
  {
    ...base,
    name: 'business',
    aliases: ['biz', 'businesses'],
    description: 'Own a kiosk, farm, shop or factory: business / business buy farm / business upgrade farm',
    async run(ctx) {
      const { jid, args, reply, myJid, prefix } = ctx;
      if (!(await needOpen(ctx))) return;
      const sub = (args[0] || '').toLowerCase();
      if (['buy', 'upgrade', 'sell'].includes(sub)) {
        if (!args[1]) return reply(`*Usage:* \`${prefix}business ${sub} farm\`\n_Kinds:_ ${Object.keys(market.BUSINESSES).join(', ')}`);
        const fn = { buy: market.businessBuy, upgrade: market.businessUpgrade, sell: market.businessSell }[sub];
        const r = fn(jid, myJid, args[1]);
        if (!r.ok) return reply(why(r, prefix));
        if (sub === 'buy') return reply(`🎉 *You own a ${r.def.name}!*\n*Cost:* ${coins(r.cost)} coins\n*Profit:* about ${coins(r.profitDay)} coins a day\n*Wallet:* ${coins(r.wallet)} coins\n_Collect with_ \`${prefix}collect\``);
        if (sub === 'upgrade') return reply(`⬆️ *${r.def.name} upgraded to level ${r.level}*\n*Cost:* ${coins(r.cost)} coins\n*Profit:* about ${coins(r.profitDay)} coins a day\n*Wallet:* ${coins(r.wallet)} coins`);
        return reply(`✅ *Sold your ${r.def.name}*\n*Got back:* ${coins(r.refund)} coins (${R.bizResale * 100}% of what you put in)${r.profit ? `\n*Profit collected:* ${coins(r.profit)} coins` : ''}\n*Wallet:* ${coins(r.wallet)} coins`);
      }
      const s = market.status(jid);
      const p = market.portfolio(jid, myJid);
      const rows = Object.entries(market.BUSINESSES).map(([id, d]) => {
        const mine = p.biz?.find((x) => x.id === id);
        if (mine) {
          const up = mine.level < R.bizMaxLevel ? ` • upgrade ${coins(market.bizUpgradeCost(id, mine.level))} → \`${prefix}business upgrade ${id}\`` : ' • max level';
          return `▸ ${d.icon} *${d.name}* level ${mine.level} – ${coins(mine.profitDay)} a day, *${coins(mine.waiting)}* waiting${up}`;
        }
        return `▸ ${d.icon} *${d.name}* – ${coins(d.cost)} coins, about ${coins(market.bizProfitDay(jid, id, 1))} a day\n   \`${prefix}business buy ${id}\``;
      });
      await reply(
        `🏭 *Business*\n_Buy a business, upgrade it and collect the profit every day. It sits next to your work and fish income._\n\n${rows.join('\n')}\n\n` +
          `*Mood now:* ${MOOD_LINE(s.def)} (profit ${pct((s.def.biz - 1) * 100, 0)})\n*Tax:* ${R.bizTax * 100}% when you collect • *Upgrade:* levels up to ${R.bizMaxLevel}, each adds ${R.bizLevelBonus * 100}% profit\n\n▸ \`${prefix}collect\` – take your profit\n▸ \`${prefix}business sell farm\` – ${R.bizResale * 100}% back`
      );
    },
  },
  {
    ...base,
    name: 'collect',
    aliases: ['harvest', 'rent'],
    description: 'Take the rent of your property and the profit of your businesses',
    async run(ctx) {
      const { jid, reply, myJid, prefix } = ctx;
      if (!(await needOpen(ctx))) return;
      const r = market.collect(jid, myJid);
      if (!r.total) return reply(`⏳ *Nothing to collect yet.* Rent and profit build up every 30 minutes.\n_You need property (\`${prefix}property\`), a business (\`${prefix}business\`) or dividend stocks (\`${prefix}market\`)._`);
      const lines = ['💵 *Collected*'];
      if (r.rent) lines.push(`🏘️ *Rent:* +${coins(r.rent.net)} coins (${coins(r.rent.gross)} − tax ${coins(r.rent.tax)})`);
      if (r.div) lines.push(`💸 *Dividends:* +${coins(r.div.net)} coins (paid by the stocks you hold)`);
      if (r.biz) for (const b of r.biz.list) lines.push(`${b.def.icon} *${b.def.name}:* +${coins(b.net)} coins (${coins(b.gross)} − tax ${coins(b.tax)})`);
      lines.push(`*Total:* +${coins(r.total)} coins`, `*Wallet:* ${coins(r.wallet)} coins`);
      const cq = quests.note(quests.track(jid, myJid, 'collect'));
      if (cq) lines.push('', cq);
      await reply(lines.join('\n'));
    },
  },

  // ---------------------------------------------------------------- price alerts
  {
    ...base,
    name: 'alert',
    aliases: ['pricealert', 'watch'],
    description: 'Get pinged when a price gets there: alert TECH above 300 / alert TRB below 40 / alert list / alert clear',
    async run(ctx) {
      const { jid, args, reply, myJid, prefix } = ctx;
      if (!(await needOpen(ctx))) return;
      const sub = (args[0] || '').toLowerCase();
      if (sub === 'clear' || sub === 'off') return reply(`🧹 *Alerts cleared* (${market.alertClear(jid, myJid)}).`);
      if (!args.length || sub === 'list') {
        const r = market.alertList(jid, myJid);
        if (!r.alerts.length) return reply(`🔔 *Price alerts*\n_You have none._\n\n*Usage:* \`${prefix}alert TECH above 300\` • \`${prefix}alert TRB below 40\`\n_I tag you in the group when the price gets there. Up to 5 alerts._`);
        return reply(`🔔 *Your price alerts*\n${r.alerts.map((a) => `▸ *${a.id}* ${a.dir} ${money(a.price)} _(now ${money(a.now)})_`).join('\n')}\n\n▸ \`${prefix}alert clear\``);
      }
      if (args.length < 3) return reply(`🔔 *Usage:* \`${prefix}alert TECH above 300\` or \`${prefix}alert TRB below 40\``);
      const r = market.alertSet(jid, myJid, args[0], (args[1] || '').toLowerCase(), args[2]);
      if (!r.ok) {
        if (r.why === 'already') return reply(`⚠️ *It is already there.* ${args[0].toUpperCase()} is at ${money(r.price)} now.`);
        if (r.why === 'alertmax') return reply(`⚠️ *You can have ${r.max} alerts.* Clear them with \`${prefix}alert clear\``);
        if (r.why === 'amount') return reply(`🔔 *Usage:* \`${prefix}alert TECH above 300\` or \`${prefix}alert TRB below 40\``);
        return reply(why(r, prefix));
      }
      await reply(`🔔 *Alert set*\nI will tag you when *${r.asset.id}* goes *${r.dir}* ${money(r.target)} _(now ${money(r.price)})_.\n▸ \`${prefix}alert list\``);
    },
  },

  // ---------------------------------------------------------------- loans
  {
    ...base,
    name: 'loan',
    aliases: ['borrow'],
    description: 'Borrow coins at interest: loan / loan 2000 (the rate grows when inflation grows)',
    async run(ctx) {
      const { jid, args, reply, myJid, prefix } = ctx;
      if (!(await needOpen(ctx))) return;
      if (args[0]) {
        const r = market.borrow(jid, myJid, args[0]);
        if (!r.ok) return reply(why(r, prefix));
        return reply(`🏦 *Loan approved*\n*Borrowed:* ${coins(r.amount)} coins\n*Fee:* ${coins(r.fee)} coins (${R.loanFee * 100}%)\n*You got:* ${coins(r.got)} coins\n*Interest:* ${r.rate.toFixed(1)}% a day\n*Pay back in:* ${R.loanDays} days\n*Wallet:* ${coins(r.wallet)} coins\n\n_Until it is paid you cannot give coins, gamble or use the bank._ \`${prefix}repay all\``);
      }
      const i = market.loanInfo(jid, myJid);
      const lines = [
        `🏦 *Loan*`,
        i.debt ? `*You owe:* 🔴 ${coins(i.debt)} coins • ${i.overdue ? '*overdue*' : `due in ${dur(i.due - Date.now())}`}` : `*You can borrow up to:* ${coins(i.limit)} coins`,
        `*Interest now:* ${i.rate.toFixed(1)}% a day _(more when inflation is high)_`,
        `*Fee:* ${i.fee * 100}% of the loan • *Term:* ${i.days} days`,
        '',
        i.debt ? `▸ \`${prefix}repay 500\` or \`${prefix}repay all\`` : `▸ \`${prefix}loan 2000\``,
        `_While you owe coins you cannot give, gamble or use the bank. If the debt gets too big for what you own, your investments are sold to pay it. A loan that is not paid after ${i.days} days is taken from everything you have._`,
      ];
      await reply(lines.join('\n'));
    },
  },
  {
    ...base,
    name: 'repay',
    aliases: ['payloan'],
    description: 'Pay back your loan: repay 500 / repay all',
    async run(ctx) {
      const { jid, args, reply, myJid, prefix } = ctx;
      if (!(await needOpen(ctx))) return;
      const r = market.repay(jid, myJid, args[0] || 'all');
      if (!r.ok) return reply(r.why === 'poor' ? `⚠️ *Not enough coins.* You owe ${coins(r.debt)} and your wallet has ${coins(r.wallet)}.` : why(r, prefix));
      await reply(r.left ? `✅ *Loan payment*\n*Paid:* ${coins(r.paid)} coins\n*Still owed:* ${coins(r.left)} coins\n*Wallet:* ${coins(r.wallet)} coins` : `🎉 *Loan paid off!*\n*Paid:* ${coins(r.paid)} coins\n*Wallet:* ${coins(r.wallet)} coins\n_You can give, gamble and bank again._`);
    },
  },

  // ---------------------------------------------------------------- economy: the mood, the ranking and the switches
  {
    ...base,
    name: 'economy',
    aliases: ['eco'],
    description: 'The mood and top investors (admins: economy on / off / news on|off / drops on|off; owner: economy off all)',
    async run(ctx) {
      const { sock, jid, args, reply, myJid, prefix, isAdmin, isOwner, isRealOwner } = ctx;
      const sub = (args[0] || '').toLowerCase();

      if (sub === 'on' || sub === 'open' || sub === 'off' || sub === 'close') {
        const turnOn = sub === 'on' || sub === 'open';
        // the owner can switch EVERY group at once: economy off all / economy on all
        if ((args[1] || '').toLowerCase() === 'all') {
          if (!isRealOwner) return reply('⚠️ *Only the main bot owner can switch every group at once.*');
          const all = new Set([...economy.groupsWithData().keys(), ...Object.keys(market.allGroups())]);
          for (const g of all) {
            economy.setOff(g, !turnOn);
            if (turnOn) market.enable(g);
            else market.disable(g);
          }
          return reply(turnOn ? `✅ *The economy is ON in ${all.size} group${all.size === 1 ? '' : 's'}.*` : `🔒 *The economy is OFF in ${all.size} group${all.size === 1 ? '' : 's'}.* Every economy command is disabled there. Nothing was deleted.`);
        }
        if (!isAdmin && !isOwner) return reply('⚠️ *Only group admins can switch the economy on or off.*');
        if (turnOn) {
          const wasOff = economy.isOff(jid);
          economy.setOff(jid, false);
          store.update(jid, (g) => {
            g.rank = true; // chatting earns coins only when ranks are on
          });
          const r = market.enable(jid);
          if (r.already && !wasOff) return reply(`✅ *The economy is already on here.* See it with \`${prefix}economy\``);
          await reply(
            `🏛️ *The economy is ON – the market is open!*\nThis group has its own economy: coins, jobs, the market, the throne and more. Everything is kept per group.\n\n` +
              `📘 *New here? Send* \`${prefix}guide\` *or* \`${prefix}earn\` *– they show what to do.*\n\n▸ \`${prefix}daily\` • \`${prefix}work\` • \`${prefix}quests\` – earn coins\n▸ \`${prefix}market\` • \`${prefix}picks\` • \`${prefix}invest TECH 500\` – grow them\n▸ \`${prefix}throne\` • \`${prefix}couple\` • \`${prefix}garden\` – more to do\n\n` +
              `_Chatting earns coins too. Market news is posted here; admins can mute it with_ \`${prefix}economy news off\``
          );
          return;
        }
        economy.setOff(jid, true);
        market.disable(jid);
        return reply(`🔒 *The economy is OFF in this group – the market is closed.*\nEvery economy command (coins, jobs, shop, market, throne, couples...) and the market news are stopped. Chatting no longer earns coins and nothing drops.\nNothing was deleted. Turn it on again with \`${prefix}economy on\`.`);
      }

      if (['guide', 'help', 'learn', 'howto'].includes(sub)) return reply(guideText(args[1], prefix));

      if (sub === 'news') {
        if (!isAdmin && !isOwner) return reply('⚠️ *Only group admins can change this.*');
        const v = (args[1] || '').toLowerCase();
        if (v === 'now' || v === 'test') {
          if (!market.isOn(jid)) return reply(closed(prefix));
          return reply(market.digestMessage(jid, prefix).text);
        }
        if (!['on', 'off'].includes(v)) return reply(`*Usage:* \`${prefix}economy news on\` or \`${prefix}economy news off\``);
        if (!market.setNews(jid, v === 'on')) return reply(closed(prefix));
        return reply(v === 'on' ? '✅ *Market news is on.* I post here when the mood changes.' : '🔕 *Market news is off.* The market still runs. Look with the commands.');
      }

      if (sub === 'drops') {
        if (!isAdmin && !isOwner) return reply('⚠️ *Only group admins can change this.*');
        const v = (args[1] || '').toLowerCase();
        if (!['on', 'off'].includes(v)) return reply(`*Usage:* \`${prefix}economy drops on\` or \`${prefix}economy drops off\`\n_Coin drops: now and then a bag of coins drops in an active chat and the first to send *grab* wins it._`);
        economy.setDrops(jid, v === 'on');
        return reply(v === 'on' ? '✅ *Coin drops are on.*' : '🔕 *Coin drops are off.*');
      }

      if (sub === 'mood') {
        if (!isOwner) return reply('⚠️ *Only the bot owner can change the mood.*');
        if (!market.isOn(jid)) return reply(closed(prefix));
        const mood = (args[1] || '').toLowerCase();
        if (!MOODS[mood]) return reply(`*Usage:* \`${prefix}economy mood <${Object.keys(MOODS).join('|')}>\``);
        market.forceMood(jid, mood);
        return reply(market.newsMessage(jid, prefix).text);
      }

      if (sub === 'reset') {
        if (!isOwner) return reply('⚠️ *Only the bot owner can reset a market.*');
        if (!market.state(jid)) return reply('ℹ️ *This group has no market yet.*');
        if ((args[1] || '').toLowerCase() !== 'confirm') return reply(`⚠️ *This deletes every investment, loan and ranking in this group.* Coins in wallets stay.\nWrite \`${prefix}economy reset confirm\` to do it.`);
        market.wipe(jid);
        return reply('✅ *The market of this group was reset.*');
      }

      if (!market.isOn(jid)) return reply(economy.isOff(jid) ? `🔒 *The economy is turned off in this group.* Turn it on with \`${prefix}economy on\`.` : closed(prefix));

      if (sub === 'top' || sub === 'rank' || sub === 'leaders') {
        const week = market.weeklyBoard(jid, 10);
        const rich = market.wealthBoard(jid, 5);
        const hall = market.status(jid).hall.slice(-3).reverse();
        const all = [...week, ...rich, ...hall];
        const who = await names(sock, jid, all);
        const medals = ['🥇', '🥈', '🥉'];
        let at = 0;
        const out = ['🏆 *Top investors*', '', '*This week (profit in %)*'];
        if (!week.length) out.push(`_Nobody yet. Invest ${coins(R.weekMinInvested)}+ coins to join._`);
        week.forEach((e, i) => out.push(`${medals[i] || `${i + 1}.`} ${who.text[at++]}${e.crown ? ' 👑' : ''} – *${pct(e.pct)}* (${gain(e.profit)} coins)`));
        out.push('', '*Richest (everything they own)*');
        rich.forEach((e, i) => out.push(`${medals[i] || `${i + 1}.`} ${who.text[(at++)]} – *${coins(e.total)}* coins`));
        if (hall.length) {
          out.push('', '*Past winners*');
          hall.forEach((h) => out.push(`👑 ${who.text[at++]} – ${pct(h.pct)} (week of ${h.week})`));
        }
        out.push('', `_Every Monday the best profit wins ${coins(R.weekPrizes[0])} coins and the 👑 title. Places 2 and 3 win ${coins(R.weekPrizes[1])} and ${coins(R.weekPrizes[2])}._`);
        return reply(out.join('\n'), { mentions: who.mentions });
      }

      // the default: the state of the economy
      const s = market.status(jid);
      const week = market.weeklyBoard(jid, 3);
      const who = await names(sock, jid, week);
      const medals = ['🥇', '🥈', '🥉'];
      const out = [
        `🏛️ *Economy*`,
        `*Mood:* ${MOOD_LINE(s.def)} (for ${dur(Date.now() - s.since)} so far)`,
        `_"${s.headline}"_`,
        `💡 _${s.def.tip}_`,
        '',
        `*Inflation:* ${s.inflation}% a year`,
        `*Bonds pay:* ${s.bondRate}% a day • *Loans cost:* ${s.loanRate.toFixed(1)}% a day`,
        `*Shop prices:* ${pct((s.shopMult - 1) * 100, 0)} • *Job pay:* ${pct((s.payMult - 1) * 100, 0)}`,
        `*Property:* ${s.propertyIndex.toFixed(3)} ${arrow(s.propertyChange)} ${pct(s.propertyChange)}`,
        `*Next price update:* ${dur(s.nextUpdate - Date.now())} • *Investors:* ${s.players}`,
        '',
        '*Top investors this week*',
      ];
      if (!week.length) out.push(`_Nobody yet. Invest ${coins(R.weekMinInvested)}+ coins to join._`);
      week.forEach((e, i) => out.push(`${medals[i]} ${who.text[i]}${e.crown ? ' 👑' : ''} – *${pct(e.pct)}*`));
      out.push('', `▸ \`${prefix}market\` • \`${prefix}portfolio\` • \`${prefix}economy top\``, `▸ \`${prefix}news economy\` – the latest headline`);
      out.push(`📘 \`${prefix}guide\` – how it all works • \`${prefix}profit\` – am I winning?`);
      if (isAdmin || isOwner) out.push(`_Admins:_ \`${prefix}economy off\` • \`${prefix}economy news off\` • \`${prefix}economy drops off\``);
      await reply(out.join('\n'), { mentions: who.mentions });
    },
  },
];
