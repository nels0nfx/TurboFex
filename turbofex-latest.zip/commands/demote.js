const { changeMembers } = require('../whatsapp/actions');

module.exports = {
  name: 'demote',
  description: 'Remove admin rights from a member (tag them or reply)',
  groupOnly: true,
  adminOnly: true,
  botAdminRequired: true,
  run: (ctx) => changeMembers(ctx, 'demote', 'Demoted'),
};
