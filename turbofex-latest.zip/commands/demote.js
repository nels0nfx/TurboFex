const { changeMembers } = require('../whatsapp/actions');

module.exports = {
  name: 'demote',
  category: 'group',
  description: 'Remove admin rights from a member (tag them or reply)',
  groupOnly: true,
  adminOnly: true,
  botAdminRequired: true,
  run: (ctx) => changeMembers(ctx, 'demote', 'Demoted'),
};
