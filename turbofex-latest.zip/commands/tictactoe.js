const games = require('../whatsapp/play');
const { resolveTarget, selfJid, num } = require('../whatsapp/utils');

module.exports = {
  name: 'tictactoe',
  category: 'games',
  aliases: ['ttt'],
  description: 'Tic-tac-toe: tictactoe @friend, or tictactoe alone to play the bot. Send 1-9 to play',
  async run({ sock, jid, msg, args, reply, prefix, botIds, myIds, myJid, isGroup, isAdmin, isOwner }) {
    const existing = games.get(jid);

    if ((args[0] || '').toLowerCase() === 'end') {
      if (!existing) return reply('ℹ️ There is no game running here.');
      if (isGroup && !isAdmin && !isOwner && !games.canEnd(existing, myIds)) return reply('⚠️ Only the players or a group admin can end the game.');
      games.end(jid);
      return reply('🛑 Game ended.');
    }
    if (existing) return reply(games.busyText(prefix));

    const bot = { jid: selfJid(sock), ids: [], ai: true };
    let opponent;
    if (!isGroup) {
      // private chat: when the owner types it, the other person plays; otherwise the person plays the bot
      opponent = msg.key.fromMe
        ? { jid, ids: [num(jid), num(msg.key.remoteJidAlt)].filter(Boolean) }
        : bot;
    } else {
      const target = resolveTarget(msg, args);
      if (!target || botIds.includes(num(target))) opponent = bot;
      else if (myIds.includes(num(target))) return reply('😅 You cannot play against yourself.');
      else opponent = { jid: target, ids: [num(target)] };
    }

    const game = games.begin(jid, games.ttt.create({ jid: myJid, ids: myIds }, opponent), myIds);
    const mentions = [myJid, ...(opponent.ai ? [] : [opponent.jid])];
    await reply(games.ttt.intro(game), { mentions });
  },
};
