const games = require('../whatsapp/games');
const { resolveTarget, memberIds, num } = require('../whatsapp/utils');

module.exports = {
  name: 'tictactoe',
  category: 'fun',
  aliases: ['ttt'],
  description: 'Play tic-tac-toe against a friend: tictactoe @friend, then send 1-9',
  groupOnly: true,
  async run({ jid, msg, args, reply, prefix, botIds, isAdmin, isOwner }) {
    const existing = games.get(jid);
    const myIds = memberIds(msg);

    if ((args[0] || '').toLowerCase() === 'end') {
      if (!existing) return reply('ℹ️ There is no game running here.');
      const playing = games.isPlayer(existing.x, myIds) || games.isPlayer(existing.o, myIds);
      if (!playing && !isAdmin && !isOwner) return reply('⚠️ Only the players or a group admin can end the game.');
      games.end(jid);
      return reply('🛑 Game ended.');
    }

    if (existing) return reply(`⚠️ A game is already running here. Finish it, or type ${prefix}tictactoe end`);

    const target = resolveTarget(msg, args);
    if (!target) return reply(`Tag the friend you want to play against.\nExample: ${prefix}tictactoe @friend`);
    if (botIds.includes(num(target))) return reply("🤖 I'd win every time. Pick a human!");
    if (myIds.includes(num(target))) return reply('😅 You cannot play against yourself.');

    const x = { jid: msg.key.participant, ids: myIds };
    const o = { jid: target, ids: [num(target)] };
    const g = games.start(jid, x, o);
    await reply(
      `🎮 *Tic-Tac-Toe*\n@${num(x.jid)} (❌) vs @${num(o.jid)} (⭕)\n\n${games.render(g.board)}\n\n@${num(x.jid)} goes first. Send a number from 1 to 9 to play.`,
      { mentions: [x.jid, o.jid] }
    );
  },
};
