const { groupByCategory } = require('../whatsapp/categories');

module.exports = {
  name: 'list',
  category: 'general',
  description: 'List every command with a short description',
  async run({ reply, commandList, prefix, isOwner }) {
    const text = groupByCategory(commandList, isOwner)
      .map((s) => `*${s.meta.icon} ${s.meta.title}*\n${s.cmds.map((c) => `• ${prefix}${c.name} - ${c.description}`).join('\n')}`)
      .join('\n\n');
    await reply(text);
  },
};
