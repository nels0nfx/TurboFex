const pkg = require('../package.json');
const brand = require('../core/brand');
const store = require('../whatsapp/store');
const { info, map, rank } = require('../whatsapp/categories');

const catOf = (c) => c.category || map[c.name] || 'other';
const meta = (key) => info[key] || { title: key.toUpperCase(), icon: '📦' };

function uptime() {
  const s = Math.floor(process.uptime());
  const d = Math.floor(s / 86400);
  const h = Math.floor((s % 86400) / 3600);
  const m = Math.floor((s % 3600) / 60);
  if (d) return `${d}d ${h}h ${m}m`;
  if (h) return `${h}h ${m}m`;
  return `${m}m ${s % 60}s`;
}

function box(key, lines) {
  const { icon, title } = meta(key);
  return `╭─「 ${icon} ${title} 」\n${lines.map((l) => `│ ➜ ${l}`).join('\n')}\n╰──────────────`;
}

module.exports = {
  name: 'menu',
  aliases: ['help'],
  description: 'Show the command menu (try: menu protection, or menu kick)',
  async run({ reply, commandList, config, prefix, args, isOwner }) {
    const visible = commandList
      .filter((c) => isOwner || !c.ownerOnly)
      .sort((a, b) => (rank[a.name] ?? 999) - (rank[b.name] ?? 999) || a.name.localeCompare(b.name));

    const groups = {};
    for (const c of visible) (groups[catOf(c)] = groups[catOf(c)] || []).push(c);
    const order = Object.keys(info).filter((k) => groups[k]);
    for (const k of Object.keys(groups)) if (!order.includes(k)) order.push(k);

    const query = (args[0] || '').toLowerCase().replace(/^[^a-z0-9]+/, '');

    // !menu <category>
    if (query && order.includes(query)) {
      const lines = groups[query].map((c) => `${prefix}${c.name} - ${c.description}`);
      return reply(box(query, lines));
    }

    // !menu <command>
    if (query) {
      const c = visible.find((x) => x.name === query || (x.aliases || []).includes(query));
      if (!c) return reply(`Nothing found for "${query}". Type ${prefix}menu to see everything.`);

      const who = c.ownerOnly ? 'Bot owner only' : c.adminOnly ? 'Group admins' : 'Everyone';
      const where = c.groupOnly ? 'Groups only' : 'Groups and private chat';
      const alias = (c.aliases || []).length
        ? `\nAlso works as: ${c.aliases.map((a) => prefix + a).join(', ')}`
        : '';
      const needs = c.botAdminRequired ? '\nThe bot must be a group admin.' : '';
      return reply(
        `📖 *${prefix}${c.name}*\n${c.description}${alias}\n\n👤 Who can use it: ${who}\n📍 Works in: ${where}${needs}`
      );
    }

    // Full menu
    const head =
      `╭━━ ⚡ *${brand.botName.toUpperCase()}* ⚡ ━━\n` +
      `┃ 👑 Owner    : ${brand.creator}\n` +
      `┃ 🔣 Prefix   : ${prefix}\n` +
      `┃ 🔐 Mode     : ${store.getMode() === 'private' ? 'Private' : 'Public'}\n` +
      `┃ 📦 Version  : v${pkg.version}\n` +
      `┃ ⏱️ Uptime   : ${uptime()}\n` +
      `┃ 🧩 Commands : ${visible.length}\n` +
      `╰━━━━━━━━━━━━━━━━━━`;

    const body = order.map((k) => box(k, groups[k].map((c) => `${prefix}${c.name}`))).join('\n\n');
    const tip =
      `💡 ${prefix}menu <category> for details\n` +
      `   Categories: ${order.join(', ')}\n` +
      `💡 ${prefix}menu <command> for help on one command`;

    return reply(`${head}\n\n${body}\n\n${tip}`);
  },
};
