const os = require('os');
const pkg = require('../package.json');
const brand = require('../core/brand');
const clock = require('../core/clock');
const store = require('../whatsapp/store');
const { groupByCategory } = require('../whatsapp/categories');

function box(section, lines) {
  return `╭─「 ${section.meta.icon} ${section.meta.title} 」\n${lines.map((l) => `│ ➜ ${l}`).join('\n')}\n╰──────────────`;
}

module.exports = {
  name: 'menu',
  category: 'general',
  aliases: ['help'],
  description: 'Show the command menu (try: menu group, or menu kick)',
  async run({ reply, commandList, prefix, args, isOwner, isAdmin }) {
    const sections = groupByCategory(commandList, isOwner);
    const all = sections.flatMap((s) => s.cmds);
    const query = (args[0] || '').toLowerCase().replace(/^[^a-z0-9]+/, '');

    // !menu <category>
    const section = sections.find((s) => s.key === query);
    if (query && section) {
      return reply(box(section, section.cmds.map((c) => `${prefix}${c.name} - ${c.description}`)));
    }

    // !menu <command>
    if (query) {
      const c = all.find((x) => x.name === query || (x.aliases || []).includes(query));
      if (!c) return reply(`Nothing found for "${query}". Type ${prefix}menu to see everything.`);

      const who = c.realOwnerOnly ? 'Main bot owner only' : c.ownerOnly ? 'Bot owner only' : c.adminOnly ? 'Group admins' : 'Everyone';
      const where = c.groupOnly ? 'Groups only' : 'Groups and private chat';
      const alias = (c.aliases || []).length ? `\nAlso works as: ${c.aliases.map((a) => prefix + a).join(', ')}` : '';
      const needs = c.botAdminRequired ? '\nThe bot must be a group admin.' : '';
      return reply(
        `📖 *${prefix}${c.name}*\n${c.description}${alias}\n\n👤 Who can use it: ${who}\n📍 Works in: ${where}${needs}`
      );
    }

    // Full menu
    const now = clock.parts();
    const role = isOwner ? 'Owner' : isAdmin ? 'Group admin' : 'Member';
    const ram = Math.round(process.memoryUsage().rss / 1048576);
    const head =
      `╭━━ ⚡ *${brand.botName.toUpperCase()}* ⚡ ━━\n` +
      `┃ 👤 You       : ${role}\n` +
      `┃ 🔣 Prefix    : ${prefix}\n` +
      `┃ 🔐 Mode      : ${store.getMode() === 'private' ? 'Private' : 'Public'}\n` +
      `┃ 🕒 Time      : ${now.time}\n` +
      `┃ 📅 Date      : ${now.day}, ${now.date}\n` +
      `┃ 📦 Version   : v${pkg.version}\n` +
      `┃ 🧩 Commands  : ${all.length}\n` +
      `┃ 💾 RAM       : ${ram} MB\n` +
      `┃ ⏱️ Uptime    : ${clock.uptime()}\n` +
      `┃ 🖥️ Platform  : ${os.type()} • Node ${process.versions.node}\n` +
      `╰━━━━━━━━━━━━━━━━━━`;

    const body = sections.map((s) => box(s, s.cmds.map((c) => `${prefix}${c.name}`))).join('\n\n');
    const tip =
      `💡 ${prefix}menu <category> for details\n` +
      `   Categories: ${sections.map((s) => s.key).join(', ')}\n` +
      `💡 ${prefix}menu <command> for help on one command\n` +
      `💡 ${prefix}list shows every command with its description\n` +
      `💡 ${prefix}support for help, channels and updates`;

    return reply(`${head}\n\n${body}\n\n${tip}`);
  },
};
