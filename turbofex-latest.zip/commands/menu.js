const os = require('os');
const pkg = require('../package.json');
const brand = require('../core/brand');
const clock = require('../core/clock');
const { smallcaps: sc, bold } = require('../core/fonts');
const store = require('../whatsapp/store');
const { groupByCategory } = require('../whatsapp/categories');

// one category: a framed block, one command per line with a symbol (no prefix in front)
function block(section, lines) {
  const m = section.meta;
  return `╭───❮ ${m.icon} *${sc(m.title)}* ❯\n${lines.map((l) => `│ ${m.symbol} ${l}`).join('\n')}\n╰──────────────`;
}

module.exports = {
  name: 'menu',
  category: 'general',
  aliases: ['help'],
  description: 'Show the command menu (try: menu group, or menu kick)',
  async run({ reply, commandList, prefix, args, isOwner, isAdmin }) {
    const sections = groupByCategory(commandList, isOwner);
    const all = sections.flatMap((s) => s.cmds);
    const query = (args[0] || '').toLowerCase().replace(/^[^a-z0-9]+/, '');

    // menu <category>: every command of it with its description
    const section = sections.find((s) => s.key === query);
    if (query && section) {
      return reply(block(section, section.cmds.map((c) => `*${sc(c.name)}*\n│    ${c.description}`)));
    }

    // menu <command>: help for one command
    if (query) {
      const c = all.find((x) => x.name === query || (x.aliases || []).includes(query));
      if (!c) return reply(`🔎 Nothing found for "${query}".\nType *${prefix}menu* to see everything.`);

      const who = c.realOwnerOnly ? 'Main bot owner only' : c.ownerOnly ? 'Bot owner only' : c.adminOnly ? 'Group admins' : 'Everyone';
      const where = c.groupOnly ? 'Groups only' : 'Groups and private chat';
      const alias = (c.aliases || []).length ? `\n│ ◦ ${sc('also')} : ${c.aliases.map((a) => prefix + a).join(', ')}` : '';
      const needs = c.botAdminRequired ? `\n│ ◦ ${sc('bot must be admin')}` : '';
      return reply(
        `╭───❮ 📖 *${sc(c.name)}* ❯\n` +
          `│ ${c.description}\n` +
          `│\n` +
          `│ ◦ ${sc('use')}   : ${prefix}${c.name}\n` +
          `│ ◦ ${sc('who')}   : ${who}\n` +
          `│ ◦ ${sc('where')} : ${where}${alias}${needs}\n` +
          `╰──────────────`
      );
    }

    // Full menu
    const now = clock.parts();
    const role = isOwner ? 'Owner' : isAdmin ? 'Group admin' : 'Member';
    const rows = [
      ['ᴜꜱᴇʀ', role],
      ['ᴘʀᴇꜰɪx', prefix],
      ['ᴍᴏᴅᴇ', store.getMode() === 'private' ? 'Private' : 'Public'],
      ['ᴛɪᴍᴇ', now.time],
      ['ᴅᴀᴛᴇ', `${now.day}, ${now.date}`],
      ['ᴠᴇʀꜱɪᴏɴ', `v${pkg.version}`],
      ['ᴄᴏᴍᴍᴀɴᴅꜱ', String(all.length)],
      ['ᴜᴘᴛɪᴍᴇ', clock.uptime()],
    ];
    // technical details are for the owner only
    if (isOwner) rows.push(['ʀᴀᴍ', `${Math.round(process.memoryUsage().rss / 1048576)} MB`], ['ᴘʟᴀᴛꜰᴏʀᴍ', `${os.type()} • Node ${process.versions.node}`]);

    const head =
      `┏━━━━━━━━━━━━━━━━━━━━\n` +
      `┃  ⚡ ${bold(brand.botName.toUpperCase())} ⚡\n` +
      `┃  ${sc('whatsapp assistant')}\n` +
      `┣━━━━━━━━━━━━━━━━━━━━\n` +
      rows.map(([k, v]) => `┃ ◈ ${k} ⟶ ${v}`).join('\n') +
      `\n┗━━━━━━━━━━━━━━━━━━━━`;

    const body = sections.map((s) => block(s, s.cmds.map((c) => sc(c.name)))).join('\n\n');

    const tip =
      `✦ *${prefix}menu* <${sc('category')}> ➜ ${sc('details')}\n` +
      `✦ *${prefix}menu* <${sc('command')}> ➜ ${sc('help for one command')}\n` +
      `✦ *${prefix}list* ➜ ${sc('every command with its description')}\n` +
      `✦ *${prefix}support* ➜ ${sc('help, channels and updates')}\n\n` +
      `${sc('categories')}: ${sections.map((s) => s.key).join(' • ')}\n\n` +
      `> ${sc('powered by')} ${sc(brand.botName)}`;

    return reply(`${head}\n\n${body}\n\n${tip}`);
  },
};
