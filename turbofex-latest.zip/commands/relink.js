// Switches how the bot shows up in WhatsApp "Linked devices" and links it again. With the "android" identity WhatsApp
// also sends view-once pictures and videos to the bot. The bot is logged out and must be linked again once.
const fs = require('fs');
const config = require('../config');
const store = require('../whatsapp/store');
const bootnote = require('../core/bootnote');
const { restartBot } = require('../core/restart');

module.exports = {
  name: 'relink',
  category: 'owner',
  realOwnerOnly: true,
  noReact: true,
  description: 'Link the bot again with the "android" identity so it can receive view-once files: relink android (or relink default to go back)',
  async run({ args, reply, prefix, jid }) {
    const mode = (args[0] || '').toLowerCase();
    const confirmed = (args[1] || '').toLowerCase() === 'confirm';
    if (mode !== 'android' && mode !== 'default') {
      const now = store.getBrowser() || config.browser || 'default';
      return reply(`🔗 *Linked-device identity:* ${now}\n\n${prefix}relink android - the bot can receive view-once files\n${prefix}relink default - the normal identity (Chrome on Ubuntu)\n\nThe bot is logged out and you link it again once.`);
    }
    if (!confirmed) {
      return reply(
        `⚠️ *${prefix}relink ${mode}* logs the bot OUT of WhatsApp and restarts it.\n\n` +
          `Afterwards you must link it again:\n` +
          `1. Open the console (logs) of your bot host.\n` +
          `2. ${config.pairingNumber ? `A pairing code is shown for ${config.pairingNumber}.` : 'A QR code is shown (or set PAIRING_NUMBER to get a code instead).'}\n` +
          `3. WhatsApp > Linked devices > Link a device, then scan the QR or enter the code.\n\n` +
          `Your settings are kept. To go ahead send:\n*${prefix}relink ${mode} confirm*`
      );
    }
    store.setBrowser(mode === 'android' ? 'android' : null);
    bootnote.write({ type: 'restart', chat: jid });
    await reply('🔗 Logging out and restarting. Link the bot again from the console, then I will message you here.');
    try {
      fs.rmSync(config.sessionDir, { recursive: true, force: true });
    } catch (err) {
      // the login is cleared at start anyway
    }
    restartBot();
  },
};
