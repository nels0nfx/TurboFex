const store = require('../whatsapp/store');
const clock = require('../core/clock');

const MAX_PER_CHAT = 10;

module.exports = {
  name: 'schedule',
  category: 'tools',
  description: 'Send a message every day at a time: schedule 18:30 Dinner time! (once 18:30 text = one time)',
  async run({ jid, rest, reply, prefix, isGroup, isAdmin, isOwner }) {
    if (isGroup && !(isAdmin || isOwner)) return reply('⚠️ Only group admins can schedule messages.');

    const m = /^(once\s+)?(\d{1,2}:\d{2})\s+([\s\S]+)$/i.exec(rest);
    const time = m && clock.parseHHMM(m[2]);
    if (!m || !time) {
      return reply(`Write the time (24-hour) and the message.\nEvery day: ${prefix}schedule 18:30 Dinner time!\nOne time: ${prefix}schedule once 18:30 Meeting now\n\nTime zone: ${clock.zone()}`);
    }
    const text = m[3].trim();
    if (text.length > 1000) return reply('⚠️ That message is too long (max 1000 characters).');
    if (store.schedules().filter((s) => s.jid === jid).length >= MAX_PER_CHAT) {
      return reply(`⚠️ This chat already has ${MAX_PER_CHAT} scheduled messages. Remove one with ${prefix}unschedule <number>`);
    }

    const item = store.addSchedule({ jid, time, text, once: !!m[1] });
    await reply(`✅ Scheduled #${item.id}: ${item.once ? 'once' : 'every day'} at *${time}* (${clock.zone()} time).\nRemove it with ${prefix}unschedule ${item.id}`);
  },
};
