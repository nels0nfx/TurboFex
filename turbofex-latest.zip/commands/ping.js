const brand = require('../core/brand');
const clock = require('../core/clock');

module.exports = {
  name: 'ping',
  category: 'general',
  description: 'Check if the bot is online and how fast it answers (with a breakdown)',
  async run({ sock, jid, reply, timing }) {
    const think = Date.now() - timing.receivedAt; // inside the bot, before replying
    const start = Date.now();
    const sent = await reply('🏓 Pinging...');
    const sendMs = Date.now() - start; // time WhatsApp took to accept my reply

    const lines = [
      '🏓 Pong!',
      `⚡ Reply speed: ${sendMs} ms`,
      `🧠 Bot thinking: ${think} ms`,
    ];
    if (timing.deliveryMs != null && timing.deliveryMs < 60000) lines.push(`📡 Delivery to bot: ${timing.deliveryMs} ms`);
    lines.push(`🕒 Uptime: ${clock.uptime()}`, `🤖 ${brand.botName} is online`);
    const text = lines.join('\n');

    try {
      await sock.sendMessage(jid, { text, edit: sent.key });
    } catch (err) {
      await reply(text);
    }
  },
};
