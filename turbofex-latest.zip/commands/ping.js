const brand = require('../core/brand');

module.exports = {
  name: 'ping',
  description: 'Check if the bot is online and how fast it responds',
  async run({ sock, jid, reply }) {
    const start = Date.now();
    const sent = await reply('🏓 Pinging...');
    const ms = Date.now() - start;

    const s = Math.floor(process.uptime());
    const uptime = `${Math.floor(s / 3600)}h ${Math.floor((s % 3600) / 60)}m ${s % 60}s`;
    const text = `🏓 Pong!\n⚡ Speed: ${ms} ms\n🕒 Uptime: ${uptime}\n🤖 ${brand.botName} is online`;

    try {
      await sock.sendMessage(jid, { text, edit: sent.key });
    } catch (err) {
      await reply(text);
    }
  },
};
