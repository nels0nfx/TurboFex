module.exports = {
  name: 'ping',
  category: 'general',
  description: 'Check if the bot is online and how fast it answers',
  async run({ sock, jid, reply, timing }) {
    const start = Date.now();
    const sent = await reply('🏓 Pinging...');
    const ms = timing.thinkMs + (Date.now() - start); // from the command arriving to my reply being sent
    const text = `🏓 *Pong!*  ⚡ ${ms} ms`;
    try {
      await sock.sendMessage(jid, { text, edit: sent.key });
    } catch (err) {
      await reply(text);
    }
  },
};
