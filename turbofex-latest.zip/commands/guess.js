const games = require('../whatsapp/play');

module.exports = {
  name: 'guess',
  category: 'games',
  description: 'Guess the number from 1 to 100: everyone in the chat can play',
  async run({ jid, reply, prefix, myIds }) {
    if (games.get(jid)) return reply(games.busyText(prefix));
    const game = games.begin(jid, games.guess.create(), myIds);
    await reply(games.guess.intro(game));
  },
};
