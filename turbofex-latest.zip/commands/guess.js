const games = require('../whatsapp/play');

module.exports = {
  name: 'guess',
  category: 'games',
  description: 'Guess the number from 1 to 100: everyone can play, e.g. guess or guess 5 (rounds)',
  async run({ sock, jid, args, reply, prefix, myIds }) {
    if (games.get(jid)) return reply(games.busyText(prefix));
    const rounds = games.parseRounds(args, 3);
    const game = games.start({ sock, jid, game: games.guess.create(), starterIds: myIds, rounds });
    await reply(games.guess.intro(game) + games.seriesNote(game, prefix));
  },
};
