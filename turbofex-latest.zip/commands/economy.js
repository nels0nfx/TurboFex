// Coins: balance, daily, give, gamble, shop, buy, richest. Coins are earned by chatting (groups with ranks on), the daily bonus and games.
const economy = require('../core/economy');
const names = require('../whatsapp/names');
const mentionsLib = require('../whatsapp/mentions');
const { resolveTarget, num, selfJid } = require('../whatsapp/utils');

const { fmt } = economy;
const base = { category: 'games', everyone: true, needs: [], weight: 'light' };

const left = (ms) => {
  const h = Math.floor(ms / 3600000);
  const m = Math.ceil((ms % 3600000) / 60000);
  return h ? `${h}h ${m}m` : `${m}m`;
};
const amountOf = (args, from) => {
  const word = (args.slice(from).find((a) => /^(all|\d[\d,_]*)$/i.test(a)) || '').toLowerCase();
  return word;
};

const lastGamble = new Map();

module.exports = [
  {
    ...base,
    name: 'balance',
    aliases: ['bal', 'wallet', 'coins'],
    description: 'Your coins (or someone else\'s: balance @user)',
    async run({ msg, args, reply, myJid, prefix }) {
      const target = resolveTarget(msg, args) || myJid;
      const u = economy.peek(target);
      const mine = num(target) === num(myJid);
      const owner = mine ? 'Your balance' : `Balance of ${names.get(target) || 'this member'}`;
      await reply(
        `💰 *${owner}*\n` +
          `*Coins:* ${fmt(u.coins)}${u.title ? `  ${u.title}` : ''}\n` +
          (u.streak > 1 ? `*Daily streak:* ${u.streak} days 🔥\n` : '') +
          (economy.hasCharm(target) ? '🍀 *Lucky Charm* is active\n' : '') +
          (mine ? `\n_Earn and spend coins:_ \`${prefix}daily\` • \`${prefix}gamble\` • \`${prefix}shop\` • \`${prefix}richest\`` : '')
      );
    },
  },
  {
    ...base,
    name: 'daily',
    description: 'Collect your daily coins (more every day in a row)',
    async run({ reply, myJid }) {
      const r = economy.daily(myJid);
      if (!r.ok) return reply(`⏳ *You already collected today.* Come back in *${left(r.waitMs)}*.`);
      await reply(`🎁 *Daily bonus*\n*Earned:* +${fmt(r.amount)} coins\n*Streak:* ${r.streak} day${r.streak > 1 ? 's' : ''} 🔥 _(every day in a row pays more)_\n*Total:* ${fmt(r.coins)} coins`);
    },
  },
  {
    ...base,
    name: 'give',
    aliases: ['pay', 'send'],
    description: 'Give coins to someone: give @user 100',
    async run({ msg, args, reply, myJid, botIds, prefix }) {
      const target = resolveTarget(msg, args);
      const raw = amountOf(args, 0);
      if (!target || !raw) return reply(`*Usage:* \`${prefix}give @user 100\` _(or reply to their message)_`);
      const amount = raw === 'all' ? economy.balance(myJid) : parseInt(raw.replace(/[,_]/g, ''), 10);
      if (num(target) === num(myJid)) return reply('😅 *You cannot give coins to yourself.*');
      if (botIds.includes(num(target))) return reply('🤖 *I do not need coins, thank you!*');
      if (!Number.isInteger(amount) || amount < 1) return reply('⚠️ *Give at least 1 coin.*');
      if (!economy.transfer(myJid, target, amount)) return reply(`⚠️ *You only have ${fmt(economy.balance(myJid))} coins.*`);
      await reply(`✅ *Coins sent*\n*To:* @${num(target)}\n*Amount:* ${fmt(amount)} coins\n*Your balance:* ${fmt(economy.balance(myJid))}`, { mentions: [target] });
    },
  },
  {
    ...base,
    name: 'gamble',
    aliases: ['bet'],
    description: 'Bet coins: win and you double the bet, lose and you lose it (gamble 100 or gamble all)',
    async run({ args, reply, myJid, prefix }) {
      const raw = amountOf(args, 0);
      if (!raw) return reply(`🎲 *Gamble*\n*Usage:* \`${prefix}gamble 100\` or \`${prefix}gamble all\`\n*Win:* double your bet\n*Odds:* 45% _(50% with a 🍀 Lucky Charm)_\n*Smallest bet:* 10 coins`);
      if (Date.now() - (lastGamble.get(num(myJid)) || 0) < 6000) return reply('⏳ *Slow down.* Wait a few seconds between bets.');
      lastGamble.set(num(myJid), Date.now());
      if (lastGamble.size > 5000) lastGamble.clear();
      const bet = raw === 'all' ? Math.min(economy.balance(myJid), 100000) : parseInt(raw.replace(/[,_]/g, ''), 10);
      if (bet > 100000) return reply('⚠️ *The highest bet is 100,000 coins.*');
      const r = economy.gamble(myJid, bet);
      if (!r.ok) return reply(r.why === 'min' ? '⚠️ *The smallest bet is 10 coins.*' : `⚠️ *You only have ${fmt(economy.balance(myJid))} coins.*`);
      await reply(r.win ? `🎉 *You won!*\n*Won:* +${fmt(bet)} coins\n*Balance:* ${fmt(r.coins)}` : `💸 *You lost.*\n*Lost:* ${fmt(bet)} coins\n*Balance:* ${fmt(r.coins)}`);
    },
  },
  {
    ...base,
    name: 'shop',
    description: 'See what you can buy with coins',
    async run({ reply, prefix }) {
      const lines = Object.entries(economy.ITEMS).map(([id, i]) => `▸ *${i.name}* – ${fmt(i.price)} coins\n   _${i.about}_\n   \`${prefix}buy ${id}\``);
      await reply(`🛒 *Shop*\n\n${lines.join('\n\n')}`);
    },
  },
  {
    ...base,
    name: 'buy',
    description: 'Buy something from the shop: buy vip',
    async run({ args, reply, myJid, prefix }) {
      const id = (args[0] || '').toLowerCase();
      if (!id) return reply(`*Usage:* \`${prefix}buy <item>\`\nSee the items with \`${prefix}shop\``);
      const r = economy.buy(myJid, id);
      if (r.ok) return reply(`✅ *Bought ${r.item.name}!*\n*Balance:* ${fmt(economy.balance(myJid))} coins`);
      const why = { unknown: `⚠️ *There is no item "${id.slice(0, 20)}".* See \`${prefix}shop\``, active: '🍀 *Your Lucky Charm is still active.*', owned: '✅ *You already have that title.*', poor: `⚠️ *You need ${fmt(r.need || 0)} more coins.*` };
      await reply(why[r.why]);
    },
  },
  {
    ...base,
    name: 'richest',
    aliases: ['rich', 'wealth'],
    description: 'The people with the most coins',
    async run({ sock, jid, isGroup, reply, prefix }) {
      const top = economy.richest(10);
      if (!top.length) return reply(`💰 *Nobody has coins yet.* Start with \`${prefix}daily\``);
      const medals = ['🥇', '🥈', '🥉'];
      // in a group the members are tagged (WhatsApp shows their name); in a private chat the name is written
      const who = isGroup ? await mentionsLib.describe(sock, jid, top.map((r) => r.jid)) : top.map((r) => ({ text: names.label(r.jid), mention: null }));
      const lines = top.map((r, i) => `${medals[i] || `${i + 1}.`} ${who[i].text}${r.title ? ` ${r.title}` : ''} – *${fmt(r.coins)}* coins`);
      await reply(`💰 *Richest*\n\n${lines.join('\n')}`, { mentions: who.map((w) => w.mention).filter(Boolean) });
    },
  },
];
