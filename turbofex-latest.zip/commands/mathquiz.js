const games = require('../whatsapp/play');

module.exports = {
  name: 'mathquiz',
  category: 'games',
  aliases: ['math'],
  description: 'Quick maths for everyone: mathquiz, mathquiz hard, or mathquiz medium 8 (rounds)',
  async run({ sock, jid, args, reply, prefix, myIds }) {
    if (games.get(jid)) return reply(games.busyText(prefix));
    const words = args.map((a) => a.toLowerCase());
    const level = ['easy', 'medium', 'hard'].find((l) => words.includes(l)) || 'easy';
    const rounds = games.parseRounds(args, 5);
    const game = games.start({
      sock, jid, game: games.mathquiz.create({ level }), starterIds: myIds, rounds, options: { level },
    });
    await reply(games.mathquiz.intro(game) + games.seriesNote(game, prefix));
  },
};
