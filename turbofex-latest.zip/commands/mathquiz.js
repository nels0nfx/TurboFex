const games = require('../whatsapp/play');

module.exports = {
  name: 'mathquiz',
  category: 'games',
  aliases: ['math'],
  description: 'Quick maths: mathquiz easy / medium / hard. First correct answer wins',
  async run({ jid, args, reply, prefix, myIds }) {
    if (games.get(jid)) return reply(games.busyText(prefix));
    const level = ['easy', 'medium', 'hard'].includes((args[0] || '').toLowerCase()) ? args[0].toLowerCase() : 'easy';
    const game = games.begin(jid, games.mathquiz.create(level), myIds);
    await reply(games.mathquiz.intro(game));
  },
};
