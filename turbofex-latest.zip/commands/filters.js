const store = require('../whatsapp/store');
const { listText } = require('../whatsapp/filtercmd');

module.exports = {
  name: 'filters',
  category: 'autoreply',
  description: 'Show the auto-replies set up in this group',
  groupOnly: true,
  async run({ jid, reply }) {
    const globalCount = Object.keys(store.getGlobalFilters()).length;
    const extra = globalCount ? `\n\n🌍 Plus ${globalCount} auto-repl${globalCount === 1 ? 'y' : 'ies'} set by the bot owner for all chats.` : '';
    await reply(listText(store.getGroup(jid).filters, 'Auto-replies in this group') + extra);
  },
};
