// Things to do every day besides gambling: quests, the throne and predictions. All of it is per group, with the group's coins.
const economy = require('../core/economy');
const quests = require('../core/quests');
const throne = require('../core/throne');
const predict = require('../core/predict');
const { num } = require('../whatsapp/utils');

const { fmt } = economy;
const base = { category: 'economy', everyone: true, groupOnly: true, needs: [], weight: 'light' };
const dur = (ms) => {
  const m = Math.max(1, Math.ceil(ms / 60000));
  if (m < 60) return `${m}m`;
  const h = Math.floor(m / 60);
  if (h < 48) return `${h}h ${m % 60}m`;
  return `${Math.floor(h / 24)}d ${h % 24}h`;
};
const bar = (n, of) => '▰'.repeat(Math.round((n / of) * 5)) + '▱'.repeat(5 - Math.round((n / of) * 5));
// 30m, 2h, 1d, 1w -> milliseconds (or null)
const span = (t) => {
  const m = /^(\d+)(m|h|d|w)$/i.exec(String(t || ''));
  return m ? Number(m[1]) * { m: 60000, h: 3600000, d: 86400000, w: 604800000 }[m[2].toLowerCase()] : null;
};
const amountOf = (t) => {
  const m = /^(\d[\d,_]*)(k)?$/i.exec(String(t || ''));
  return m ? Math.round(parseInt(m[1].replace(/[,_]/g, ''), 10) * (m[2] ? 1000 : 1)) : NaN;
};
const tag = (jid) => `@${num(jid)}`;

module.exports = [
  {
    ...base,
    name: 'quests',
    aliases: ['quest', 'missions'],
    description: 'Your 3 quests of the day: finish them for coins (all 3 pay a bonus)',
    async run({ jid, reply, myJid, prefix }) {
      const s = quests.status(jid, myJid);
      const lines = s.quests.map((q) => `${q.done ? '✅' : q.icon} *${q.text}*\n   ${bar(q.progress, q.n)} ${q.progress}/${q.n} • *+${q.reward} coins*${q.done ? ' ✔' : ''}`);
      const w = s.week;
      await reply(
        `🎯 *Quests of today*\n_The same for everybody in this group. New ones every day._\n\n${lines.join('\n\n')}\n\n` +
          `🏆 *All 3:* bonus *+${s.sweepReward} coins* ${s.sweep ? '✅ got it' : ''}\n` +
          `🌟 *This week:* ${w.count}/${w.need} quests done → *+${w.reward} coins* ${w.paid ? '✅ got it' : ''}\n\n` +
          `_Coins are paid by themselves when you finish. Try_ \`${prefix}daily\` • \`${prefix}work\` • \`${prefix}throne\` • \`${prefix}predict\``
      );
    },
  },

  {
    ...base,
    name: 'throne',
    aliases: ['king', 'crownme'],
    description: 'Be the king of the group: throne / throne take / throne collect / throne decree <text>',
    async run(ctx) {
      const { jid, args, reply, myJid, prefix } = ctx;
      const sub = (args[0] || '').toLowerCase();
      const i = throne.info(jid);
      if (sub === 'take' || sub === 'buy' || sub === 'claim') {
        const r = throne.take(jid, myJid);
        if (!r.ok) {
          if (r.why === 'already') return reply('👑 *You are already the king.* Keep it as long as you can!');
          if (r.why === 'debt') return reply(`🔒 *You have a loan.* Repay it first (\`${prefix}repay\`).`);
          return reply(`⚠️ *The throne costs ${fmt(r.price)} coins.* You have ${fmt(r.wallet)}.`);
        }
        const p = r.prev;
        await reply(
          `👑 *${tag(myJid)} is the new king!*\n*Paid:* ${fmt(r.price)} coins\n` +
            (p ? `*${tag(p.jid)}* was dethroned and got *${fmt(r.prevGot + r.prevIncome)}* coins back.\n` : '') +
            `*Next price:* ${fmt(r.next)} coins _(it slides down by itself every hour)_\n*King income:* ${throne.RULES.incomePerHour} coins every hour → \`${prefix}throne collect\`\n_Set your word with_ \`${prefix}throne decree <text>\``,
          { mentions: [myJid, p?.jid].filter(Boolean) }
        );
        return;
      }
      if (sub === 'collect') {
        const r = throne.collect(jid, myJid);
        if (!r.ok) return reply(r.why === 'nothing' ? '⏳ *Nothing to collect yet.* The king earns every hour.' : `⚠️ *Only the king can collect.* Take the throne with \`${prefix}throne take\``);
        return reply(`👑 *King's income collected*\n*Got:* +${fmt(r.amount)} coins\n*Wallet:* ${fmt(r.wallet)} coins`);
      }
      if (sub === 'decree' || sub === 'say') {
        const r = throne.decree(jid, myJid, args.slice(1).join(' '));
        if (!r.ok) return reply(r.why === 'empty' ? `*Usage:* \`${prefix}throne decree <your words>\`` : '⚠️ *Only the king can write a decree.*');
        return reply(`📜 *The king has spoken:*\n_"${r.decree}"_`);
      }
      const R = throne.RULES;
      const head = i.king
        ? `👑 *King:* ${tag(i.king.jid)} _(on the throne for ${dur(Date.now() - i.since)})_\n${i.decree ? `📜 _"${i.decree}"_\n` : ''}*Waiting for the king:* ${fmt(i.waiting)} coins`
        : '👑 *The throne is empty!* Be the first king.';
      await reply(
        `🏰 *The Throne*\n\n${head}\n\n*Price to take it:* ${fmt(i.price)} coins\n▸ The old king gets ${Math.round(R.payback * 100)}% of the price back, so being dethroned is not a loss\n▸ The king earns *${R.incomePerHour} coins an hour*\n▸ The price slides down every hour\n\n▸ \`${prefix}throne take\` • \`${prefix}throne collect\` • \`${prefix}throne decree <text>\``,
        { mentions: [i.king?.jid].filter(Boolean) }
      );
    },
  },

  {
    ...base,
    name: 'predict',
    aliases: ['prediction', 'predictions'],
    description: 'Bet coins on a yes/no question: predict / predict yes 1 200 / predict new 2d Will it rain on Saturday?',
    async run(ctx) {
      const { jid, args, reply, myJid, prefix, isAdmin, isOwner } = ctx;
      const sub = (args[0] || '').toLowerCase();
      const R = predict.RULES;
      const view = (it) => {
        const p = it.pool || predict.poolOf(it);
        const left = it.closes - Date.now();
        return `*#${it.id}* ${it.q}\n   ✅ YES ${fmt(p.yes)} • ❌ NO ${fmt(p.no)} • ${left > 0 ? `closes in ${dur(left)}` : '🔒 betting closed, waiting for the answer'}`;
      };

      if (sub === 'new' || sub === 'ask' || sub === 'create') {
        if (!isAdmin && !isOwner) return reply('⚠️ *Only group admins can ask a question.*');
        const d = span(args[1]);
        const text = args.slice(2).join(' ');
        if (!d || !text) return reply(`🔮 *Usage:* \`${prefix}predict new 2d Will Nigeria win on Saturday?\`\n_The time is how long people can bet (30m, 6h, 2d, 1w)._`);
        const r = predict.create(jid, myJid, text, d);
        if (!r.ok) return reply(r.why === 'many' ? `⚠️ *There are already ${r.max} open questions.*` : r.why === 'short' ? '⚠️ *Write a longer question.*' : '⚠️ *The time must be between 1 minute and 30 days.*');
        return reply(`🔮 *New prediction #${r.id}*\n_${text.replace(/\s+/g, ' ').slice(0, R.questionMax)}_\n\n*Betting closes in:* ${dur(d)}\n▸ \`${prefix}predict yes ${r.id} 200\`\n▸ \`${prefix}predict no ${r.id} 200\`\n_Winners share the pool. The person who asked cannot bet._`);
      }
      if (sub === 'yes' || sub === 'no') {
        const id = Number(args[1]);
        const amount = amountOf(args[2]);
        if (!id || !(amount > 0)) return reply(`🔮 *Usage:* \`${prefix}predict ${sub} <number> <coins>\`\n*Example:* \`${prefix}predict ${sub} 1 200\` _(smallest ${R.minStake}, most ${fmt(R.maxStake)})_`);
        const r = predict.stake(jid, myJid, id, sub, amount);
        if (!r.ok) {
          const m = {
            none: `⚠️ *There is no open question #${id}.* See \`${prefix}predict\``,
            closed: '🔒 *Betting is closed* for that one.',
            creator: '⚠️ *You asked the question, so you cannot bet on it.*',
            debt: `🔒 *You have a loan.* Repay it first (\`${prefix}repay\`).`,
            otherside: '⚠️ *You already bet on the other side* of this one.',
            min: `⚠️ *The smallest bet is ${R.minStake} coins.*`,
            max: `⚠️ *The most is ${fmt(R.maxStake)} coins on one question* (you put ${fmt(r.have || 0)}).`,
            poor: `⚠️ *Not enough coins.* You have ${fmt(r.wallet || 0)}.`,
          }[r.why];
          return reply(m || '⚠️ *That did not work.*');
        }
        const x = r.payoutPerCoin;
        return reply(`🔮 *Bet placed on ${sub.toUpperCase()}* (#${id})\n*Your total on ${sub.toUpperCase()}:* ${fmt(r.total)} coins\n*Pool:* ✅ ${fmt(r.pool.yes)} • ❌ ${fmt(r.pool.no)}\n${x ? `_If ${sub.toUpperCase()} wins now you get about ×${x.toFixed(2)} back._` : ''}\n_Win or lose, the admin settles it when the answer is known._`);
      }
      if (sub === 'resolve' || sub === 'settle' || sub === 'end') {
        const id = Number(args[1]);
        const out = (args[2] || '').toLowerCase();
        if (!id || !['yes', 'no'].includes(out)) return reply(`🔮 *Usage:* \`${prefix}predict resolve <number> yes|no\``);
        const r = predict.settle(jid, myJid, id, out, isOwner);
        if (!r.ok) return reply(r.why === 'notyours' ? '⚠️ *Only the person who asked (or the bot owner) can settle it.*' : r.why === 'none' ? `⚠️ *There is no open question #${id}.*` : '⚠️ *Say yes or no.*');
        if (r.refunded) return reply(`🔮 *#${id} settled: ${out.toUpperCase()}*\n_Nobody was on the other side, so every bet was given back._`);
        const top = r.winners.slice(0, 5).map((w) => `▸ ${tag(w.jid)} put ${fmt(w.stake)} → *+${fmt(w.got - w.stake)}* profit`);
        return reply(`🔮 *Prediction #${id} settled: ${out.toUpperCase()}* ${out === 'yes' ? '✅' : '❌'}\n_${r.item.q}_\n\n*Pool:* ${fmt(r.pool.total)} coins • *Winners:* ${r.winners.length}\n${top.join('\n')}`, { mentions: r.winners.slice(0, 5).map((w) => w.jid) });
      }
      if (sub === 'cancel') {
        const id = Number(args[1]);
        const r = predict.cancel(jid, myJid, id, isOwner);
        if (!r.ok) return reply(r.why === 'notyours' ? '⚠️ *Only the person who asked (or the bot owner) can cancel it.*' : `⚠️ *There is no open question #${id || '?'}.*`);
        return reply(`🔮 *#${id} cancelled.* ${r.players} ${r.players === 1 ? 'person' : 'people'} got the coins back.`);
      }
      const open = predict.list(jid);
      if (!open.length) return reply(`🔮 *Predictions*\n_No open questions now._\n\n▸ Admins: \`${prefix}predict new 2d Will it rain on Saturday?\`\n_Everybody bets coins on YES or NO. When the answer is known the admin settles it and the winners share the pool._`);
      await reply(`🔮 *Predictions*\n\n${open.map(view).join('\n\n')}\n\n▸ \`${prefix}predict yes <number> <coins>\` • \`${prefix}predict no <number> <coins>\`\n_Winners share the pool (5% is taken). Admins settle with_ \`${prefix}predict resolve <number> yes|no\``, { mentions: [] });
    },
  },
];
