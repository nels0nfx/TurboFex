const store = require('../whatsapp/store');
const { memberIds, num } = require('../whatsapp/utils');

module.exports = {
  name: 'afk',
  category: 'tools',
  description: 'Mark yourself away: afk gone for lunch (I tell people who mention you)',
  groupOnly: true,
  async run({ msg, rest, reply }) {
    const ids = memberIds(msg);
    if (!ids.length) return reply('⚠️ I could not tell who you are.');
    store.afkSet(ids, rest.slice(0, 100));
    await reply(`😴 @${num(ids[0])} is now AFK${rest ? `: ${rest.slice(0, 100)}` : ''}\nI will tell people who mention you, and welcome you back when you write again.`, {
      mentions: [msg.key.participant],
    });
  },
};
