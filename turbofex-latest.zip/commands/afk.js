const store = require('../whatsapp/store');
const { num } = require('../whatsapp/utils');

module.exports = {
  name: 'afk',
  category: 'tools',
  description: 'Mark yourself away: afk gone for lunch (I answer people who mention or message you)',
  async run({ rest, reply, myIds, myJid, isGroup }) {
    if (!myIds.length) return reply('⚠️ I could not tell who you are.');
    const reason = rest.slice(0, 100);
    store.afkSet(myIds, reason);
    const why = reason ? `: ${reason}` : '';
    if (isGroup) {
      return reply(`😴 @${num(myJid)} is now AFK${why}\nI will tell people who mention you, and welcome you back when you write again.`, {
        mentions: [myJid],
      });
    }
    return reply(`😴 You are now AFK${why}\nI will tell people who mention you in groups or message you privately. It switches off when you write again.`);
  },
};
