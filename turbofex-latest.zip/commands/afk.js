const store = require('../whatsapp/store');
const clock = require('../core/clock');
const { num } = require('../whatsapp/utils');

module.exports = {
  name: 'afk',
  category: 'tools',
  description: 'Away mode: afk on <reason> / afk off (I answer people who mention or message you)',
  async run({ rest, args, reply, prefix, myIds, myJid, isGroup }) {
    if (!myIds.length) return reply('⚠️ I could not tell who you are.');
    const first = (args[0] || '').toLowerCase();
    const current = store.afkGet(myIds);

    if (first === 'off') {
      if (!current) return reply('ℹ️ You were not AFK.');
      store.afkDel(myIds);
      return reply(`✅ AFK is now *OFF*. You were away for ${clock.duration(Date.now() - current.since)}.`);
    }

    // "afk" alone shows the status
    if (!first) {
      const status = current
        ? `😴 You are *AFK*${current.reason ? `: ${current.reason}` : ''} (for ${clock.duration(Date.now() - current.since)}).`
        : '🟢 You are *not* AFK.';
      return reply(`${status}\n\nTurn on: ${prefix}afk on gone for lunch\nTurn off: ${prefix}afk off`);
    }

    // "afk on lunch" or just "afk lunch"
    const reason = (first === 'on' ? rest.slice(2) : rest).trim().slice(0, 100);
    store.afkSet(myIds, reason);
    const why = reason ? `: ${reason}` : '';
    if (isGroup) {
      return reply(
        `😴 @${num(myJid)} is now AFK${why}\nI will tell people who mention you or message you, and switch AFK off when you write again. (Or type ${prefix}afk off)`,
        { mentions: [myJid] }
      );
    }
    return reply(`😴 AFK is now *ON*${why}\nI will tell people who mention you in groups or message you privately. It switches off when you write again, or with ${prefix}afk off`);
  },
};
