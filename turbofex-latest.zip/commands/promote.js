const { changeMembers } = require('../whatsapp/actions');

module.exports = {
  name: 'promote',
  description: 'Make a member an admin (tag them or reply)',
  groupOnly: true,
  adminOnly: true,
  botAdminRequired: true,
  run: (ctx) => changeMembers(ctx, 'promote', 'Promoted to admin'),
};
