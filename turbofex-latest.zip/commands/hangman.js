const games = require('../whatsapp/play');

module.exports = {
  name: 'hangman',
  category: 'games',
  description: 'Hangman for everyone: guess letters, e.g. hangman or hangman 5 (rounds)',
  async run({ sock, jid, args, reply, prefix, myIds }) {
    if (games.get(jid)) return reply(games.busyText(prefix));
    const rounds = games.parseRounds(args, 5);
    const game = games.start({ sock, jid, game: games.hangman.create(), starterIds: myIds, rounds });
    await reply(games.hangman.intro(game) + games.seriesNote(game, prefix));
  },
};
