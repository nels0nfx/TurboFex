const games = require('../whatsapp/play');

module.exports = {
  name: 'hangman',
  category: 'games',
  description: 'Hangman: guess the word one letter at a time',
  async run({ jid, reply, prefix, myIds }) {
    if (games.get(jid)) return reply(games.busyText(prefix));
    const game = games.begin(jid, games.hangman.create(), myIds);
    await reply(games.hangman.intro(game));
  },
};
