const store = require('../whatsapp/store');
const { removeFilter } = require('../whatsapp/filtercmd');

module.exports = {
  name: 'stop',
  category: 'autoreply',
  aliases: ['unfilter'],
  description: 'Remove an auto-reply from this group: stop hello (admins only)',
  groupOnly: true,
  adminOnly: true,
  run: (ctx) => removeFilter(ctx, store.getGroup(ctx.jid).filters, () => store.update(ctx.jid, () => {})),
};
