const MOVES = { rock: '🪨', paper: '📄', scissors: '✂️' };
const ALIASES = { r: 'rock', p: 'paper', s: 'scissors' };
const BEATS = { rock: 'scissors', paper: 'rock', scissors: 'paper' };

module.exports = {
  name: 'rps',
  category: 'games',
  description: 'Rock paper scissors against the bot: rps rock',
  async run({ args, reply, prefix }) {
    const raw = (args[0] || '').toLowerCase();
    const mine = ALIASES[raw] || raw;
    if (!MOVES[mine]) return reply(`Pick one: ${prefix}rps rock | paper | scissors`);

    const names = Object.keys(MOVES);
    const bot = names[Math.floor(Math.random() * names.length)];
    const result = mine === bot ? "🤝 It's a draw!" : BEATS[mine] === bot ? '🎉 You win!' : '🤖 I win!';
    await reply(`You: ${MOVES[mine]} ${mine}\nMe: ${MOVES[bot]} ${bot}\n\n${result}`);
  },
};
