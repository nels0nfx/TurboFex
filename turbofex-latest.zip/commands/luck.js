// Owner tools for the coin economy: luck (the gamble chance of one person) and ecoboost (pay, chat coins and shop prices).
const economy = require('../core/economy');
const groups = require('../whatsapp/groups');
const { resolveTarget, num } = require('../whatsapp/utils');

const base = { category: 'owner', realOwnerOnly: true, needs: [], weight: 'light' };

const DURATION = /^(\d+)\s*(m|min|h|hr|hrs|d|day|days|w)$/i;
const UNIT = { m: 60000, min: 60000, h: 3600000, hr: 3600000, hrs: 3600000, d: 86400000, day: 86400000, days: 86400000, w: 604800000 };
const span = (ms) => {
  const m = Math.round(ms / 60000);
  if (m < 60) return `${m} minute${m === 1 ? '' : 's'}`;
  if (m < 2880) return `${Math.round(m / 60)} hour${Math.round(m / 60) === 1 ? '' : 's'}`;
  return `${Math.round(m / 1440)} days`;
};
const isNumberToken = (t) => /^@?\+?\d{7,15}$/.test(t);

// where to apply: the group named, the current group, or every group (null)
async function whereOf(sock, words, isGroup, jid) {
  const text = words.join(' ').trim();
  if (/^(all|everywhere|any)$/i.test(text)) return { group: null, name: 'all groups' };
  if (text) {
    const g = await groups.resolve(sock, text);
    return g ? { group: g.jid, name: g.name } : { error: `⚠️ *I could not find a group called "${text.slice(0, 30)}".* Use the number from the groups list, or part of the group name.` };
  }
  if (isGroup) return { group: jid, name: 'this group' };
  return { group: null, name: 'all groups' };
}

module.exports = [
  {
    ...base,
    name: 'luck',
    aliases: ['setluck', 'gambleodds'],
    description: 'Owner: set the gamble chance of someone: luck 2348012345678 80 (also 1d, and a group) / luck off / luck list',
    async run({ sock, msg, args, reply, jid, isGroup, prefix }) {
      const first = (args[0] || '').toLowerCase();

      if (first === 'list') {
        const rows = economy.luckList();
        if (!rows.length) return reply('🍀 *Nobody has special luck.*');
        const names = {};
        try {
          for (const g of await groups.list(sock)) names[g.jid] = g.name;
        } catch (err) {
          // the group names are only a nicety
        }
        return reply(`🍀 *Special luck*\n\n${rows.map((r) => `▸ *${r.key}* – ${Math.round(r.chance * 100)}% • ${r.group ? names[r.group] || r.group : 'all groups'} • ${r.until ? `${span(r.until - Date.now())} left` : 'until removed'}`).join('\n')}\n\n_Remove with_ \`${prefix}luck off <number>\``);
      }

      const target = resolveTarget(msg, args);
      const off = first === 'off' || first === 'remove' || first === 'clear';
      if (!target) {
        return reply(
          `🍀 *Luck*\n_Change the gamble chance of one person. They are not told. Normal chance is 45%._\n\n*Usage:*\n▸ \`${prefix}luck 2348012345678 80\` – 80% in every group\n▸ \`${prefix}luck 2348012345678 70 1d\` – for one day (also 30m, 2h, 1w)\n▸ \`${prefix}luck 2348012345678 90 1\` – only in group number 1 of \`${prefix}gjids\`\n▸ \`${prefix}luck @user 80\` – in a group: this group only\n▸ \`${prefix}luck off 2348012345678\` – back to normal\n▸ \`${prefix}luck list\``
        );
      }
      const rest = args.filter((a) => !isNumberToken(a) && !/^@/.test(a) && !['off', 'remove', 'clear'].includes(a.toLowerCase()));

      if (off) {
        const where = await whereOf(sock, rest, isGroup, jid);
        if (where.error) return reply(where.error);
        const had = economy.clearLuck(target, args.some((a) => /^(all|everywhere)$/i.test(a)) ? null : where.group);
        return reply(had ? `✅ *Luck removed* for @${num(target)}.` : `ℹ️ *@${num(target)} had no special luck.*`, { mentions: [target] });
      }

      const chanceWord = rest.find((a) => /^\d{1,3}(\.\d+)?%?$/.test(a));
      if (!chanceWord) return reply(`⚠️ *Write the chance (1 to 100).* Example: \`${prefix}luck 2348012345678 80\``);
      const chance = parseFloat(chanceWord) / 100;
      if (!(chance > 0 && chance <= 1)) return reply('⚠️ *The chance must be between 1 and 100.*');
      let until = null;
      const words = rest.filter((a) => a !== chanceWord);
      const dWord = words.find((a) => DURATION.test(a));
      if (dWord) {
        const m = DURATION.exec(dWord);
        until = Date.now() + Number(m[1]) * UNIT[m[2].toLowerCase()];
      }
      const left = words.filter((a) => a !== dWord && !/^(forever|always|permanent)$/i.test(a));
      const where = await whereOf(sock, left, isGroup, jid);
      if (where.error) return reply(where.error);
      economy.setLuck(target, where.group, chance, until);
      await reply(
        `🍀 *Luck set*\n*Person:* @${num(target)}\n*Gamble chance:* ${Math.round(chance * 100)}% _(normal 45%)_\n*Where:* ${where.name}\n*For:* ${until ? span(until - Date.now()) : 'until you remove it'}\n\n_They are not told. Only the gamble command uses it._`,
        { mentions: [target] }
      );
    },
  },
  {
    ...base,
    name: 'ecoboost',
    aliases: ['ecoset', 'economyset'],
    description: 'Owner: make coins easier or harder to earn: ecoboost pay 1.5 / shop 0.5 / chat 2 / reset',
    async run({ args, reply, prefix }) {
      const what = (args[0] || '').toLowerCase();
      const show = () => {
        const c = economy.getCfg();
        return `⚙️ *Economy settings*\n*Pay* (work, fish, hunt, mine, daily): ×${c.pay}\n*Chat coins:* ×${c.chat}\n*Shop prices:* ×${c.shop}\n\n▸ \`${prefix}ecoboost pay 1.5\` – 50% more pay\n▸ \`${prefix}ecoboost shop 0.5\` – everything in the shop half price\n▸ \`${prefix}ecoboost chat 2\` – double coins for chatting\n▸ \`${prefix}ecoboost reset\` – back to normal\n_Applies to every group. Between 0.1 and 20._`;
      };
      if (!what) return reply(show());
      if (what === 'reset') {
        economy.resetCfg();
        return reply(`✅ *Back to normal.*\n\n${show()}`);
      }
      if (!economy.setCfg(what, args[1])) return reply(`⚠️ *Use:* \`${prefix}ecoboost pay|shop|chat <number between 0.1 and 20>\``);
      await reply(`✅ *Updated.*\n\n${show()}`);
    },
  },
];
