const store = require('../whatsapp/store');
const { addFilter } = require('../whatsapp/filtercmd');

module.exports = {
  name: 'filter',
  category: 'autoreply',
  description: 'Auto-reply to a word in this group: filter hello | Hi there! (admins only)',
  groupOnly: true,
  adminOnly: true,
  run: (ctx) => addFilter(ctx, store.getGroup(ctx.jid).filters, () => store.update(ctx.jid, () => {})),
};
