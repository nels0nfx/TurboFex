// Owner automation: autotyping, autorecording, alwaysonline, autoread, autobio, autoreact, pmblocker
const store = require('../whatsapp/store');
const presence = require('../whatsapp/presence');

const base = { category: 'owner', ownerOnly: true, needs: [], weight: 'light' };
const word = (args) => (args[0] || '').toLowerCase();
const state = (v) => (v ? 'ON' : 'OFF');

// the common on/off command
const toggle = (name, key, label, about, aliases = [], after = null) => ({
  ...base,
  name,
  aliases,
  description: `${about} (on / off)`,
  async run({ args, reply, prefix, sock }) {
    const w = word(args);
    if (w !== 'on' && w !== 'off') return reply(`⚙️ *${label}*\n*Status:* ${state(store.getAuto(key))}\n_${about}_\n\n*Use:* \`${prefix}${name} on\` or \`${prefix}${name} off\``);
    store.setAuto(key, w === 'on');
    if (after) after(sock, w === 'on');
    await reply(`✅ *${label} is now ${state(w === 'on')}.*`);
  },
});

module.exports = [
  toggle('autotyping', 'typing', 'Auto typing', 'Shows "typing..." while the bot prepares an answer', ['typing'], (s, on) => on && store.setAuto('recording', false)),
  toggle('autorecording', 'recording', 'Auto recording', 'Shows "recording audio..." while the bot prepares an answer', ['recording'], (s, on) => on && store.setAuto('typing', false)),
  toggle('alwaysonline', 'online', 'Always online', 'Keeps the bot showing as online', ['online'], (sock, on) => {
    presence.apply(sock);
    if (!on) sock.sendPresenceUpdate('unavailable').catch(() => {});
  }),
  toggle('autoread', 'read', 'Auto read', 'Marks every message the bot receives as read (blue ticks)', ['read']),
  {
    ...base,
    name: 'autobio',
    description: 'Keep the bot bio updated with the time: autobio on / off / set <text with {time} {date}>',
    async run({ args, rest, reply, prefix, sock }) {
      const cfg = store.getAuto('bio') || { on: false, text: null };
      const w = word(args);
      if (w === 'set') {
        const text = rest.replace(/^set\s*/i, '').trim();
        if (!text) return reply(`*Usage:* \`${prefix}autobio set 🤖 Online • {time} • {date}\``);
        store.setAuto('bio', { ...cfg, text: text.slice(0, 139) });
        presence.apply(sock);
        return reply(`✅ *Bio text saved.*\n*It reads:* ${presence.fillBio(text)}${cfg.on ? '' : `\n_Turn it on with_ \`${prefix}autobio on\``}`);
      }
      if (w === 'on' || w === 'off') {
        store.setAuto('bio', { ...cfg, on: w === 'on' });
        presence.apply(sock);
        return reply(`✅ *Auto bio is now ${state(w === 'on')}.*${w === 'on' ? '\n_It updates every 10 minutes._' : ''}`);
      }
      await reply(`📝 *Auto bio*\n*Status:* ${state(cfg.on)}\n*Text:* ${cfg.text || presence.DEFAULT_BIO}\n\n▸ \`${prefix}autobio on\` / \`${prefix}autobio off\`\n▸ \`${prefix}autobio set <text>\` _(use {time}, {date}, {day})_`);
    },
  },
  {
    ...base,
    name: 'autoreact',
    description: 'React to messages with an emoji: autoreact on / off / emojis ❤️ 😂 🔥',
    async run({ args, reply, prefix }) {
      const cfg = store.getAuto('react') || { on: false, emojis: [] };
      const w = word(args);
      if (w === 'emojis') {
        const list = args.slice(1).filter((e) => e.length <= 8).slice(0, 12);
        if (!list.length) return reply(`*Usage:* \`${prefix}autoreact emojis ❤️ 😂 🔥\` _(or "reset")_`);
        store.setAuto('react', { ...cfg, emojis: /^reset$/i.test(list[0]) ? [] : list });
        return reply(/^reset$/i.test(list[0]) ? '✅ *Back to the default emojis.*' : `✅ *Emojis saved:* ${list.join(' ')}`);
      }
      if (w === 'on' || w === 'off') {
        store.setAuto('react', { ...cfg, on: w === 'on' });
        return reply(`✅ *Auto react is now ${state(w === 'on')}.*${w === 'on' ? '\n_At most one reaction every 20 seconds in each chat._' : ''}`);
      }
      await reply(`😀 *Auto react*\n*Status:* ${state(cfg.on)}\n*Emojis:* ${(cfg.emojis?.length ? cfg.emojis : presence.DEFAULT_EMOJIS).join(' ')}\n\n▸ \`${prefix}autoreact on\` / \`${prefix}autoreact off\`\n▸ \`${prefix}autoreact emojis ❤️ 😂 🔥\``);
    },
  },
  {
    ...base,
    name: 'pmblocker',
    aliases: ['pmblock', 'antipm'],
    description: 'Strangers writing to the bot in private: pmblocker off / warn / block',
    async run({ args, reply, prefix }) {
      const w = word(args);
      if (!['off', 'warn', 'block'].includes(w)) {
        const cur = store.getAuto('pm', 'off');
        return reply(
          `🚫 *Private message blocker*\n*Status:* ${cur.toUpperCase()}\n\n` +
            `▸ \`${prefix}pmblocker warn\` – tell strangers the bot does not answer private messages (once a day)\n` +
            `▸ \`${prefix}pmblocker block\` – warn, and block them if they write again\n` +
            `▸ \`${prefix}pmblocker off\`\n\n_You and your sudo users are never affected. Group chats are not affected._`
        );
      }
      store.setAuto('pm', w);
      await reply(`✅ *Private message blocker is now ${w.toUpperCase()}.*`);
    },
  },
];
