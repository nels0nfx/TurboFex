const store = require('../whatsapp/store');

module.exports = {
  name: 'ratelimit',
  aliases: ['limit'],
  category: 'security',
  ownerOnly: true,
  noReact: true,
  needs: [],
  weight: 'light',
  description: 'How many commands one person may use per minute: ratelimit 20 / on / off',
  async run({ args, reply, prefix }) {
    const a = (args[0] || '').toLowerCase();
    if (a === 'on' || a === 'off') {
      store.updateRate((r) => {
        r.on = a === 'on';
      });
      return reply(`✅ Rate limit is now *${a.toUpperCase()}*.`);
    }
    const n = parseInt(a, 10);
    if (a && Number.isFinite(n)) {
      if (n < 1 || n > 120) return reply('⚠️ Choose a number between 1 and 120 commands per minute.');
      store.updateRate((r) => {
        r.limit = n;
      });
      return reply(`✅ Each person can use *${n}* commands per minute.`);
    }
    const r = store.rateCfg();
    return reply(`*Rate limit:* ${r.on ? 'ON' : 'OFF'}\n▸ *Per person:* ${r.limit} commands per minute\n▸ *After the limit:* 30 seconds pause\n▸ The owner is never limited.\n\n▸ \`${prefix}ratelimit 20\`\n▸ \`${prefix}ratelimit off\``);
  },
};
