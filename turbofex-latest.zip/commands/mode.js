const store = require('../whatsapp/store');

module.exports = {
  name: 'mode',
  category: 'owner',
  description: 'Set the bot to public or private (owner only)',
  ownerOnly: true,
  async run({ args, reply, prefix, config }) {
    const choice = (args[0] || '').toLowerCase();

    if (choice !== 'public' && choice !== 'private') {
      return reply(
        `🤖 Bot mode: *${store.getMode().toUpperCase()}*\n\n` +
          `• ${prefix}mode public - everyone can use commands\n` +
          `• ${prefix}mode private - only the owner can use commands (people can still play games that are running)`
      );
    }
    if (choice === 'private' && !config.ownerNumber) {
      return reply('⚠️ Set ownerNumber in config.js first, otherwise nobody could use the bot.');
    }

    store.setMode(choice);
    return reply(
      choice === 'private'
        ? '🔒 Bot is now *PRIVATE*. Only the owner can use commands.\n(Games in progress, auto-replies, AFK notices, anti-link, welcome and goodbye still work for everyone.)'
        : '🔓 Bot is now *PUBLIC*. Everyone can use commands.'
    );
  },
};
