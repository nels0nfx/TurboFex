const SYMBOLS = ['🍒', '🍋', '🍊', '🍇', '🔔', '⭐', '7️⃣'];

module.exports = {
  name: 'slots',
  category: 'games',
  description: 'Spin the slot machine',
  async run({ reply }) {
    const pick = () => SYMBOLS[Math.floor(Math.random() * SYMBOLS.length)];
    const [a, b, c] = [pick(), pick(), pick()];
    const result = a === b && b === c ? '🎉 JACKPOT!' : a === b || b === c || a === c ? '😮 So close! Two match.' : '😅 No match. Try again!';
    await reply(`🎰 *Slots*\n\n| ${a} | ${b} | ${c} |\n\n${result}`);
  },
};
