const { resolveTarget, num } = require('../whatsapp/utils');

module.exports = {
  name: 'block',
  category: 'owner',
  description: 'Block a person on WhatsApp (tag, reply, number, or use it in their chat) (owner only)',
  ownerOnly: true,
  async run({ sock, jid, msg, args, reply, isGroup, botIds, config }) {
    const target = resolveTarget(msg, args) || (!isGroup ? jid : null);
    if (!target) return reply('Tag the person, reply to them, or type their number.');
    if (botIds.includes(num(target)) || num(target) === config.ownerNumber) return reply('⚠️ I will not block that one.');
    await sock.updateBlockStatus(target, 'block');
    await reply(`🚫 Blocked @${num(target)}`, { mentions: [target] });
  },
};
