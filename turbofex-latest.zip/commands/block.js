const { resolveTarget, jidVariants, num } = require('../whatsapp/utils');
const { setBlock } = require('../whatsapp/blocklist');

module.exports = {
  name: 'block',
  category: 'owner',
  description: 'Block a person on WhatsApp (tag, reply, number, or use it in their private chat) (owner only)',
  ownerOnly: true,
  async run({ sock, jid, msg, args, reply, isGroup, botIds, config, groupMetadata }) {
    const target = resolveTarget(msg, args) || (!isGroup ? jid : null);
    if (!target) return reply('Tag the person, reply to them, type their number, or use this in their private chat.');
    if (botIds.includes(num(target)) || num(target) === config.ownerNumber) return reply('⚠️ I will not block that one.');

    const candidates = [target];
    if (isGroup) candidates.push(...jidVariants(groupMetadata, target));
    else if (msg.key.remoteJidAlt) candidates.push(msg.key.remoteJidAlt);

    const res = await setBlock(sock, [...new Set(candidates)], 'block');
    if (!res.ok) {
      console.error('Block failed:', res.error);
      return reply(`⚠️ WhatsApp would not let me block that number.\nReason: ${String(res.error?.message || res.error).slice(0, 120)}`);
    }
    await reply(`🚫 Blocked @${num(target)}`, { mentions: [target] });
  },
};
