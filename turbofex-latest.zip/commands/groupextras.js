// More group tools: antibot, antitag, tagadmins, exportrank, silence, unsilence, mutelist
const store = require('../whatsapp/store');
const levels = require('../whatsapp/levels');
const names = require('../whatsapp/names');
const mentionsLib = require('../whatsapp/mentions');
const meta = require('../whatsapp/metadata');
const { setActionMode } = require('../whatsapp/actions');
const { getTargets, num } = require('../whatsapp/utils');

const base = { category: 'group', groupOnly: true, needs: [], weight: 'light' };

module.exports = [
  {
    ...base,
    name: 'antibot',
    adminOnly: true,
    description: 'Other bots writing in the group: off / delete / warn / kick (admins only)',
    run: (ctx) => setActionMode(ctx, { key: 'antibotMode', label: 'Anti-bot', trigger: 'looks like another bot (best-effort guess from how its messages are built)' }),
  },
  {
    ...base,
    name: 'antitag',
    adminOnly: true,
    description: 'Mass tagging: antitag off / delete / warn / kick, antitag limit 8 (admins only)',
    async run(ctx) {
      const { jid, args, reply } = ctx;
      if ((args[0] || '').toLowerCase() === 'limit') {
        const n = parseInt(args[1], 10);
        if (!Number.isInteger(n) || n < 2 || n > 100) return reply('⚠️ *Choose a number from 2 to 100.* Example: `antitag limit 8`');
        store.update(jid, (g) => {
          g.antitagLimit = n;
        });
        return reply(`✅ *Anti-tag limit set to ${n}.* _A message that tags ${n} or more people counts as mass tagging._`);
      }
      await setActionMode(ctx, { key: 'antitagMode', label: `Anti-tag (limit ${store.getGroup(jid).antitagLimit} people)`, trigger: 'tags too many people in one message' });
    },
  },
  {
    ...base,
    name: 'tagadmins',
    aliases: ['admintag', 'calladmins'],
    description: 'Tag all the admins of the group (add a message if you like)',
    async run({ sock, jid, rest, reply }) {
      const info = await meta.getMeta(sock, jid);
      const admins = (info?.participants || []).filter((p) => p.admin).map((p) => p.id);
      if (!admins.length) return reply('⚠️ I could not find the admins of this group.');
      await sock.sendMessage(jid, { text: `📢 *Admins*${rest ? `\n_${rest.slice(0, 500)}_` : ''}\n\n${admins.map((a) => `@${num(a)}`).join(' ')}`, mentions: admins });
    },
  },
  {
    ...base,
    name: 'exportrank',
    aliases: ['rankfile'],
    adminOnly: true,
    description: 'Send the group ranking (level and XP of every member) as a spreadsheet file (admins only)',
    async run({ sock, jid, msg, reply, groupMetadata }) {
      const list = levels.board(jid);
      if (!list.length) return reply('📊 *Nobody has XP yet.* Turn ranks on with `rank on` and chat for a while.');
      const q = (s) => `"${String(s).replace(/"/g, '""')}"`;
      const rows = list.map(([key, v], i) => {
        const jidOf = v.j || `${key}@s.whatsapp.net`;
        return [i + 1, q(names.get(jidOf) || ''), q(names.phoneOf(jidOf) || ''), v.x, levels.level(v.x)].join(',');
      });
      const csv = `Position,Name,Phone,XP,Level\n${rows.join('\n')}\n`;
      const file = `rank-${String(groupMetadata?.subject || 'group').replace(/[^\w-]+/g, '_').slice(0, 30)}.csv`;
      await sock.sendMessage(jid, { document: Buffer.from(`\ufeff${csv}`, 'utf8'), mimetype: 'text/csv', fileName: file, caption: `📊 Ranking of ${list.length} member(s)` }, { quoted: msg });
    },
  },
  {
    ...base,
    name: 'silence',
    aliases: ['mutemember'],
    adminOnly: true,
    botAdminRequired: true,
    description: 'Delete every message of a member until you unsilence them: silence @user (admins only)',
    async run({ msg, reply, botIds, prefix }) {
      const targets = getTargets(msg).filter((t) => !botIds.includes(num(t)));
      if (!targets.length) return reply(`*Usage:* \`${prefix}silence @person\` _(or reply to their message)_`);
      const keys = targets.map((t) => levels.keyOf(t));
      store.update(msg.key.remoteJid, (g) => {
        for (const k of keys) if (!g.silenced.includes(k)) g.silenced.push(k);
        g.silenceTold = g.silenceTold.filter((k) => !keys.includes(k)); // they are told again the first time they write
      });
      await reply(`🤫 *Silenced*\n*Members:* ${targets.map((t) => `@${num(t)}`).join(' ')}\n_Their messages are deleted. Admins are never affected._\nUndo it with \`${prefix}unsilence\``, { mentions: targets });
    },
  },
  {
    ...base,
    name: 'unsilence',
    aliases: ['unmutemember'],
    adminOnly: true,
    description: 'Let a silenced member write again: unsilence @user (admins only)',
    async run({ msg, reply, prefix }) {
      const targets = getTargets(msg);
      if (!targets.length) return reply(`*Usage:* \`${prefix}unsilence @person\` _(or reply to their message)_`);
      const keys = targets.map((t) => levels.keyOf(t));
      store.update(msg.key.remoteJid, (g) => {
        g.silenced = g.silenced.filter((k) => !keys.includes(k));
        g.silenceTold = g.silenceTold.filter((k) => !keys.includes(k));
      });
      await reply(`🔊 *They can write again*\n*Members:* ${targets.map((t) => `@${num(t)}`).join(' ')}`, { mentions: targets });
    },
  },
  {
    ...base,
    name: 'mutelist',
    aliases: ['silenced'],
    adminOnly: true,
    description: 'Who is silenced in this group (admins only)',
    async run({ sock, jid, reply }) {
      const g = store.getGroup(jid);
      if (!g.silenced.length) return reply('🔊 *Nobody is silenced in this group.*');
      const who = await mentionsLib.describe(sock, jid, g.silenced.map((k) => `${k}@s.whatsapp.net`));
      await reply(`🤫 *Silenced members* (${g.silenced.length})\n\n${who.map((w) => `▸ ${w.text}`).join('\n')}`, { mentions: who.map((w) => w.mention).filter(Boolean) });
    },
  },
];
