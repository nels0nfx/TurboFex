// Forex: trade made-up currencies with leverage. Not real money, not real currencies. See core/forex.js.
const market = require('../core/market');
const economy = require('../core/economy');
const quests = require('../core/quests');
const forex = require('../core/forex');
const { CUR, RULES: FR } = forex;
const { RULES: R } = market;
const { fmt } = economy;
const base = { category: 'economy', everyone: true, groupOnly: true, needs: [], weight: 'light' };

const pct = (n) => `${n >= 0 ? '+' : '−'}${Math.abs(n).toFixed(2)}%`;
const gain = (n) => `${n >= 0 ? '+' : '−'}${fmt(Math.abs(Math.round(n)))}`;
const icon = (n) => (n > 0 ? '🟢' : n < 0 ? '🔴' : '⚪');
const arrow = (n) => (n >= 0.005 ? '▲' : n <= -0.005 ? '▼' : '▬');
const SPARK = '▁▂▃▄▅▆▇█';
const spark = (list, width = 24) => {
  const step = Math.max(1, Math.ceil(list.length / width));
  const pts = list.filter((_, i) => i % step === step - 1 || i === list.length - 1);
  const lo = Math.min(...pts);
  const hi = Math.max(...pts);
  return pts.map((v) => SPARK[hi === lo ? 3 : Math.min(7, Math.floor(((v - lo) / (hi - lo)) * 7.999))]).join('');
};
const SIDE = { long: 'LONG 📈', short: 'SHORT 📉' };
const why = (r, prefix) => ({
  closed: `📉 *The market is closed in this group.* An admin can open it with \`${prefix}economy on\`.`,
  amount: '⚠️ *I did not understand the amount.* Write a number (500, 2k), a share (50%) or all.',
  wait: `⏳ *Wait ${Math.ceil((r.waitMs || 0) / 1000)} seconds* before your next trade.`,
  poor: `⚠️ *Not enough coins.* Your wallet has ${fmt(r.wallet || 0)} coins.`,
  min: `⚠️ *Too small.* The smallest forex margin is ${r.min} coins.`,
  cap: `⚠️ *Too much for one trade.* You can use at most ${fmt(r.cap)} coins as margin at a time.`,
  nopair: `⚠️ *I do not know that pair.* See them with \`${prefix}forex\``,
  side: `⚠️ *Use long or short.*`,
  lev: `⚠️ *Leverage is x1 to x${r.max}.* Example: \`x3\``,
  fxmany: `⚠️ *You already have ${r.max} open forex trades.* Close one with \`${prefix}forex close <number>\``,
  nopos: `⚠️ *I did not find that trade.* See yours with \`${prefix}forex trades\``,
  tp: `⚠️ *Take profit is on the wrong side.* The price is ${forex.show(r.price || 0)}. For a long it must be higher, for a short lower.`,
  sl: `⚠️ *Stop loss is on the wrong side.* The price is ${forex.show(r.price || 0)}. For a long it must be lower, for a short higher.`,
  debt: `🔒 *You have a loan.* Repay it first (\`${prefix}repay\`).`,
}[r.why] || '⚠️ *That did not work.*');

// "x5", "5x", "tp 1.10", "sl=1.07" -> { lev, tp, sl }, the rest is left for the amount
function options(args) {
  const o = { lev: null, tp: null, sl: null };
  const rest = [];
  for (let i = 0; i < args.length; i++) {
    const a = String(args[i]).toLowerCase();
    let m;
    if ((m = /^x(\d+)$|^(\d+)x$/.exec(a))) o.lev = Number(m[1] || m[2]);
    else if ((m = /^(tp|sl)[=:]?(.*)$/.exec(a))) {
      const v = m[2] || args[++i];
      const n = Number(String(v || '').replace(/,/g, ''));
      o[m[1]] = n > 0 ? n : NaN;
    } else rest.push(args[i]);
  }
  return { o, rest };
}
const tradeLines = (list) => list.map((x) => {
  const lvl = [x.tp ? `🎯 ${forex.show(x.tp)}` : null, x.sl ? `🛑 ${forex.show(x.sl)}` : null].filter(Boolean).join(' ');
  return `*#${x.id}* ${SIDE[x.side]} *${x.pair}* x${x.lev}\n   in ${forex.show(x.entry)} → now ${forex.show(x.price)} • margin ${fmt(x.margin)}\n   ${icon(x.pl)} *${gain(x.pl)}* (${pct(x.plPct)}) • forced close at ${forex.show(x.liq)}${lvl ? ` • ${lvl}` : ''}`;
}).join('\n\n');

const GUIDE = (p) => `📘 *Guide: forex*\nForex is trading *currencies*. These are invented ones, not real money.\n▸ 💵 TBD Turbo Dollar • 💶 NVE Nova Euro • 💴 GLY Gold Yen • 🪙 SHN Sahara Naira\n▸ A pair like *TBD/NVE 1.0850* means 1 TBD costs 1.0850 NVE.\n▸ *Long* = you bet the first currency gets stronger (price up). *Short* = you bet it gets weaker (price down).\n▸ You put a *margin* (coins). *Leverage* (x2, x5, x10) multiplies your win *and* your loss. x5 and a 2% move = 10% of your margin.\n▸ You cannot lose more than your margin. If a trade loses ${100 - FR.liquidAt * 100}% of it, it is *closed by force* (liquidation).\n▸ *tp* (take profit) and *sl* (stop loss) close the trade by themselves.\n▸ The mood moves them: in a 💥 crash TBD and GLY get strong (safe), SHN falls. In a 🚀 boom SHN rises.\n\n*Example:* \`${p}forex long TBD/NVE 500 x3 tp 1.10 sl 1.07\`\n▸ \`${p}forex\` rates • \`${p}forex trades\` your trades • \`${p}forex close all\` • \`${p}forex top\`\n_Start with x2 and a small margin._`;

module.exports = [
  {
    ...base,
    name: 'forex',
    description: 'Trade made-up currencies with leverage: forex / forex long TBD/NVE 500 x3 / forex trades / forex close all',
    async run(ctx) {
      const { jid, args, reply, myJid, prefix } = ctx;
      if (!market.isOn(jid)) return reply(`📉 *The market is closed in this group.*\nAn admin or the owner can open it with \`${prefix}economy on\`.`);
      const sub = (args[0] || '').toLowerCase();

      if (['long', 'buy', 'short', 'sell'].includes(sub)) {
        const side = sub === 'long' || sub === 'buy' ? 'long' : 'short';
        const { o, rest } = options(args.slice(1));
        if (rest.length < 2 || Number.isNaN(o.tp) || Number.isNaN(o.sl)) {
          return reply(`💱 *Forex ${side}*\n*Usage:* \`${prefix}forex ${side} <pair> <margin> [x leverage] [tp price] [sl price]\`\n*Example:* \`${prefix}forex ${side} TBD/NVE 500 x3 tp ${side === 'long' ? '1.10' : '1.05'} sl ${side === 'long' ? '1.07' : '1.12'}\`\n_Leverage x1 to x${FR.maxLev} (default x${FR.defaultLev}). Smallest margin ${FR.minMargin} coins. See pairs:_ \`${prefix}forex\``);
        }
        const r = market.fxOpen(jid, myJid, side, rest[0], rest[1], o);
        if (!r.ok) return reply(why(r, prefix));
        const q = quests.note(quests.track(jid, myJid, 'forex'));
        const p = r.pos;
        return reply(
          `💱 *Forex trade opened* #${p.id}\n*${SIDE[side]} ${p.pair}* x${p.lev}\n*Price in:* ${forex.show(r.price)}\n*Margin:* ${fmt(p.margin)} coins (spread ${fmt(r.fee)}) • *Size:* ${fmt(p.exposure)}\n` +
            `*Forced close at:* ${forex.show(r.liq)}${p.tp ? `\n*Take profit:* ${forex.show(p.tp)}` : ''}${p.sl ? `\n*Stop loss:* ${forex.show(p.sl)}` : ''}\n*Wallet:* ${fmt(r.wallet)} coins\n` +
            `_Prices change every 30 minutes._\n▸ \`${prefix}forex trades\` • \`${prefix}forex close ${p.id}\`${q ? `\n\n${q}` : ''}`
        );
      }

      if (sub === 'close' || sub === 'exit') {
        if (!args[1]) return reply(`*Usage:* \`${prefix}forex close <number>\` or \`${prefix}forex close all\``);
        const r = market.fxClose(jid, myJid, args[1]);
        if (!r.ok) return reply(why(r, prefix));
        const lines = r.closed.map((c) => `${icon(c.gain)} *#${c.id} ${c.side.toUpperCase()} ${c.pair}* x${c.lev}: ${forex.show(c.entry)} → ${forex.show(c.price)} • *${gain(c.gain)} coins*`);
        const total = r.closed.reduce((s, c) => s + c.gain, 0);
        const q = total > 0 ? quests.note(quests.track(jid, myJid, 'sellprofit')) : null;
        return reply(`✅ *Forex closed*\n${lines.join('\n')}\n*Result:* ${icon(total)} ${gain(total)} coins _(spread included)_\n*Wallet:* ${fmt(r.wallet)} coins${q ? `\n\n${q}` : ''}`);
      }

      if (['trades', 'positions', 'pos', 'open', 'mine'].includes(sub)) {
        const r = market.fxPositions(jid, myJid);
        if (!r.positions.length) return reply(`💱 *Your forex trades*\n_You have no open trades._\n\n▸ \`${prefix}forex long TBD/NVE 200 x2\`\n▸ \`${prefix}forex guide\``);
        const total = r.positions.reduce((s, x) => s + x.pl, 0);
        return reply(`💱 *Your forex trades*\n\n${tradeLines(r.positions)}\n\n*Open result:* ${icon(total)} ${gain(total)} coins • *Margin worth now:* ${fmt(r.equity)}\n▸ \`${prefix}forex close <number>\` • \`${prefix}forex close all\``);
      }

      if (sub === 'top' || sub === 'ranking') {
        const r = market.fxTop(jid);
        if (!r.top.length) return reply('🏆 *Forex ranking*\n_Nobody has closed a trade yet._');
        const mentionsLib = require('../whatsapp/mentions');
        const who = await mentionsLib.describe(ctx.sock, jid, r.top.map((x) => x.j));
        const medals = ['🥇', '🥈', '🥉'];
        return reply(`🏆 *Forex traders*\n_Total result of closed trades._\n\n${r.top.map((x, i) => `${medals[i] || `${i + 1}.`} ${who[i].text} ${icon(x.pl)} *${gain(x.pl)}* coins • ${x.w}W/${x.l}L`).join('\n')}`, { mentions: who.map((w) => w.mention).filter(Boolean) });
      }

      if (sub === 'guide' || sub === 'help' || sub === 'learn') return reply(GUIDE(prefix));

      const f = market.fxQuotes(jid);
      const one = args[0] ? forex.findPair(args[0]) : null;
      if (args[0] && !one) return reply(why({ why: 'nopair' }, prefix));
      if (one) {
        const row = f.quotes.find((x) => x.pair === one);
        const [b, q] = one.split('/');
        return reply(
          `💱 *${one}* — ${CUR[b].icon} ${CUR[b].name} / ${CUR[q].icon} ${CUR[q].name}\n*Rate:* ${forex.show(row.price)}  ${arrow(row.change)} ${pct(row.change)} in 24h\n*24h range:* ${forex.show(row.lo)} – ${forex.show(row.hi)}\n*Trend:* ${spark(row.hist)}\n\n` +
            `▸ \`${prefix}forex long ${one} 500 x3\` _(bet it goes up)_\n▸ \`${prefix}forex short ${one} 500 x3\` _(bet it goes down)_`
        );
      }
      const mood = market.state(jid)?.mood;
      const lines = f.quotes.map((x) => `${arrow(x.change)} *${x.pair}* ${forex.show(x.price)}  ${pct(x.change)}`);
      await reply(
        `💱 *Forex* — made-up currencies\n_${Object.entries(CUR).map(([k, c]) => `${c.icon} ${k}`).join(' • ')}_\n\n${lines.join('\n')}\n\n_24h change. Rates update every 30 minutes and follow the ${mood || ''} mood._\n` +
          `▸ \`${prefix}forex long TBD/NVE 500 x3\` • \`${prefix}forex short ...\`\n▸ \`${prefix}forex trades\` • \`${prefix}forex guide\` • \`${prefix}forex top\``
      );
    },
  },
];
