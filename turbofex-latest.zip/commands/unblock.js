const { resolveTarget, num } = require('../whatsapp/utils');

module.exports = {
  name: 'unblock',
  category: 'owner',
  description: 'Unblock a person on WhatsApp (tag, reply or number) (owner only)',
  ownerOnly: true,
  async run({ sock, jid, msg, args, reply, isGroup }) {
    const target = resolveTarget(msg, args) || (!isGroup ? jid : null);
    if (!target) return reply('Tag the person, reply to them, or type their number.');
    await sock.updateBlockStatus(target, 'unblock');
    await reply(`✅ Unblocked @${num(target)}`, { mentions: [target] });
  },
};
