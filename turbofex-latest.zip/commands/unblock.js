const { resolveTarget, jidVariants, num } = require('../whatsapp/utils');
const { setBlock } = require('../whatsapp/blocklist');

module.exports = {
  name: 'unblock',
  category: 'owner',
  description: 'Unblock a person on WhatsApp (tag, reply or number) (owner only)',
  ownerOnly: true,
  async run({ sock, jid, msg, args, reply, isGroup, groupMetadata }) {
    const target = resolveTarget(msg, args) || (!isGroup ? jid : null);
    if (!target) return reply('Tag the person, reply to them, or type their number.');

    const candidates = [target];
    if (isGroup) candidates.push(...jidVariants(groupMetadata, target));
    else if (msg.key.remoteJidAlt) candidates.push(msg.key.remoteJidAlt);

    const res = await setBlock(sock, [...new Set(candidates)], 'unblock');
    if (!res.ok) {
      console.error('Unblock failed:', res.error);
      return reply(`⚠️ WhatsApp would not let me unblock that number.\nReason: ${String(res.error?.message || res.error).slice(0, 120)}`);
    }
    await reply(`✅ Unblocked @${num(target)}`, { mentions: [target] });
  },
};
