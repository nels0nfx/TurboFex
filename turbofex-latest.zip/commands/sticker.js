const media = require('../whatsapp/media');

module.exports = {
  name: 'sticker',
  category: 'media',
  aliases: ['s'],
  description: 'Make a sticker from a picture, GIF or short video: reply to it with sticker',
  async run(ctx) {
    await media.handle(ctx, ['image', 'video', 'sticker'], 'Reply to a picture, GIF or short video with this command (or send one with the command as its caption).', async (found, buffer) => {
      let webp;
      if (found.kind === 'sticker') {
        webp = buffer; // already a sticker
      } else if (found.kind === 'video') {
        // animated sticker: up to 8 seconds, kept under WhatsApp's 1 MB limit
        const make = (fps, q) => media.ffmpeg(buffer, 'webp', (i, o) => [
          '-i', i, '-t', '8', '-an', '-vsync', '0',
          '-vf', `fps=${fps},scale=512:512:force_original_aspect_ratio=decrease,pad=512:512:(ow-iw)/2:(oh-ih)/2:color=0x00000000`,
          '-c:v', 'libwebp', '-lossless', '0', '-q:v', String(q), '-loop', '0', '-preset', 'default', o,
        ]);
        webp = await make(12, 50);
        if (webp.length > 1000 * 1024) webp = await make(8, 30);
        if (webp.length > 1000 * 1024) throw new Error('The result is too big for a sticker. Try a shorter video.');
      } else {
        const sharp = media.loadSharp();
        webp = await sharp(buffer)
          .resize(512, 512, { fit: 'contain', background: { r: 0, g: 0, b: 0, alpha: 0 } })
          .webp({ quality: 80 })
          .toBuffer();
      }
      await ctx.sock.sendMessage(ctx.jid, { sticker: webp }, { quoted: ctx.msg });
    });
  },
};
