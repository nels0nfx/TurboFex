require('./_setup');
const test = require('node:test');
const assert = require('node:assert');
const baileys = require('../core/baileys');
const store = require('../whatsapp/store');
const handler = require('../whatsapp/handler');
const economy = require('../core/economy');
const market = require('../core/market');
const scheduler = require('../core/scheduler');
const D = require('../core/marketdata');

baileys.setForTests({});

const R = market.RULES;
const T0 = Date.UTC(2026, 9, 28, 12, 0, 0); // a Wednesday
const TICK = R.tickMs;
const DAY = 86400000;
let gid = 0;
const newGroup = () => `1203630000000${String(++gid).padStart(5, '0')}@g.us`;
let uid = 0;
const newPerson = () => `2785550${String(++uid).padStart(4, '0')}@s.whatsapp.net`;
const fund = (g, who, n) => economy.runIn(g, () => economy.add(who, n));
const wallet = (g, who) => economy.runIn(g, () => economy.balance(who));
// a market that is open since T0 with one funded person
function setup(coins = 10000) {
  const g = newGroup();
  const who = newPerson();
  market.enable(g, T0);
  fund(g, who, coins);
  return { g, who };
}
// plays price updates from time `from` to `to`; returns every event
function play(g, from, to, step = TICK) {
  const events = { news: [], notes: [] };
  for (let t = from + step; t <= to; t += step) {
    const ev = market.advance(g, t);
    if (ev.news) events.news.push(ev.news);
    events.notes.push(...ev.notes);
  }
  return events;
}
// a small repeatable random number generator
function seeded(seed = 7) {
  let s = seed;
  return () => {
    s = (s * 1664525 + 1013904223) % 4294967296;
    return (s + 1) / 4294967297;
  };
}
test.beforeEach(() => market.setRandom(seeded(11)));
test.after(() => market.setRandom(null));

// ---------------------------------------------------------------------------------------------------------------- coins per group
test('coins are per group: the same person has a separate purse in every group', () => {
  const a = newPerson();
  const g1 = newGroup();
  const g2 = newGroup();
  fund(g1, a, 500);
  assert.strictEqual(wallet(g1, a), 500);
  assert.strictEqual(wallet(g2, a), 0, 'another group has its own purse');
  fund(g2, a, 70);
  assert.strictEqual(wallet(g1, a), 500);
  assert.strictEqual(wallet(g2, a), 70);
});

test('old bot-wide coins move into the first group that touches them (nothing is lost)', () => {
  const a = newPerson();
  economy.add(a, 1234); // no group: the old purse
  const g1 = newGroup();
  const g2 = newGroup();
  assert.strictEqual(wallet(g1, a), 1234);
  assert.strictEqual(wallet(g2, a), 0, 'moved once, not copied');
  assert.strictEqual(economy.balance(a), 0);
});

test('market commands and coins use the group of the message through the handler', async () => {
  const sock = fakeSock();
  const g1 = newGroup();
  const g2 = newGroup();
  const p = newPerson();
  fund(g1, p, 900);
  await say(sock, g1, p, '.balance');
  await say(sock, g2, p, '.balance');
  const [first, second] = sock.texts();
  assert.match(first, /900 coins/);
  assert.match(second, /Wallet:\* 0 coins/);
});

// ---------------------------------------------------------------------------------------------------------------- switching on and off
test('a market that is not switched on does nothing', () => {
  const g = newGroup();
  const a = newPerson();
  assert.strictEqual(market.isOn(g), false);
  assert.strictEqual(market.invest(g, a, 'TECH', '100', T0).why, 'closed');
  assert.strictEqual(market.loanInfo(g, a).why, 'closed');
  market.enable(g, T0);
  assert.strictEqual(market.isOn(g), true);
  assert.strictEqual(market.enable(g, T0).already, true);
  assert.ok(market.disable(g));
  assert.strictEqual(market.invest(g, a, 'TECH', '100', T0).why, 'closed');
});

test('every group has its own prices and mood', () => {
  const g1 = newGroup();
  const g2 = newGroup();
  market.enable(g1, T0);
  market.enable(g2, T0);
  market.forceMood(g1, 'crash', T0);
  assert.strictEqual(market.status(g1).mood, 'crash');
  assert.strictEqual(market.status(g2).mood, 'stable');
  play(g1, T0, T0 + 5 * TICK);
  assert.notDeepStrictEqual(market.quotes(g1).map((q) => q.price), market.quotes(g2).map((q) => q.price));
});

// ---------------------------------------------------------------------------------------------------------------- trading
test('amounts: numbers, k, percent and all', () => {
  assert.deepStrictEqual(market.parseAmount('500'), { n: 500 });
  assert.deepStrictEqual(market.parseAmount('2k'), { n: 2000 });
  assert.deepStrictEqual(market.parseAmount('1,500'), { n: 1500 });
  assert.deepStrictEqual(market.parseAmount('50%'), { pct: 50 });
  assert.deepStrictEqual(market.parseAmount('ALL'), { all: true });
  for (const bad of ['', 'abc', '0', '-5', '150%', '0%', '1.2.3']) assert.strictEqual(market.parseAmount(bad), null, bad);
});

test('assets are found by ticker, name or the start of the name', () => {
  assert.strictEqual(market.findAsset('tech').id, 'TECH');
  assert.strictEqual(market.findAsset('TurboTech').id, 'TECH');
  assert.strictEqual(market.findAsset('naijacom').id, 'NCOM');
  assert.strictEqual(market.findAsset('moon').id, 'PUP');
  assert.strictEqual(market.findAsset('bonds').kind, 'bond');
  assert.strictEqual(market.findAsset('turbo'), null, 'two assets start with turbo: not guessed');
  assert.strictEqual(market.findAsset('xx'), null);
  assert.strictEqual(D.STOCKS.length, 10);
  assert.ok(D.COINS.length >= 4);
});

test('invest takes the fee, gives units and sell gives coins back minus the fee', () => {
  const { g, who } = setup(10000);
  const price = market.quotes(g).find((q) => q.asset.id === 'TECH').price;
  const r = market.invest(g, who, 'TECH', '1000', T0);
  assert.ok(r.ok);
  assert.strictEqual(r.fee, Math.round(1000 * R.fee.stock));
  assert.ok(Math.abs(r.units - (1000 - r.fee) / price) < 1e-5);
  assert.strictEqual(wallet(g, who), 9000);
  const s = market.sell(g, who, 'TECH', 'all', T0 + R.cooldownMs);
  assert.ok(s.ok);
  assert.strictEqual(wallet(g, who), 9000 + s.proceeds);
  assert.ok(s.proceeds < 1000 && s.proceeds >= 1000 - 2 * Math.round(1000 * R.fee.stock) - 1, 'a round trip at the same price costs only the two fees');
  assert.strictEqual(market.portfolio(g, who).positions.length, 0);
});

test('the fee is a coin sink: coins that were paid as fees do not come back', () => {
  const { g, who } = setup(10000);
  market.invest(g, who, 'NCOM', '2000', T0);
  market.sell(g, who, 'NCOM', 'all', T0 + R.cooldownMs);
  assert.ok(wallet(g, who) < 10000);
});

test('caps: a trade uses at most a share of the wallet, the minimum is 10, and there is a wait between trades', () => {
  const { g, who } = setup(10000);
  const big = market.invest(g, who, 'TECH', '5000', T0);
  assert.strictEqual(big.why, 'cap');
  assert.strictEqual(big.cap, 2500);
  assert.strictEqual(market.invest(g, who, 'TECH', '5', T0).why, 'min');
  assert.strictEqual(market.invest(g, who, 'TECH', 'zzz', T0).why, 'amount');
  assert.strictEqual(market.invest(g, who, 'NOPE', '100', T0).why, 'unknown');
  assert.ok(market.invest(g, who, 'TECH', 'all', T0).ok, 'all = the most one trade may use');
  assert.strictEqual(wallet(g, who), 7500);
  const wait = market.invest(g, who, 'TECH', '100', T0 + 5000);
  assert.strictEqual(wait.why, 'wait');
  assert.ok(wait.waitMs > 0 && wait.waitMs <= R.cooldownMs);
  assert.ok(market.invest(g, who, 'TECH', '100', T0 + R.cooldownMs + 1).ok);
  // a small wallet can still use all of it (up to 100)
  const small = newPerson();
  fund(g, small, 60);
  assert.ok(market.invest(g, small, 'FARM', 'all', T0).ok);
  assert.strictEqual(wallet(g, small), 0);
  assert.strictEqual(market.invest(g, newPerson(), 'FARM', '100', T0).why, 'poor');
});

test('the wait between trades is the same for selling', () => {
  const { g, who } = setup();
  market.invest(g, who, 'FARM', '500', T0);
  assert.strictEqual(market.sell(g, who, 'FARM', 'all', T0 + 1000).why, 'wait');
  assert.ok(market.sell(g, who, 'FARM', 'all', T0 + R.cooldownMs).ok);
});

test('sell: percent, an amount, too much and something you do not own', () => {
  const { g, who } = setup();
  market.invest(g, who, 'OIL', '2000', T0);
  assert.strictEqual(market.sell(g, who, 'TECH', '100', T0 + 60000).why, 'none');
  assert.strictEqual(market.sell(g, who, 'OIL', '99999', T0 + 60000).why, 'over');
  const half = market.sell(g, who, 'OIL', '50%', T0 + 60000);
  assert.ok(half.ok);
  const held = market.portfolio(g, who).positions[0].units;
  const price = market.quotes(g).find((q) => q.asset.id === 'OIL').price;
  assert.ok(Math.abs(held * price - (2000 - 30) / 2) < 3, 'half is left');
  const part = market.sell(g, who, 'OIL', '300', T0 + 120000);
  assert.ok(part.ok && Math.abs(part.units * price - 300) < 0.5);
});

test('profit and loss follow the price (and the cost includes the fee)', () => {
  const { g, who } = setup();
  market.invest(g, who, 'TECH', '2000', T0);
  const G = market.state(g);
  G.prices.TECH *= 1.1;
  let pos = market.portfolio(g, who).positions[0];
  assert.ok(pos.pl > 150 && pos.pl < 200, `a 10% rise on 1970 coins is about +167, got ${pos.pl}`);
  G.prices.TECH /= 1.5;
  pos = market.portfolio(g, who).positions[0];
  assert.ok(pos.pl < 0 && pos.plPct < 0);
  assert.ok(Math.abs(market.portfolio(g, who).worth.total - (8000 + pos.value)) < 1e-6);
});

// ---------------------------------------------------------------------------------------------------------------- the moods and prices
test('prices update on a schedule: nothing changes between updates, everybody sees the same numbers', () => {
  const { g } = setup();
  const before = market.quotes(g).map((q) => q.price);
  market.advance(g, T0 + TICK - 1000);
  assert.deepStrictEqual(market.quotes(g).map((q) => q.price), before, 'not yet');
  market.advance(g, T0 + TICK);
  assert.notDeepStrictEqual(market.quotes(g).map((q) => q.price), before);
  const after = market.quotes(g).map((q) => q.price);
  market.advance(g, T0 + TICK + 5000);
  assert.deepStrictEqual(market.quotes(g).map((q) => q.price), after);
});

test('the mood shifts every few hours with a headline, and never to the same mood', () => {
  const { g } = setup();
  const e = play(g, T0, T0 + 3 * DAY);
  assert.ok(e.news.length >= 8 && e.news.length <= 20, `${e.news.length} shifts in 3 days`);
  let prev = 'stable';
  for (const n of e.news) {
    assert.notStrictEqual(n.mood, prev);
    assert.ok(n.text.length > 10);
    prev = n.mood;
  }
  assert.ok(new Set(e.news.map((n) => n.mood)).size >= 3, 'different moods happen');
});

test('the mood moves prices: a boom lifts stocks, a crash drops them, a safe stock holds better than a risky one', () => {
  const run = (mood) => {
    const { g } = setup();
    market.forceMood(g, mood, T0);
    market.state(g).until = T0 + 9 * DAY; // keep the mood
    market.setRandom(() => 0.5000001); // no luck either way: only the mood works (the random part is -1.18 sd every time, same for all moods)
    play(g, T0, T0 + 8 * TICK);
    return Object.fromEntries(market.quotes(g).map((q) => [q.asset.id, q.change]));
  };
  const boom = run('boom');
  const crash = run('crash');
  const tech = (m) => m.TECH;
  assert.ok(tech(boom) > tech(crash) + 3, `boom ${tech(boom)} vs crash ${tech(crash)}`);
  assert.ok(crash.TECH < crash.CARE, 'the safe pharma stock falls less in a crash than the tech stock');
  assert.ok(crash.PUP < crash.GCH, 'the meme coin falls more than the gold coin');
  const inflation = run('inflation');
  assert.ok(inflation.FARM > inflation.MOVE, 'inflation: farms up, transport down');
});

test('crash protection: no price can lose more than its share in 24 hours', () => {
  const { g } = setup();
  market.forceMood(g, 'crash', T0);
  market.state(g).until = T0 + 20 * DAY;
  market.setRandom(() => 0.5000001); // the worst luck every single update
  const series = Object.fromEntries(D.ASSETS.map((a) => [a.id, [a.base]]));
  for (let i = 1; i <= 200; i++) {
    market.advance(g, T0 + i * TICK);
    for (const q of market.quotes(g)) series[q.asset.id].push(q.price);
  }
  for (const a of D.ASSETS) {
    const s = series[a.id];
    for (let i = 48; i < s.length; i++) {
      assert.ok(s[i] >= s[i - 48] * (1 - a.drop) - 0.011, `${a.id} fell ${(1 - s[i] / s[i - 48]) * 100}% in a day`);
    }
    assert.ok(s[s.length - 1] < s[0], `${a.id} did fall in a crash`);
  }
  // so a portfolio of only coins loses at most 25% in a day, a portfolio of stocks at most 12%
  assert.ok(D.COINS.every((c) => c.drop <= 0.25) && D.STOCKS.every((s) => s.drop <= 0.12));
});

test('prices cannot run away: a long boom stays inside the limits', () => {
  const { g } = setup();
  market.forceMood(g, 'boom', T0);
  market.state(g).until = T0 + 40 * DAY;
  market.setRandom(() => 0.9999);
  play(g, T0, T0 + 30 * DAY, TICK * 4);
  for (const q of market.quotes(g)) assert.ok(q.price <= q.asset.base * 8 + 0.01, q.asset.id);
});

test('inflation makes the shop dearer, a boom pays more for jobs (only in a group with the market on)', () => {
  const { g, who } = setup();
  const off = newGroup();
  market.forceMood(g, 'inflation', T0);
  market.state(g).inflation = 15;
  economy.runIn(g, () => assert.ok(economy.shopMult() > 1.2));
  economy.runIn(off, () => assert.strictEqual(economy.shopMult(), 1));
  market.forceMood(g, 'crash', T0);
  economy.runIn(g, () => assert.strictEqual(economy.payMult(), MOODSPAY('crash')));
  market.forceMood(g, 'boom', T0);
  economy.runIn(g, () => assert.strictEqual(economy.payMult(), MOODSPAY('boom')));
  economy.runIn(g, () => assert.strictEqual(economy.priceOf('vip'), Math.round(2500 * economy.shopMult())));
  assert.strictEqual(economy.priceOf('vip'), 2500, 'outside a group nothing changes');
});
const MOODSPAY = (m) => market.MOODS[m].pay;

test('the bot being off: the updates are played back, but at most two days', () => {
  const { g } = setup();
  market.advance(g, T0 + 30 * DAY);
  const G = market.state(g);
  assert.ok(G.ticked <= T0 + 30 * DAY && G.ticked > T0 + 30 * DAY - TICK);
  assert.ok(G.hist.TECH.length <= 48);
  const n = market.state(g).hist.TECH.length;
  assert.ok(n > 40, 'two days were played');
});

// ---------------------------------------------------------------------------------------------------------------- bonds
test('bonds pay a little every update, more in a crash than in a boom, and have a limit', () => {
  const { g, who } = setup(100000);
  const r = market.bondBuy(g, who, '1000', T0);
  assert.ok(r.ok);
  assert.strictEqual(r.held, 1000 - Math.round(1000 * R.fee.bond));
  market.forceMood(g, 'stable', T0);
  market.state(g).until = T0 + 9 * DAY;
  play(g, T0, T0 + DAY);
  const after = market.portfolio(g, who).bond;
  assert.ok(Math.abs(after / 995 - 1.005) < 0.0002, `a day in a stable market pays 0.5%: ${after}`);
  assert.strictEqual(market.bondBuy(g, who, '30000', T0 + 99999999).why, 'bondcap');
  assert.ok(market.bondBuy(g, who, '20000', T0 + 99999999).ok);
  assert.ok(market.bondBuy(g, who, 'all', T0 + 199999999).ok, 'all fills the bonds up to the limit');
  assert.strictEqual(market.bondBuy(g, who, '100', T0 + 299999999).why, 'bondcap', 'the limit is reached');
  const sold = market.bondSell(g, who, 'all', T0 + 399999999);
  assert.ok(sold.ok && market.portfolio(g, who).bond === 0);
  assert.ok(market.MOODS.crash.bond > market.MOODS.boom.bond, 'the safe choice pays more when it is needed');
});

test('invest and sell also work for bonds', () => {
  const { g, who } = setup();
  assert.ok(market.invest(g, who, 'bonds', '1000', T0).bond);
  assert.ok(market.sell(g, who, 'bond', '500', T0 + R.cooldownMs).bond);
});

// ---------------------------------------------------------------------------------------------------------------- property
test('property: costs stamp duty, pays rent minus tax, value follows the index, selling costs again', () => {
  const { g, who } = setup(100000);
  const price = market.propValue(g, 'flat');
  assert.strictEqual(price, 10000);
  const b = market.propertyBuy(g, who, 'flat');
  assert.ok(b.ok);
  assert.strictEqual(b.stamp, Math.round(10000 * R.propertyStamp));
  assert.strictEqual(wallet(g, who), 100000 - 10000 - b.stamp);
  assert.strictEqual(market.propertyBuy(g, who, 'castle').why, 'unknown');
  market.state(g).until = T0 + 9 * DAY;
  play(g, T0, T0 + DAY);
  const c = market.collect(g, who);
  assert.ok(c.rent && c.rent.gross > 50 && c.rent.tax > 0 && c.rent.net === c.rent.gross - c.rent.tax);
  assert.ok(Math.abs(c.rent.gross - 10000 * R.rentPerDay) < 15, `a day of rent is about ${10000 * R.rentPerDay}: ${c.rent.gross}`);
  assert.strictEqual(market.collect(g, who).total, 0, 'nothing more to collect right away');
  const before = wallet(g, who);
  const s = market.propertySell(g, who, 'flat');
  assert.ok(s.ok && s.proceeds < s.price);
  assert.strictEqual(wallet(g, who), before + s.proceeds);
  assert.strictEqual(market.propertySell(g, who, 'flat').why, 'none');
});

test('property: at most three of each kind, and the rent waiting is limited to three days', () => {
  const { g, who } = setup(1000000);
  for (let i = 0; i < R.propertyMax; i++) assert.ok(market.propertyBuy(g, who, 'room').ok);
  assert.strictEqual(market.propertyBuy(g, who, 'room').why, 'max');
  market.state(g).until = T0 + 99 * DAY;
  play(g, T0, T0 + 10 * DAY, TICK * 2);
  const c = market.collect(g, who);
  const perDay = 3 * 2500 * R.rentPerDay;
  assert.ok(c.rent.gross <= perDay * R.rentStoreDays * 1.15 && c.rent.gross >= perDay * R.rentStoreDays * 0.85, `${c.rent.gross}`);
});

test('property value follows the mood slowly', () => {
  const { g } = setup();
  market.forceMood(g, 'crash', T0);
  market.state(g).until = T0 + 20 * DAY;
  market.setRandom(() => 0.5000001);
  play(g, T0, T0 + DAY);
  const crash = market.state(g).prices.PROP;
  assert.ok(crash < 1 && crash >= 0.96 - 1e-9, `a crash moves property at most 4% a day: ${crash}`);
  assert.ok(market.propValue(g, 'flat') < 20000);
});

// ---------------------------------------------------------------------------------------------------------------- business
test('business: buy, upgrade, collect profit minus tax, sell for 70%', () => {
  const { g, who } = setup(100000);
  market.state(g).until = T0 + 99 * DAY;
  const b = market.businessBuy(g, who, 'kiosk');
  assert.ok(b.ok && b.cost === 1500);
  assert.strictEqual(market.businessBuy(g, who, 'kiosk').why, 'owned');
  assert.strictEqual(market.businessBuy(g, who, 'airline').why, 'unknown');
  play(g, T0, T0 + DAY);
  const c = market.collect(g, who, 'business');
  assert.ok(c.biz && Math.abs(c.biz.gross - 1500 * R.bizProfitPerDay) < 3, `${c.biz?.gross}`);
  assert.strictEqual(c.biz.net, c.biz.gross - Math.round(c.biz.gross * R.bizTax));
  const up = market.businessUpgrade(g, who, 'kiosk');
  assert.ok(up.ok && up.level === 2 && up.cost === 750);
  assert.ok(up.profitDay > b.profitDay * 1.4);
  for (let i = 0; i < 3; i++) assert.ok(market.businessUpgrade(g, who, 'kiosk').ok);
  assert.strictEqual(market.businessUpgrade(g, who, 'kiosk').why, 'maxlevel');
  assert.strictEqual(market.businessUpgrade(g, who, 'farm').why, 'none');
  const spent = 1500 + 750 + 1500 + 2250 + 3000;
  const before = wallet(g, who);
  const s = market.businessSell(g, who, 'kiosk');
  assert.strictEqual(s.refund, Math.floor(spent * R.bizResale));
  assert.strictEqual(wallet(g, who), before + s.refund + s.profit);
});

test('business profit waits at most two days and follows the mood', () => {
  const run = (mood) => {
    const { g, who } = setup(100000);
    market.businessBuy(g, who, 'farm');
    market.forceMood(g, mood, T0);
    market.state(g).until = T0 + 99 * DAY;
    play(g, T0, T0 + 6 * DAY, TICK * 2);
    return market.collect(g, who).biz.gross;
  };
  const boom = run('boom');
  const crash = run('crash');
  assert.ok(boom > crash);
  assert.ok(boom <= 5000 * R.bizProfitPerDay * 1.2 * R.bizStoreDays * 1.1);
});

// ---------------------------------------------------------------------------------------------------------------- loans
test('loan: limit, fee, interest, and no giving, gambling or banking while you owe', () => {
  const { g, who } = setup(4000);
  const info = market.loanInfo(g, who, T0);
  assert.strictEqual(info.limit, 2000, 'half of what you own');
  assert.strictEqual(market.borrow(g, who, '3000', T0).why, 'limit');
  assert.strictEqual(market.borrow(g, who, '50', T0).why, 'min');
  const l = market.borrow(g, who, '2000', T0);
  assert.ok(l.ok && l.fee === 40 && l.got === 1960);
  assert.strictEqual(wallet(g, who), 5960);
  assert.strictEqual(market.borrow(g, who, '100', T0).why, 'has');
  const friend = newPerson();
  economy.runIn(g, () => {
    assert.strictEqual(economy.transfer(who, friend, 100), false, 'no giving');
    assert.strictEqual(economy.gamble(who, 100).why, 'debt', 'no gambling');
    assert.strictEqual(economy.deposit(who, 100), false, 'no bank');
    assert.strictEqual(economy.rob(who, friend).why, 'debt', 'no robbing');
    assert.ok(economy.inDebt(who));
  });
  economy.runIn(newGroup(), () => assert.ok(!economy.inDebt(who), 'the loan is a loan of this group only'));
  market.state(g).until = T0 + 99 * DAY;
  play(g, T0, T0 + DAY);
  const owed = market.loanInfo(g, who).debt;
  const expect = 2000 * Math.pow(1 + (R.loanBaseRate + market.state(g).inflation * 0.1) / 100 / 48, 48);
  assert.ok(Math.abs(owed - expect) < 3, `after a day ${owed} vs ${expect.toFixed(1)}`);
  assert.ok(owed > 2020);
  const p = market.repay(g, who, '1000');
  assert.ok(p.ok && p.paid === 1000);
  const all = market.repay(g, who, 'all');
  assert.ok(all.ok && all.left === 0);
  assert.strictEqual(market.loanInfo(g, who).debt, 0);
  economy.runIn(g, () => assert.ok(!economy.inDebt(who)));
  assert.strictEqual(market.repay(g, who, 'all').why, 'noloan');
});

test('loan interest is higher when inflation is higher', () => {
  const { g, who } = setup();
  market.state(g).inflation = 3;
  const low = market.loanInfo(g, who).rate;
  market.state(g).inflation = 16;
  assert.ok(market.loanInfo(g, who).rate > low + 1);
});

test('a loan that grows too big for what you own sells your investments (margin call)', () => {
  const { g, who } = setup(4000);
  market.state(g).until = T0 + 99 * DAY;
  market.borrow(g, who, '2000', T0);
  let t = T0;
  for (let i = 0; i < 4; i++) {
    t += R.cooldownMs + 1;
    assert.ok(market.invest(g, who, 'TRB', 'all', t).ok);
  }
  assert.ok(market.portfolio(g, who).positions[0].value > 3500);
  market.state(g).prices.TRB = 40; // the coin collapses
  market.state(g).hist.TRB = [40];
  const cashBefore = wallet(g, who);
  const e = market.advance(g, T0 + TICK);
  const call = e.notes.find((n) => n.type === 'margin');
  assert.ok(call, 'a margin call');
  assert.ok(call.paid > 0);
  assert.ok(market.loanInfo(g, who).debt < 2000, 'part of the debt was paid');
  assert.ok(wallet(g, who) >= cashBefore - 1, 'the wallet is not touched by a margin call');
  assert.match(market.noteMessage(g, call).text, /Margin call/);
});

test('a loan that is not paid in time is taken from the wallet and the investments; what is left is taken from future coins', () => {
  const { g, who } = setup(4000);
  market.state(g).until = T0 + 99 * DAY;
  market.borrow(g, who, '2000', T0);
  economy.runIn(g, () => economy.take(who, wallet(g, who) - 300)); // the borrower spent it all
  let notes = [];
  for (let t = T0 + TICK; t <= T0 + 8 * DAY; t += TICK) notes.push(...market.advance(g, t).notes);
  const od = notes.find((n) => n.type === 'overdue');
  assert.ok(od, 'overdue');
  assert.ok(od.left > 1500);
  assert.strictEqual(wallet(g, who), 0);
  assert.ok(market.loanInfo(g, who).overdue);
  fund(g, who, 500); // coins earned later go to the bank
  market.advance(g, T0 + 8 * DAY + TICK + TICK);
  assert.strictEqual(wallet(g, who), 0, 'garnished');
  assert.ok(market.loanInfo(g, who).debt < od.left + 50);
});

test('a loan that is due and can be paid is collected', () => {
  const { g, who } = setup(4000);
  market.state(g).until = T0 + 99 * DAY;
  market.borrow(g, who, '1000', T0);
  const notes = play(g, T0, T0 + 8 * DAY).notes;
  assert.ok(notes.some((n) => n.type === 'collected'));
  assert.strictEqual(market.loanInfo(g, who).debt, 0);
  assert.ok(wallet(g, who) > 3000);
});

// ---------------------------------------------------------------------------------------------------------------- the weekly prize
test('the week starts on Monday and the best profit in percent wins a prize and the title', () => {
  assert.notStrictEqual(market.weekId(T0), market.weekId(T0 + 5 * DAY), 'Wednesday and the next Monday are different weeks');
  assert.strictEqual(market.weekId(T0), market.weekId(T0 + DAY));
  const { g, who } = setup(20000);
  const second = newPerson();
  const loser = newPerson();
  fund(g, second, 20000);
  fund(g, loser, 20000);
  market.state(g).until = T0 + 99 * DAY;
  for (const p of [who, second, loser]) market.invest(g, p, 'FARM', 'all', T0);
  market.invest(g, who, 'FARM', 'all', T0 + R.cooldownMs);
  market.invest(g, second, 'FARM', 'all', T0 + R.cooldownMs);
  market.invest(g, loser, 'FARM', 'all', T0 + R.cooldownMs);
  // one more trade each so every one has invested over the minimum
  const G = market.state(g);
  G.prices.FARM *= 1.2;
  assert.ok(market.weeklyBoard(g)[0].pct > 5);
  // the rich-by-work person is not the best investor: coins from work do not count
  fund(g, loser, 50000);
  assert.ok(market.weeklyBoard(g).every((e) => e.profit < 2000));
  // sell some to make profit differ: second takes the profit, loser loses
  G.prices.FARM /= 1.2;
  market.sell(g, loser, 'FARM', 'all', T0 + 2 * R.cooldownMs);
  G.prices.FARM *= 1.3;
  const before = [wallet(g, who), wallet(g, second), wallet(g, loser)];
  const notes = play(g, T0, T0 + 6 * DAY, TICK).notes;
  const wk = notes.find((n) => n.type === 'week');
  assert.ok(wk, 'the week ended');
  assert.ok(wk.winners.length >= 1 && wk.winners[0].prize === R.weekPrizes[0]);
  assert.ok(wk.winners[0].pct > 0);
  const top = wk.winners[0].jid;
  assert.ok([who, second].includes(top));
  const crowned = market.portfolio(g, top);
  assert.ok(crowned.crown, 'the winner has the title');
  assert.strictEqual(market.state(g).hall.length, 1);
  assert.match(market.noteMessage(g, wk).text, /Investor of the Week/);
  // a new week: the ranking starts again
  assert.notStrictEqual(market.state(g).week, wk.week);
  assert.ok(market.weeklyBoard(g).every((e) => Math.abs(e.profit) < 5000));
  assert.ok(before.length === 3);
});

test('only people who invested enough can rank, and only a profit wins', () => {
  const { g, who } = setup(10000);
  const tiny = newPerson();
  fund(g, tiny, 500);
  market.invest(g, tiny, 'FARM', '300', T0);
  market.invest(g, who, 'FARM', '2000', T0);
  market.state(g).prices.FARM *= 1.5;
  const board = market.weeklyBoard(g);
  assert.strictEqual(board.length, 1, 'the one with 300 coins is not ranked');
  market.state(g).prices.FARM /= 3; // everyone loses
  market.state(g).until = T0 + 99 * DAY;
  const notes = play(g, T0, T0 + 6 * DAY).notes;
  assert.ok(!notes.some((n) => n.type === 'week'), 'nobody made a profit, no winner');
});

test('profit of the week counts investing only, not coins from work, and fees count against you', () => {
  const { g, who } = setup(5000);
  market.invest(g, who, 'NCOM', '1000', T0);
  const p0 = market.portfolio(g, who).week;
  assert.ok(p0.profit < 0 && p0.profit > -25, `the fee of the first trade: ${p0.profit}`);
  fund(g, who, 100000);
  assert.strictEqual(Math.round(market.portfolio(g, who).week.profit), Math.round(p0.profit));
});

// ---------------------------------------------------------------------------------------------------------------- posting news
test('news is posted when the mood changes and only in groups where it is on', async () => {
  const on = newGroup();
  const muted = newGroup();
  const off = newGroup();
  for (const g of [on, muted]) market.enable(g, Date.now() - 6 * 3600000);
  market.enable(off, Date.now() - 6 * 3600000);
  market.disable(off);
  market.setNews(muted, false);
  for (const g of [on, muted, off]) market.state(g).until = Date.now() - 1000; // a shift is due
  const sent = [];
  await market.tick(async (group, content) => { sent.push({ group, content }); }, Date.now());
  const to = (g) => sent.filter((s) => s.group === g);
  assert.strictEqual(to(on).length >= 1, true, 'the group with news on hears it');
  assert.match(to(on)[0].content.text, /Market News/);
  assert.match(to(on)[0].content.text, /Mood:/);
  assert.strictEqual(to(muted).length, 0, 'muted');
  assert.strictEqual(to(off).length, 0, 'closed');
  // an update without a mood change is still news now: a short update every 30 minutes
  const again = [];
  const G = market.state(on);
  G.until = Date.now() + 99 * DAY;
  await market.tick(async (gr, c) => { if (gr === on) again.push(c); }, Date.now() + TICK + 1000);
  assert.strictEqual(again.length, 1);
  assert.match(again[0].text, /Market Update/);
});

test('the scheduler sends the news to the group it belongs to', async () => {
  const g = newGroup();
  market.enable(g, Date.now() - 4 * 3600000);
  market.state(g).until = Date.now() - 1;
  const sock = fakeSock();
  await scheduler.checkMarket(sock);
  const mine = sock.sent.filter((s) => s.j === g);
  assert.ok(mine.length >= 1);
  assert.match(mine[0].c.text, /Market News/);
});

test('the news text names the mood, the headline, the moves and the effects', () => {
  const { g } = setup();
  market.forceMood(g, 'inflation', T0);
  const text = market.newsMessage(g, '.').text;
  assert.match(text, /Mood: Inflation/);
  assert.match(text, /Inflation:\*/);
  assert.match(text, /Bonds pay/);
  assert.match(text, /Shop prices/);
  assert.match(text, /Job pay/);
  assert.match(text, /`\.market`/);
});

// ---------------------------------------------------------------------------------------------------------------- through the handler
function fakeSock() {
  const sent = [];
  const sock = {
    user: { id: '27899999999:1@s.whatsapp.net', lid: '999888777:1@lid' },
    sent,
    texts: () => sent.filter((s) => s.c.text).map((s) => s.c.text),
    sendMessage: async (j, c) => { sent.push({ j, c }); return { key: { id: `K${sent.length}` } }; },
    groupMetadata: async () => ({ subject: 'G', participants: [{ id: OWNER, admin: 'admin' }, { id: MEMBER }, { id: MEMBER2 }] }),
    readMessages: async () => {},
    sendPresenceUpdate: async () => {},
    presenceSubscribe: async () => {},
  };
  return sock;
}
const OWNER = '27800000001@s.whatsapp.net';
const MEMBER = '27811111111@s.whatsapp.net';
const MEMBER2 = '27822222222@s.whatsapp.net';
let n = 0;
async function say(sock, group, from, text) {
  await handler.handleMessage(sock, { key: { remoteJid: group, participant: from, id: `M${++n}`, fromMe: false }, message: { conversation: text }, messageTimestamp: Math.floor(Date.now() / 1000) });
  await handler.idle();
  await new Promise((r) => setTimeout(r, 15));
}
const last = (sock) => sock.texts().at(-1);

test('commands: closed market, then an admin opens it, then people trade', async () => {
  store.setMode('public');
  const sock = fakeSock();
  const g = newGroup();
  fund(g, MEMBER, 5000);
  await say(sock, g, MEMBER, '.market');
  assert.match(last(sock), /market is closed/);
  await say(sock, g, MEMBER, '.economy on');
  assert.match(last(sock), /Only group admins/);
  await say(sock, g, OWNER, '.economy on');
  assert.match(last(sock), /market is open/);
  assert.ok(market.isOn(g));
  await say(sock, g, MEMBER, '.market');
  assert.match(last(sock), /\*Market\*/);
  assert.match(last(sock), /TECH/);
  assert.match(last(sock), /TRB/);
  assert.match(last(sock), /Next price update/);
  await say(sock, g, MEMBER, '.invest tech 1000');
  assert.match(last(sock), /Invested in TECH/);
  assert.match(last(sock), /Fee|fee/);
  await say(sock, g, MEMBER, '.portfolio');
  assert.match(last(sock), /Your portfolio/);
  assert.match(last(sock), /TECH/);
  assert.match(last(sock), /Net worth/);
  assert.ok([4000, 4150, 4300].includes(wallet(g, MEMBER)), "wallet is 4000, plus a quest reward if investing was the quest of the day");
});

test('commands: portfolios of other members are visible, in that group only', async () => {
  store.setMode('public');
  const sock = fakeSock();
  const g = newGroup();
  const other = newGroup();
  market.enable(g, Date.now());
  market.enable(other, Date.now());
  fund(g, MEMBER, 3000);
  fund(g, MEMBER2, 3000);
  fund(other, MEMBER, 3000);
  market.invest(g, MEMBER, 'OIL', '700', Date.now());
  market.invest(other, MEMBER, 'NCOM', '500', Date.now());
  await say(sock, g, MEMBER2, `.portfolio @${MEMBER.split('@')[0]}`);
  const c = sock.sent.filter((s) => s.c.text).at(-1).c;
  assert.match(c.text, /Portfolio of @27811111111/);
  assert.match(c.text, /OIL/);
  assert.doesNotMatch(c.text, /NCOM/, 'what they own in another group is not shown');
});

test('commands: usage hints and mistakes are explained', async () => {
  store.setMode('public');
  const sock = fakeSock();
  const g = newGroup();
  market.enable(g, Date.now());
  fund(g, OWNER, 1000);
  await say(sock, g, OWNER, '.invest');
  assert.match(last(sock), /Usage/);
  await say(sock, g, OWNER, '.invest nothing 100');
  assert.match(last(sock), /do not know/);
  await say(sock, g, OWNER, '.invest tech 900');
  assert.match(last(sock), /Too much for one trade/);
  await say(sock, g, OWNER, '.invest tech 100');
  await say(sock, g, OWNER, '.invest tech 100');
  assert.match(last(sock), /Wait \d+ seconds/);
  await say(sock, g, OWNER, '.sell');
  assert.match(last(sock), /Usage/);
  await say(sock, g, OWNER, '.market tech');
  assert.match(last(sock), /TurboTech/);
  assert.match(last(sock), /You hold/);
  assert.match(last(sock), /Likes|Hates/);
  await say(sock, g, OWNER, '.market coins');
  assert.match(last(sock), /Coins/);
  assert.doesNotMatch(last(sock), /Stocks/);
});

test('commands: bonds, property, business, collect, loan and repay', async () => {
  store.setMode('public');
  const sock = fakeSock();
  const g = newGroup();
  market.enable(g, Date.now());
  fund(g, OWNER, 60000);
  await say(sock, g, OWNER, '.bonds');
  assert.match(last(sock), /Bonds/);
  await say(sock, g, OWNER, '.bonds buy 1000');
  assert.match(last(sock), /Bought bonds/);
  await say(sock, g, OWNER, '.property');
  assert.match(last(sock), /Family Flat/);
  await say(sock, g, OWNER, '.property buy room');
  assert.match(last(sock), /Bought a Room Apartment/);
  await say(sock, g, OWNER, '.business');
  assert.match(last(sock), /Kiosk/);
  await say(sock, g, OWNER, '.business buy kiosk');
  assert.match(last(sock), /You own a Kiosk/);
  await say(sock, g, OWNER, '.business upgrade kiosk');
  assert.match(last(sock), /level 2/);
  await say(sock, g, OWNER, '.collect');
  assert.match(last(sock), /Nothing to collect/);
  market.advance(g, Date.now() + 2 * TICK + 1000);
  await say(sock, g, OWNER, '.collect');
  assert.match(last(sock), /Collected/);
  await say(sock, g, OWNER, '.loan');
  assert.match(last(sock), /You can borrow up to/);
  await say(sock, g, OWNER, '.loan 2000');
  assert.match(last(sock), /Loan approved/);
  await say(sock, g, OWNER, '.give @27822222222 10');
  assert.match(last(sock), /You have a loan/);
  await say(sock, g, OWNER, '.gamble 100');
  assert.match(last(sock), /You have a loan/);
  await say(sock, g, OWNER, '.repay 500');
  assert.match(last(sock), /Still owed/);
  await say(sock, g, OWNER, '.repay all');
  assert.match(last(sock), /Loan paid off/);
  await say(sock, g, OWNER, '.portfolio');
  assert.match(last(sock), /Bonds/);
  assert.match(last(sock), /Room Apartment/);
  assert.match(last(sock), /Kiosk/);
});

test('commands: economy shows the mood, top shows the ranking, the owner can set the mood', async () => {
  store.setMode('public');
  const sock = fakeSock();
  const mem = newPerson();
  const g = newGroup();
  market.enable(g, Date.now());
  fund(g, mem, 5000);
  market.invest(g, mem, 'FARM', '2000', Date.now());
  await say(sock, g, mem, '.economy');
  assert.match(last(sock), /Mood:/);
  assert.match(last(sock), /Inflation:/);
  assert.match(last(sock), /Top investors this week/);
  await say(sock, g, mem, '.economy top');
  assert.match(last(sock), /This week/);
  assert.match(last(sock), /Richest/);
  await say(sock, g, mem, '.economy mood crash');
  assert.match(last(sock), /Only the bot owner/);
  await say(sock, g, OWNER, '.economy mood crash');
  assert.match(last(sock), /Mood: Crash/);
  assert.strictEqual(market.status(g).mood, 'crash');
  await say(sock, g, mem, '.news economy');
  assert.match(last(sock), /Market News/);
  assert.match(last(sock), /Crash/);
  await say(sock, g, mem, '.economy news off');
  assert.match(last(sock), /Only group admins/);
  await say(sock, g, OWNER, '.economy news off');
  assert.strictEqual(market.state(g).news, false);
  await say(sock, g, OWNER, '.economy off');
  assert.match(last(sock), /market is closed/);
  await say(sock, g, mem, '.invest tech 100');
  assert.match(last(sock), /economy is turned off/);
  await say(sock, g, OWNER, '.economy reset');
  assert.match(last(sock), /deletes every investment/);
  await say(sock, g, OWNER, '.economy reset confirm');
  assert.match(last(sock), /reset/);
});

test('commands: the shop shows the new prices and says why', async () => {
  store.setMode('public');
  const sock = fakeSock();
  const mem = newPerson();
  const g = newGroup();
  market.enable(g, Date.now());
  market.forceMood(g, 'inflation', Date.now());
  market.state(g).inflation = 15;
  await say(sock, g, mem, '.shop');
  assert.match(last(sock), /higher because of the economy/);
  const dear = economy.runIn(g, () => economy.priceOf('vip'));
  assert.ok(dear > 2750);
  assert.match(last(sock), new RegExp(dear.toLocaleString('en-US').replace(',', ',')));
});

test('all market commands are in the economy category with a description and work in groups only', () => {
  const cmds = require('../commands/market');
  const names = cmds.map((c) => c.name);
  for (const n of ['market', 'invest', 'sell', 'portfolio', 'bonds', 'property', 'business', 'collect', 'loan', 'repay', 'economy']) assert.ok(names.includes(n), n);
  for (const c of cmds) {
    assert.strictEqual(c.category, 'economy', c.name);
    assert.ok(c.description && c.description.length > 10, c.name);
    assert.strictEqual(c.groupOnly, true, c.name);
    assert.strictEqual(c.everyone, true, c.name);
  }
});

test('coins in circulation: every sink takes coins and nothing is created by trading', () => {
  const { g, who } = setup(50000);
  const start = wallet(g, who);
  market.invest(g, who, 'NCOM', 'all', T0);
  market.bondBuy(g, who, '2000', T0 + R.cooldownMs + 1);
  market.propertyBuy(g, who, 'room');
  market.businessBuy(g, who, 'kiosk');
  const w = market.portfolio(g, who).worth;
  assert.ok(w.total < start, 'fees, stamp duty and the business resale value are gone');
  assert.ok(start - w.total < start * 0.1);
});

// ---------------------------------------------------------------------------------------------------------------- clear profit
test('profit: a fresh investor starts a little in the red (the fee) and the numbers add up', () => {
  const { g, who } = setup(10000);
  assert.strictEqual(market.profit(g, who).empty, true);
  market.invest(g, who, 'NCOM', '2000', T0);
  const p = market.profit(g, who);
  assert.ok(p.overall.profit < 0 && p.overall.profit > -40, `fee only: ${p.overall.profit}`);
  const x = p.parts;
  assert.ok(Math.abs(x.worth + x.income - x.putIn - x.loanCost - p.overall.profit) < 1e-6, 'profit = worth + income - put in - costs');
  assert.ok(x.fees >= 30 && x.fees < 31, `the trading fee is shown: ${x.fees}`);
});

test('profit: a price rise shows green, a fall shows red, and selling keeps the result', () => {
  const { g, who } = setup(10000);
  market.invest(g, who, 'TECH', '2000', T0);
  const G = market.state(g);
  G.prices.TECH *= 1.2;
  assert.ok(market.profit(g, who).overall.profit > 300);
  G.prices.TECH /= 1.6;
  assert.ok(market.profit(g, who).overall.profit < -500);
  G.prices.TECH *= 2;
  const before = market.profit(g, who).overall.profit;
  market.sell(g, who, 'TECH', 'all', T0 + R.cooldownMs);
  const after = market.profit(g, who);
  assert.ok(Math.abs(after.overall.profit - (before - (before - after.overall.profit))) < 1e-6);
  assert.ok(after.overall.profit > 0 && after.parts.fees > 30, 'the profit is kept as coins and the fees of both trades are counted');
  assert.ok(after.parts.fees > 55, 'buy and sell fee: ' + after.parts.fees);
});

test('profit: rent, business income, loan interest and fees are all counted', () => {
  const { g, who } = setup(100000);
  market.state(g).until = T0 + 99 * DAY;
  market.propertyBuy(g, who, 'flat');
  market.businessBuy(g, who, 'farm');
  market.borrow(g, who, '5000', T0);
  play(g, T0, T0 + 2 * DAY);
  market.collect(g, who);
  const p = market.profit(g, who);
  assert.ok(p.parts.income > 100, `income ${p.parts.income}`);
  assert.ok(p.parts.interest > 50 && p.parts.loanCost >= p.parts.interest, `interest ${p.parts.interest}`);
  assert.ok(p.parts.tax > 0, 'taxes');
  assert.ok(Math.abs(p.parts.worth + p.parts.income - p.parts.putIn - p.parts.loanCost - p.overall.profit) < 1e-6);
});

test('profit: the last 24 hours shows the price moves on what you hold', () => {
  const { g, who } = setup(10000);
  market.invest(g, who, 'OIL', '2000', T0);
  market.state(g).hist.OIL = [150];
  market.state(g).prices.OIL = 165;
  const units = market.portfolio(g, who).positions[0].units;
  assert.ok(Math.abs(market.profit(g, who).day - units * 15) < 1e-6);
});

test('after buying you are told the price where you break even, and selling there really breaks even', () => {
  const { g, who } = setup(10000);
  const r = market.invest(g, who, 'TECH', '2000', T0);
  assert.ok(r.breakEven > r.price && r.breakEven < r.price * 1.04, `${r.breakEven} vs ${r.price}`);
  const G = market.state(g);
  G.prices.TECH = r.breakEven;
  const s = market.sell(g, who, 'TECH', 'all', T0 + R.cooldownMs);
  assert.ok(Math.abs(s.proceeds - 2000) <= 1, `sold for ${s.proceeds}`);
  // a second buy at another price moves the break-even to the average
  const { g: g2, who: w2 } = setup(10000);
  market.invest(g2, w2, 'TECH', '1000', T0);
  market.state(g2).prices.TECH *= 1.1;
  const r2 = market.invest(g2, w2, 'TECH', '1000', T0 + R.cooldownMs);
  assert.ok(r2.breakEven > r2.price * 0.95 && r2.breakEven < r2.price * 1.05, `${r2.breakEven} vs ${r2.price}`);
});

test('profit from an older saved market (no lifetime ledger yet) starts from what they had, not from zero', () => {
  const { g, who } = setup(10000);
  market.invest(g, who, 'FARM', '1000', T0);
  const P = Object.values(market.state(g).players)[0];
  delete P.life; // a market saved before profit tracking
  market.advance(g, T0 + TICK);
  assert.ok(Math.abs(market.profit(g, who).overall.profit) < 100, 'no fake profit appears');
});

test('every mood has a plain-words tip, shown in the news, the market and the economy', () => {
  for (const m of Object.values(market.MOODS)) assert.ok(m.tip && m.tip.length > 30);
  const { g } = setup();
  market.forceMood(g, 'crash', T0);
  assert.match(market.newsMessage(g, '.').text, /Crashes end|crashes end/);
});

test('commands: guide and profit explain things in plain words', async () => {
  store.setMode('public');
  const sock = fakeSock();
  const g = newGroup();
  const me = newPerson();
  market.enable(g, Date.now());
  fund(g, me, 5000);
  await say(sock, g, OWNER, '.guide');
  assert.match(last(sock), /How the market works/);
  assert.match(last(sock), /\.invest TECH 500/);
  for (const topic of ['stocks', 'profit', 'property', 'loans', 'mood', 'tips']) {
    await say(sock, g, OWNER, `.guide ${topic}`);
    assert.match(last(sock), /Guide:/, topic);
  }
  await say(sock, g, OWNER, '.economy guide');
  assert.match(last(sock), /How the market works/);
  await say(sock, g, OWNER, '.profit');
  assert.match(last(sock), /not invested yet/);
  fund(g, OWNER, 5000);
  await say(sock, g, OWNER, '.invest tech 1000');
  assert.match(last(sock), /break even when TECH reaches/);
  await say(sock, g, OWNER, '.profit');
  assert.match(last(sock), /Your profit/);
  assert.match(last(sock), /Overall:/);
  assert.match(last(sock), /This week:/);
  assert.match(last(sock), /How it adds up/);
  assert.match(last(sock), /Profit = /);
  await say(sock, g, OWNER, '.portfolio');
  assert.match(last(sock), /Profit overall:/);
  assert.match(last(sock), /Last 24h:/);
  assert.match(last(sock), /\.profit/);
  await say(sock, g, OWNER, '.market');
  assert.match(last(sock), /💡/);
  await say(sock, g, OWNER, '.economy');
  assert.match(last(sock), /💡/);
  assert.ok(me);
});

test('commands: opening the market tells new people where to start', async () => {
  store.setMode('public');
  const sock = fakeSock();
  const g = newGroup();
  await say(sock, g, OWNER, '.economy on');
  assert.match(last(sock), /New here/);
  assert.match(last(sock), /\.guide/);
});
