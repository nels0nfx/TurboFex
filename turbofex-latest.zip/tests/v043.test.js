require('./_setup');
const test = require('node:test');
const assert = require('node:assert');
const baileys = require('../core/baileys');
const store = require('../whatsapp/store');
const handler = require('../whatsapp/handler');
const economy = require('../core/economy');
const market = require('../core/market');
const throne = require('../core/throne');
const drops = require('../core/drops');
const ratelimit = require('../whatsapp/ratelimit');

baileys.setForTests({});
const OWNER = '27800000001@s.whatsapp.net';
let gid = 0;
const newGroup = () => `1203640000001${String(++gid).padStart(5, '0')}@g.us`;
let uid = 0;
const person = () => `2787770${String(++uid).padStart(4, '0')}@s.whatsapp.net`;
const fund = (g, who, n) => economy.runIn(g, () => economy.add(who, n));
const wallet = (g, who) => economy.runIn(g, () => economy.balance(who));
function fakeSock() {
  const sent = [];
  return {
    user: { id: '27899999999:1@s.whatsapp.net', lid: '999888777:1@lid' },
    sent,
    texts: () => sent.filter((s) => s.c.text).map((s) => s.c.text),
    sendMessage: async (j, c) => { sent.push({ j, c }); return { key: { id: `K${sent.length}` } }; },
    groupMetadata: async () => ({ subject: 'G', participants: [{ id: OWNER, admin: 'admin' }] }),
    readMessages: async () => {}, sendPresenceUpdate: async () => {}, presenceSubscribe: async () => {},
  };
}
let n = 0;
async function say(sock, group, from, text) {
  await handler.handleMessage(sock, { key: { remoteJid: group, participant: from, id: `V${++n}`, fromMe: false }, message: { conversation: text }, messageTimestamp: Math.floor(Date.now() / 1000) });
  await handler.idle();
  await new Promise((r) => setTimeout(r, 15));
}
const last = (sock) => sock.texts().at(-1);

test('economy off turns off every economy command in that group, economy on brings them back', async () => {
  store.setMode('public');
  ratelimit.reset();
  const sock = fakeSock();
  const g = newGroup();
  const a = person();
  await say(sock, g, a, '.balance');
  assert.match(last(sock), /Your balance/);
  await say(sock, g, OWNER, '.economy off');
  assert.match(last(sock), /OFF/);
  assert.ok(economy.isOff(g));
  for (const c of ['.balance', '.daily', '.work', '.gamble 100', '.shop', '.market', '.throne', '.couple', '.earn', '.quests', '.crime']) {
    await say(sock, g, a, c);
    assert.match(last(sock), /economy is turned off/, c);
  }
  await say(sock, g, OWNER, '.balance'); // the owner too
  assert.match(last(sock), /economy is turned off/);
  await say(sock, g, OWNER, '.economy on');
  assert.ok(!economy.isOff(g));
  await say(sock, g, a, '.balance');
  assert.match(last(sock), /Your balance/);
  assert.ok(store.getGroup(g).rank, 'ranks are on so chatting earns coins');
});

test('economy off does not touch another group, and the owner can switch all groups', async () => {
  const sock = fakeSock();
  const g1 = newGroup();
  const g2 = newGroup();
  const a = person();
  fund(g1, a, 10);
  fund(g2, a, 10);
  await say(sock, g1, OWNER, '.economy off');
  await say(sock, g2, a, '.balance');
  assert.match(last(sock), /Your balance/);
  await say(sock, g2, OWNER, '.economy off all');
  assert.match(last(sock), /OFF in/);
  assert.ok(economy.isOff(g1) && economy.isOff(g2));
  await say(sock, g2, OWNER, '.economy on all');
  assert.ok(!economy.isOff(g1) && !economy.isOff(g2));
});

test('while the economy is off nothing is earned from chatting and no bets are placed', async () => {
  const sock = fakeSock();
  const g = newGroup();
  const a = person();
  economy.setOff(g, true);
  store.update(g, (x) => { x.rank = true; });
  await say(sock, g, a, 'hello everybody');
  assert.strictEqual(wallet(g, a), 0);
  economy.setOff(g, false);
  await say(sock, g, a, 'hello again');
  assert.ok(wallet(g, a) > 0);
});

test('outlook: a boom shows buy signals, a crash shows avoid, bonds are not listed, picks command answers', async () => {
  const g = newGroup();
  market.enable(g);
  market.forceMood(g, 'boom');
  const boom = market.picks(g);
  assert.ok(boom[0].o.net > 0.8 && /buy/i.test(boom[0].o.label));
  market.forceMood(g, 'crash');
  const crash = market.picks(g);
  assert.ok(crash.some((p) => p.o.key === 'avoid'));
  assert.ok(market.quotes(g).every((q) => q.outlook && q.outlook.icon));
  const sock = fakeSock();
  await say(sock, g, OWNER, '.picks');
  assert.match(last(sock), /Better to avoid/);
  await say(sock, g, OWNER, '.market TECH');
  assert.match(last(sock), /Outlook/);
});

test('news: a failed send is tried again, and an update with the owners tagged goes out on EVERY 30 minute update', async () => {
  const g = newGroup();
  const a = person();
  const b = person();
  market.enable(g);
  fund(g, a, 50000);
  fund(g, b, 50000);
  assert.ok(market.invest(g, a, 'TECH', '10000').ok);
  assert.ok(market.invest(g, b, 'TECH', '5000').ok);
  assert.ok(market.propertyBuy(g, a, 'flat').ok);
  const G = market.state(g);
  let t = G.ticked;
  let fail = true;
  const out = [];
  const post = async (grp, c) => { if (fail) throw new Error('offline'); if (grp === g && /Market (Update|News)/.test(c.text)) out.push(c); };
  t += 30 * 60000 + 1;
  await market.tick(post, t);
  assert.strictEqual(out.length, 0);
  assert.ok(G.pending, 'kept for later');
  fail = false;
  await market.tick(post, t + 1000);
  assert.strictEqual(out.length, 1);
  assert.strictEqual(G.pending, null);
  for (let i = 0; i < 9; i++) { t += 30 * 60000 + 1; await market.tick(post, t); }
  assert.strictEqual(out.length, 10, 'one message for each update');
  assert.ok(out.every((m) => /Market (Update|News)/.test(m.text)));
  const tagged = out.filter((m) => m.mentions && m.mentions.includes(a));
  assert.ok(tagged.length >= 1, 'owners are tagged');
  assert.ok(out.some((m) => m.text.includes(`@${a.split('@')[0]}`)));
});

test('profit: rent, dividends and business profit that wait to be collected count, and collecting does not change profit', async () => {
  const g = newGroup();
  const a = person();
  market.enable(g);
  fund(g, a, 500000);
  assert.ok(market.businessBuy(g, a, 'shop').ok);
  const p0 = market.profit(g, a).overall.profit;
  assert.ok(Math.abs(p0) < 1, 'buying a business is not a loss');
  const G = market.state(g);
  let t = G.ticked;
  for (let i = 0; i < 96; i++) { t += 30 * 60000; market.advance(g, t); }
  const before = market.profit(g, a, t).overall.profit;
  assert.ok(before > 300, `two days of business profit show in profit (${before})`);
  const w0 = wallet(g, a);
  const c = market.collect(g, a);
  assert.ok(c.total > 300 && wallet(g, a) - w0 === c.total, 'the coins reach the wallet');
  const after = market.profit(g, a, t).overall.profit;
  assert.ok(Math.abs(after - before) < 3, `collect keeps profit the same (${before} vs ${after})`);
});

test('bank: pays a little interest on what is in it', async () => {
  const g = newGroup();
  const a = person();
  fund(g, a, 10000);
  economy.runIn(g, () => {
    economy.deposit(a, 10000);
    economy.peek(a).bt -= 2 * 86400000;
    assert.ok(economy.bankOf(a) >= 10050);
  });
});

test('the king cannot rob and cannot be robbed; peace law stops all robbery', async () => {
  const g = newGroup();
  const king = person();
  const a = person();
  const b = person();
  fund(g, king, 20000);
  fund(g, a, 5000);
  fund(g, b, 5000);
  assert.ok(throne.take(g, king).ok);
  economy.runIn(g, () => {
    assert.strictEqual(economy.rob(king, a).why, 'king');
    assert.strictEqual(economy.rob(a, king).why, 'kingsafe');
  });
  assert.ok(throne.law(g, king, 'peace').ok);
  assert.strictEqual(throne.law(g, king, 'peace').why, 'active');
  economy.runIn(g, () => assert.strictEqual(economy.rob(a, b).why, 'peace'));
});

test('gov: unjail one, amnesty for all, bank holiday pays more, the gov panel answers', async () => {
  const sock = fakeSock();
  const g = newGroup();
  const king = person();
  const a = person();
  const b = person();
  fund(g, king, 50000);
  assert.ok(throne.take(g, king).ok);
  assert.ok(throne.jail(g, king, a).ok);
  assert.ok(throne.jailLeft(g, economy.keyOf(a)) > 0);
  assert.strictEqual(throne.unjail(g, a, b).why, 'notking');
  assert.ok(throne.unjail(g, king, a).ok);
  assert.strictEqual(throne.jailLeft(g, economy.keyOf(a)), 0);
  assert.strictEqual(throne.unjail(g, king, a).why, 'free');
  // amnesty frees everybody
  const cd = throne.RULES.jailCooldownMs;
  state: {
    const G = require('../core/throne');
    assert.strictEqual(G.amnesty(g, king).why, 'none');
  }
  // holiday
  const base = economy.runIn(g, () => economy.payout(b, 1000, { tax: false, tools: false }).gross);
  assert.ok(throne.law(g, king, 'holiday').ok);
  const hol = economy.runIn(g, () => economy.payout(b, 1000, { tax: false, tools: false }).gross);
  assert.ok(hol > base * 1.1, `holiday pays more (${hol} vs ${base})`);
  // commands
  await say(sock, g, king, '.gov');
  assert.match(last(sock), /Government/);
  await say(sock, g, king, `.gov unjail @${a.split('@')[0]}`);
  assert.match(last(sock), /not in jail/);
  await say(sock, g, a, '.gov unjail @' + b.split('@')[0]);
  assert.match(last(sock), /Only the king/);
  assert.ok(cd > 0);
});

test('alert: a plain price picks above or below by itself', async () => {
  const sock = fakeSock();
  const g = newGroup();
  market.enable(g);
  await say(sock, g, OWNER, '.alert TECH 200');
  assert.match(last(sock), /below/);
  await say(sock, g, OWNER, '.alert FARM 9999');
  assert.match(last(sock), /above/);
});

test('throne: the owner sets the king income, the king sets a tax that people pay, feast and jail work', async () => {
  const g = newGroup();
  const king = person();
  const a = person();
  const b = person();
  const c = person();
  const d = person();
  fund(g, king, 10000);
  assert.ok(throne.take(g, king).ok);
  const t = Date.now();
  throne.setIncome(g, 400);
  assert.strictEqual(throne.info(g).income, 400);
  assert.ok(throne.collect(g, king, t + 2 * 3600000).amount >= 800);
  throne.setIncome(null, 250);
  throne.resetIncome(g);
  assert.strictEqual(throne.info(g).income, 250);
  throne.resetIncome(null);
  assert.strictEqual(throne.info(g).income, 100);
  assert.strictEqual(throne.setTax(g, a, 3).why, 'notking');
  assert.strictEqual(throne.setTax(g, king, 50).why, 'range');
  assert.ok(throne.setTax(g, king, 5).ok);
  const before = wallet(g, king);
  economy.runIn(g, () => {
    const p = economy.payout(a, 1000, { tools: false });
    assert.ok(p.tax >= 40 && p.net + p.tax === p.gross);
  });
  assert.ok(wallet(g, king) > before, 'the king got the tax');
  // feast
  for (const x of [a, b, c, d]) throne.seen(g, x);
  const f = throne.feast(g, king, 1000);
  assert.ok(f.ok && f.guests.length === 4 && f.each >= 270);
  assert.strictEqual(throne.feast(g, king, 1000).why, 'wait');
  // jail
  assert.ok(throne.jail(g, king, b).ok);
  economy.runIn(g, () => {
    fund(g, b, 1000);
    assert.strictEqual(economy.gamble(b, 100).why, 'jail');
    assert.strictEqual(economy.rob(b, a).why, 'jail');
  });
  // a new king clears the tax and the jail
  const k2 = person();
  fund(g, k2, 100000);
  assert.ok(throne.take(g, k2).ok);
  assert.strictEqual(throne.info(g).tax, 0);
  economy.runIn(g, () => assert.ok(economy.gamble(b, 100).ok));
});

test('couples: love grows, gives a pay bonus, shared waiting times, divorce resets', async () => {
  const sock = fakeSock();
  const g = newGroup();
  const a = person();
  const b = person();
  fund(g, a, 1000);
  await say(sock, g, a, '.couple');
  assert.match(last(sock), /no partner/);
  economy.runIn(g, () => {
    economy.propose(a, b);
    assert.ok(economy.accept(b).ok);
  });
  await say(sock, g, a, '.couple date');
  assert.match(last(sock), /Date night/);
  await say(sock, g, b, '.couple date');
  assert.match(last(sock), /already had a date/);
  await say(sock, g, b, '.couple daily');
  assert.match(last(sock), /Couple bonus/);
  economy.runIn(g, () => {
    assert.ok(economy.coupleInfo(a).love >= 11);
    economy.addLove(a, 200);
    assert.strictEqual(economy.loveTier(economy.coupleInfo(a).love).name, 'Soulmates');
    const p = economy.payout(a, 1000, { tax: false, tools: false });
    assert.ok(p.gross >= 1060);
    economy.divorce(a);
    assert.strictEqual(economy.coupleInfo(a), null);
    assert.strictEqual(economy.peek(b).love, 0);
  });
});

test('shop: shield stops robbery, lockpick and toolbox are timed items', async () => {
  const g = newGroup();
  const a = person();
  const v = person();
  fund(g, a, 20000);
  fund(g, v, 5000);
  economy.runIn(g, () => {
    assert.ok(economy.buy(v, 'shield').ok);
    assert.strictEqual(economy.buy(v, 'shield').why, 'active');
    assert.strictEqual(economy.rob(a, v).why, 'shield');
    assert.ok(economy.buy(a, 'tools').ok);
    const p = economy.payout(a, 1000);
    assert.ok(p.tools && p.gross >= 1250 * 0.84);
    assert.ok(economy.buy(a, 'lockpick').ok);
  });
});

test('give: a phone number before the amount is not taken as the amount', async () => {
  const sock = fakeSock();
  const g = newGroup();
  const a = person();
  const b = person();
  fund(g, a, 1000);
  await say(sock, g, a, `.give ${b.split('@')[0]} 100`);
  assert.strictEqual(wallet(g, b), 100);
  assert.strictEqual(wallet(g, a), 900);
});

test('activities: crime, beg, weekly, garden, rep, earn and the coin drop answer', async () => {
  ratelimit.reset();
  const sock = fakeSock();
  const g = newGroup();
  const a = person();
  const b = person();
  fund(g, a, 1000);
  await say(sock, g, a, '.weekly');
  assert.match(last(sock), /Weekly bonus/);
  await say(sock, g, a, '.weekly');
  assert.match(last(sock), /already took/);
  await say(sock, g, a, '.plant');
  assert.match(last(sock), /Planted/);
  await say(sock, g, a, '.garden harvest');
  assert.match(last(sock), /Not ready/);
  economy.runIn(g, () => { economy.peek(a).plot.at -= 2 * 3600000; });
  await say(sock, g, a, '.garden harvest');
  assert.match(last(sock), /Harvest!/);
  await say(sock, g, a, '.crime');
  assert.match(last(sock), /Earned|Fine/);
  await say(sock, g, a, '.beg');
  assert.ok(last(sock));
  await say(sock, g, a, `.rep @${b.split('@')[0]}`);
  assert.match(last(sock), /reputation/i);
  ratelimit.reset(); // (the coin flood guard would pause somebody who sends 12 coin commands in a few seconds)
  await say(sock, g, a, '.earn');
  assert.match(last(sock), /What to do now/);
  await say(sock, g, a, '.grab');
  assert.match(last(sock), /nothing to grab/);
  drops.drop(g, 200);
  const before = wallet(g, b);
  await say(sock, g, b, '.grab');
  assert.strictEqual(wallet(g, b), before + 200);
  await say(sock, g, a, '.grab');
  assert.match(last(sock), /nothing to grab/);
});

test('coin drops: appear in a busy chat, never when the economy is off or drops are muted', async () => {
  const sock = fakeSock();
  const g = newGroup();
  const t = Date.now() + 3600000;
  let dropped = 0;
  for (let i = 0; i < 100; i++) if (await drops.onMessage(sock, g, t, () => 0)) dropped++;
  assert.strictEqual(dropped, 1);
  const g2 = newGroup();
  economy.setOff(g2, true);
  for (let i = 0; i < 100; i++) assert.ok(!(await drops.onMessage(sock, g2, t, () => 0)));
  const g3 = newGroup();
  economy.setDrops(g3, false);
  for (let i = 0; i < 100; i++) assert.ok(!(await drops.onMessage(sock, g3, t, () => 0)));
});

test('rate limit: one person is counted once even when the id changes, and coin commands have their own limit', async () => {
  ratelimit.reset();
  store.updateRate((r) => { r.on = true; r.limit = 5; r.owner = false; });
  const sock = fakeSock();
  const g = newGroup();
  const a = '2787771111@s.whatsapp.net';
  let answered = 0;
  for (let i = 0; i < 12; i++) {
    const before = sock.texts().length;
    await say(sock, g, a, '.ping');
    if (sock.texts().length > before && !/Slow down/.test(last(sock))) answered++;
  }
  assert.ok(answered <= 5 + 1, `answered ${answered}`);
  ratelimit.reset();
  const who = 'eco-spammer';
  const ok = [];
  for (let i = 0; i < 10; i++) ok.push(ratelimit.checkEconomy(who).ok);
  assert.strictEqual(ok.filter(Boolean).length, 8);
  // the owner can test the limit on himself
  ratelimit.reset();
  store.updateRate((r) => { r.limit = 3; r.owner = true; });
  let ownerAnswered = 0;
  for (let i = 0; i < 8; i++) {
    const before = sock.texts().length;
    await say(sock, g, OWNER, '.ping');
    if (sock.texts().length > before && !/Slow down/.test(last(sock))) ownerAnswered++;
  }
  assert.ok(ownerAnswered <= 4, `owner answered ${ownerAnswered}`);
  store.updateRate((r) => { r.limit = 20; r.owner = false; });
  ratelimit.reset();
});

test('ecotransfer: coins, items and investments move to another group (move and copy)', async () => {
  const from = newGroup();
  const to = newGroup();
  const a = person();
  const b = person();
  market.enable(from);
  fund(from, a, 5000);
  fund(from, b, 700);
  economy.runIn(from, () => economy.buy(a, 'shield'));
  assert.ok(market.invest(from, a, 'FARM', '500').ok);
  fund(to, a, 100);
  const worthBefore = market.portfolio(from, a).worth.total + 0;
  const copied = economy.moveGroup(from, to, economy.keyOf(a), 'copy');
  assert.strictEqual(copied.length, 1);
  assert.ok(wallet(from, a) > 0, 'copy keeps the data');
  assert.ok(wallet(to, a) > 3000);
  const left = wallet(from, a);
  economy.runIn(to, () => assert.ok(economy.itemLeft(a, 'shield') > 0));
  assert.strictEqual(market.transferPlayers(from, to, economy.keyOf(a), 'move'), 1);
  assert.ok(market.state(to).players[economy.keyOf(a)].hold.FARM > 0);
  assert.ok(!market.state(from).players[economy.keyOf(a)]);
  const all = economy.moveGroup(from, to, null, 'move');
  assert.ok(all.length >= 1);
  assert.strictEqual(wallet(from, b), 0);
  assert.strictEqual(wallet(to, b), 700);
  assert.ok(left >= 0 && worthBefore > 0);
});

test('owner commands: kingincome and ecotransfer need the main owner and answer', async () => {
  const sock = fakeSock();
  const g = newGroup();
  const a = person();
  await say(sock, g, a, '.kingincome 500');
  assert.match(last(sock), /Only the main bot owner|^$/);
  await say(sock, g, OWNER, '.kingincome 500');
  assert.match(last(sock), /500 coins an hour/);
  assert.strictEqual(throne.info(g).income, 500);
  await say(sock, g, OWNER, '.kingincome maxtax 10');
  assert.strictEqual(throne.info(g).maxTax, 10);
  await say(sock, g, OWNER, '.kingincome reset');
  assert.strictEqual(throne.info(g).income, 100);
  await say(sock, g, OWNER, '.ecotransfer');
  assert.match(last(sock), /Move economy data/);
});

test('the version is 0.7.7', () => {
  assert.strictEqual(require('../package.json').version, '0.7.7');
  assert.match(require('fs').readFileSync(require('path').join(__dirname, '..', 'changelog.txt'), 'utf8'), /^TurboFex v0\.7\.7/);
});

// ------------------------------------------------------------ the second round: governor, breaking news, new activities
const governor = require('../core/governor');
const community = require('../core/community');
const report = require('../core/report');

test('governor: run, vote, the election closes, the winner earns a salary and has powers', async () => {
  const g = newGroup();
  const [c1, c2, v1, v2, v3, king] = [person(), person(), person(), person(), person(), person()];
  for (const w of [c1, c2, v1, v2, v3]) fund(g, w, 2000);
  fund(g, king, 50000);
  assert.ok(throne.take(g, king).ok);
  assert.strictEqual(governor.run(g, king).why, 'king');
  const t0 = Date.now();
  assert.ok(governor.run(g, c1, t0).started);
  assert.ok(governor.run(g, c2, t0).ok);
  assert.strictEqual(governor.run(g, c2, t0).why, 'already');
  assert.strictEqual(governor.vote(g, v1, v1, t0).why, 'notcand');
  for (const v of [v1, v2, v3]) assert.ok(governor.vote(g, v, c2, t0).ok);
  assert.ok(governor.vote(g, v3, c1, t0).changed);
  assert.strictEqual(governor.resolve(g, t0 + 1000), null, 'not over yet');
  const r = governor.resolve(g, t0 + 13 * 3600000);
  assert.ok(r.ok && r.winner.key === economy.keyOf(c2));
  assert.strictEqual(wallet(g, c2), 2000 - 200 + 400, 'the winner gets the campaign fund');
  assert.ok(governor.isGovernor(g, c2));
  assert.strictEqual(governor.run(g, v1).why, 'term');
  // salary
  const later = t0 + 13 * 3600000 + 5 * 3600000;
  assert.ok(governor.collect(g, c2, later).amount >= 290);
  // sale makes the shop cheaper, feecut halves the fees
  const price = economy.runIn(g, () => economy.priceOf('charm'));
  fund(g, c2, 5000);
  assert.ok(governor.law(g, c2, 'sale').ok);
  assert.ok(economy.runIn(g, () => economy.priceOf('charm')) < price);
  assert.strictEqual(governor.law(g, c2, 'sale').why, 'active');
  market.enable(g);
  const fee0 = market.quotes(g)[0].outlook.fees;
  assert.ok(governor.law(g, c2, 'feecut').ok);
  assert.ok(market.quotes(g)[0].outlook.fees < fee0 * 0.6);
  // veto stops the king's tax
  assert.strictEqual(governor.law(g, c2, 'veto').why, 'notax');
  assert.ok(throne.setTax(g, king, 5).ok);
  assert.ok(governor.law(g, c2, 'veto').ok);
  economy.runIn(g, () => assert.strictEqual(economy.payout(v1, 1000, { tools: false }).tax, 0));
  // audit
  fund(g, v1, 10);
  const a = governor.audit(g, c2, v1);
  assert.ok(a.ok && a.coins >= 2000);
  assert.strictEqual(governor.audit(g, v1, c2).why, 'notgov');
  // not enough votes: fees go back
  const g2 = newGroup();
  const solo = person();
  fund(g2, solo, 1000);
  governor.run(g2, solo, t0);
  const fail = governor.resolve(g2, t0 + 13 * 3600000);
  assert.ok(!fail.ok);
  assert.strictEqual(wallet(g2, solo), 1000);
});

test('gov command answers for both the king and the governor', async () => {
  const sock = fakeSock();
  const g = newGroup();
  const a = person();
  fund(g, a, 1000);
  await say(sock, g, a, '.gov');
  assert.match(last(sock), /Government/);
  assert.match(last(sock), /Governor/);
  await say(sock, g, a, '.gov run');
  assert.match(last(sock), /candidate for Governor/);
  await say(sock, g, a, '.governor');
  assert.match(last(sock), /Election is open/);
  await say(sock, g, OWNER, '.kingincome salary 100');
  assert.match(last(sock), /100 coins an hour/);
  await say(sock, g, OWNER, '.kingincome salary reset');
  assert.strictEqual(governor.salaryOf(), 60);
});

test('breaking news moves prices and tags the owners', async () => {
  const g = newGroup();
  const a = person();
  market.enable(g);
  fund(g, a, 20000);
  assert.ok(market.invest(g, a, 'TECH', '5000').ok);
  const G = market.state(g);
  G.until = Date.now() + 99 * 86400000;
  require('../core/marketdata').RULES.flashChance = 0.5;
  let t = G.ticked;
  let found = null;
  for (let i = 0; i < 400 && !found; i++) {
    t += 30 * 60000 + 1;
    const ev = market.advance(g, t);
    found = ev.notes.find((n) => n.type === 'flash' && n.flash.rows.some((r) => r.id === 'TECH'));
  }
  require('../core/marketdata').RULES.flashChance = 0;
  assert.ok(found, 'a breaking news about TECH came');
  const msg = market.noteMessage(g, found);
  assert.match(msg.text, /BREAKING NEWS/);
  assert.ok(msg.mentions.includes(a), 'the owner is tagged');
  assert.ok(Math.abs(found.flash.rows.find((r) => r.id === 'TECH').pct) > 1);
});

test('daily report lists the richest, government and tags', async () => {
  const g = newGroup();
  const a = person();
  market.enable(g);
  fund(g, a, 7000);
  const out = report.build(g);
  assert.match(out.text, /Daily Economy Report/);
  assert.ok(out.mentions.includes(a));
  const sent = [];
  const G = market.state(g);
  await report.tick(async (grp, c) => { if (grp === g) sent.push(c); }, G.created + 25 * 3600000);
  assert.strictEqual(sent.length, 1);
  await report.tick(async (grp, c) => { if (grp === g) sent.push(c); }, G.created + 26 * 3600000);
  assert.strictEqual(sent.length, 1, 'once a day');
});

test('community fund: donors get 125% back at the goal and the group earns more for an hour', async () => {
  const g = newGroup();
  const [a, b, c] = [person(), person(), person()];
  for (const w of [a, b, c]) fund(g, w, 5000);
  economy.runIn(g, () => {
    assert.ok(community.donate(g, a, 2000).ok);
    assert.ok(community.donate(g, b, 2000).ok);
    const r = community.donate(g, c, 4000);
    assert.ok(r.reached && r.put === 1000);
    assert.strictEqual(economy.balance(a), 3000 + 2500);
    const p = economy.payout(a, 1000, { tax: false, tools: false });
    assert.ok(p.gross >= 1140, `boom pays more (${p.gross})`);
    assert.strictEqual(community.info(g).goal, 7500);
  });
});

test('bounty: collected by whoever robs the target; the king cannot carry one', async () => {
  const g = newGroup();
  const [a, b, c, king] = [person(), person(), person(), person()];
  for (const w of [a, b, c]) fund(g, w, 5000);
  fund(g, king, 20000);
  throne.take(g, king);
  economy.runIn(g, () => {
    assert.strictEqual(economy.placeBounty(a, king, 500).why, 'king');
    assert.strictEqual(economy.placeBounty(a, a, 500).why, 'self');
    assert.ok(economy.placeBounty(a, b, 1000).ok);
    assert.ok(economy.placeBounty(c, b, 500).ok);
    assert.strictEqual(economy.bountyOf(b), 1500);
    const r = economy.rob(c, b, () => 0.1); // always succeeds
    assert.ok(r.success && r.bounty === 1500);
    assert.strictEqual(economy.bountyOf(b), 0);
  });
});

test('new activities answer: pet, quiz, spin, rain, community, bounty', async () => {
  const sock = fakeSock();
  const g = newGroup();
  const [a, b, c, d] = [person(), person(), person(), person()];
  fund(g, a, 5000);
  ratelimit.reset();
  await say(sock, g, a, '.pet');
  assert.match(last(sock), /no pet/);
  await say(sock, g, a, '.pet adopt dog Rex');
  assert.match(last(sock), /adopted Rex/);
  await say(sock, g, a, '.pet feed');
  assert.match(last(sock), /ate/);
  await say(sock, g, a, '.pet play');
  assert.match(last(sock), /played|tired/);
  economy.runIn(g, () => { economy.peek(a).pet.collected -= 5 * 3600000; });
  await say(sock, g, a, '.pet collect');
  assert.match(last(sock), /brought you/);
  ratelimit.reset();
  await say(sock, g, a, '.spin');
  assert.match(last(sock), /You won/);
  await say(sock, g, a, '.spin');
  assert.match(last(sock), /already spun/);
  await say(sock, g, a, '.brain');
  assert.match(last(sock), /QUIZ TIME/);
  const text = last(sock);
  await say(sock, g, a, '.brain');
  assert.match(last(sock), /still open/);
  // find the right answer by trying all letters from different people
  const before = wallet(g, b);
  let won = false;
  for (const [who, l] of [[b, 'a'], [c, 'b'], [d, 'c'], [person(), 'd']]) {
    await say(sock, g, who, `.brain ${l}`);
    if (/got it/.test(last(sock))) { won = true; break; }
  }
  assert.ok(won || text);
  ratelimit.reset();
  for (const w of [b, c, d]) await say(sock, g, w, 'hi all');
  await say(sock, g, a, '.rain 300');
  assert.match(last(sock), /made it rain|Too quiet/);
  await say(sock, g, a, '.community');
  assert.match(last(sock), /Community fund/);
  await say(sock, g, a, '.community give 100');
  assert.match(last(sock), /gave 100/);
  await say(sock, g, a, `.bounty @${b.split('@')[0]} 300`);
  assert.match(last(sock), /BOUNTY/);
  await say(sock, g, a, '.bounty list');
  assert.match(last(sock), /Wanted/);
  assert.ok(before >= 0);
});

test('economy off also stops the new commands', async () => {
  const sock = fakeSock();
  const g = newGroup();
  const a = person();
  ratelimit.reset();
  economy.setOff(g, true);
  for (const c of ['.pet', '.brain', '.spin', '.rain 100', '.community', '.bounty list', '.governor', '.gov', '.rep', '.heist']) {
    await say(sock, g, a, c);
    assert.match(last(sock), /economy is turned off/, c);
  }
});
