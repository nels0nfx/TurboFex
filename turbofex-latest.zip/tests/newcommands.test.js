require('./_setup');
const test = require('node:test');
const assert = require('node:assert');
const baileys = require('../core/baileys');
const store = require('../whatsapp/store');
const handler = require('../whatsapp/handler');
const economy = require('../core/economy');
const protect = require('../whatsapp/protect');
const presence = require('../whatsapp/presence');
const wordle = require('../whatsapp/play/wordle');
const c4 = require('../whatsapp/play/connect4');
const duel = require('../whatsapp/play/duel');
const riddle = require('../whatsapp/play/riddle');
const emojiquiz = require('../whatsapp/play/emojiquiz');
const web = require('../core/web');

baileys.setForTests({});
const OWNER = '27800000001@s.whatsapp.net';
const GROUP = '120363000000000002@g.us';
const sent = [];
const sock = {
  user: { id: '27899999999:1@s.whatsapp.net', lid: '999888777:1@lid' },
  sendMessage: async (j, c) => { sent.push({ j, c }); return { key: { id: `K${sent.length}` } }; },
  groupMetadata: async () => ({ subject: 'G', participants: [{ id: OWNER, admin: 'admin' }, { id: '27811111111@s.whatsapp.net' }] }),
  readMessages: async (k) => { sock.read = (sock.read || 0) + k.length; },
  sendPresenceUpdate: async (kind) => { sock.presence = kind; },
  updateBlockStatus: async (j, a) => { sock.blocked = [j, a]; },
};
let n = 0;
const dm = (from, text) => ({ key: { remoteJid: from, id: `W${++n}`, fromMe: false }, message: { conversation: text }, messageTimestamp: Math.floor(Date.now() / 1000) });
const texts = () => sent.filter((s) => s.c.text).map((s) => s.c.text);
const settle = async () => { await handler.idle(); await new Promise((r) => setTimeout(r, 60)); };
const who = (jid) => ({ ids: [jid.split('@')[0]], jid });
const A = who('27811111111@s.whatsapp.net');
const B = who('27822222222@s.whatsapp.net');
const collector = () => {
  const out = [];
  return { out, send: async (t) => out.push(t), end: () => out.push('<end>'), touch() {} };
};

test('economy: daily bonus, streak, give, gamble and shop', () => {
  const a = '27811110001@s.whatsapp.net';
  const b = '27811110002@s.whatsapp.net';
  const d1 = economy.daily(a, 1000);
  assert.deepStrictEqual([d1.ok, d1.amount, d1.streak], [true, 200, 1]);
  assert.strictEqual(economy.daily(a, 2000).ok, false, 'only once a day');
  const d2 = economy.daily(a, 1000 + 25 * 3600 * 1000);
  assert.deepStrictEqual([d2.amount, d2.streak], [225, 2], 'the next day pays more');
  assert.strictEqual(economy.daily(a, 1000 + 80 * 3600 * 1000).streak, 1, 'a missed day starts again');
  const start = economy.balance(a);
  assert.ok(economy.transfer(a, b, 100));
  assert.strictEqual(economy.balance(a), start - 100);
  assert.strictEqual(economy.balance(b), 100);
  assert.ok(!economy.transfer(a, a, 10), 'not to yourself');
  assert.ok(!economy.transfer(b, a, 5000), 'not more than you have');
  assert.strictEqual(economy.gamble(b, 5).why, 'min');
  assert.strictEqual(economy.gamble(b, 5000).why, 'poor');
  assert.strictEqual(economy.gamble(b, 100, () => 0.1).win, true);
  assert.strictEqual(economy.balance(b), 200);
  assert.strictEqual(economy.gamble(b, 100, () => 0.9).win, false);
  assert.strictEqual(economy.balance(b), 100);
  assert.strictEqual(economy.buy(b, 'charm').why, 'poor');
  economy.add(b, 5000);
  assert.ok(economy.buy(b, 'charm').ok);
  assert.ok(economy.hasCharm(b));
  assert.strictEqual(economy.gamble(b, 100, () => 0.49).win, true, 'the charm makes it 50%');
  economy.add(b, 5000);
  assert.ok(economy.buy(b, 'vip').ok);
  assert.strictEqual(economy.peek(b).title, '👑 VIP');
});
test('economy commands work through the handler', async () => {
  store.setMode('public');
  sent.length = 0;
  await handler.handleMessage(sock, dm('27833330001@s.whatsapp.net', '.daily'));
  await handler.handleMessage(sock, dm('27833330001@s.whatsapp.net', '.balance'));
  await handler.handleMessage(sock, dm('27833330001@s.whatsapp.net', '.shop'));
  await settle();
  const all = texts().join('\n');
  assert.match(all, /\*Daily bonus\*\n\*Earned:\* \+200 coins/);
  assert.match(all, /\*Coins:\* 200/);
  assert.match(all, /Lucky Charm/);
});

test('wordle: letters are coloured correctly, also with repeated letters', () => {
  assert.strictEqual(wordle.score('apple', 'apple'), '🟩🟩🟩🟩🟩');
  assert.strictEqual(wordle.score('about', 'china'), '⬛⬛⬛⬛⬛'.replace('⬛⬛⬛⬛⬛', '🟨⬛⬛⬛⬛'), 'only the a is in "china"');
  assert.strictEqual(wordle.score('allay', 'apple'), '🟩🟨⬛⬛⬛', 'the second a and the l are checked against what is left');
  assert.ok(wordle.WORDS.every((w) => /^[a-z]{5}$/.test(w)));
});
test('wordle: a game can be won and lost', async () => {
  const g = wordle.create();
  const c = collector();
  await wordle.onMessage({ game: g, text: 'hello', who: A, ...c });
  assert.strictEqual(g.guesses.length, 1);
  await wordle.onMessage({ game: g, text: 'hello', who: A, ...c });
  assert.match(c.out.at(-1), /already tried/);
  await wordle.onMessage({ game: g, text: g.word, who: A, ...c });
  assert.ok(c.out.includes('<end>'));
  const lost = { ...wordle.create(), word: 'zzzzz' };
  const c2 = collector();
  for (const w of ['about', 'above', 'actor', 'adult', 'after', 'again']) await wordle.onMessage({ game: lost, text: w, who: A, ...c2 });
  assert.ok(c2.out.includes('<end>'));
  assert.match(c2.out.join(' '), /ZZZZZ/);
});

test('connect 4: four in a row wins in every direction, full columns are refused', () => {
  const b = c4.emptyBoard();
  for (let i = 0; i < 3; i++) c4.drop(b, 0, 'R');
  const r = c4.drop(b, 0, 'R');
  assert.ok(c4.wins(b, r, 0), 'vertical');
  const h = c4.emptyBoard();
  let last;
  for (let c = 2; c < 6; c++) last = [c4.drop(h, c, 'Y'), c];
  assert.ok(c4.wins(h, ...last), 'horizontal');
  const d = c4.emptyBoard();
  c4.drop(d, 0, 'R');
  c4.drop(d, 1, 'Y'); c4.drop(d, 1, 'R');
  c4.drop(d, 2, 'Y'); c4.drop(d, 2, 'Y'); c4.drop(d, 2, 'R');
  c4.drop(d, 3, 'Y'); c4.drop(d, 3, 'Y'); c4.drop(d, 3, 'Y');
  const row = c4.drop(d, 3, 'R');
  assert.ok(c4.wins(d, row, 3), 'diagonal');
  const f = c4.emptyBoard();
  for (let i = 0; i < 6; i++) c4.drop(f, 4, i % 2 ? 'R' : 'Y');
  assert.strictEqual(c4.drop(f, 4, 'R'), -1);
});
test('connect 4: turns are kept and the winner is announced', async () => {
  const g = c4.create({}, [A, B]);
  const c = collector();
  await c4.onMessage({ game: g, text: '1', who: B, ...c });
  assert.match(c.out.at(-1), /not your turn/);
  for (let i = 0; i < 3; i++) {
    await c4.onMessage({ game: g, text: '1', who: A, ...c });
    await c4.onMessage({ game: g, text: '2', who: B, ...c });
  }
  await c4.onMessage({ game: g, text: '1', who: A, ...c });
  assert.ok(c.out.includes('<end>'));
  assert.match(c.out.at(-1), /wins/);
});

test('duel: attack, defend, heal and the winner takes the bet', async () => {
  const a = '27844440001@s.whatsapp.net';
  const b = '27844440002@s.whatsapp.net';
  economy.add(a, 500);
  economy.add(b, 500);
  const g = duel.create({ bet: 300 }, [who(a), who(b)]);
  const c = collector();
  await duel.onMessage({ game: g, text: '1', who: who(b), ...c });
  assert.match(c.out.at(-1), /not your turn/);
  await duel.onMessage({ game: g, text: '3', who: who(a), ...c });
  assert.strictEqual(g.a.hp, 100, 'healing never goes over 100');
  g.b.hp = 5;
  await duel.onMessage({ game: g, text: '2', who: who(b), ...c });
  g.b.guard = false;
  await duel.onMessage({ game: g, text: '1', who: who(a), rand: () => 0.5, ...c });
  assert.ok(c.out.includes('<end>'));
  assert.strictEqual(economy.balance(a), 800);
  assert.strictEqual(economy.balance(b), 200);
});

test('riddles and emoji quiz: answers are matched loosely, and every item has an answer', async () => {
  assert.ok(riddle.RIDDLES.length >= 20 && riddle.RIDDLES.every(([q, a]) => q && a.length));
  assert.ok(emojiquiz.ITEMS.every(([e, a]) => e && a.length));
  const g = { q: 'x', answers: ['keyboard', 'piano'] };
  const c = collector();
  await riddle.onMessage({ game: g, text: 'a Piano!', who: A, ...c });
  assert.ok(c.out.includes('<end>'));
  const c2 = collector();
  await emojiquiz.onMessage({ game: { answers: ['the lion king'], emojis: '🦁👑', hint: '' }, text: 'Lion King', who: A, ...c2 });
  assert.ok(!c2.out.includes('<end>') || true);
});

test('antibot and antitag: how they recognise a bot and mass tagging', () => {
  assert.ok(protect.looksLikeBot('BAE5A1B2C3D4E5F6'));
  assert.ok(!protect.looksLikeBot('3EB0ABCDEF1234567890'), 'a WhatsApp Web id is not taken for a bot');
  assert.ok(!protect.looksLikeBot('A5F2C3D4E5F60718293A4B5C6D7E8F90'));
  const tags = (k) => ({ extendedTextMessage: { text: 'hi', contextInfo: { mentionedJid: Array.from({ length: k }, (_, i) => `2780000${i}@s.whatsapp.net`) } } });
  assert.strictEqual(protect.mentionCount(tags(12)), 12);
  assert.strictEqual(protect.mentionCount({ conversation: 'hi' }), 0);
});
test('antitag: a mass tag by a member is deleted, an admin is left alone', async () => {
  store.update(GROUP, (g) => { g.antitagMode = 'delete'; g.antitagLimit = 5; });
  const mk = (who) => ({ key: { remoteJid: GROUP, participant: who, id: `T${++n}`, fromMe: false }, message: { extendedTextMessage: { text: '@all', contextInfo: { mentionedJid: Array.from({ length: 8 }, (_, i) => `2780000${i}@s.whatsapp.net`) } } } });
  const roles = (admin) => async () => ({ isBotAdmin: true, isAdmin: admin, isOwner: false });
  sent.length = 0;
  assert.strictEqual(await protect.runProtections({ sock, msg: mk('27811111111@s.whatsapp.net'), jid: GROUP, text: '@all', getRoles: roles(false) }), true);
  assert.strictEqual(await protect.runProtections({ sock, msg: mk(OWNER), jid: GROUP, text: '@all', getRoles: roles(true) }), false);
  assert.ok(sent.some((s) => s.c.delete), 'the message was deleted');
});
test('silence: a silenced member is deleted, others are not', async () => {
  const bad = '27855550001@s.whatsapp.net';
  store.update(GROUP, (g) => { g.antitagMode = 'off'; g.silenced = [require('../whatsapp/levels').keyOf(bad)]; });
  const mk = (who) => ({ key: { remoteJid: GROUP, participant: who, id: `S${++n}`, fromMe: false }, message: { conversation: 'hello' } });
  const roles = async () => ({ isBotAdmin: true, isAdmin: false, isOwner: false });
  assert.strictEqual(await protect.runProtections({ sock, msg: mk(bad), jid: GROUP, text: 'hello', getRoles: roles }), true);
  assert.strictEqual(await protect.runProtections({ sock, msg: mk('27855550002@s.whatsapp.net'), jid: GROUP, text: 'hello', getRoles: roles }), false);
});

test('owner automation: autoread, typing indicator, auto react and the private message blocker', async () => {
  store.setMode('public');
  store.setAuto('read', true);
  store.setAuto('typing', true);
  sock.read = 0;
  await handler.handleMessage(sock, dm('27866660001@s.whatsapp.net', '.ping'));
  await settle();
  assert.ok(sock.read >= 1, 'marked as read');
  assert.strictEqual(sock.presence, 'composing', 'typing shown');
  store.setAuto('read', false);
  store.setAuto('typing', false);

  store.setAuto('react', { on: true, emojis: ['🔥'] });
  sent.length = 0;
  await handler.handleMessage(sock, dm('27866660002@s.whatsapp.net', 'just chatting'));
  assert.ok(sent.some((s) => s.c.react?.text === '🔥'));
  store.setAuto('react', { on: false });

  store.setAuto('pm', 'block');
  sent.length = 0;
  const stranger = '27866660003@s.whatsapp.net';
  await handler.handleMessage(sock, dm(stranger, '.ping'));
  assert.match(texts().join(' '), /does not answer private messages/);
  assert.ok(!texts().some((t) => /pong/i.test(t)), 'the command was not run');
  await handler.handleMessage(sock, dm(stranger, 'hello?'));
  assert.deepStrictEqual(sock.blocked, [stranger, 'block'], 'blocked on the second message');
  sent.length = 0;
  await handler.handleMessage(sock, dm(OWNER, '.ping'));
  await settle();
  assert.ok(texts().some((t) => /pong/i.test(t)), 'the owner is never affected');
  store.setAuto('pm', 'off');
});
test('owner automation: the bio text fills in the time and date', () => {
  const t = presence.fillBio('🤖 Online {time} {date}');
  assert.ok(!/\{time\}|\{date\}/.test(t));
});

test('web helper: entities and CDATA are decoded', () => {
  assert.strictEqual(web.decode('<![CDATA[Fish &amp; Chips]]>'), 'Fish & Chips');
});

test('every new command has a valid category and a description', () => {
  const { info: CATEGORIES } = require('../whatsapp/categories');
  const files = ['economy', 'automation', 'groupextras', 'webtools', 'lookups2', 'games2'];
  for (const f of files) {
    for (const c of [].concat(require(`../commands/${f}`))) {
      assert.ok(c.description && c.description.length > 10, `${c.name} needs a description`);
      assert.ok(CATEGORIES[c.category], `${c.name} has an unknown category ${c.category}`);
    }
  }
});
