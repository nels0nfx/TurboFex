// Reaction on the command message: ⏳ while the bot works, then ✅ (or ⚠️ / ❌ when something went wrong).
// Turn it off with the "cmdreact" command. Reactions never slow a command down: they are sent in the background.
const store = require('./store');
const { withTimeout } = require('./timeout');

const LOADING = '⏳';
const DONE = '✅';
const WARN = '⚠️';
const FAIL = '❌';

function begin(sock, msg) {
  const mode = store.getCmdReact();
  if (mode === 'off' || !msg?.key?.id || !msg.key.remoteJid) return { finish() {} };

  // reactions are sent one after the other so the last one always wins
  let chain = Promise.resolve();
  const send = (text) => {
    chain = chain
      .then(() => withTimeout(sock.sendMessage(msg.key.remoteJid, { react: { text, key: msg.key } }), 10000, 'reaction timed out'))
      .catch(() => {}); // a missing reaction must never break a command
    return chain;
  };
  send(LOADING);

  return {
    // outcome: 'ok' | 'warn' | 'fail'
    finish(outcome) {
      if (outcome === 'fail') return send(FAIL);
      if (outcome === 'warn') return send(WARN);
      return send(mode === 'clean' ? '' : DONE); // an empty reaction removes it
    },
  };
}

module.exports = { begin, LOADING, DONE, WARN, FAIL };
