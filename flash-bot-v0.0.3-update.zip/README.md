# ⚡ Flash Bot v0.0.3
WhatsApp group management bot by **Nelson Fx** (Trinity Flow).

## Commands
**Basics:** `!ping` `!menu` `!groupinfo`
**Members:** `!tagall` `!kick` `!promote` `!demote`
**Protection:** `!antilink off/delete/warn/kick` `!warn` `!warnings` `!resetwarn` `!warnlimit 5`
**Group:** `!open` `!close` `!welcome on/off` `!goodbye on/off` `!setwelcome` `!setgoodbye`
**Owner:** `!mode public/private`

- Anti-link, welcome and goodbye are OFF by default. Turn them on per group.
- Welcome/goodbye text can use `@user`, `{group}` and `{count}`.
- The bot must be a group admin to delete links, remove people, and open/close the group.
- Private mode: only the owner can use commands.

## Setup on a Pterodactyl panel
1. Upload the zip in the panel's **Files** tab, then tap **Unarchive**.
2. Open `config.js` and fill in your numbers (country code, digits only, no +):
   - `ownerNumber` = your personal number
   - `pairingNumber` = the number the bot will run on
3. Make sure the server uses **Node.js 20 or newer**.
4. Startup: run `npm install` then `npm start` (or set the main file to `index.js` with auto-install on).
5. Press **Start**. The console shows a pairing code like `ABCD-1234`.
6. On the bot number's WhatsApp: **Settings > Linked devices > Link a device > Link with phone number instead**, then enter the code.
7. Add the bot to a group, make it admin, and send `!ping`.

## Notes
- Your login is saved in `session/`. Group settings and warnings are saved in `data/`. Don't delete them.
- Use a spare number for the bot, not your main one. Unofficial bots can get banned.
