const store = require('../whatsapp/store');

module.exports = {
  name: 'antilink',
  description: 'Anti-link: off / delete / warn / kick (admins only)',
  groupOnly: true,
  adminOnly: true,
  async run({ jid, args, reply, prefix, isBotAdmin }) {
    const g = store.getGroup(jid);
    let choice = (args[0] || '').toLowerCase();
    if (choice === 'on') choice = 'warn';

    if (!store.ANTILINK_MODES.includes(choice)) {
      return reply(
        `🛡️ Anti-link is currently *${g.antilinkMode.toUpperCase()}*.\n\n` +
          `Choose what happens when a member sends a link:\n` +
          `• ${prefix}antilink delete - delete the link only\n` +
          `• ${prefix}antilink warn - delete + warn (removed after ${store.getLimit(jid)} warnings)\n` +
          `• ${prefix}antilink kick - delete + remove straight away\n` +
          `• ${prefix}antilink off - switch off\n\n` +
          `Admins are never affected.`
      );
    }

    store.update(jid, (grp) => {
      grp.antilinkMode = choice;
    });
    await reply(`✅ Anti-link is now *${choice.toUpperCase()}*.`);
    if (choice !== 'off' && !isBotAdmin) {
      await reply('⚠️ Note: I must be a group admin to delete links and remove people.');
    }
  },
};
