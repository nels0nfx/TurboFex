const store = require('../whatsapp/store');

const onOff = (v) => (v ? 'ON ✅' : 'OFF ❌');

module.exports = {
  name: 'groupinfo',
  aliases: ['info'],
  description: 'Show group details and bot settings',
  groupOnly: true,
  async run({ jid, reply, groupMetadata: m }) {
    const g = store.getGroup(jid);
    const admins = m.participants.filter((p) => p.admin).length;
    const created = m.creation ? new Date(m.creation * 1000).toLocaleDateString('en-GB') : 'unknown';
    const desc = m.desc ? `\n\n📝 ${String(m.desc).slice(0, 300)}` : '';
    const link = g.antilinkMode === 'off' ? 'OFF ❌' : `${g.antilinkMode.toUpperCase()} ✅`;

    await reply(
      `ℹ️ *${m.subject}*\n\n` +
        `👥 Members: ${m.participants.length}\n` +
        `👑 Admins: ${admins}\n` +
        `📅 Created: ${created}\n` +
        `💬 Who can send: ${m.announce ? 'Admins only 🔒' : 'Everyone 🔓'}\n\n` +
        `🛡️ Anti-link: ${link}\n` +
        `⚠️ Warn limit: ${store.getLimit(jid)}\n` +
        `👋 Welcome: ${onOff(g.welcome)}\n` +
        `🚪 Goodbye: ${onOff(g.goodbye)}` +
        desc
    );
  },
};
