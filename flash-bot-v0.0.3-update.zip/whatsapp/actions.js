const { getTargets, num } = require('./utils');
const store = require('./store');

// Remove one member. Returns true if it worked.
async function removeMember(sock, jid, id) {
  const res = await sock.groupParticipantsUpdate(jid, [id], 'remove');
  return Array.isArray(res) && String(res[0]?.status) === '200';
}

// Shared code for kick / promote / demote
async function changeMembers(ctx, action, doneWord) {
  const { sock, jid, msg, reply, botIds, prefix, cmdName } = ctx;

  const targets = getTargets(msg).filter((t) => !botIds.includes(num(t)));
  if (!targets.length) {
    return reply(
      `Please tag the person or reply to their message.\nExample: ${prefix}${cmdName} @person`
    );
  }

  const results = await sock.groupParticipantsUpdate(jid, targets, action);
  const list = Array.isArray(results) ? results : [];
  const okCount = list.filter((r) => String(r.status) === '200').length;

  if (okCount > 0 && okCount === targets.length) {
    const tags = targets.map((t) => `@${num(t)}`).join(' ');
    return reply(`✅ ${doneWord}: ${tags}`, { mentions: targets });
  }
  if (okCount > 0) {
    return reply(`⚠️ ${doneWord} ${okCount} of ${targets.length}. Some could not be changed.`);
  }
  return reply('⚠️ I could not do that. The person may be the group owner or not in this group.');
}

// Shared code for on/off settings (welcome, goodbye)
async function toggleSetting(ctx, key, label) {
  const { jid, args, reply, prefix, cmdName } = ctx;
  const choice = (args[0] || '').toLowerCase();
  const g = store.getGroup(jid);

  if (choice !== 'on' && choice !== 'off') {
    return reply(
      `${label} is currently *${g[key] ? 'ON' : 'OFF'}*.\nUse ${prefix}${cmdName} on  or  ${prefix}${cmdName} off`
    );
  }
  store.update(jid, (grp) => {
    grp[key] = choice === 'on';
  });
  return reply(`✅ ${label} is now *${choice.toUpperCase()}*.`);
}

// Shared code for !setwelcome and !setgoodbye
async function setMessage(ctx, { textKey, onKey, label, defaultText, toggleCmd }) {
  const { jid, rest, reply, prefix, cmdName } = ctx;
  const g = store.getGroup(jid);

  if (!rest) {
    return reply(
      `✏️ *Current ${label} message:*\n\n${g[textKey] || defaultText}\n\n` +
        `To change it, type:\n${prefix}${cmdName} your message here\n\n` +
        `You can use:\n@user = the person\n{group} = group name\n{count} = member count\n\n` +
        `To go back to the default: ${prefix}${cmdName} reset`
    );
  }

  if (rest.toLowerCase() === 'reset') {
    store.update(jid, (grp) => {
      grp[textKey] = null;
    });
    return reply(`✅ ${label} message reset to the default.`);
  }

  if (rest.length > 1000) return reply('⚠️ That message is too long. Please keep it under 1000 characters.');

  store.update(jid, (grp) => {
    grp[textKey] = rest;
  });
  const note = g[onKey] ? '' : `\n\n(It's currently OFF. Turn it on with ${prefix}${toggleCmd} on)`;
  return reply(`✅ ${label} message saved.${note}`);
}

module.exports = { changeMembers, toggleSetting, setMessage, removeMember };
