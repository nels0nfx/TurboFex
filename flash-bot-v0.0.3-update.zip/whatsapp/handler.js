const fs = require('fs');
const path = require('path');
const config = require('../config');
const store = require('./store');
const { handleAntiLink, LINK_REGEX } = require('./antilink');
const { getText, num, participantIds, senderIds } = require('./utils');

const commands = new Map(); // name or alias -> command
const commandList = [];

function loadCommands() {
  const dir = path.join(__dirname, '..', 'commands');
  for (const file of fs.readdirSync(dir)) {
    if (!file.endsWith('.js')) continue;
    try {
      const cmd = require(path.join(dir, file));
      commandList.push(cmd);
      commands.set(cmd.name, cmd);
      (cmd.aliases || []).forEach((a) => commands.set(a, cmd));
    } catch (err) {
      console.error(`Could not load command ${file}:`, err.message);
    }
  }
  commandList.sort((a, b) => a.name.localeCompare(b.name));
  console.log(`Loaded ${commandList.length} commands.`);
}
loadCommands();

// Works out who sent the message and what rights they (and the bot) have
async function getRoles(sock, msg, jid, isGroup) {
  const sIds = senderIds(msg);
  const botIds = [sock.user?.id, sock.user?.lid].filter(Boolean).map(num);
  const ownerNum = config.ownerNumber;

  let isOwner = !!msg.key.fromMe || !!(ownerNum && sIds.includes(ownerNum));
  let groupMetadata = null;
  let isAdmin = false;
  let isBotAdmin = false;

  if (isGroup) {
    groupMetadata = await sock.groupMetadata(jid);
    for (const p of groupMetadata.participants) {
      const ids = participantIds(p);
      const isSender = ids.some((i) => sIds.includes(i));
      if (isSender && ownerNum && ids.includes(ownerNum)) isOwner = true;
      if (p.admin === 'admin' || p.admin === 'superadmin') {
        if (isSender) isAdmin = true;
        if (ids.some((i) => botIds.includes(i))) isBotAdmin = true;
      }
    }
  }
  return { botIds, isOwner, groupMetadata, isAdmin, isBotAdmin };
}

async function handleMessage(sock, msg) {
  if (!msg.message) return;
  const jid = msg.key.remoteJid;
  if (!jid || jid === 'status@broadcast') return;

  const text = getText(msg).trim();
  const isGroup = jid.endsWith('@g.us');

  // Anti-link check (only when switched on for this group)
  if (
    isGroup && !msg.key.fromMe && text && LINK_REGEX.test(text) &&
    store.getGroup(jid).antilinkMode !== 'off'
  ) {
    const roles = await getRoles(sock, msg, jid, true);
    if (await handleAntiLink(sock, msg, jid, roles)) return;
  }

  if (!text.startsWith(config.prefix)) return;

  const body = text.slice(config.prefix.length).trim();
  const [rawName, ...args] = body.split(/\s+/);
  const cmdName = (rawName || '').toLowerCase();
  const cmd = commands.get(cmdName);
  if (!cmd) return;
  const rest = body.slice((rawName || '').length).trim(); // everything after the command, keeps new lines

  const reply = (t, extra = {}) => sock.sendMessage(jid, { text: t, ...extra }, { quoted: msg });
  const { botIds, isOwner, groupMetadata, isAdmin, isBotAdmin } = await getRoles(sock, msg, jid, isGroup);

  // Private mode: only the owner can use commands
  if (store.getMode() === 'private' && !isOwner) return;

  if (cmd.groupOnly && !isGroup) return reply('⚠️ This command only works in groups.');
  if (cmd.ownerOnly && !isOwner) return reply('⚠️ Only the bot owner can use this command.');
  if (cmd.adminOnly && !(isAdmin || isOwner)) return reply('⚠️ Only group admins can use this command.');
  if (cmd.botAdminRequired && !isBotAdmin) {
    return reply('⚠️ Please make me a group admin first, then try again.');
  }

  try {
    await cmd.run({
      sock, msg, jid, args, rest, reply, cmdName,
      prefix: config.prefix, config, commandList, botIds,
      isGroup, isAdmin, isOwner, isBotAdmin, groupMetadata,
    });
  } catch (err) {
    console.error(`Error in command ${cmd.name}:`, err);
    await reply('❌ Something went wrong running that command.');
  }
}

module.exports = { handleMessage };
