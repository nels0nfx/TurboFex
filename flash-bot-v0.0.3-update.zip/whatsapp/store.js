// Saves each group's settings and warnings in data/groups.json
const fs = require('fs');
const path = require('path');
const config = require('../config');
const { num } = require('./utils');

const MAX_WARNINGS = Number(config.maxWarnings) || 3;
const DEFAULT_WELCOME = '👋 Welcome @user to *{group}*!\n👥 You are member #{count}.';
const DEFAULT_GOODBYE = '🚪 @user has left *{group}*. Goodbye! 👋';
const ANTILINK_MODES = ['off', 'delete', 'warn', 'kick'];
const BOT_KEY = '__bot';

const dir = path.join(__dirname, '..', 'data');
const file = path.join(dir, 'groups.json');

let db = {};
try {
  db = JSON.parse(fs.readFileSync(file, 'utf8'));
} catch (err) {
  db = {};
}

function save() {
  try {
    fs.mkdirSync(dir, { recursive: true });
    fs.writeFileSync(file, JSON.stringify(db, null, 2));
  } catch (err) {
    console.error('Could not save settings:', err.message);
  }
}

function getGroup(jid) {
  const g = db[jid] || (db[jid] = {});
  if (!ANTILINK_MODES.includes(g.antilinkMode)) g.antilinkMode = g.antilink === true ? 'warn' : 'off';
  delete g.antilink; // old v0.0.2 setting
  if (typeof g.welcome !== 'boolean') g.welcome = false;
  if (typeof g.goodbye !== 'boolean') g.goodbye = false;
  if (typeof g.welcomeText !== 'string') g.welcomeText = null;
  if (typeof g.goodbyeText !== 'string') g.goodbyeText = null;
  if (!Number.isInteger(g.warnLimit)) g.warnLimit = null;
  if (!g.warnings) g.warnings = {};
  return g;
}

function update(jid, fn) {
  const g = getGroup(jid);
  fn(g);
  save();
  return g;
}

// ----- warnings -----
function getLimit(jid) {
  return getGroup(jid).warnLimit || MAX_WARNINGS;
}

function setLimit(jid, n) {
  return update(jid, (g) => {
    g.warnLimit = n;
  });
}

function addWarning(jid, id) {
  const g = getGroup(jid);
  const key = num(id);
  const count = (g.warnings[key]?.count || 0) + 1;
  g.warnings[key] = { jid: id, count };
  save();
  return { count, max: getLimit(jid) };
}

function resetWarnings(jid, id) {
  const g = getGroup(jid);
  delete g.warnings[num(id)];
  save();
}

function getWarnings(jid, id) {
  return getGroup(jid).warnings[num(id)]?.count || 0;
}

function allWarnings(jid) {
  return Object.values(getGroup(jid).warnings).filter((w) => w.count > 0);
}

// ----- bot mode (public / private) -----
function getMode() {
  return db[BOT_KEY]?.mode === 'private' ? 'private' : 'public';
}

function setMode(mode) {
  db[BOT_KEY] = { ...(db[BOT_KEY] || {}), mode };
  save();
}

module.exports = {
  MAX_WARNINGS, DEFAULT_WELCOME, DEFAULT_GOODBYE, ANTILINK_MODES,
  getGroup, update, getLimit, setLimit, addWarning, resetWarnings, getWarnings, allWarnings,
  getMode, setMode,
};
