const store = require('./store');
const { removeMember } = require('./actions');
const { num } = require('./utils');

const LINK_REGEX =
  /(https?:\/\/\S+|www\.\S+|chat\.whatsapp\.com\/\S+|wa\.me\/\S+|t\.me\/\S+|discord\.gg\/\S+)/i;

async function tryRemove(sock, jid, id) {
  try {
    return await removeMember(sock, jid, id);
  } catch (err) {
    return false;
  }
}

// Returns true if the message was a link that we dealt with
async function handleAntiLink(sock, msg, jid, roles) {
  const { isAdmin, isOwner, isBotAdmin } = roles;
  const sender = msg.key.participant;
  if (!sender || isAdmin || isOwner || !isBotAdmin) return false;

  const mode = store.getGroup(jid).antilinkMode;
  if (mode === 'off') return false;

  // Every mode deletes the link
  try {
    await sock.sendMessage(jid, { delete: msg.key });
  } catch (err) {
    console.log('Could not delete message:', err.message);
  }

  const tag = `@${num(sender)}`;
  if (mode === 'delete') return true;

  if (mode === 'kick') {
    const removed = await tryRemove(sock, jid, sender);
    await sock.sendMessage(jid, {
      text: removed
        ? `🚫 ${tag} was removed for sending a link.`
        : `⚠️ ${tag} sent a link but I could not remove them.`,
      mentions: [sender],
    });
    return true;
  }

  // mode === 'warn'
  const { count, max } = store.addWarning(jid, sender);
  if (count >= max) {
    const removed = await tryRemove(sock, jid, sender);
    if (removed) store.resetWarnings(jid, sender);
    await sock.sendMessage(jid, {
      text: removed
        ? `🚫 ${tag} was removed after ${max} warnings (links are not allowed here).`
        : `⚠️ ${tag} reached ${max} warnings but I could not remove them.`,
      mentions: [sender],
    });
  } else {
    await sock.sendMessage(jid, {
      text: `⚠️ ${tag}, links are not allowed here.\nWarning ${count}/${max}`,
      mentions: [sender],
    });
  }
  return true;
}

module.exports = { handleAntiLink, LINK_REGEX };
