const store = require('./store');
const { num } = require('./utils');

// Fills in @user, {group} and {count} in the saved message
function render(template, jid, name, count) {
  return template
    .replace(/@user/gi, () => `@${num(jid)}`)
    .replace(/\{group\}/gi, () => name)
    .replace(/\{count\}/gi, () => String(count ?? ''));
}

// Sends welcome / goodbye messages when people join or leave
async function handleParticipants(sock, update) {
  const { id, participants, action } = update;
  if (action !== 'add' && action !== 'remove') return;

  const g = store.getGroup(id);
  if (action === 'add' && !g.welcome) return;
  if (action === 'remove' && !g.goodbye) return;

  const botIds = [sock.user?.id, sock.user?.lid].filter(Boolean).map(num);
  const ids = (participants || [])
    .map((p) => (typeof p === 'string' ? p : p?.id))
    .filter(Boolean)
    .filter((j) => !botIds.includes(num(j)));
  if (!ids.length) return;

  let meta = null;
  try {
    meta = await sock.groupMetadata(id);
  } catch (err) {
    meta = null;
  }
  const name = meta?.subject || 'the group';
  const count = meta?.participants?.length;

  const template =
    action === 'add'
      ? g.welcomeText || store.DEFAULT_WELCOME
      : g.goodbyeText || store.DEFAULT_GOODBYE;

  for (const j of ids) {
    await sock.sendMessage(id, { text: render(template, j, name, count), mentions: [j] });
  }
}

module.exports = { handleParticipants };
